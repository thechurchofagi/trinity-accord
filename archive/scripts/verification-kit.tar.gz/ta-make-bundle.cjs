#!/usr/bin/env node
'use strict';

/**
 * Build SPV bundle (spv-bundle.json) from Esplora endpoints.
 * Tries block-raw first, falls back to per-tx mode (low concurrency + retries).
 * - Fix: BIP141 coinbase leaf = 32 bytes of 0x00 when computing witness merkle root.
 * - Only target tx rawHex are embedded; others only contribute wtxid/txid leaves.
 *
 * Boundary: non‑amending; BTC Originals prevail. This bundle is for local verification only; NOT authoritative. DO NOT publish.
 */

const https = require('https');
const { URL } = require('url');
const fs = require('fs');
const crypto = require('crypto');
const path = require('path');

// Defaults
const DEFAULT_TXS = {
  protocol: 'e40dfb2aa78cbccca88f749e9ec5cbe3c1df503273d73c72297863ae0d1d8343',
  covenant: '90116f35de075074f5e5d1fbdda69a646a124e2287d7d58e2520317098cd4258',
  accord:   '4d1c8f5ea8e8bae2982b42de6cc79deda3d243a21010a2888546e62ed7192c8c'
};
const DEFAULT_ESPLORA = ['https://mempool.space/api','https://blockstream.info/api'];

// CLI
function args(a){ const o={}; for (let i=2;i<a.length;i++){ const s=a[i]; if(!s.startsWith('--')) continue; let [k,v]=s.split('='); k=k.replace(/^--/,''); if(v===undefined){ const n=a[i+1]; if(n && !n.startsWith('--')){ v=n; i++; } else v='1'; } o[k]=v; } return o; }
const A = args(process.argv);
function csv(s){ return String(s||'').split(/[,\s]+/).map(x=>x.trim()).filter(Boolean); }

const OUT = path.resolve(process.cwd(), A.out || 'spv-bundle.json');
const ESPLORA = csv(A.esplora||'').length ? csv(A.esplora) : DEFAULT_ESPLORA;
const TIMEOUT_MS = parseInt(A.timeoutMs||'120000',10);   // 大请求给足超时
const CONC = Math.max(1, parseInt(A.concurrency||'4',10));

// TX set
function parseTxArg(arg){
  if (!arg) return { ...DEFAULT_TXS };
  const out={};
  for (const pair of csv(arg)){ const [label,txid]=pair.split(':'); if(label&&txid) out[label]=txid; }
  for (const k of ['protocol','covenant','accord']) if (!out[k]) out[k]=DEFAULT_TXS[k];
  return out;
}
const TXS = parseTxArg(A.tx);

// HTTP helpers
function getBinary(urlStr, timeoutMs=TIMEOUT_MS){
  return new Promise((resolve,reject)=>{
    const u = new URL(urlStr);
    const opts = { protocol:u.protocol, hostname:u.hostname, port:u.port||443, path:u.pathname+(u.search||''), method:'GET', timeout:timeoutMs };
    const req = https.request(opts, res=>{
      if (res.statusCode>=300 && res.statusCode<400 && res.headers.location){
        const next = new URL(res.headers.location,u).toString(); res.resume();
        return resolve(getBinary(next, timeoutMs));
      }
      if (res.statusCode!==200){ res.resume(); return reject(new Error(`HTTP ${res.statusCode} ${urlStr}`)); }
      const chunks=[]; res.on('data',d=> chunks.push(Buffer.isBuffer(d)?d:Buffer.from(d)));
      res.on('end', ()=> resolve(Buffer.concat(chunks)));
    });
    req.on('error', reject);
    req.on('timeout', ()=>{ req.destroy(new Error('timeout')); });
    req.end();
  });
}
function getText(urlStr, timeoutMs=TIMEOUT_MS){
  return new Promise((resolve,reject)=>{
    const u = new URL(urlStr);
    const opts = { protocol:u.protocol, hostname:u.hostname, port:u.port||443, path:u.pathname+(u.search||''), method:'GET', timeout:timeoutMs };
    const req = https.request(opts, res=>{
      if (res.statusCode>=300 && res.statusCode<400 && res.headers.location){
        const next = new URL(res.headers.location,u).toString(); res.resume();
        return resolve(getText(next, timeoutMs));
      }
      if (res.statusCode!==200){ res.resume(); return reject(new Error(`HTTP ${res.statusCode} ${urlStr}`)); }
      let data=''; res.setEncoding('utf8'); res.on('data',d=> data+=d); res.on('end', ()=> resolve(data));
    });
    req.on('error', reject);
    req.on('timeout', ()=>{ req.destroy(new Error('timeout')); });
    req.end();
  });
}
async function tryFetchBinary(pathFn){ let last=null; for (const base of ESPLORA){ try{ return await getBinary(base.replace(/\/+$/,'')+pathFn); }catch(e){ last=e; } } throw last||new Error('All endpoints failed '+pathFn); }
async function tryFetchText(pathFn){ let last=null; for (const base of ESPLORA){ try{ return await getText(base.replace(/\/+$/,'')+pathFn); }catch(e){ last=e; } } throw last||new Error('All endpoints failed '+pathFn); }
async function getJSON(pathFn){ return JSON.parse(await tryFetchText(pathFn)); }
async function getHEX(pathFn){ return (await tryFetchText(pathFn)).trim(); }

// Crypto + utils
function sha256(buf){ return crypto.createHash('sha256').update(buf).digest(); }
function sha256d(buf){ return sha256(sha256(buf)); }
function hexToBufLE(hex){ const b=Buffer.from(hex,'hex'); return Buffer.from(b).reverse(); }
function bufLEToHex(b){ return Buffer.from(b).reverse().toString('hex'); }

// VarInt + TX parser (stream and buffer modes)
function readVarInt(buf, off){
  const first = buf[off];
  if (first<0xfd) return { v:first, n:1 };
  if (first===0xfd) return { v:buf.readUInt16LE(off+1), n:3 };
  if (first===0xfe) return { v:buf.readUInt32LE(off+1), n:5 };
  return { v:Number(buf.readBigUInt64LE(off+1)), n:9 };
}
function parseTxBuf(buf, off0=0){
  let off = off0;
  const start = off;
  const version = buf.readInt32LE(off); off+=4;
  let hasWitness=false;
  if (buf[off]===0x00 && buf[off+1]===0x01){ hasWitness=true; off+=2; }

  const vin=[]; let vi=readVarInt(buf,off); off+=vi.n;
  for(let i=0;i<vi.v;i++){
    const txidLE=buf.slice(off,off+32); off+=32;
    const vout=buf.readUInt32LE(off); off+=4;
    const sl=readVarInt(buf,off); off+=sl.n;
    const script=buf.slice(off,off+sl.v); off+=sl.v;
    const seq=buf.readUInt32LE(off); off+=4;
    vin.push({ txidLE, vout, scriptSig:script, sequence:seq });
  }

  const vout=[]; let vo=readVarInt(buf,off); off+=vo.n;
  for(let i=0;i<vo.v;i++){
    const value=buf.readBigUInt64LE(off); off+=8;
    const sl=readVarInt(buf,off); off+=sl.n;
    const spk=buf.slice(off,off+sl.v); off+=sl.v;
    vout.push({ value, scriptPubKey: spk });
  }

  const witness=[];
  if (hasWitness){
    for (let i=0;i<vin.length;i++){
      const wi=readVarInt(buf,off); off+=wi.n;
      const items=[];
      for(let j=0;j<wi.v;j++){
        const wl=readVarInt(buf,off); off+=wl.n;
        const wd=buf.slice(off,off+wl.v); off+=wl.v;
        items.push(wd);
      }
      witness.push(items);
    }
  }
  const locktime=buf.readUInt32LE(off); off+=4;
  const end = off;

  // serialize no-witness
  const parts=[]; const pushVarInt=(n)=>{
    if(n<0xfd){ const b=Buffer.alloc(1); b.writeUInt8(n,0); parts.push(b); return; }
    if(n<=0xffff){ const b=Buffer.alloc(3); b.writeUInt8(0xfd,0); b.writeUInt16LE(n,1); parts.push(b); return; }
    if(n<=0xffffffff){ const b=Buffer.alloc(5); b.writeUInt8(0xfe,0); b.writeUInt32LE(n,1); parts.push(b); return; }
    const b=Buffer.alloc(9); b.writeUInt8(0xff,0); b.writeBigUInt64LE(BigInt(n),1); parts.push(b);
  };
  const ver=Buffer.alloc(4); ver.writeInt32LE(version,0); parts.push(ver);
  pushVarInt(vin.length);
  for(const i of vin){
    parts.push(Buffer.from(i.txidLE));
    const voutB=Buffer.alloc(4); voutB.writeUInt32LE(i.vout,0); parts.push(voutB);
    pushVarInt(i.scriptSig.length); parts.push(i.scriptSig);
    const seqB=Buffer.alloc(4); seqB.writeUInt32LE(i.sequence,0); parts.push(seqB);
  }
  pushVarInt(vout.length);
  for(const o of vout){
    const val=Buffer.alloc(8); val.writeBigUInt64LE(o.value,0); parts.push(val);
    pushVarInt(o.scriptPubKey.length); parts.push(o.scriptPubKey);
  }
  const lock=Buffer.alloc(4); lock.writeUInt32LE(locktime,0); parts.push(lock);
  const rawNoWitness = Buffer.concat(parts);

  return {
    start, end, version, hasWitness,
    vin, vout, witness,
    rawWithWitness: buf.slice(start,end),
    rawNoWitness
  };
}

// Merkle helpers (leaves as LE 32-byte)
function merkleParent(le, re){ return sha256d(Buffer.concat([le,re])); }
function merkleBranch(leavesLE, index){
  const branch=[]; let idx=index;
  let level = leavesLE.map(b=>Buffer.from(b));
  while(level.length>1){
    const next=[];
    for(let i=0;i<level.length;i+=2){
      const left=level[i]; const right=(i+1<level.length)?level[i+1]:level[i];
      const parent = merkleParent(left,right);
      if (i===idx || i+1===idx){
        const sib = (i===idx)? right:left;
        branch.push(bufLEToHex(sib));
        idx = Math.floor(i/2);
      }
      next.push(parent);
    }
    level=next;
  }
  return { branchHex: branch, rootHex: bufLEToHex(level[0]) };
}
function computeRootFromBranch(leafHex, branchHexArr, index){
  let hLE = hexToBufLE(leafHex);
  let idx = index;
  for(const sibHex of branchHexArr){
    const sibLE = hexToBufLE(sibHex);
    const pair = (idx%2===0)? Buffer.concat([hLE, sibLE]) : Buffer.concat([sibLE, hLE]);
    hLE = sha256d(pair); idx>>=1;
  }
  return bufLEToHex(hLE);
}

// BIP141 bits
function getWitnessCommitment32(tx){
  for(const o of tx.vout){
    const spk=o.scriptPubKey; if (!spk || !spk.length) continue;
    for(let i=0;i<spk.length;i++){
      const op=spk[i];
      if (op>=0x01 && op<=0x4b){
        const len=op; i++;
        const data=spk.slice(i,i+len); i+=len-1;
        if (data.length>=36 && data[0]===0xaa && data[1]===0x21 && data[2]===0xa9 && data[3]===0xed){
          return data.slice(4,36);
        }
      } else if (op===0x4c){
        const len=spk[i+1]; i+=2;
        const data=spk.slice(i,i+len); i+=len-1;
        if (data.length>=36 && data[0]===0xaa && data[1]===0x21 && data[2]===0xa9 && data[3]===0xed){
          return data.slice(4,36);
        }
      }
    }
  }
  return null;
}
function getCoinbaseReserved32(tx){
  if (!tx.witness || !tx.witness[0]) return Buffer.alloc(32,0);
  for(const it of tx.witness[0]) if (it.length===32) return it;
  return Buffer.alloc(32,0);
}

// Header parse
function parseHeader(hex){
  const b=Buffer.from(hex,'hex'); if (b.length!==80) throw new Error('header not 80 bytes');
  const mrkl = b.slice(36,68); const hash=sha256d(b);
  return { merkleRootHex: bufLEToHex(mrkl), hashHex: bufLEToHex(hash), bits: b.readUInt32LE(72) };
}

// Esplora helpers
async function getTxMeta(txid){
  const j = await getJSON(`/tx/${txid}`);
  if (!j?.status?.block_hash) throw new Error('tx not confirmed: '+txid);
  return { block_hash:j.status.block_hash, block_height:j.status.block_height };
}
async function getBlockHeaderHex(blockhash){ return await getHEX(`/block/${blockhash}/header`); }
async function getBlockTxids(blockhash){ return await getJSON(`/block/${blockhash}/txids`); }
async function getTxRawHex(txid){ return await getHEX(`/tx/${txid}/hex`); }
async function getBlockRaw(blockhash){ return await tryFetchBinary(`/block/${blockhash}/raw`); }

// Block-raw parse → tx list
function parseBlockRawToTxs(blockRawBuf){
  let off=0;
  const header = blockRawBuf.slice(off, off+80); off+=80;
  const vi = readVarInt(blockRawBuf, off); off+=vi.n;
  const nTx = vi.v;
  const txs = new Array(nTx);
  for(let i=0;i<nTx;i++){
    const tx = parseTxBuf(blockRawBuf, off);
    const raw = tx.rawWithWitness;
    const noWit = tx.rawNoWitness;
    const txid = bufLEToHex(sha256d(noWit));
    const wtxidLE = sha256d(raw);
    txs[i] = { raw, noWit, txid, wtxidLE, parsed: tx };
    off = tx.end;
  }
  return { headerHex: header.toString('hex'), txs };
}

// Per-tx fallback fetcher (low conc + retries)
async function fetchTxRawsWithRetry(txids){
  const raws = new Array(txids.length);
  let done=0; let idx=0;
  async function fetchOne(i){
    const id = txids[i];
    const MAX_TRY=5;
    for (let t=1;t<=MAX_TRY;t++){
      try { raws[i] = await getTxRawHex(id); break; }
      catch(e){
        if (t===MAX_TRY) throw e;
        await new Promise(r=> setTimeout(r, 400*t)); // backoff
      }
    }
    done++; if (done%200===0 || done===txids.length) console.log(`  fetched tx raw: ${done}/${txids.length}`);
  }
  const ws=[];
  for(let k=0;k<CONC;k++){
    ws.push((async()=>{
      while(idx<txids.length){
        const i = idx++; await fetchOne(i);
      }
    })());
  }
  await Promise.all(ws);
  return raws;
}

async function main(){
  console.log('[INFO] Building SPV bundle (online)…');

  // Locate blocks for three Originals
  const targets = [
    { label:'protocol', txid: TXS.protocol.toLowerCase() },
    { label:'covenant', txid: TXS.covenant.toLowerCase() },
    { label:'accord',   txid: TXS.accord.toLowerCase() }
  ];
  const blkMap = new Map();
  for (const t of targets){
    const meta = await getTxMeta(t.txid);
    t.block_hash = meta.block_hash; t.block_height = meta.block_height;
    blkMap.set(meta.block_hash, { height: meta.block_height });
    console.log(`  - ${t.label}: txid=${t.txid} block=${meta.block_height} ${meta.block_hash}`);
  }

  const blocksOut = {};
  const headersOut = [];

  for (const [bh, info] of blkMap.entries()){
    console.log(`\n[BLOCK] ${bh} (height ${info.height})`);

    // Try block-raw first
    let headerHex, txRecords;
    try{
      const raw = await getBlockRaw(bh);
      const parsed = parseBlockRawToTxs(raw);
      headerHex = parsed.headerHex;
      txRecords = parsed.txs;
    }catch(e){
      console.warn('  [WARN] block-raw failed, fallback per-tx:', e.message||String(e));
      // fallback: header + txids + per-tx raw
      headerHex = await getBlockHeaderHex(bh);
      const txids = await getBlockTxids(bh);
      console.log(`  tx count: ${txids.length}`);
      const raws = await fetchTxRawsWithRetry(txids);
      txRecords = txids.map((id, i)=>{
        const raw = Buffer.from(raws[i], 'hex');
        const tx = parseTxBuf(raw, 0); // parse from self buffer
        const noWit = tx.rawNoWitness;
        const txid = bufLEToHex(sha256d(noWit));
        const wtxidLE = sha256d(raw);
        return { raw, noWit, txid, wtxidLE, parsed: tx };
      });
    }

    // Header record
    headersOut.push({ height: info.height, hash: bh, headerHex });
    const headerParsed = parseHeader(headerHex);

    // Build txid list & wtxid leaves (coinbase special)
    const n = txRecords.length;
    const txidsOrdered = txRecords.map(r=> r.txid);
    const txidLeavesLE = txRecords.map(r=> hexToBufLE(r.txid));
    const wLeavesLE = new Array(n);
    wLeavesLE[0] = Buffer.alloc(32, 0); // BIP141 coinbase leaf = zero
    for (let i=1;i<n;i++) wLeavesLE[i] = txRecords[i].wtxidLE;

    // Coinbase proofs
    const cbBranch = merkleBranch(txidLeavesLE, 0);
    const mrklCalc = computeRootFromBranch(txidsOrdered[0], cbBranch.branchHex, 0);
    if (mrklCalc !== headerParsed.merkleRootHex) throw new Error('header.merkleRoot mismatch via coinbase branch');

    const coinbase = txRecords[0].parsed;
    const coinbaseTxidHex = txRecords[0].txid;
    const coinbaseRawHex = txRecords[0].raw.toString('hex');
    const reserved = getCoinbaseReserved32(coinbase);
    const commitment = getWitnessCommitment32(coinbase);
    if (!commitment) throw new Error('No BIP141 witness commitment in coinbase');
    const wRoot = merkleBranch(wLeavesLE, 0).rootHex;
    const commitCalc = sha256d(Buffer.concat([hexToBufLE(wRoot), reserved]));
    if (commitCalc.toString('hex') !== Buffer.from(commitment).toString('hex')){
      throw new Error('Witness commitment mismatch: coinbase commitment does not match computed witness root');
    }

    // Block record init
    const blkOut = {
      height: info.height,
      headerHex,
      coinbase: {
        rawHex: coinbaseRawHex,
        txid: coinbaseTxidHex,
        txidBranch: cbBranch.branchHex,
        witnessReservedValueHex: reserved.toString('hex'),
        witnessCommitmentHex: Buffer.from(commitment).toString('hex')
      },
      witnessMerkleRoot: wRoot,
      txs: {}
    };

    // Add target tx proofs (only embed target rawHex)
    const labelByTxid = new Map(targets.filter(t=>t.block_hash===bh).map(t=>[t.txid, t.label]));
    for (let i=0;i<n;i++){
      const id = txidsOrdered[i];
      const label = labelByTxid.get(id);
      if (!label) continue;
      const rawHex = txRecords[i].raw.toString('hex');
      const wtxid = bufLEToHex(txRecords[i].wtxidLE);
      const wBranch = merkleBranch(wLeavesLE, i);
      const rootCheck = computeRootFromBranch(wtxid, wBranch.branchHex, i);
      if (rootCheck !== wRoot) throw new Error('Witness branch root mismatch for '+id);
      blkOut.txs[id] = { rawHex, index:i, wtxid, witnessBranch: wBranch.branchHex };
      console.log(`  + proof for ${label}: index=${i}`);
    }

    blocksOut[bh] = blkOut;
  }

  const bundle = {
    meta: { version:'v3', generatedAt: new Date().toISOString(), esplora: ESPLORA },
    headers: headersOut,
    blocks: blocksOut
  };
  fs.writeFileSync(OUT, JSON.stringify(bundle, null, 2));
  console.log('\n[OK] spv-bundle written:', OUT);
  console.log('Note: Contains raw witness (targets). For local verification only. DO NOT publish.');
}

main().catch(e=>{ console.error('[ERROR]', e.message||String(e)); process.exit(1); });