#!/usr/bin/env node
'use strict';

/**
 * Trinity Accord — Unified Verifier (Online/Offline)
 * - Online: build spv-bundle.json from Esplora, then offline verify
 * - Offline: use local spv-bundle.json to SPV-verify & extract digests
 * - Optional: verify ETH mirrors' input bytes equal BTC bodies (len/sha256) and sender is guardian
 *
 * Boundary 1/2: non‑amending; BTC Originals prevail. This program is for verification only; NOT authoritative.
 * Boundary 2/2: ETH is the only mirror layer; AR is for indexing/forensics only. Raw witness & body files are for local verification; NOT authoritative.
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const crypto = require('crypto');

// ---------- CLI ----------
function args(a){ const o={}; for(let i=2;i<a.length;i++){ let s=a[i]; if(!s.startsWith('--')) continue; let[k,v]=s.split('='); k=k.replace(/^--/,''); if(v===undefined){ const n=a[i+1]; if(n&&!n.startsWith('--')){ v=n; i++; } else v='1'; } o[k]=v; } return o; }
const A = args(process.argv);
function csv(s){ return String(s||'').split(/[,\s]+/).map(x=>x.trim()).filter(Boolean); }
function bflag(k, def=false){ const v=A[k]; if(v===undefined) return def; return ['1','true','yes'].includes(String(v).toLowerCase()); }

// Inputs & options
const CWD = process.cwd();
const OUTDIR = path.resolve(CWD, A.outdir || '.');
const ONLINE = bflag('online', false);
const BUNDLE = path.resolve(CWD, A.bundle || './spv-bundle.json');
const WRITE_BODIES = bflag('write-bodies', false);
const ESPLORA = csv(A.esplora||'');
const TIMEOUT_MS = parseInt(A.timeoutMs||'120000',10);
const CONC = Math.max(1, parseInt(A.concurrency||'4',10));
const CHECK_POW = bflag('check-pow', false);

const OWNER_ADDRS = csv(A['owner-addrs']||'').map(s=>s.toLowerCase());
const ETH_RPC_URLS = csv(A['eth-rpc']||''); // optional online ETH step

// ---------- Constants ----------
const DEFAULT_TXS = {
  protocol: 'e40dfb2aa78cbccca88f749e9ec5cbe3c1df503273d73c72297863ae0d1d8343',
  covenant: '90116f35de075074f5e5d1fbdda69a646a124e2287d7d58e2520317098cd4258',
  accord:   '4d1c8f5ea8e8bae2982b42de6cc79deda3d243a21010a2888546e62ed7192c8c'
};
const DEFAULT_ETH_TXS = {
  protocol: '0x6652162e8e6c56ddc0d9476407b3b911e918d4e4683408440dc3af51c5bb63d5',
  covenant: '0x9c1bd6e21dc2370e8dbb6549b7ba13b4ea7ba7a192b3b876e0ec28b4633f1612',
  accord:   '0x0affc8099ea965cd6d6a0d1cf9b93adb11f7e40ac41fffe1b0ca4637f39df665'
};
const DEFAULT_ESPLORA = ['https://mempool.space/api', 'https://blockstream.info/api'];

function parseMapArg(arg, def){ if(!arg) return { ...def }; const out={}; for(const p of csv(arg)){ const [k,v]=p.split(':'); if(k&&v) out[k]=v; } for(const k of Object.keys(def)) if(!out[k]) out[k]=def[k]; return out; }
const BTC_TXS = parseMapArg(A.tx, DEFAULT_TXS);
const ETH_TXS = parseMapArg(A['eth-txs'], DEFAULT_ETH_TXS);
const ESPLORA_URLS = ESPLORA.length ? ESPLORA : DEFAULT_ESPLORA;

// ---------- Utils ----------
function sha256(buf){ return crypto.createHash('sha256').update(buf).digest(); }
function sha256hex(buf){ return crypto.createHash('sha256').update(buf).digest('hex'); }
function sha256d(buf){ return sha256(sha256(buf)); }
function hexToBuf(hex){ return Buffer.from(hex.trim(),'hex'); }
function hexToBufLE(hex){ const b=Buffer.from(hex,'hex'); return Buffer.from(b).reverse(); }
function bufLEToHex(b){ return Buffer.from(b).reverse().toString('hex'); }

// ---------- HTTP (no deps) ----------
function getBinary(urlStr, timeoutMs=TIMEOUT_MS){
  return new Promise((resolve,reject)=>{
    const u=new URL(urlStr);
    const opts={protocol:u.protocol,hostname:u.hostname,port:u.port||443,path:u.pathname+(u.search||''),method:'GET',timeout:timeoutMs};
    const req=https.request(opts,res=>{
      if(res.statusCode>=300 && res.statusCode<400 && res.headers.location){
        const next=new URL(res.headers.location,u).toString(); res.resume(); return resolve(getBinary(next,timeoutMs));
      }
      if(res.statusCode!==200){ res.resume(); return reject(new Error(`HTTP ${res.statusCode} ${urlStr}`)); }
      const chunks=[]; res.on('data',d=> chunks.push(Buffer.isBuffer(d)?d:Buffer.from(d)));
      res.on('end',()=> resolve(Buffer.concat(chunks)));
    });
    req.on('error',reject); req.on('timeout',()=>{req.destroy(new Error('timeout'));}); req.end();
  });
}
function getText(urlStr, timeoutMs=TIMEOUT_MS){
  return new Promise((resolve,reject)=>{
    const u=new URL(urlStr);
    const opts={protocol:u.protocol,hostname:u.hostname,port:u.port||443,path:u.pathname+(u.search||''),method:'GET',timeout:timeoutMs};
    const req=https.request(opts,res=>{
      if(res.statusCode>=300 && res.statusCode<400 && res.headers.location){
        const next=new URL(res.headers.location,u).toString(); res.resume(); return resolve(getText(next,timeoutMs));
      }
      if(res.statusCode!==200){ res.resume(); return reject(new Error(`HTTP ${res.statusCode} ${urlStr}`)); }
      let data=''; res.setEncoding('utf8'); res.on('data',d=> data+=d); res.on('end',()=> resolve(data));
    });
    req.on('error',reject); req.on('timeout',()=>{req.destroy(new Error('timeout'));}); req.end();
  });
}
async function tryFetchText(pathFn){ let last=null; for(const base of ESPLORA_URLS){ try{ return await getText(base.replace(/\/+$/,'')+pathFn); }catch(e){ last=e; } } throw last||new Error('All Esplora endpoints failed: '+pathFn); }
async function tryFetchBinary(pathFn){ let last=null; for(const base of ESPLORA_URLS){ try{ return await getBinary(base.replace(/\/+$/,'')+pathFn); }catch(e){ last=e; } } throw last||new Error('All Esplora endpoints failed: '+pathFn); }
async function getJSON(pathFn){ return JSON.parse(await tryFetchText(pathFn)); }
async function getHEX(pathFn){ return (await tryFetchText(pathFn)).trim(); }

// ---------- Bitcoin parse ----------
function readVarInt(buf, off){ const first=buf[off]; if(first<0xfd) return {v:first,n:1}; if(first===0xfd) return {v:buf.readUInt16LE(off+1),n:3}; if(first===0xfe) return {v:buf.readUInt32LE(off+1),n:5}; return {v:Number(buf.readBigUInt64LE(off+1)),n:9}; }
function parseTx(buf, off0=0){
  let off=off0; const start=off; const version=buf.readInt32LE(off); off+=4;
  let hasWitness=false; if (buf[off]===0x00 && buf[off+1]===0x01){ hasWitness=true; off+=2; }
  const vin=[]; let vi=readVarInt(buf,off); off+=vi.n;
  for(let i=0;i<vi.v;i++){ const txidLE=buf.slice(off,off+32); off+=32; const vout=buf.readUInt32LE(off); off+=4; const sl=readVarInt(buf,off); off+=sl.n; const script=buf.slice(off,off+sl.v); off+=sl.v; const seq=buf.readUInt32LE(off); off+=4; vin.push({txidLE,vout,scriptSig:script,sequence:seq}); }
  const vout=[]; let vo=readVarInt(buf,off); off+=vo.n;
  for(let i=0;i<vo.v;i++){ const value=buf.readBigUInt64LE(off); off+=8; const sl=readVarInt(buf,off); off+=sl.n; const spk=buf.slice(off,off+sl.v); off+=sl.v; vout.push({value,scriptPubKey:spk}); }
  const witness=[]; if(hasWitness){ for(let i=0;i<vin.length;i++){ const wi=readVarInt(buf,off); off+=wi.n; const items=[]; for(let j=0;j<wi.v;j++){ const wl=readVarInt(buf,off); off+=wl.n; const wd=buf.slice(off,off+wl.v); off+=wl.v; items.push(wd); } witness.push(items); } }
  const locktime=buf.readUInt32LE(off); off+=4; const end=off;
  // serialize no-witness
  const parts=[]; const pushVarInt=(n)=>{ if(n<0xfd){ const b=Buffer.alloc(1); b.writeUInt8(n,0); parts.push(b); return; } if(n<=0xffff){ const b=Buffer.alloc(3); b.writeUInt8(0xfd,0); b.writeUInt16LE(n,1); parts.push(b); return; } if(n<=0xffffffff){ const b=Buffer.alloc(5); b.writeUInt8(0xfe,0); b.writeUInt32LE(n,1); parts.push(b); return; } const b=Buffer.alloc(9); b.writeUInt8(0xff,0); b.writeBigUInt64LE(BigInt(n),1); parts.push(b); };
  const ver=Buffer.alloc(4); ver.writeInt32LE(version,0); parts.push(ver);
  pushVarInt(vin.length);
  for(const i of vin){ parts.push(Buffer.from(i.txidLE)); const voutB=Buffer.alloc(4); voutB.writeUInt32LE(i.vout,0); parts.push(voutB); pushVarInt(i.scriptSig.length); parts.push(i.scriptSig); const seqB=Buffer.alloc(4); seqB.writeUInt32LE(i.sequence,0); parts.push(seqB); }
  pushVarInt(vout.length);
  for(const o of vout){ const val=Buffer.alloc(8); val.writeBigUInt64LE(o.value,0); parts.push(val); pushVarInt(o.scriptPubKey.length); parts.push(o.scriptPubKey); }
  const lock=Buffer.alloc(4); lock.writeUInt32LE(locktime,0); parts.push(lock);
  const rawNoWitness = Buffer.concat(parts);

  return { start,end,version,hasWitness,vin,vout,witness, rawWithWitness:buf.slice(start,end), rawNoWitness };
}
function parseHeader(hex){ const b=Buffer.from(hex,'hex'); if(b.length!==80) throw new Error('header not 80 bytes'); const ver=b.readInt32LE(0); const prev=b.slice(4,36); const mrkl=b.slice(36,68); const time=b.readUInt32LE(68); const bits=b.readUInt32LE(72); const nonce=b.readUInt32LE(76); const hash=sha256d(b); return { version:ver, prevHashHex:bufLEToHex(prev), merkleRootHex:bufLEToHex(mrkl), time,bits,nonce, hashHex:bufLEToHex(hash) }; }
function bitsToTarget(nbits){ const n=BigInt(nbits>>>24); const mant=BigInt(nbits & 0x007fffff); if(n<=3n){ const shift=8n*(3n-n); return mant>>shift; } else { const shift=8n*(n-3n); return mant<<shift; } }
function hexToBigIntBE(hex){ return BigInt('0x'+hex); }

// Merkle
function merkleParent(le,re){ return sha256d(Buffer.concat([le,re])); }
function merkleBranch(leavesLE, index){ const branch=[]; let idx=index; let level=leavesLE.map(b=>Buffer.from(b)); while(level.length>1){ const next=[]; for(let i=0;i<level.length;i+=2){ const left=level[i]; const right=(i+1<level.length)?level[i+1]:level[i]; const parent=merkleParent(left,right); if (i===idx || i+1===idx){ const sib=(i===idx)? right:left; branch.push(bufLEToHex(sib)); idx=Math.floor(i/2); } next.push(parent); } level=next; } return { branchHex:branch, rootHex:bufLEToHex(level[0]) }; }
function computeRootFromBranch(leafHex, branchHexArr, index){ let hLE=hexToBufLE(leafHex); let idx=index; for(const sibHex of branchHexArr){ const sibLE=hexToBufLE(sibHex); const pair=(idx%2===0)? Buffer.concat([hLE,sibLE]) : Buffer.concat([sibLE,hLE]); hLE=sha256d(pair); idx>>=1; } return bufLEToHex(hLE); }

// BIP141 helpers
function getWitnessCommitment32(tx){
  for(const o of tx.vout){
    const spk=o.scriptPubKey; if(!spk || !spk.length) continue;
    for(let i=0;i<spk.length;i++){
      const op=spk[i];
      if(op>=0x01 && op<=0x4b){
        const len=op; i++;
        const data=spk.slice(i,i+len); i+=len-1;
        if(data.length>=36 && data[0]===0xaa && data[1]===0x21 && data[2]===0xa9 && data[3]===0xed){ return data.slice(4,36); }
      }else if(op===0x4c){
        const len=spk[i+1]; i+=2;
        const data=spk.slice(i,i+len); i+=len-1;
        if(data.length>=36 && data[0]===0xaa && data[1]===0x21 && data[2]===0xa9 && data[3]===0xed){ return data.slice(4,36); }
      }
    }
  }
  return null;
}
function getCoinbaseReserved32(tx){ if(!tx.witness || !tx.witness[0]) return Buffer.alloc(32,0); for(const it of tx.witness[0]) if(it.length===32) return it; return Buffer.alloc(32,0); }

// ---------- Ordinals extraction ----------
function parseScriptOps(script){
  const ops=[]; let i=0;
  while(i<script.length){
    const op=script[i++];
    if (op>=0x01 && op<=0x4b){ const len=op; if(i+len>script.length) throw new Error('PUSHDATA short'); ops.push({op,data:script.slice(i,i+len)}); i+=len; }
    else if (op===0x4c){ const len=script[i++]; if(i+len>script.length) throw new Error('PUSHDATA1 short'); ops.push({op,data:script.slice(i,i+len)}); i+=len; }
    else if (op===0x4d){ const len=script.readUInt16LE(i); i+=2; if(i+len>script.length) throw new Error('PUSHDATA2 short'); ops.push({op,data:script.slice(i,i+len)}); i+=len; }
    else if (op===0x4e){ const len=script.readUInt32LE(i); i+=4; if(i+len>script.length) throw new Error('PUSHDATA4 short'); ops.push({op,data:script.slice(i,i+len)}); i+=len; }
    else { ops.push({op}); }
  }
  return ops;
}
const OP_0=0x00, OP_IF=0x63, OP_ELSE=0x67, OP_ENDIF=0x68;
function extractOrdEnvelopesFromScript(script){
  const ops=parseScriptOps(script); const out=[]; const ORD=Buffer.from('ord','ascii');
  for(let i=0;i<ops.length;i++){
    if(ops[i].op===OP_0 && ops[i+1] && ops[i+1].op===OP_IF){
      let j=i+2, depth=1;
      if(!(ops[j] && ops[j].data && ops[j].data.equals(ORD))) continue; j++;
      let version=null, contentType=null, bodyStarted=false; const chunks=[];
      while(j<ops.length && depth>0){
        const ins=ops[j];
        if(ins.op===OP_IF){ depth++; }
        else if(ins.op===OP_ENDIF){ depth--; if(depth===0) break; }
        else if(ins.op===OP_ELSE){ /* depth unchanged */ }
        else{
          if(!bodyStarted){
            if(ins.op===OP_0){ bodyStarted=true; }
            else if(ins.data){ if(version===null && ins.data.length<=2) version=Buffer.from(ins.data); else if(contentType===null) contentType=Buffer.from(ins.data); }
          }else{
            if(ins.data) chunks.push(Buffer.from(ins.data)); else if(ins.op===OP_0) chunks.push(Buffer.alloc(0));
          }
        }
        j++;
      }
      if(chunks.length){ out.push({ contentType: contentType?contentType.toString('utf8'):'application/octet-stream', body: Buffer.concat(chunks) }); }
      i=j;
    }
  }
  return out;
}

// ---------- Esplora helpers ----------
async function getTxMeta(txid){ const j=await getJSON(`/tx/${txid}`); if(!j?.status?.block_hash) throw new Error('tx not confirmed: '+txid); return { block_hash:j.status.block_hash, block_height:j.status.block_height }; }
async function getBlockHeaderHex(blockhash){ return await getHEX(`/block/${blockhash}/header`); }
async function getBlockTxids(blockhash){ return await getJSON(`/block/${blockhash}/txids`); }
async function getTxRawHex(txid){ return await getHEX(`/tx/${txid}/hex`); }
async function getBlockRaw(blockhash){ return await tryFetchBinary(`/block/${blockhash}/raw`); }

// Parse /block/:hash/raw
function parseBlockRawToTxs(blockRawBuf){
  let off=0; const header=blockRawBuf.slice(off,off+80); off+=80;
  const vi=readVarInt(blockRawBuf,off); off+=vi.n; const nTx=vi.v;
  const txs=new Array(nTx);
  for(let i=0;i<nTx;i++){
    const tx=parseTx(blockRawBuf, off);
    const raw=tx.rawWithWitness; const noWit=tx.rawNoWitness;
    const txid=bufLEToHex(sha256d(noWit)); const wtxidLE=sha256d(raw);
    txs[i]={ raw, noWit, txid, wtxidLE, parsed:tx }; off=tx.end;
  }
  return { headerHex: header.toString('hex'), txs };
}
async function fetchTxRawsWithRetry(txids){
  const raws=new Array(txids.length); let done=0; let idx=0;
  async function fetchOne(i){
    const id=txids[i]; const MAX=5;
    for(let t=1;t<=MAX;t++){ try{ raws[i]=await getTxRawHex(id); break; } catch(e){ if(t===MAX) throw e; await new Promise(r=>setTimeout(r, 400*t)); } }
    done++; if(done%200===0 || done===txids.length) console.log(`  fetched tx raw: ${done}/${txids.length}`);
  }
  const ws=[]; for(let k=0;k<CONC;k++){ ws.push((async()=>{ while(idx<txids.length){ const i=idx++; await fetchOne(i);} })()); }
  await Promise.all(ws); return raws;
}

// ---------- Online builder ----------
async function buildBundleOnline(){
  console.log('[INFO] Building SPV bundle (online)…');
  const targets = [
    { label:'protocol', txid: BTC_TXS.protocol.toLowerCase() },
    { label:'covenant', txid: BTC_TXS.covenant.toLowerCase() },
    { label:'accord',   txid: BTC_TXS.accord.toLowerCase() }
  ];
  const blkMap=new Map();
  for(const t of targets){
    const meta=await getTxMeta(t.txid); t.block_hash=meta.block_hash; t.block_height=meta.block_height; blkMap.set(meta.block_hash,{height:meta.block_height});
    console.log(`  - ${t.label}: txid=${t.txid} block=${meta.block_height} ${meta.block_hash}`);
  }
  const blocksOut={}; const headersOut=[];
  for(const [bh,info] of blkMap.entries()){
    console.log(`\n[BLOCK] ${bh} (height ${info.height})`);
    let headerHex, txRecords;
    try{ const raw=await getBlockRaw(bh); const parsed=parseBlockRawToTxs(raw); headerHex=parsed.headerHex; txRecords=parsed.txs; }
    catch(e){
      console.warn('  [WARN] block-raw failed, fallback per-tx:', e.message||String(e));
      headerHex=await getBlockHeaderHex(bh); const txids=await getBlockTxids(bh); console.log(`  tx count: ${txids.length}`);
      const raws=await fetchTxRawsWithRetry(txids);
      txRecords=txids.map((id,i)=>{ const raw=Buffer.from(raws[i],'hex'); const tx=parseTx(raw,0); const noWit=tx.rawNoWitness; const txid=bufLEToHex(sha256d(noWit)); const wtxidLE=sha256d(raw); return { raw,noWit,txid,wtxidLE,parsed:tx }; });
    }
    headersOut.push({ height:info.height, hash:bh, headerHex });
    const headerParsed=parseHeader(headerHex);
    const n=txRecords.length;
    const txidsOrdered=txRecords.map(r=> r.txid);
    const txidLeavesLE=txRecords.map(r=> hexToBufLE(r.txid));
    const wLeavesLE=new Array(n); wLeavesLE[0]=Buffer.alloc(32,0); for(let i=1;i<n;i++) wLeavesLE[i]=txRecords[i].wtxidLE;

    // coinbase branch -> header.merkleRoot
    const cbBranch=merkleBranch(txidLeavesLE,0);
    const mrklCalc=computeRootFromBranch(txidsOrdered[0], cbBranch.branchHex, 0);
    if(mrklCalc !== headerParsed.merkleRootHex) throw new Error('header.merkleRoot mismatch via coinbase branch');

    // witness commitment
    const coinbase=txRecords[0].parsed;
    const reserved=getCoinbaseReserved32(coinbase);
    const commitment=getWitnessCommitment32(coinbase);
    if(!commitment) throw new Error('No BIP141 witness commitment in coinbase');
    const wRoot=merkleBranch(wLeavesLE,0).rootHex;
    const commitCalc=sha256d(Buffer.concat([hexToBufLE(wRoot), reserved]));
    if(commitCalc.toString('hex') !== Buffer.from(commitment).toString('hex')) throw new Error('Witness commitment mismatch: coinbase commitment does not match computed witness root');

    const blkOut = {
      height:info.height,
      headerHex,
      coinbase:{
        rawHex: txRecords[0].raw.toString('hex'),
        txid: txRecords[0].txid,
        txidBranch: cbBranch.branchHex,
        witnessReservedValueHex: reserved.toString('hex'),
        witnessCommitmentHex: Buffer.from(commitment).toString('hex')
      },
      witnessMerkleRoot: wRoot,
      txs: {}
    };

    const labelByTxid=new Map(targets.filter(x=>x.block_hash===bh).map(x=>[x.txid,x.label]));
    for(let i=0;i<n;i++){
      const id=txidsOrdered[i]; const label=labelByTxid.get(id); if(!label) continue;
      const rawHex=txRecords[i].raw.toString('hex'); const wtxid=bufLEToHex(txRecords[i].wtxidLE);
      const wBranch=merkleBranch(wLeavesLE, i); const rootCheck=computeRootFromBranch(wtxid, wBranch.branchHex, i);
      if(rootCheck !== wRoot) throw new Error('Witness branch root mismatch for '+id);
      blkOut.txs[id]={ rawHex, index:i, wtxid, witnessBranch: wBranch.branchHex };
      console.log(`  + proof for ${label}: index=${i}`);
    }
    blocksOut[bh]=blkOut;
  }
  const bundle={ meta:{ version:'v3', generatedAt:new Date().toISOString(), esplora: ESPLORA_URLS }, headers: headersOut, blocks: blocksOut };
  fs.writeFileSync(BUNDLE, JSON.stringify(bundle,null,2));
  console.log('\n[OK] spv-bundle written:', BUNDLE);
  console.log('Note: Contains target raw witness. For local verification only. NOT authoritative.');
}

// ---------- SPV verify (offline) ----------
function verifyBundleSPV(bundle){
  const blocks=bundle.blocks||{}; const headers=bundle.headers||[];
  // optional header PoW check (if headers provided)
  if (CHECK_POW && headers.length){
    for(const h of headers){ const p=parseHeader(h.headerHex); const target=bitsToTarget(p.bits); const hVal=hexToBigIntBE(p.hashHex); if(hVal>target) throw new Error(`Header PoW invalid at height ${h.height}`); }
  }
  let txCount=0;
  for(const [bh, blk] of Object.entries(blocks)){
    const header=parseHeader(blk.headerHex);
    // coinbase txid -> header.merkleRoot
    const coinbase=parseTx(hexToBuf(blk.coinbase.rawHex),0);
    const coinbaseTxidHex=bufLEToHex(sha256d(coinbase.rawNoWitness));
    if (coinbaseTxidHex !== (blk.coinbase.txid||'').toLowerCase()) throw new Error(`Coinbase txid mismatch for ${bh}`);
    const mrCalc=computeRootFromBranch(coinbaseTxidHex, blk.coinbase.txidBranch||[], 0);
    if (mrCalc !== header.merkleRootHex) throw new Error(`Header.merkleRoot mismatch via coinbase branch for ${bh}`);

    const reserved = hexToBuf(blk.coinbase.witnessReservedValueHex || ''); // prefer bundle value if present; else parse (above)
    const commitment = hexToBuf(blk.coinbase.witnessCommitmentHex || '');
    for(const [txid, proof] of Object.entries(blk.txs||{})){
      const raw=hexToBuf(proof.rawHex); const wtxidHex=bufLEToHex(sha256d(raw));
      if (wtxidHex !== proof.wtxid.toLowerCase()) throw new Error(`wtxid mismatch for tx ${txid} in ${bh}`);
      const witRoot=computeRootFromBranch(wtxidHex, proof.witnessBranch||[], proof.index);
      if (witRoot !== (blk.witnessMerkleRoot||'').toLowerCase()) throw new Error(`Witness merkle root mismatch for tx ${txid} in ${bh}`);
      const commitCalc=sha256d(Buffer.concat([hexToBufLE(witRoot), reserved]));
      if (commitCalc.toString('hex') !== commitment.toString('hex')) throw new Error(`Witness commitment mismatch for tx ${txid} in ${bh}`);
      txCount++;
    }
  }
  return { blocks: Object.keys(blocks).length, txs: txCount };
}

// ---------- Manifest build (no body write unless asked) ----------
function buildManifestFromBundle(bundle){
  const items=[]; const blocks=bundle.blocks||{};
  for(const [bh, blk] of Object.entries(blocks)){
    for(const [txid, t] of Object.entries(blk.txs||{})){
      const tx=parseTx(hexToBuf(t.rawHex),0);
      for(let vinIndex=0; vinIndex<tx.witness.length; vinIndex++){
        const w=tx.witness[vinIndex]; if(!w || w.length<2) continue;
        const script = w[w.length-2]; if(!script || !script.length) continue;
        let envs=[]; try{ envs=extractOrdEnvelopesFromScript(script);}catch{}
        for(let k=0;k<envs.length;k++){
          const {contentType, body} = envs[k];
          const sha = sha256hex(body);
          const entry = { txid: txid.toLowerCase(), vin: vinIndex, idx: k, contentType, byteLength: body.length, sha256: sha };
          if (WRITE_BODIES){
            const friendly = txid.toLowerCase();
            const base = (friendly===DEFAULT_TXS.protocol)?'protocol' : (friendly===DEFAULT_TXS.covenant)?'covenant' : (friendly===DEFAULT_TXS.accord)?'accord' : friendly.slice(0,16);
            const fn = `inscription-${base}-vin${vinIndex}-idx${k}.txt`;
            fs.writeFileSync(path.join(OUTDIR, fn), body);
            entry.file = fn;
          }
          items.push(entry);
        }
      }
    }
  }
  const out = { createdAt: new Date().toISOString(), items };
  fs.writeFileSync(path.join(OUTDIR,'inscriptions-manifest.json'), JSON.stringify(out,null,2));
  return out;
}

// ---------- ETH RPC ----------
function hexToBufFromHexString(hex){ const h = hex.startsWith('0x')? hex.slice(2):hex; return Buffer.from(h,'hex'); }
function httpsPostJson(url, payload){
  return new Promise((resolve,reject)=>{
    const u=new URL(url);
    const opts={protocol:u.protocol,hostname:u.hostname,port:u.port||443,path:u.pathname+(u.search||''),method:'POST',headers:{'content-type':'application/json'},timeout:20000};
    const req=https.request(opts,res=>{
      let data=''; res.setEncoding('utf8'); res.on('data',d=> data+=d); res.on('end',()=>{ try{ const j=JSON.parse(data); if(j.error) return reject(new Error(j.error.message||'RPC error')); resolve(j.result); }catch(e){ reject(new Error('Bad JSON from RPC')); }});
    });
    req.on('error',reject); req.on('timeout',()=>{ req.destroy(new Error('RPC timeout')); }); req.write(JSON.stringify(payload)); req.end();
  });
}
async function tryEth(method, params){ let last=null; for(const url of ETH_RPC_URLS){ try{ return await httpsPostJson(url,{jsonrpc:'2.0',id:Date.now(),method,params}); }catch(e){ last=e; } } throw last||new Error('All ETH RPC failed'); }
async function verifyEthMirrors(manifest){
  if (!ETH_RPC_URLS.length){ return { skipped:true, reason:'No ETH RPC specified' }; }
  if (!OWNER_ADDRS.length){ return { skipped:true, reason:'No owner-addrs specified' }; }
  const mapItemsByTxid = new Map(); for(const it of (manifest.items||[])) mapItemsByTxid.set(String(it.txid).toLowerCase(), it);
  const tasks = [
    { label:'protocol', eth:ETH_TXS.protocol, btc:DEFAULT_TXS.protocol },
    { label:'covenant', eth:ETH_TXS.covenant, btc:DEFAULT_TXS.covenant },
    { label:'accord',   eth:ETH_TXS.accord,   btc:DEFAULT_TXS.accord }
  ];
  const res=[]; let fail=0;
  for(const t of tasks){
    const it = mapItemsByTxid.get(t.btc.toLowerCase());
    if (!it){ res.push({label:t.label, status:'MISSING in manifest'}); fail++; continue; }
    const tx = await tryEth('eth_getTransactionByHash', [t.eth]);
    if (!tx){ res.push({label:t.label, status:'ETH tx not found'}); fail++; continue; }
    const from=(tx.from||'').toLowerCase(); const inputHex=tx.input||'0x'; const inputBytes=hexToBufFromHexString(inputHex);
    const ethSha=sha256hex(inputBytes); const ethLen=inputBytes.length;
    const okFrom = OWNER_ADDRS.includes(from);
    const okSha = (ethSha.toLowerCase()===String(it.sha256).toLowerCase());
    const okLen = (ethLen===Number(it.byteLength));
    res.push({ label:t.label, from:tx.from, okFrom, ethLen, ethSha, btcLen:it.byteLength, btcSha:it.sha256, okSha, okLen, status: (okFrom&&okSha&&okLen)?'PASS':'FAIL' });
    if(!(okFrom&&okSha&&okLen)) fail++;
  }
  return { results:res, fail };
}

// ---------- Run ----------
(async()=>{
  console.log('— Boundary 1/2 — This verification program is Non‑Amending; BTC Originals prevail. It is NOT authoritative.');
  console.log('— Boundary 2/2 — ETH is the only mirror layer; AR is indexing/forensics only. Raw witness & bodies are for local verification.');

  // Online build if requested or bundle missing
  const needBuild = ONLINE || !fs.existsSync(BUNDLE);
  if (needBuild){ await buildBundleOnline(); }

  // Load bundle
  const bundle = JSON.parse(fs.readFileSync(BUNDLE,'utf8'));

  // SPV verify
  console.log('\n▶ SPV: verifying bundle against headers/commitments…');
  const spv = verifyBundleSPV(bundle);
  console.log(`✓ SPV OK — Blocks: ${spv.blocks}, Target proofs: ${spv.txs}`);

  // Manifest (digests only; write bodies only if requested)
  fs.mkdirSync(OUTDIR, { recursive:true });
  console.log(`\n▶ Extracting inscriptions → digests (writeBodies=${WRITE_BODIES?'YES':'NO'})…`);
  const manifest = buildManifestFromBundle(bundle);
  console.log(`✓ Manifest OK — items: ${manifest.items.length} → ${path.join(OUTDIR,'inscriptions-manifest.json')}`);

  // ETH mirrors (optional)
  let ethSummary = { skipped:true, reason:'no RPC/owner' };
  if (ETH_RPC_URLS.length && OWNER_ADDRS.length){
    console.log('\n▶ ETH: verifying mirrors byte‑for‑byte & sender…');
    const r = await verifyEthMirrors(manifest);
    if (r.skipped){ console.log(`↺ ETH skipped: ${r.reason}`); ethSummary=r; }
    else {
      for(const it of r.results){
        console.log(`  [${it.label}] from=${it.from} okFrom=${it.okFrom?'YES':'NO'} len=${it.ethLen}/${it.btcLen} sha=${it.okSha?'OK':'MISMATCH'} → ${it.status}`);
      }
      if (r.fail>0){ console.log(`✗ ETH FAILED (${r.fail} mismatch)`); } else { console.log('✓ ETH ALL PASS'); }
      ethSummary = { fail: r.fail };
    }
  } else {
    console.log('↺ ETH skipped (no --eth-rpc or --owner-addrs)');
  }

  // Report
  const report = {
    boundary: 'non‑amending; BTC originals prevail; verification only; NOT authoritative',
    startedAt: new Date().toISOString(),
    bundleFile: BUNDLE,
    spv: { blocks: spv.blocks, proofs: spv.txs, pass: true },
    manifestFile: path.join(OUTDIR,'inscriptions-manifest.json'),
    eth: ethSummary,
    notes: [
      'ETH is the only mirror layer; AR is indexing/forensics only.',
      'Do NOT treat raw witness or body files as authoritative.',
      'Sole and final authority lies solely with the three Bitcoin Originals.'
    ]
  };
  const reportPath = path.join(OUTDIR,'verify-report.json');
  fs.writeFileSync(reportPath, JSON.stringify(report,null,2));
  console.log(`\n▶ Report written: ${reportPath}`);

  // Summary
  const allPass = true && (!ethSummary.fail); // SPV pass by exception; ethSummary.fail undefined when skipped
  console.log('\n—— Summary ——');
  console.log('SPV  : PASS');
  console.log('ETH  :', (ETH_RPC_URLS.length && OWNER_ADDRS.length) ? (ethSummary.fail? 'FAIL' : 'PASS') : 'SKIPPED');
  console.log('Note : Boundary 1/2 — Non‑Amending; BTC Originals prevail. Boundary 2/2 — ETH only mirror; AR for indexing.');

  process.exit((ETH_RPC_URLS.length && OWNER_ADDRS.length && ethSummary.fail)>0 ? 2 : 0);
})().catch(e=>{ console.error('[FATAL]', e.message||String(e)); process.exit(1); });