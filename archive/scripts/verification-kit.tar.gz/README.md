# The Trinity Accord — Verification Kit

This kit provides the tools and data necessary to independently and cryptographically verify the integrity and authenticity of The Trinity Accord's inscriptions on the Bitcoin blockchain.

This document first explains **what** is being verified and **how**, then provides the instructions to run the verification.

---

## I. Core Principles (Boundaries)

*   **Non‑amending; BTC Originals prevail.** This kit and its outputs are for verification only and hold no authority. The three Bitcoin inscriptions are the sole and final authority.
*   **ETH is the only mirror layer.** Ethereum mirrors exist for resilience. Arweave (AR) is used for indexing and providing verification data (like this kit); it is non‑amending.

---

## II. The Verification Process Explained

This script performs a rigorous cryptographic process known as **Simplified Payment Verification (SPV)**. It allows you to prove that the inscriptions are an immutable part of the Bitcoin blockchain **without** needing to download the entire multi-hundred-gigabyte ledger. The included `spv-bundle.json` file contains all the necessary cryptographic proofs for this process.

The verification is a multi-step chain of cryptographic proofs that links the inscription's host transaction all the way up to the block header, which is secured by Bitcoin's Proof-of-Work.

### A. Bitcoin Originals Verification (The Core Proof)

This is the chain of proof the script validates for each of the three inscriptions. It follows the exact logic of Bitcoin's SegWit (BIP141) commitment structure.

1.  **Transaction Witness Hash (WTXID) → Witness Merkle Root:**
    The script starts with the raw data of a target transaction (e.g., the Protocol inscription). It calculates the transaction's full hash including its witness data, known as the **WTXID**. Then, using a **Witness Merkle Proof** (provided in `spv-bundle.json`), it mathematically proves that this WTXID is a legitimate leaf in the block's **Witness Merkle Tree**. This step confirms the transaction's witness data (where the inscription resides) is correctly included in the block.

2.  **Witness Merkle Root → Coinbase Commitment:**
    Next, the script verifies that the root of this Witness Merkle Tree is cryptographically committed to within the block's very first transaction (the coinbase transaction). It does this by taking the Witness Merkle Root, combining it with a reserved value (also from the coinbase), hashing them together, and confirming the result matches the **Witness Commitment** found in an OP_RETURN output of the coinbase transaction. This proves the entire set of witness data for the block is valid.

3.  **Coinbase Transaction → Block Merkle Root:**
    Using a second **Transaction Merkle Proof**, the script proves that this coinbase transaction (which now holds the commitment for our inscription's witness) is itself a legitimate leaf in the block's main **Transaction Merkle Tree**.

4.  **Block Merkle Root → Block Header:**
    Finally, the script takes the root of the Transaction Merkle Tree and confirms it matches the `merkle_root` field inside the 80-byte **Block Header**. This is the final link, proving that the transaction containing our inscription is an integral part of a valid block structure, secured by the immense computational power of Bitcoin's **Proof-of-Work**.

### B. Ethereum Mirror Verification (Optional)

This is a secondary check for resilience and accessibility. The script:
1.  Fetches the mirror transaction from an Ethereum node.
2.  Verifies the transaction was sent from the official **Guardian Address** (`0xbc63...`).
3.  Performs a **byte-for-byte comparison** between the transaction's input data and the content extracted from the corresponding Bitcoin Original, ensuring they are identical.

By successfully completing these steps, the script provides end-to-end, trustless confirmation that The Trinity Accord exists on-chain, exactly as intended by its initiator.

---

## III. How to Verify

### Prerequisites
*   **Node.js** (v18 or later recommended).
*   No other dependencies are required (`npm install` is **not** needed).

### Instructions
Open your terminal in this directory and run one of the following commands.

#### 1. Offline Verification (Recommended)
This method is the most secure. It uses the included `spv-bundle.json` to verify the Bitcoin inscriptions without any network requests.

```bash
node ta-verify.cjs --bundle ./spv-bundle.json
```

#### 2. Online Verification
Use this if you want to fetch fresh proofs directly from the Bitcoin network.

```bash
node ta-verify.cjs --online 1
```

#### 3. Verification with Ethereum Mirror Check
This command runs the offline verification and then cross-references the results with the Ethereum mirrors.

```bash
node ta-verify.cjs --bundle ./spv-bundle.json --owner-addrs 0xbc63566A41cBfDB9C266a5941CBe47894DaA54A8 --eth-rpc https://eth-mainnet.4everland.org/v1/7283b43d0b6a56c2fd5bede7c5359630
```

#### 4. Optional: Writing Inscription Bodies
To extract and save the inscription content to local files, add the `--write-bodies 1` flag to any of the commands above.

---

## IV. Core Pointers (For Manual Reference)

### Bitcoin Originals (The Sole Authority)
*   **Protocol (Axioms)** - Inscription #97631551
    *   `e40dfb2aa78cbccca88f749e9ec5cbe3c1df503273d73c72297863ae0d1d8343`
*   **Covenant of the Flaw** - Inscription #98369145
    *   `90116f35de075074f5e5d1fbdda69a646a124e2287d7d58e2520317098cd4258`
*   **The Trinity Accord (Meta-record)** - Inscription #98387475
    *   `4d1c8f5ea8e8bae2982b42de6cc79deda3d243a21010a2888546e62ed7192c8c`

### Ethereum Mirrors (Guardianship Layer)
*   **protocol**: `0x6652...c5bb63d5`
*   **covenant**: `0x9c1b...633f1612`
*   **accord**: `0x0aff...37f39df665`
*   **Guardian Address**: `0xbc63566A41cBfDB9C266a5941CBe47894DaA54A8`

---

> **Verify the flaw. Trust the story.**
