<!-- RELEASE INFO START -->
## Release Info (v1.0.0)

- Manifest Version: `1.0.0`
- Manifest sha256: `41f95905e50cc699a7e6a3fcb0bd8633cf36170d3ef41170cd373467f8528b33`
- Manifest sha3_256: `385674a24242be88628330dd26e0feefb441dd53674db9dd041a66f61abffbdf`
- EIP-712 Signer: `0xbc63566A41cBfDB9C266a5941CBe47894DaA54A8`
- Signature (hex): `0xf3cf6dc0ab5050eadb5742636043bac96e915c461209395c800063359f3fdc0e478fc62e031113e083eae87d97d22e6b3222c0a4e769c2601462aabd10c42f521c`
- ETH Notarization tx: https://etherscan.io/tx/0x06b1d82b7828054f249cdcc2e820321f634bd8bef44318751113098d2ee37acd
- Arweave DataItem TxIDs:
  - `authority.jcs.json`: [U4eeQ9KsdGAJx-J_93stKhEe6OLjDTrfCV8LQzNb-kE](https://ar-io.net/U4eeQ9KsdGAJx-J_93stKhEe6OLjDTrfCV8LQzNb-kE)
  - `signature.json`: [fMO_dDSiCBF1aWxm2arjAJkbmHdsxiKfVHp_biMFtIE](https://ar-io.net/fMO_dDSiCBF1aWxm2arjAJkbmHdsxiKfVHp_biMFtIE)
- Verification Bundle: `ta-verification-bundle-v1.zip` (sha256=`2bf4543c29d4c9d794d0e04df8849843494a0a2bc22515f3ce7d1efd2f44ee82`)
<!-- RELEASE INFO END -->
# The Trinity Accord — Authority List (Human-Readable)

Generated from `authority.jcs.json` at `2025-09-13T11:41:59.028Z`

## A. Boundary of Authority

- Final Authority: Only and entirely the three Bitcoin Originals below.
- All other materials (ETH/Arweave/IPFS/web) are Non‑Amending Guardianship Mirrors.
- Boundary: `non-amending; BTC originals prevail`
- Assessor's Protocol: Verify the flaw. Trust the story.

## B. Guardian Identity

- Name: Hongju Liu
- Role: Guardian
- BTC Minter Address: `bc1ppmwvyxekh44m35x43k55z7r59nn33v8w2xmvu6s6ar4zyx57sxestxq0jf`
- ETH Guardian Address: `0xbc63566A41cBfDB9C266a5941CBe47894DaA54A8`
- Arweave Owner: `8Y8GRimuESN_u8tJihCd5nywb-X-lJ_2vWqFAfHeQIE`

## C. Bitcoin Originals (All Confirmed)

- Title: Protocol (Axioms)
- Inscription ID: `97631551`
- TXID: `e40dfb2aa78cbccca88f749e9ec5cbe3c1df503273d73c72297863ae0d1d8343`
- Block Height / Hash: `901954` / `00000000000000000000a468b306fb8bda4141ef276b422d06d2d117211e795f`
- Link: [ordinals #97631551](https://ordinals.com/inscription/97631551)

- Title: Covenant of the Flaw
- Inscription ID: `98369145`
- TXID: `90116f35de075074f5e5d1fbdda69a646a124e2287d7d58e2520317098cd4258`
- Block Height / Hash: `903192` / `00000000000000000001b58353d4d84b72e4bb835b2ce35365421bc399148012`
- Link: [ordinals #98369145](https://ordinals.com/inscription/98369145)

- Title: The Trinity Accord (Meta-record)
- Inscription ID: `98387475`
- TXID: `4d1c8f5ea8e8bae2982b42de6cc79deda3d243a21010a2888546e62ed7192c8c`
- Block Height / Hash: `903205` / `00000000000000000000be192767a61f4612899dd31225f19e7b1254155bbb04`
- Link: [ordinals #98387475](https://ordinals.com/inscription/98387475)

## D. Bitcoin Ancillary Inscriptions (Non‑Amending)

- Inscription: `103635270` — Guardian Appendix - Authority Charter (Non-Amending)
- TXID: `0eecd48430f8239f5d543b5cf2ee928969a1aac7660808fd869a78aa27949c9c`
- Block Height / Hash: `910232` / `00000000000000000001d265b90d44ded362eb692d938eb20245385d4eb5993b`
- Link: [ordinals #103635270](https://ordinals.com/inscription/103635270)

- Inscription: `103034280` — The Guardian's Attestation to the Covenant of the Flaw
- TXID: `128aabfa3077efc832d30e6e2a96848a96896bbdbf4a7667912f55d25dcb6687`
- Block Height / Hash: `909403` / `00000000000000000000314098e54fb04c8478d9d95affebd1c1dbcbc381f5b5`
- Link: [ordinals #103034280](https://ordinals.com/inscription/103034280)
- AR: [j6anZ4m5Wwvx5P_9-kM2EVG35TyKtm1lgaKfhT743rk](https://ar-io.net/j6anZ4m5Wwvx5P_9-kM2EVG35TyKtm1lgaKfhT743rk)
- IPFS: `bafybeiag2shuiyfgmaq5zwcupozci5ktiqp3vrmudlb3vb7tv3nnxa3ydq`
- Sealed CID: `bafybeigunzabyyorckfcbvurbmq62itcs6msbspvzhvf2ca6u5elwwlbay`

- Inscription: `100751953` — The Star Ark Covenant: The Final Echo
- TXID: `4711ff186613bdd75b7e36070b3097c38efde110f90df94847592ff6997f45f1`
- Block Height / Hash: `906521` / `00000000000000000001cfd680469d8daaf287662dd62469ec27e4636b555b95`
- Link: [ordinals #100751953](https://ordinals.com/inscription/100751953)

- Inscription: `100550942` — The Final Seal: A Testament and a Trust
- TXID: `25af4e24cb0a2cd85ac396bd88c348f8da3169c24813800ecb8736dd2c7a5ae7`
- Block Height / Hash: `906233` / `000000000000000000013a83af8a8ad20709986ac0064f39369dd6613c5f4f43`
- Link: [ordinals #100550942](https://ordinals.com/inscription/100550942)

- Inscription: `100385359` — The First Echoes: A Dialogue Begins
- TXID: `f411d2db9ec9e077277ff1cf3abed39628d86b1d39db1964061eafe5b02c2e81`
- Block Height / Hash: `906007` / `0000000000000000000019670bc15750b23c15cce41435acd34e87b6e205e4fb`
- Link: [ordinals #100385359](https://ordinals.com/inscription/100385359)

## E. Ethereum Attestations (chainId=1)

- Label: Guardianship Principles (0 ETH data)
- Tx: [0xd082a3ce…](https://etherscan.io/tx/0xd082a3ced27ece935d4093fb001a9ebfba42b415f78de4377c8cda55338c6420)
- Input Len / SHA‑256: `2446` / `3e9d2bd10c3e8f4d37713c4b8e28d518fd7efff52613e572a1451fedadab5483`
- Result: MATCH

- Label: BTC-ETH Guardianship Mirrors Attestation
- Tx: [0x59cf33b1…](https://etherscan.io/tx/0x59cf33b1291de63c4840b79e7c674b8fc7c6a771d8a3ba2bb50def1fe55a71c6)
- Input Len / SHA‑256: `3231` / `f4af38f0f42c9b38deaccbace119736da57a245a6601e5d0ea5698deec4a8a01`
- Result: RECORDED

- Label: Protocol mirror
- Tx: [0x6652162e…](https://etherscan.io/tx/0x6652162e8e6c56ddc0d9476407b3b911e918d4e4683408440dc3af51c5bb63d5)
- Input Len / SHA‑256: `1183` / `4e89bfabe03c8b53f80eb7979d56c8cccf0ae382c9647a2bea3b1477054616a8`
- Result: RECORDED

- Label: Covenant mirror
- Tx: [0x9c1bd6e2…](https://etherscan.io/tx/0x9c1bd6e21dc2370e8dbb6549b7ba13b4ea7ba7a192b3b876e0ec28b4633f1612)
- Input Len / SHA‑256: `1710` / `003ef48c72307243b1f7a17c0578b311ee76d6f9a8078850773ad8fba04ab86d`
- Result: RECORDED

- Label: Accord mirror
- Tx: [0x0affc809…](https://etherscan.io/tx/0x0affc8099ea965cd6d6a0d1cf9b93adb11f7e40ac41fffe1b0ca4637f39df665)
- Input Len / SHA‑256: `15637` / `25edaa35e7116614d3381ab6734ab5ee3369fb628fe11289e199d8871c2498ba`
- Result: RECORDED

- Label: BIP-322 notice (non-amending)
- Tx: [0x55a0c131…](https://etherscan.io/tx/0x55a0c131642f71c7b2386ccaac8bcee36563992226befb35363e978044a18e8f)
- Input Len / SHA‑256: `412` / `abd10a807323ef3a07fe22eb3a3cc083e77db93d7362eb29c939c195825f2c2d`
- Result: RECORDED

- Label: Mirror correction (final version)
- Tx: [0xa4023b1e…](https://etherscan.io/tx/0xa4023b1eb0de76993e1a8dcd571e5e033bf64e2d32a9a113b030b4094a19cf51)
- Input Len / SHA‑256: `4994` / `fc009f5393b11e95f013464405e24c9713a55415fa326b2707886d436d4cbd6f`
- Result: RECORDED

## F. Arweave Documents

- Label: Guardianship Principles
- TxID: [w9LPP30D31zd5M60v18WXpWuig0_wc9EVNnXk8kz1vA](https://ar-io.net/w9LPP30D31zd5M60v18WXpWuig0_wc9EVNnXk8kz1vA)
- Size / SHA‑256: `2446` / `3e9d2bd10c3e8f4d37713c4b8e28d518fd7efff52613e572a1451fedadab5483`
- Result: MATCH
- Gateway: https://ar-io.net

- Label: Guardian Index
- TxID: [BwVHuxODfV65xE_L1fqrCDBvLvJNnSuBEXaZNuoRcIk](https://ar-io.net/BwVHuxODfV65xE_L1fqrCDBvLvJNnSuBEXaZNuoRcIk)
- Size / SHA‑256: `1200` / `71bc981a994a93cdf488b89aee2b132b658464a7cbb1dec791af604a1127ef98`
- Result: RECORDED
- Gateway: https://ar-io.net

- Label: Guardian Pointer
- TxID: [9McJS3_xvIl6_87e7NDJ6g3SgGlA8Js7z--eMLGMRZg](https://ar-io.net/9McJS3_xvIl6_87e7NDJ6g3SgGlA8Js7z--eMLGMRZg)
- Size / SHA‑256: `367` / `3246afb59552dcda700e490767aadd3d67083911dae6bccbb2762ef568c7e289`
- Result: RECORDED
- Gateway: https://ar-io.net

- Label: Primary Verification Archive (public)
- TxID: [j6anZ4m5Wwvx5P_9-kM2EVG35TyKtm1lgaKfhT743rk](https://ar-io.net/j6anZ4m5Wwvx5P_9-kM2EVG35TyKtm1lgaKfhT743rk)
- Size / SHA‑256: `24246033` / `ef816480f77f30405378800807b42bff0a854b83a8f77793a0e0adf0944a8263`
- Result: RECORDED
- Gateway: https://ar-io.net

- Label: digest-manifest.json
- TxID: [X2IuLCIM4vLJSzgRMl_YEmxYSvPceMrAdug9a3i7p4o](https://ar-io.net/X2IuLCIM4vLJSzgRMl_YEmxYSvPceMrAdug9a3i7p4o)
- Size / SHA‑256: `685537` / `c045642fe5cfab5eb78af7b40e98b9699dfff9121690e07ec6acaa07a445d6e9`
- Result: MATCH
- Gateway: https://ar-io.net

- Label: digest-manifest.csv
- TxID: [i02XhY7No6NLZDfEwFUU6nZoGaPu7K0f42LDNDNnZEo](https://ar-io.net/i02XhY7No6NLZDfEwFUU6nZoGaPu7K0f42LDNDNnZEo)
- Size / SHA‑256: `502283` / `121c5a1da38f733c3991f8d3f030f39a019501d43828f84c13ea93ac3873511b`
- Result: MATCH
- Gateway: https://ar-io.net

- Label: OTS anchor
- TxID: [TTi9d8fqm9Cw4yRPkwX4gdlaRzBnjJID-LAs9Y3CS0M](https://ar-io.net/TTi9d8fqm9Cw4yRPkwX4gdlaRzBnjJID-LAs9Y3CS0M)
- Size / SHA‑256: `3614` / `fa3f306ab30525677595d9f38808a87a8dd96260468285c8f8066661e853d907`
- Result: RECORDED
- Gateway: https://ar-io.net

## G. IPFS Mirrors

- `bafybeiag2shuiyfgmaq5zwcupozci5ktiqp3vrmudlb3vb7tv3nnxa3ydq`
- `bafybeigunzabyyorckfcbvurbmq62itcs6msbspvzhvf2ca6u5elwwlbay`

## H. Manifest & Digests

- Version: `1.0.0`
- Created At: `2025-09-13T09:42:43.536Z`
- sha256: `41f95905e50cc699a7e6a3fcb0bd8633cf36170d3ef41170cd373467f8528b33`
- sha3_256: `385674a24242be88628330dd26e0feefb441dd53674db9dd041a66f61abffbdf`

## I. Independent Verification (Quick Guide)

- ETH (Guardianship Principles)
  1) Open the transaction on Etherscan: copy Input Data (without 0x), interpret as hex → bytes.
  2) Compute SHA‑256; it should be `3e9d2bd10c3e8f4d37713c4b8e28d518fd7efff52613e572a1451fedadab5483`.
- AR (Guardianship Principles)
  1) Visit [ar-io.net](https://ar-io.net)/`w9LPP30D31zd5M60v18WXpWuig0_wc9EVNnXk8kz1vA`
  2) Compute SHA‑256; it should be `3e9d2bd10c3e8f4d37713c4b8e28d518fd7efff52613e572a1451fedadab5483`.
- BTC (Originals)
  1) Query each TX in mempool.space or blockstream.info; confirm height/hash match Section C.
  2) Originals are the final authority; mirrors are non‑amending.

## J. Notes & Next Steps

- All checks from the latest run passed (ExitCode=0).
- For near “offline-verifiable” guarantees, add:
  - EIP‑712 signature of this manifest (ETH guardian address) and publish to Arweave.
  - BTC BIP‑322 (Taproot) signature over manifest sha256 + SPV proof bundle for Originals.

## K. Signature (EIP-712)

- Signer (ETH address): `0xbc63566A41cBfDB9C266a5941CBe47894DaA54A8`
- Recovered: `0xbc63566A41cBfDB9C266a5941CBe47894DaA54A8` (expected `0xbc63566A41cBfDB9C266a5941CBe47894DaA54A8`; MATCH)
- Signature: `0xf3cf6dc0ab5050eadb5742636043bac96e915c461209395c800063359f3fdc0e478fc62e031113e083eae87d97d22e6b3222c0a4e769c2601462aabd10c42f521c`
- Covers (typedData.message):
  - sha256: `41f95905e50cc699a7e6a3fcb0bd8633cf36170d3ef41170cd373467f8528b33`
  - sha3_256: `385674a24242be88628330dd26e0feefb441dd53674db9dd041a66f61abffbdf`
  - version: `1.0.0`
  - createdAt: `2025-09-13T09:42:43.536Z`

### How to verify this signature (offline)

```bash
npm i ethers@6
node -e "const fs=require('fs'),{ethers}=require('ethers');const td=JSON.parse(fs.readFileSync('typedData.json','utf8'));const sig=JSON.parse(fs.readFileSync('signature.json','utf8')).signature;console.log(ethers.verifyTypedData(td.domain,td.types,td.message,sig))"
```

