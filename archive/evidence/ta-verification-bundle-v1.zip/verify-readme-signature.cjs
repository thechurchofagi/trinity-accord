// verify-readme-signature.cjs
// Robust, no dynamic-regex version.
// Verify that the "Signature (EIP-712)" section in authority-readme.md
// matches signature.json / typedData.json / authority.hashes.json / authority.jcs.json.
//
// Usage (run inside authority/):
//   node verify-readme-signature.cjs
// Exit codes:
//   0 = OK (all checks pass)
//   2 = mismatch or missing required data

const fs = require("fs");
const path = require("path");

// ---------- utils ----------
function die(msg) {
  console.error("[FATAL]", msg);
  process.exit(2);
}
function getUtf8(p) {
  if (!fs.existsSync(p)) die("Missing file: " + p);
  return fs.readFileSync(p, "utf8");
}
function mustParse(s, name) {
  try { return JSON.parse(s); }
  catch (e) { die("Invalid JSON in " + name + ": " + e.message); }
}
function normHex(x) {
  return String(x || "").toLowerCase().replace(/^0x/, "");
}
function normAddr(x) {
  return String(x || "").toLowerCase();
}
function normalizeDashes(s) {
  // normalize various unicode dashes to ASCII hyphen
  return String(s || "").replace(/[\u2010-\u2015\u2212]/g, "-");
}

// Try to locate a section that starts at a heading (##..######) containing "signature" or "eip-712" (case-insensitive).
// If not found, fallback: find the line containing "Signer:" and take from nearest previous heading to before next heading.
function extractSignatureSection(md) {
  const lines = normalizeDashes(md).split(/\r?\n/);
  let start = -1;
  let end = lines.length;

  // 1) find heading containing signature/eip-712
  for (let i = 0; i < lines.length; i++) {
    const L = lines[i].trim();
    if ((/^#{2,6}\s+/i).test(L) && (/(signature|eip[-\s]?712)/i).test(L)) {
      start = i;
      break;
    }
  }
  // 2) fallback: find "Signer:" label line
  if (start < 0) {
    let signerLine = -1;
    for (let i = 0; i < lines.length; i++) {
      if ((/Signer\s*:/i).test(lines[i])) { signerLine = i; break; }
    }
    if (signerLine >= 0) {
      start = signerLine;
      for (let j = signerLine; j >= 0; j--) {
        if ((/^#{2,6}\s+/i).test(lines[j].trim())) { start = j; break; }
      }
    }
  }
  if (start < 0) return null;

  // find end at next heading after start
  for (let j = start + 1; j < lines.length; j++) {
    if ((/^#{2,6}\s+/i).test(lines[j].trim())) { end = j; break; }
  }
  return lines.slice(start, end).join("\n");
}

// Capture the first backtick-quoted content on the line that starts with an optional bullet then "FieldName:"
function captureField(section, fieldName) {
  const lines = section.split(/\r?\n/);
  const want = String(fieldName).toLowerCase() + ":";
  for (const raw of lines) {
    let L = raw.trim();
    // strip optional bullet
    if (L.startsWith("-")) L = L.slice(1).trim();
    if (L.startsWith("*")) L = L.slice(1).trim();
    const lower = L.toLowerCase();
    // must start with the field (case-insensitive)
    if (!lower.startsWith(String(fieldName).toLowerCase())) continue;
    // must contain colon after the field
    const colonPos = L.indexOf(":");
    if (colonPos < 0) continue;
    // find first backtick after colon
    const firstTick = L.indexOf("`", colonPos + 1);
    if (firstTick < 0) return "";
    const secondTick = L.indexOf("`", firstTick + 1);
    if (secondTick < 0) return "";
    return L.slice(firstTick + 1, secondTick).trim();
  }
  return "";
}

// ---------- main ----------
(function main() {
  const ROOT = process.cwd();

  const readmePath = path.join(ROOT, "authority-readme.md");
  const sigPath    = path.join(ROOT, "signature.json");
  const tdPath     = path.join(ROOT, "typedData.json");
  const hashesPath = path.join(ROOT, "authority.hashes.json");
  const manPath    = path.join(ROOT, "authority.jcs.json");

  const readme = getUtf8(readmePath);
  const sigObj = mustParse(getUtf8(sigPath), "signature.json");
  const td     = mustParse(getUtf8(tdPath), "typedData.json");
  const hashes = fs.existsSync(hashesPath) ? mustParse(getUtf8(hashesPath), "authority.hashes.json") : null;
  const man    = mustParse(getUtf8(manPath), "authority.jcs.json");

  const sec = extractSignatureSection(readme);
  if (!sec) {
    die('Cannot find a "Signature" section or any line containing "Signer:". Please append the generated signature section.');
  }

  // Values parsed from README signature section
  const r_signer    = captureField(sec, "Signer");
  const r_recovered = captureField(sec, "Recovered");
  const r_signature = captureField(sec, "Signature");
  const r_sha256    = captureField(sec, "sha256");
  const r_sha3      = captureField(sec, "sha3_256");
  const r_version   = captureField(sec, "version");
  const r_createdAt = captureField(sec, "createdAt");

  // Expected (ground truth) values from JSON files
  const e_signer    = String(sigObj.signer || "");
  const e_recovered = String(sigObj.recovered || "");
  const e_signature = String(sigObj.signature || "");
  const e_sha256    = normHex((hashes && hashes.sha256) || (td?.message?.sha256));
  const e_sha3      = normHex((hashes && hashes.sha3_256) || (td?.message?.sha3_256) || "");
  const e_version   = String(td?.message?.version || man?.version || "");
  const e_createdAt = String(td?.message?.createdAt || man?.created_at || "");

  let ok = true;
  function check(name, got, exp, norm = (x)=>x) {
    const a = norm(got);
    const b = norm(exp);
    if (a === b) console.log("[PASS]", name, "=", got);
    else { ok = false; console.log("[FAIL]", name, "got:", got, "| expected:", exp); }
  }

  check("Signer", r_signer, e_signer, normAddr);
  check("Recovered", r_recovered, e_recovered, normAddr);
  check("Signature(hex)", r_signature, e_signature, (x)=>String(x||"").toLowerCase());
  check("sha256", r_sha256, e_sha256, normHex);
  if (e_sha3)      check("sha3_256", r_sha3, e_sha3, normHex); // only assert if expected exists
  if (e_version)   check("version", r_version, e_version);
  if (e_createdAt) check("createdAt", r_createdAt, e_createdAt);

  if (!ok) process.exit(2);
  console.log("[OK] README signature section verified");
})();