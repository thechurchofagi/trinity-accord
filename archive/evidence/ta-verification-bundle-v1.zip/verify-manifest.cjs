// verify-manifest.cjs
// Purpose: Reverse-verify authority.jcs.json against live BTC/ETH/Arweave data.
// Usage:
//   1) npm i axios proxy-agent
//   2) node verify-manifest.cjs [path/to/authority.jcs.json]
// Env (optional):
//   ALL_PROXY=socks5h://127.0.0.1:5000
//   BTC_API_BASE=https://mempool.space/api
//   ETH_RPC_URLS=https://eth-mainnet.4everland.org/v1/...,https://ethereum.publicnode.com
//   AR_PROVIDER_URL=https://ar-io.net
//   AR_GATEWAYS=https://arweave.net,https://gateway.irys.xyz

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const axios = require("axios");
const proxyAgentModule = require("proxy-agent");

// ---------- config / helpers ----------
const MANIFEST_PATH = process.argv[2] || path.join(process.cwd(), "authority.jcs.json");
const HASHES_PATH = path.join(path.dirname(MANIFEST_PATH), "authority.hashes.json");

function buildAgent(proxyUrl) {
  if (!proxyUrl) return undefined;
  try {
    if (typeof proxyAgentModule === "function") return proxyAgentModule(proxyUrl);
    if (proxyAgentModule && typeof proxyAgentModule.ProxyAgent === "function") return new proxyAgentModule.ProxyAgent(proxyUrl);
    if (proxyAgentModule && typeof proxyAgentModule.createProxyAgent === "function") return proxyAgentModule.createProxyAgent(proxyUrl);
  } catch {}
  return undefined;
}

const proxyUrl =
  process.env.ALL_PROXY || process.env.HTTPS_PROXY || process.env.HTTP_PROXY ||
  process.env.all_proxy || process.env.https_proxy || process.env.http_proxy || "";

const agent = buildAgent(proxyUrl);
function httpClient(baseURL) {
  return axios.create({
    baseURL: baseURL || "",
    timeout: 30000,
    httpAgent: agent,
    httpsAgent: agent,
    proxy: false,
    headers: { "content-type": "application/json" }
  });
}

function sha256Hex(buf) {
  return crypto.createHash("sha256").update(buf).digest("hex");
}
function sha3_256Hex(buf) {
  try {
    return crypto.createHash("sha3-256").update(buf).digest("hex");
  } catch {
    return null;
  }
}
function toISO(ts) {
  if (ts === null || ts === undefined) return null;
  try { return new Date(Number(ts) * 1000).toISOString(); } catch { return null; }
}
function envList(name) {
  const v = process.env[name] || "";
  return v.split(/[,;\s]+/).map(s=>s.trim()).filter(Boolean);
}
function trimSlash(s) {
  s = String(s || "");
  while (s.endsWith("/")) s = s.slice(0, -1);
  return s;
}
function pass(report, name, extra) { report.checks.push({ name, ok:true, ... (extra?{extra}:{} ) }); }
function fail(report, name, detail) { report.ok=false; report.checks.push({ name, ok:false, detail }); }

// ---------- load manifest ----------
if (!fs.existsSync(MANIFEST_PATH)) {
  console.error("[FATAL] manifest not found:", MANIFEST_PATH);
  process.exit(1);
}
const manifestRaw = fs.readFileSync(MANIFEST_PATH, "utf-8");
let manifestObj;
try { manifestObj = JSON.parse(manifestRaw); }
catch(e){ console.error("[FATAL] invalid JSON in manifest:", e.message); process.exit(1); }

const report = { ok: true, manifest_path: MANIFEST_PATH, checks: [] };
if (proxyUrl) report.proxy = proxyUrl;

// verify hashes file (optional)
if (fs.existsSync(HASHES_PATH)) {
  const hashes = JSON.parse(fs.readFileSync(HASHES_PATH, "utf-8"));
  const s256 = sha256Hex(Buffer.from(manifestRaw, "utf-8"));
  if (hashes.sha256 && hashes.sha256 === s256) pass(report, "manifest.sha256.matches", { sha256: s256 });
  else fail(report, "manifest.sha256.matches", { computed: s256, expected: hashes.sha256 || null });

  const s3 = sha3_256Hex(Buffer.from(manifestRaw, "utf-8"));
  if (hashes.sha3_256 && s3 && hashes.sha3_256 === s3) pass(report, "manifest.sha3_256.matches", { sha3_256: s3 });
  else pass(report, "manifest.sha3_256.skipped_or_mismatch", { computed: s3, expected: hashes.sha3_256 || null });
} else {
  pass(report, "manifest.hashes.not_found_skipped");
}

// boundary check
if (manifestObj.boundary && /non-amending/i.test(manifestObj.boundary)) pass(report, "boundary.non_amending");
else fail(report, "boundary.non_amending", { boundary: manifestObj.boundary });

// ---------- BTC verification ----------
async function fetchTxBTC_mempool(txid, base) {
  const c = httpClient(trimSlash(base || "https://mempool.space/api"));
  const { data } = await c.get("/tx/" + txid);
  return { source:"mempool", json: data };
}
async function fetchTxBTC_blockstream(txid) {
  const c = httpClient("https://blockstream.info/api");
  const [status, tx] = await Promise.all([
    c.get("/tx/" + txid + "/status").then(r=>r.data),
    c.get("/tx/" + txid).then(r=>r.data).catch(()=>null)
  ]);
  // compose a mempool-like object
  const json = {
    status: {
      confirmed: !!status.confirmed,
      block_height: status.block_height ?? null,
      block_hash: status.block_hash || null
    },
    vin: (tx && tx.vin) || []
  };
  return { source:"blockstream", json };
}
async function fetchTxBTC(txid, base) {
  let lastErr = null;
  try { return await fetchTxBTC_mempool(txid, base); } catch(e){ lastErr = e; }
  try { return await fetchTxBTC_blockstream(txid); } catch(e){ lastErr = e; }
  throw lastErr || new Error("btc fetch failed");
}

async function verifyBTC() {
  const base = process.env.BTC_API_BASE || "https://mempool.space/api";
  const originals = manifestObj.bitcoin?.originals || [];
  const ancillary = manifestObj.bitcoin?.ancillary || [];

  for (const it of originals) {
    const txid = it.txid;
    try {
      const { source, json } = await fetchTxBTC(txid, base);
      const okBlock = (json?.status?.block_height === it.block_height) && (json?.status?.block_hash === it.block_hash) && !!json?.status?.confirmed;
      if (okBlock) pass(report, "btc.original." + (it.label || txid) + ".block", { source, txid, block_height: json.status.block_height });
      else fail(report, "btc.original." + (it.label || txid) + ".block", { source, txid, got: json?.status, expected: { block_height: it.block_height, block_hash: it.block_hash, confirmed: true } });
    } catch(e) {
      fail(report, "btc.original." + (it.label || txid) + ".fetch_error", { txid, error: e?.message || String(e) });
    }
  }
  for (const it of ancillary) {
    const txid = it.txid;
    if (!txid) { fail(report, "btc.ancillary." + it.inscription_id + ".missing_txid", {}); continue; }
    try {
      const { source, json } = await fetchTxBTC(txid, base);
      const okBlock = (json?.status?.block_height === it.block_height) && (json?.status?.block_hash === it.block_hash) && !!json?.status?.confirmed;
      if (okBlock) pass(report, "btc.ancillary." + it.inscription_id + ".block", { source, txid, block_height: json.status.block_height });
      else fail(report, "btc.ancillary." + it.inscription_id + ".block", { source, txid, got: json?.status, expected: { block_height: it.block_height, block_hash: it.block_hash, confirmed: true } });
    } catch(e) {
      fail(report, "btc.ancillary." + it.inscription_id + ".fetch_error", { txid, error: e?.message || String(e) });
    }
  }
}

// ---------- ETH verification ----------
async function getTxETH(rpc, hash) {
  const c = httpClient(rpc);
  const body = { jsonrpc: "2.0", id: 1, method: "eth_getTransactionByHash", params: [hash] };
  const { data } = await c.post("", body);
  return data?.result || null;
}
async function verifyETH() {
  const seedRpcs = []; // rely on env primarily
  const envRpcs = envList("ETH_RPC_URLS");
  const rpcs = Array.from(new Set([].concat(envRpcs, seedRpcs))).filter(Boolean);
  if (rpcs.length === 0) rpcs.push("https://ethereum.publicnode.com");

  for (const it of (manifestObj.ethereum?.attestations || [])) {
    const txh = it.tx_hash;
    if (!txh) { fail(report, "eth.missing_tx_hash", it); continue; }
    let used = null, inputSha = null, inputLen = null, errLast = null;
    for (const rpc of rpcs) {
      try {
        const tx = await getTxETH(rpc, txh);
        if (!tx) continue;
        const hex = String(tx.input || "0x").slice(2);
        const buf = Buffer.from(hex, "hex");
        inputLen = buf.length;
        inputSha = sha256Hex(buf);
        used = rpc;
        break;
      } catch (e) { errLast = e; continue; }
    }
    if (!used) { fail(report, "eth.tx.fetch_error." + (it.label || txh), { txh, error: errLast?.message || String(errLast) }); continue; }
    const hasExp = !!it.input_sha256 || it.input_len !== null && it.input_len !== undefined;
    const matchSha = it.input_sha256 ? (String(it.input_sha256).toLowerCase() === String(inputSha).toLowerCase()) : true;
    const matchLen = (typeof it.input_len === "number") ? (it.input_len === inputLen) : true;
    if (matchSha && matchLen) pass(report, "eth.tx.ok." + (it.label || txh), { rpc: used, sha256: inputSha, len: inputLen });
    else fail(report, "eth.tx.mismatch." + (it.label || txh), { rpc: used, got_sha256: inputSha, got_len: inputLen, expected_sha256: it.input_sha256 || null, expected_len: it.input_len || null, has_expected: hasExp });
  }
}

// ---------- AR verification ----------
async function fetchAR(txid, gateways) {
  let lastErr = null;
  for (const gw of gateways) {
    try {
      const c = httpClient(trimSlash(gw));
      const res = await c.get("/" + txid, { responseType: "arraybuffer" });
      const buf = Buffer.from(res.data);
      return { gateway: gw, buf };
    } catch (e) { lastErr = e; continue; }
  }
  throw lastErr || new Error("all AR gateways failed");
}
async function verifyAR() {
  const envOne = process.env.AR_PROVIDER_URL ? [ process.env.AR_PROVIDER_URL ] : [];
  const envMany = envList("AR_GATEWAYS");
  const gateways = Array.from(new Set([].concat(envOne, envMany, [
    "https://ar-io.net",
    "https://arweave.net",
    "https://gateway.irys.xyz",
    "https://ar-io.dev",
    "https://permaweb.eu"
  ]))).filter(Boolean);

  for (const it of (manifestObj.arweave?.documents || [])) {
    const txid = it.txid;
    if (!txid) { fail(report, "ar.missing_txid." + (it.label || "doc")); continue; }
    try {
      const { gateway, buf } = await fetchAR(txid, gateways);
      const gotSha = sha256Hex(buf);
      const gotLen = buf.length;
      const okSha = it.ar_sha256 ? (String(it.ar_sha256).toLowerCase() === gotSha) : true;
      const okLen = (typeof it.size === "number") ? (it.size === gotLen) : true;
      if (okSha && okLen) pass(report, "ar.doc.ok." + (it.label || txid), { gateway, sha256: gotSha, size: gotLen });
      else fail(report, "ar.doc.mismatch." + (it.label || txid), { gateway, got_sha256: gotSha, got_size: gotLen, expected_sha256: it.ar_sha256 || null, expected_size: it.size || null });
    } catch (e) {
      fail(report, "ar.doc.fetch_error." + (it.label || txid), { txid, error: e?.message || String(e) });
    }
  }
}

// ---------- run ----------
(async()=>{
  if (proxyUrl) pass(report, "proxy.in_use", { proxyUrl });

  await verifyBTC();
  await verifyETH();
  await verifyAR();

  // final report
  console.log(JSON.stringify(report, null, 2));
  process.exit(report.ok ? 0 : 2);
})().catch(e=>{
  console.error("[FATAL]", e?.message || String(e));
  process.exit(1);
});