# Prepared deposit boundary — v1.1.0

No Zenodo deposition was created or published by this preparation. No DOI is assigned.
The user's present request is final manuscript preparation, not a publication transaction.

Deposit the exact final PDF, English source and reproducibility archive after authorization and metadata/rights checks. The metadata JSON is a wrapper: only its `metadata` object is a proposed service payload; related works outside it are planning notes. Do not submit wrapper status fields as metadata. Do not insert a guessed DOI. If an actual DOI is reserved and inserted into the manuscript before release, rebuild once, re-review, and replace all hashes BEFORE publication.

Preserve older editions. Read public bytes anonymously and verify SHA-256 after publication. Only then follow the repository's current DOI -> OTS -> verified Bitcoin proof -> Arweave order. A pending timestamp is not Bitcoin-confirmed. Cumulative Arweave fees for one edition must remain strictly below 0.1 AR under the existing additional guards. Use actual receipts, never file names or this document as evidence of completion.

License proposal: CC-BY-4.0 for the new manuscript; MIT proposed for newly supplied code after author adoption. Existing predecessor archive notices are not superseded. No author ORCID, external funding award or journal acceptance has been invented.
