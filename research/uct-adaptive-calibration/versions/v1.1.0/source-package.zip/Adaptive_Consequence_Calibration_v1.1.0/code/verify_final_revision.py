#!/usr/bin/env python3
"""Exact witnesses, metric recovery, and familywise decision audit for GD v1.1.

Reuses frozen v1.0 experiment counts; no new online adaptation is asserted.
All tested worlds are declared mathematical constructions, not participants.
"""
from __future__ import annotations
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
import argparse, csv, json, math
import numpy as np
import sympy as sp
from calibration_core import recover, exact_probabilities, body_variance
from calibration_safeguards import (trace_enclosure, clopper_pearson_box,
    standard_reference_vectors, reconstruct_metric, metric_equalizer,
    metric_bound, validate_spd)


def qform_probability(sigma, g, t, s=.8):
    # det(I+2t Sigma G) has positive real eigenvalues under SPD premises.
    sign, logdet = np.linalg.slogdet(np.eye(len(g))+2*t*np.asarray(sigma)@g)
    if sign <= 0: raise ValueError('Invalid determinant')
    return float(s*np.exp(-.5*logdet))


def verify_algebra():
    t = sp.symbols('t', nonnegative=True)
    eye = sp.eye(2)
    # SAME input path and fixed reference v=e1; directional gain changes.
    g1 = sp.diag(1,1); s1 = sp.diag(1,1)
    g2 = sp.diag(1,sp.Rational(1,4)); s2 = sp.diag(1,4)
    assert (eye+2*t*s1*g1).det() == (eye+2*t*s2*g2).det()
    assert g1[0,0]==g2[0,0] and sp.trace(s1)==2 and sp.trace(s2)==5
    # Even exactly KNOWN G leaves an eigenvalue/orientation ambiguity.
    g = sp.diag(1,4); sa = sp.diag(1,2); sb = sp.diag(8,sp.Rational(1,4))
    assert sp.expand((eye+2*t*sa*g).det()-(eye+2*t*sb*g).det())==0
    assert sp.trace(sa)==3 and sp.trace(sb)==sp.Rational(33,4)
    # Basis-only references fail to determine cross sensitivity.
    plus = sp.Matrix([[1,sp.Rational(1,4)],[sp.Rational(1,4),1]])
    minus = sp.Matrix([[1,-sp.Rational(1,4)],[-sp.Rational(1,4),1]])
    assert plus[0,0]==minus[0,0] and plus[1,1]==minus[1,1]
    assert plus.det()>0 and minus.det()>0
    assert sum(plus)!=sum(minus)
    return {
        'same_path_anisotropic_twin':{'true_traces':[2.,5.], 'all_relative_body_gains_match':True,
                                    'common_reference':[1.,0.], 'scalar_reconstruction':2.},
        'known_metric_twin':{'metric_diagonal':[1.,4.], 'true_traces':[3.,8.25],
                            'weighted_trace_both':9.,'all_relative_body_gains_match':True},
        'basis_only_reference_twin':{'diagonal_both':[1.,1.], 'offdiagonal':[.25,-.25],
                                    'reference_e1_plus_e2_quadratic':[2.5,1.5]},
        'proof_method':'Symbolic equalities in arbitrary relative gain; illustrative arrays do not replace general proofs.'}


def verify_metric(rng):
    max_metric = 0.; max_eq = 0.; max_trace = 0.; cases = 0; ranks = []
    for n in range(2,7):
        refs = standard_reference_vectors(n)
        index = [(i,j) for i in range(n) for j in range(i,n)]
        design = np.array([[v[i]*v[j]*(1 if i==j else 2) for i,j in index] for v in refs])
        assert np.linalg.matrix_rank(design)==n*(n+1)//2
        ranks.append({'dimension':n,'directional_references':len(refs),'rank':int(np.linalg.matrix_rank(design))})
        for _ in range(80):
            b=rng.normal(size=(n,n)); g=.05*(b@b.T)+.3*np.eye(n)
            a=rng.normal(size=(n,n)); sigma=.2*(a@a.T)+.05*np.eye(n)
            q0=float(rng.uniform(.5,.95))
            probs=np.array([q0*np.exp(-v@g@v) for v in refs])
            fitted=reconstruct_metric(q0,probs,n)
            h=metric_equalizer(fitted); k=h.T@g@h
            max_metric=max(max_metric,float(np.max(abs(fitted-g))))
            max_eq=max(max_eq,float(np.max(abs(k-np.eye(n)))))
            assert np.max(abs(k-np.eye(n)))<1e-10
            # After physically implementing H, compare full determinant at two gains.
            for tau in [.2,1.,2.]:
                pred=qform_probability(sigma,k,tau,q0)
                target=qform_probability(sigma,np.eye(n),tau,q0)
                assert abs(pred-target)<1e-11
            if n==2:
                qs=[q0,q0*np.exp(-1),qform_probability(sigma,k,1,q0),qform_probability(sigma,k,2,q0)]
                err=abs(recover(qs)[1]-np.trace(sigma));max_trace=max(max_trace,float(err));assert err<1e-10
            # Nonideal equalization permits a range, not a point guarantee.
            eig,vec=np.linalg.eigh(k)
            perturb=vec@np.diag(rng.uniform(.85,1.15,n))@vec.T
            weighted=float(np.trace(perturb@sigma));lo,hi=metric_bound(weighted,perturb)
            assert lo-1e-10<=np.trace(sigma)<=hi+1e-10
            cases+=1
    return {'metric_recovery_cases':cases,'equalized_body_probability_checks':cases*3,
            'imperfect_equalization_bound_checks':cases,'reference_span_checks':ranks,
            'max_metric_entry_error':max_metric,'max_equalization_entry_error':max_eq,'max_2d_trace_error':max_trace}


def verify_validation(rng):
    rejected=0
    bad=[np.zeros((3,2)),np.array([[.9,.8],[.1,.2],[.2,.3],[.1,.2]]),
         np.full((4,2),np.nan),np.array([[-.1,.2],[.1,.2],[.1,.2],[.1,.2]]),
         np.array([[.1,1.1],[.1,.2],[.1,.2],[.1,.2]])]
    for arr in bad:
        try:trace_enclosure(arr)
        except ValueError:rejected+=1
        else:raise AssertionError('Malformed input accepted')
    for c in [0.,-1.,np.inf,np.nan]:
        try:trace_enclosure(np.tile([.1,.2],(4,1)),c)
        except ValueError:rejected+=1
        else:raise AssertionError('Invalid reference accepted')
    for g in [np.diag([1,0]),np.diag([1,-1]),[[1,2],[0,1]],[[np.nan,0],[0,1]]]:
        try:validate_spd(g)
        except ValueError:rejected+=1
        else:raise AssertionError('Invalid metric accepted')
    z=trace_enclosure([[.5,.7],[.5,.7],[.2,.3],[.1,.2]])
    assert z.status=='NOT_IDENTIFIED' and z.lower is None
    z=trace_enclosure([[.5,.6],[.7,.8],[.2,.3],[.1,.2]])
    assert z.status=='INCONSISTENT_BOX' and z.lower is None
    coverage=0
    for _ in range(500):
        b=rng.normal(size=(2,2));sigma=b@b.T+.05*np.eye(2)
        r=float(rng.uniform(.1,2));s=float(rng.uniform(.5,.95));q=exact_probabilities(sigma,r,s)
        radius=min(.0001,float(q.min())*.05,(q[0]-q[1])*.05)
        lo=np.maximum(0,q-radius);hi=np.minimum(1,q+radius)
        result=trace_enclosure(np.column_stack([lo,hi]));assert result.status=='ENCLOSURE'
        assert result.lower-1e-9<=np.trace(sigma)<=result.upper+1e-9;coverage+=1
    return {'invalid_input_rejections':rejected,'explicit_abstention_cases':2,'valid_enclosure_checks':coverage}


def audit_existing_counts(source,out):
    grouped=defaultdict(list)
    for row in csv.DictReader(source.open()):grouped[(row['environment'],int(row['seed']))].append(row)
    detail=[];settings=[];sums={};params={'upstream':(.1,1.,0.),'downstream':(.1,0.,1.),'low_noise':(1.,.01,0.)}
    n=65536;alpha=.05
    for (env,seed),rows in sorted(grouped.items()):
        rows.sort(key=lambda a:float(a['p']));boxes=[];trace=[];covered=0
        for row in rows:
            probs=np.array([float(row[k]) for k in ['q_zero','q_ref','q_body','q_double']])
            counts=np.rint(n*probs).astype(int)
            if not np.allclose(counts/n,probs,atol=1e-14,rtol=0):raise AssertionError('Not exact archived counts')
            result=trace_enclosure(clopper_pearson_box(counts,n,alpha,4*len(rows)))
            p=float(row['p']);true=float(1/7+body_variance(p,*params[env]));trace.append(true);boxes.append(result)
            if result.status=='ENCLOSURE':covered+=int(result.lower<=true<=result.upper)
            settings.append(dict(environment=env,seed=seed,p=p,status=result.status,lower=result.lower,upper=result.upper,true_trace=true))
        baseline=boxes[-1]
        cert=[i for i,x in enumerate(boxes) if x.status=='ENCLOSURE' and baseline.status=='ENCLOSURE' and x.upper<baseline.lower]
        selected=min(cert,key=lambda i:boxes[i].upper) if cert else len(rows)-1
        improvement=trace[-1]-trace[selected]
        assert not cert or improvement>0
        detail.append(dict(environment=env,seed=seed,decision='CERTIFIED_HELD_MEAN_IMPROVEMENT' if cert else 'RETAIN_BASELINE_UNRESOLVED',
                           selected_p=float(rows[selected]['p']),certified_candidates=len(cert),body_trace_improvement=improvement,
                           finite_intervals=sum(x.status=='ENCLOSURE' for x in boxes),covered_intervals=covered))
    for env in params:
        rr=[d for d in detail if d['environment']==env]
        sums[env]={'runs':len(rr),'certified_runs':sum(d['certified_candidates']>0 for d in rr),
                   'retained_baseline':sum(d['certified_candidates']==0 for d in rr),
                   'all_finite_interval_coverage_observed':sum(d['covered_intervals'] for d in rr),
                   'finite_intervals':sum(d['finite_intervals'] for d in rr),
                   'false_certificates_observed':sum(d['certified_candidates']>0 and d['body_trace_improvement']<=0 for d in rr)}
    for name,rr in [('FAMILYWISE_DECISIONS.csv',detail),('FAMILYWISE_ENCLOSURES.csv',settings)]:
        with (out/name).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
    return {'method':'Reanalysis of archived counts, not new samples; 95% simultaneous probability coverage per 21-setting decision family',
            'n_per_mode':n,'alpha_per_decision_family':alpha,'columns_per_family':84,'settings_audited':len(settings),
            'scope':'Confidence about held-setting mean under the stated sampling/model contract. Not safety, transient cost or combined online convergence.',
            'allocation_note':'95% applies per run; the 96 validation runs are not claimed to form one joint 95% family.',
            'results':sums}


def main(out,source):
    out.mkdir(parents=True,exist_ok=True);rng=np.random.default_rng(1013202611)
    result={'version':'UCT-GD-2026-01-v1.1.0','algebra':verify_algebra(),'metric':verify_metric(rng),
            'input_validation':verify_validation(rng),'familywise_audit':audit_existing_counts(source,out),
            'status':'EXECUTED_INTERNAL_MODEL_REVIEW_NOT_EMPIRICAL_CONSCIOUSNESS_EVIDENCE'}
    # Noncentral formula: covariance trace alone omits physical mean offset.
    mean=np.array([1.,0.]);sigma=np.diag([.2,.4]);r=.5;s=.8
    qs=[s,s*np.exp(-r)]
    for t in [1.,2.]:
        a=np.eye(2)+2*t*r*sigma
        qs.append(s/np.sqrt(np.linalg.det(a))*np.exp(-t*r*mean@np.linalg.solve(a,mean)))
    result['nonzero_mean_example']={'mean':mean.tolist(),'covariance_trace':float(np.trace(sigma)),
          'actual_total_squared_deviation':float(np.trace(sigma)+mean@mean),
          'misapplied_centered_reconstruction':float(recover(qs)[1]),'no_alarm_probabilities':qs}
    (out/'FINAL_REVISION_RESULTS.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':
    ap=argparse.ArgumentParser();base=Path(__file__).resolve().parents[1]
    ap.add_argument('--out',type=Path,default=base/'results')
    ap.add_argument('--counts',type=Path,default=base/'results/SELECTION_TRACE.csv')
    a=ap.parse_args();main(a.out,a.counts)
