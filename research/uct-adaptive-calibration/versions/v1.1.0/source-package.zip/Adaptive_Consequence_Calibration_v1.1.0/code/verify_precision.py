#!/usr/bin/env python3
from pathlib import Path
import argparse,json,math,csv
import numpy as np
from scipy.stats import beta
from scipy.linalg import solve_continuous_lyapunov,expm
from calibration_core import *

def binomial_intervals(k,n,alpha=.05,modes=4):
 ans=[];tail=alpha/(2*modes)
 for v in k:
  lo=0. if v==0 else float(beta.ppf(tail,v,n-v+1))
  hi=1. if v==n else float(beta.ppf(1-tail,v+1,n-v))
  ans.append((lo,hi))
 return ans

def main(out):
 out.mkdir(parents=True,exist_ok=True);rng=np.random.default_rng(861306)
 S=np.diag([1/7,.9]);rows=[]
 for r in (.0001,.001,.01,.1,.5,1.,2.):
  q=exact_probabilities(S,r,.8);n=65536;nsim=1000
  k=rng.binomial(n,q,size=(nsim,4));none=0;cover=0;finite_cover=0;width=[];rawerr=[]
  for kk in k:
   lo,hi=score_interval(binomial_intervals(kk,n))
   if not np.isfinite(lo+hi):none+=1
   else:
    good=lo<=np.trace(S)<=hi;finite_cover+=int(good);width.append(hi-lo)
   tt=recover(kk/n)[1]
   if np.isfinite(tt):rawerr.append(abs(tt-np.trace(S)))
  rows.append(dict(r=r,n_per_mode=n,trials=nsim,no_score=none,finite_intervals=nsim-none,
                   finite_interval_coverage=finite_cover,max_or_undefined_coverage=(finite_cover+none)/nsim,
                   median_interval_width=float(np.median(width)) if width else None,
                   median_plugin_error=float(np.median(rawerr)) if rawerr else None))
 # actual stationary Gaussian time correlations from complete 4-state OU.
 D=.1;N=1.;M=0.;p=.3;dt=.2;m=128;r=.5;s=.8
 A=np.zeros((4,4));Q=np.zeros((4,4))
 A[:2,:2]=[[-.2,-1.],[2*p,-2.]];Q[:2,:2]=np.diag([2*D,8*(N*p*p+M)])
 A[2:,2:]=[[-.1,-1.],[2.,-2.]];Q[2:,2:]=np.diag([.2,.08])
 C=solve_continuous_lyapunov(A,-Q);ii=[0,2];Sb=C[np.ix_(ii,ii)]
 q=s/np.sqrt(np.linalg.det(np.eye(2)+2*r*Sb))
 var_iid=q*(1-q)/m;var=var_iid
 for lag in range(1,m):
  cross=(C@expm(A.T*dt*lag))[np.ix_(ii,ii)]
  cv=joint_alarm_covariance(Sb,cross,r,s)
  var+=2*(m-lag)/m**2*cv
 assert var>var_iid
 # independently sampled temporal records validate the covariance formula.
 Fd=expm(A*dt);R=C-Fd@C@Fd.T;L=np.linalg.cholesky(R);L0=np.linalg.cholesky(C)
 nsim=16000;x=rng.normal(size=(nsim,4))@L0.T;counts=np.zeros(nsim)
 for t in range(m):
  if t:x=x@Fd.T+rng.normal(size=(nsim,4))@L.T
  E=x[:,0]**2+x[:,2]**2;counts+=(rng.random(nsim)<s*np.exp(-r*E))
 vv=float(np.var(counts/m,ddof=1))
 # Slack for finite MC variance; no confidence claim assigned to this tolerance.
 assert abs(vv-var)<.07*var
 result=dict(status='EXECUTED',iid_clopper_pearson_experiment=rows,
   interval_note='Valid only for IID binomial column samples; a nonfinite score is abstention, not zero loss. Joint union bound is 95% or above.',
   correlated_record=dict(m=m,dt=dt,r=r,s=s,analytic_variance=float(var),iid_variance=float(var_iid),factor=float(var/var_iid),
     independent_records=nsim,MC_variance=vv),
   sensor_loss_note='No uniform finite precision guarantee as r tends to zero; at r=0 the body modes contain no state information.')
 (out/'PRECISION_RESULTS.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'results');main(ap.parse_args().out)
