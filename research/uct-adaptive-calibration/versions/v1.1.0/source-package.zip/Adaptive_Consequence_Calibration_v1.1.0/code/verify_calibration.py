#!/usr/bin/env python3
"""Exact algebra / finite probability checks for adaptive consequence calibration.
Results are internally executed verification, not independent peer review.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,itertools,json,math,sys
import numpy as np
import sympy as sp
from scipy.linalg import expm, solve_continuous_lyapunov
from calibration_core import *

def main(out):
 out.mkdir(parents=True,exist_ok=True);res={};rng=np.random.default_rng(20261013)
 # Polynomial n=2 identity checked over exact rational covariance diagonals/rates.
 n2=0
 for u,v,r in itertools.product([F(1,100),F(1,7),F(1,2),F(1),F(7)], [F(1,10),F(2,3),F(3),F(11)], [F(1,50),F(1,4),F(1),F(2)]):
  p1=(1+2*r*u)*(1+2*r*v);p2=(1+4*r*u)*(1+4*r*v)
  assert (4*p1-p2-3)/(4*r)==u+v
  assert (p2-2*p1+1)/(8*r*r)==u*v;n2+=1
 res['exact_two_dimensional_cases']=n2
 # General n-sample recovery: derivative of a degree-n determinant polynomial.
 gen=0
 for n in range(1,9):
  for rr in (F(1,5),F(1,2),F(3,2)):
   vals=[F(j+1,j+2) for j in range(n)]
   poly=[math.prod(1+2*rr*F(j)*v for v in vals) for j in range(n+1)]
   deriv=-sum(F(1,j) for j in range(1,n+1))*poly[0]
   deriv+=sum(F((-1)**(j+1)*math.comb(n,j),j)*poly[j] for j in range(1,n+1))
   assert deriv/(2*rr)==sum(vals);gen+=1
 res['exact_general_dimension_cases']=gen
 # Numeric recovery independent of eigenbasis / correlated covariance.
 err=0.;interval_checks=0
 for i in range(1000):
  B=rng.normal(size=(2,2));S=B@B.T+.03*np.eye(2);r=float(rng.uniform(.03,2));s=float(rng.uniform(.4,.95))
  q=exact_probabilities(S,r,s)
  rh,tr,det=recover(q)
  err=max(err,abs(rh-r),abs(tr-np.trace(S)),abs(det-np.linalg.det(S)))
  # Deliberately unequal shifted intervals containing the exact probabilities.
  e=min(.0001,float(np.min(q))*.02,(q[0]-q[1])*.02)
  intervals=np.c_[q-e*rng.random(4),q+e*rng.random(4)]
  lo,hi=score_interval(intervals)
  assert lo-1e-9<=np.trace(S)<=hi+1e-9;interval_checks+=1
 assert err<1e-8
 res['numeric_rotated_covariances']=1000;res['maximum_recovery_absolute_error']=err
 res['deterministic_interval_checks']=interval_checks
 # The scale ambiguity even with arbitrary body gain settings.
 for k in (.01,.5,2.,100.):
  S=np.array([[.7,.2],[.2,1.5]]);r=.7;s=.83
  for level in (.1,.5,1,2,3,7):
   left=s/np.sqrt(np.linalg.det(np.eye(2)+2*level*r*S))
   right=s/np.sqrt(np.linalg.det(np.eye(2)+2*level*r/k*(k*S)))
   assert abs(left-right)<1e-12
 res['scale_ambiguity_checks']=24
 # Explicit single body-gain Gaussian twin, all covariances strictly positive.
 S1=np.diag([1.,1.]);S2=np.diag([.5,5/3]);q1=exact_probabilities(S1,.5,.8);q2=exact_probabilities(S2,.5,.8)
 assert np.allclose(q1[:3],q2[:3]) and not np.isclose(q1[3],q2[3])
 res['one_gain_twins']={'covariance_eigenvalues':[[1,1],[.5,5/3]],'traces':[2,13/6], 'no_alarm_probabilities':[q1.tolist(),q2.tolist()]}
 # General fewer-than-n fixed-gain ambiguity by polynomial perturbation.
 t=sp.symbols('t');ngeneric=0;witnesses=[]
 for n in range(2,7):
  roots0=np.linspace(.3,2.,n)
  # polynomial P(t)=prod(1+2*v*t). R(t)=t prod(t-j), j=1..n-1.
  base=np.polynomial.Polynomial([1.])
  for v in roots0:base*=np.polynomial.Polynomial([1.,2*v])
  pert=np.polynomial.Polynomial([0.,1.])
  for j in range(1,n):pert*=np.polynomial.Polynomial([-float(j),1.])
  eps=1e-7;other=base+eps*pert
  roots=other.roots()
  assert max(abs(roots.imag))<1e-8 and max(roots.real)<0
  assert np.max(np.abs(base(np.arange(1,n))-other(np.arange(1,n))))<1e-7
  lam=-1/(2*roots.real)
  assert abs(sum(lam)-sum(roots0))>1e-10
  witnesses.append({'n':n,'trace_base':float(sum(roots0)),'trace_perturbed':float(sum(lam))})
  ngeneric+=1
 res['fewer_gain_witnesses']=witnesses
 # NonGaussian exact counterexample passing BOTH Gaussian determinant tests.
 # U=exp(-energy). EU=1/2, EU²=1/3 matches a 2D Gaussian Sigma=(1/2)I,r=1.
 support=[F(1,10),F(1,2),F(9,10)];eps=F(1,1000)
 mat=sp.Matrix([[1,1,1],support,[x*x for x in support]])
 cases=[]
 for m in (4,8,32,128,1024):
  d=F(1,2**m)
  rhs=sp.Matrix([1-eps,F(1,2)-eps*d,F(1,3)-eps*d*d]);w=mat.inv()*rhs
  assert all(x>0 for x in w)
  assert sum(w)+eps==1
  assert sum(w[i]*support[i] for i in range(3))+eps*d==F(1,2)
  assert sum(w[i]*support[i]**2 for i in range(3))+eps*d*d==F(1,3)
  mean=sum(float(w[i])*(-math.log(float(support[i]))) for i in range(3))+float(eps)*m*math.log(2)
  cases.append({'m':m,'probability_near_zero':float(eps),'weights':[float(x) for x in w], 'actual_mean_energy':mean,'Gaussian_inferred_mean':1.})
 res['nonGaussian_exact_moment_twins']=cases
 # Body-specific gain bypass, even with correctly functioning reference probes.
 # Actual Sigma=k*S, body path 1/k before comparator -> identical to S.
 S=np.diag([.2,.8]);q=exact_probabilities(S,.4,.9)
 res['reference_bypass_twin']={'reported_trace':float(recover(q)[1]),'actual_trace_factor_4':float(4*np.trace(S)), 'probabilities_identical':True}
 # Calibration common-path mismatch r_b/r_c biases trace by that ratio (n=2).
 for k in (.1,.5,1,2,5):
  qbody=exact_probabilities(S,.4*k,.9);qbody[:2]=q[:2]
  assert abs(recover(qbody)[1]-k*np.trace(S))<1e-10
 res['common_path_ratio_checks']=5
 # Independently calibrated arbitrary gains: six modes when gains/backgrounds differ.
 arbitrary=0
 for i in range(400):
  B=rng.normal(size=(2,2));S=B@B.T+.05*np.eye(2)
  ra=float(rng.uniform(.1,.7));rb=float(rng.uniform(.9,2.));sa=float(rng.uniform(.4,.95));sb=float(rng.uniform(.4,.95))
  qa=exact_probabilities(S,ra,sa);qb=exact_probabilities(S,rb,sb)
  rra=np.log(qa[0]/qa[1]);rrb=np.log(qb[0]/qb[1])
  ya=((qa[0]/qa[2])**2-1)/(2*rra);yb=((qb[0]/qb[2])**2-1)/(2*rrb)
  tr=(rrb*ya-rra*yb)/(rrb-rra);det=(yb-ya)/(2*(rrb-rra))
  assert abs(tr-np.trace(S))<1e-9 and abs(det-np.linalg.det(S))<1e-9;arbitrary+=1
 res['six_mode_arbitrary_gain_checks']=arbitrary
 # Distribution-relaxed Laplace bounds with an independently supported second moment.
 bounded=0
 for i in range(1000):
  E=rng.uniform(0,20,size=10);w=rng.dirichlet(np.ones(10));r=float(rng.uniform(.001,1));ss=.8
  T=float(w@E);M2=float(w@(E*E));q=np.array([ss,ss*np.exp(-r),ss*(w@np.exp(-r*E))])
  low=(1-q[2]/q[0])/r;assert low<=T+1e-9 and T<=low+r*M2/2+1e-9
  er=min(1e-6,float(np.min(q))*.01,(q[0]-q[1])*.01)
  lo,hi=bounded_moment_interval(np.c_[q-er,q+er],M2)
  assert lo<=T+1e-9 and hi>=T-1e-9;bounded+=1
 res['nonGaussian_bounded_second_moment_checks']=bounded

 # Exact full OU covariance verifies inherited variance and current fitted body trace.
 count=0;cov_err=0
 for p,D,N,M in itertools.product([0.,.1,.4,.7,1.],[.1,1.],[0.,.01,1.],[0.,.2,1.]):
  A=np.array([[-.2,-1],[2*p,-2.]])
  Q=np.diag([2*D,8*(N*p*p+M)])
  Cov=solve_continuous_lyapunov(A,-Q)
  cov_err=max(cov_err,abs(Cov[0,0]-body_variance(p,D,N,M)))
  assert np.max(abs(A@Cov+Cov@A.T+Q))<1e-9;count+=1
 res['OU_stationary_checks']=count;res['OU_max_error']=cov_err
 # Nonzero mean violates Gaussian polynomial model; keep detectable case.
 res['scope']={'centered_Gaussian_required':True,'within_quartet_gain_and_background_fixed':True,
 'same_path_reference_required':True,'no_phenomenal_target_inferred':True,'full_map_audit_complete':False}
 (out/'PROOF_CHECKS.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n');print(json.dumps(res,indent=2))

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'results');main(ap.parse_args().out)
