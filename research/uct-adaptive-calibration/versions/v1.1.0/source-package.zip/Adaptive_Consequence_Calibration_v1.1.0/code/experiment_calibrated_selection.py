#!/usr/bin/env python3
"""Finite-sample reference-calibrated routing selection.

Each setting uses independent stationary body preparations, NOT one carried-state
adaptive biological trajectory. The selector sees only four empirical no-alarm
frequencies at each setting, C, and the known relative monitor gain 2.
The environment constructs Gaussian body states and mutable gain/background.
It never gives state values, plant parameters, or oracle optima to the selector.
"""
from pathlib import Path
import argparse,csv,json,platform
import numpy as np
import scipy
from calibration_core import *

GRID=np.linspace(0.,1.,21)
ENVS={'upstream':(.1,1.,0.),'downstream':(.1,0.,1.),'low_noise':(1.,.01,0.)}
SEEDS=list(range(910000,910032))

def environment_counts(rng,p,params,samples):
 D,N,M=params
 # Both change with p, but are not passed to the estimator.
 r=.2+1.8*p*p;s=.85-.1*p
 E=body_variance(p,D,N,M)*rng.standard_normal(samples)**2 + (1/7)*rng.standard_normal(samples)**2
 # Each of the four readings has samples outcomes. Body readings share E per draw.
 q0=rng.binomial(samples,s)/samples
 qc=rng.binomial(samples,s*np.exp(-r))/samples
 q1=np.mean(rng.random(samples)<s*np.exp(-r*E))
 q2=np.mean(rng.random(samples)<s*np.exp(-2*r*E))
 return np.array([q0,qc,q1,q2])

def select_from_counts(rows):
 raw=np.array([1-q[2] for q in rows])
 fitted=np.array([recover(q)[1] for q in rows])
 valid=np.isfinite(fitted)&(fitted>=0)
 if not valid.any():raise RuntimeError('No estimable score: no recommendation')
 scores=np.where(valid,fitted,np.inf)
 return int(np.argmin(raw)),int(np.argmin(scores)),fitted

def main(out,samples,seeds):
 out.mkdir(parents=True,exist_ok=True);summary={};allrows=[];finals=[]
 for ei,(name,params) in enumerate(ENVS.items()):
  for seed in seeds:
   rng=np.random.default_rng(seed+10000*ei)
   probs=[environment_counts(rng,float(p),params,samples) for p in GRID]
   rawi,cali,fit=select_from_counts(probs)
   for j,(p,q) in enumerate(zip(GRID,probs)):
    allrows.append(dict(environment=name,seed=seed,p=float(p),q_zero=q[0],q_ref=q[1],q_body=q[2],q_double=q[3],inferred_trace=fit[j]))
   rr=float(GRID[rawi]);cc=float(GRID[cali]);D,N,M=params
   finals.append(dict(environment=name,seed=seed,raw_p=rr,calibrated_p=cc,
     raw_differential_variance=body_variance(rr,D,N,M),calibrated_differential_variance=body_variance(cc,D,N,M),
     raw_trace=1/7+body_variance(rr,D,N,M),calibrated_trace=1/7+body_variance(cc,D,N,M),
     oracle_p=optimum(D,N,M),oracle_variance=body_variance(optimum(D,N,M),D,N,M),
     invalid_estimates=int(np.sum(~np.isfinite(fit)|(fit<0)))))
  ff=[v for v in finals if v['environment']==name]
  summary[name]={k:np.quantile([f[k] for f in ff],[.1,.5,.9]).tolist() for k in ('raw_p','calibrated_p','raw_differential_variance','calibrated_differential_variance')}
  summary[name].update(trials=len(ff),oracle_p=ff[0]['oracle_p'],oracle_variance=ff[0]['oracle_variance'],
    raw_better_trials=sum(f['raw_differential_variance']<f['calibrated_differential_variance'] for f in ff),
    invalid_estimates=sum(f['invalid_estimates'] for f in ff))
  print(name,summary[name],flush=True)
 for filename,rs in [('SELECTION_TRACE.csv',allrows),('SELECTION_FINALS.csv',finals)]:
  with (out/filename).open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
 result=dict(status='EXECUTED_FINITE_STATIONARY_PREPARATION_STUDY',n_per_mode_per_setting=samples,
   modes_per_setting=4,settings=GRID.tolist(),seeds=seeds,results=summary,
   learner_inputs=['candidate setting','four measured frequencies','known reference squared amplitude C=1','relative gain 2'],
   not_given=['r(p)','s(p)','body state values','D,N,M','variance formula','oracle setting'],
   limitations=['independent stationary preparations are supplied','finite grid selection, not continuous online stochastic convergence',
                'sample cost is 4*n per setting','gain/background fixed within each setting','Gaussian radial monitor required'],
   versions={'numpy':np.__version__,'scipy':scipy.__version__,'python':platform.python_version()})
 (out/'CALIBRATED_SELECTION_RESULTS.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'results')
 ap.add_argument('--samples',type=int,default=65536);ap.add_argument('--trials',type=int,default=32)
 a=ap.parse_args();main(a.out,a.samples,SEEDS[:a.trials])
