# Work log — UCT-GD v1.1.0 final revision

Date: 13 October 2026. Request: further refine the final manuscript for DOI deposition. Starting artifact: actual v1.0 source/PDF/code/results package. Original artifacts were not overwritten.

Actions: read repository research guidance and branch identity; inspect all manuscript sections and supplied code; render original critical pages; independently rerun all three original programs; derive shared-path anisotropy and known-metric ambiguities; prove reference-span calibration and actual input equalization with residual bounds; add explicit noncentral formula; implement validated probability/metric interfaces; audit simultaneous evidence over all candidate settings; run and repeat final verifier; update English manuscript, claims, source ledger, deposit templates and disclosures; rebuild and render final PDF.

Observed: original five outputs match byte-for-byte. Final verifier adds three matching repeat outputs. Joint audit accepts 4 upstream changes and no changes in two already-optimal baseline environments, over 32 runs each. No unsupported statistical efficiency, online synthesis or biological outcome is claimed. Mathematical proofs remain distinct from finite verification.

Failure: a streaming execution mode was unavailable; no computation is credited to it. Subsequent counted commands executed synchronously. A minor grammar defect introduced during editing was corrected before final freeze. No scientific assertion failed in the verified runs.

Source access: primary one-bit covariance, reward-tampering, self-calibration and quadratic-measurement literature checked as logged. Homeostatic-learning primary pages were challenged this round; earlier review not represented as newly repeated. Map scope: full historical semantics not re-audited; official UCT-MAP-v1.1.2 unchanged and GD candidates disabled.

Deposit decision: final scoped preprint preparation, not publication. No new DOI, OTS or Arweave. Next operational step: retrieve exact final package, verify hashes, confirm metadata/license, obtain actual deposit authorization and execute existing repository process; do not treat a handoff as full remote backup. Remote/local persistence scope is recorded in PERSISTENCE_RECEIPT.json.
