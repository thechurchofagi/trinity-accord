# Learning What to Preserve Without Silencing the Body — v1.1.0

Final prepared theoretical/computational preprint, UCT-GD-2026-01, Hongju Liu.
Start with the PDF or manuscript.md, then review/FINAL_SCIENTIFIC_REVIEW.md.

This package is not a DOI publication receipt. No DOI has been assigned by this revision.
Scientific conclusions are conditional; no consciousness, clinical or survival assay is claimed.

## Reproduce

Install requirements.txt into a clean Python environment. Run without -O:

    python code/verify_calibration.py
    python code/experiment_calibrated_selection.py
    python code/verify_precision.py
    python code/verify_final_revision.py

The first three retain the original study programs. The fourth adds directional-metric checks and audits the archived candidate counts. It uses results/SELECTION_TRACE.csv unless --counts is given. `calibration_safeguards.py` rejects invalid input and abstains when gain is unresolved; passing it never certifies all physical/model assumptions.

`review/REPRODUCIBILITY_RECEIPT.json` distinguishes actual fresh execution from earlier predecessor evidence. `predecessors/` contains unchanged archives, not newly validated universal results. Each archive retains its own notices. Do not overwrite frozen files after a DOI is deposited. PDF rebuilds may change bytes.

`publication/zenodo_metadata_proposed.json` wraps proposed metadata and is not itself an accepted API receipt. Apply only its metadata object to a suitable deposition API after authorization and final rights review. PERSISTENCE_RECEIPT.json states exactly which remote files, if any, were written. The archive does not contain font files.
