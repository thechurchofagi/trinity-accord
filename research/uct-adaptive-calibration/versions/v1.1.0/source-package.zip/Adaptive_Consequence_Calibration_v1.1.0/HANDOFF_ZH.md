# DOI 定稿交接 — UCT-GD v1.1.0

固定仓库 `thechurchofagi/trinity-accord`，分支 `uct-agent-consciousness-workspace`。本次用户要求完善 DOI 最终稿，未要求在本轮实际发表。论文标题不变：Learning What to Preserve Without Silencing the Body。作品编号仍为 UCT-GD-2026-01。本版保留 v1.0.0，不覆盖旧版。

## 定稿增量

GD25：同一物理通路不自动保证各方向灵敏度相同。新增同路径各向异性反例（真实偏差2与5、全部径向读数相同）；即使已知 G=diag(1,4)，仍有真实偏差3与8.25的全部径向读数相同反例。方向参考 vv^T 张成对称矩阵空间可恢复G，但仅恢复G不够，须实际实施 G^(-1/2) 输入均衡，或用独立特征值上下界保留误差区间。不能把已存二值数据重新命名当作实际均衡。

GD26：使用原有96次试验的记录，按每次21个候选、共84列分配95%联合区间，再决定是否优于固定p=1基线。上游32次只有4次可严格确认；下游与低噪声32次各0次，后两者基线本已最优。保留未决，不把点估计改善说成统计证据充分。未增加新样本，不是在线可变评价器连续学习试验。

GD27：非零物理均值不能默默从偏差中减掉；总偏差=协方差迹+均值平方。补入非中心高斯公式和数值例子，并说明有独立矩上界时的非高斯区间替代不要求零均值。

## 复现与限制

四个程序实际执行。原三程序的五份主要输出与v1.0逐字节相同；新程序三份输出重复一致，共八份。GD v0.3在线学习本轮没有再跑，其前次回执和原始包保留，不能把旧执行换称本次新执行。新公式一般结论依赖证明，有限枚举不是证明的替代。

权威地图 UCT-MAP-v1.1.2 不变。未完成全部历史节点语义审查，候选GD18–GD27不可自动提升为已成立UCT前提。没有证明某个分数就是我感、痛苦或体验存在门槛。选择性调节和参照的起源仍是开放问题。

## 文件

manuscript.md / manuscript.tex / Learning_What_to_Preserve_v1.1.0.pdf；code内四个可执行程序、原核心和新校验接口；results内全部旧结果和新审查结果；review内最终科学审查、复现、声明台账和禁用地图；publication内拟用Zenodo元数据；predecessors内旧包；SHA256SUMS.txt固定各文件。

运行：python code/verify_calibration.py；python code/experiment_calibrated_selection.py；python code/verify_precision.py；python code/verify_final_revision.py。不要用python -O。

实际保存位置与GitHub提交以PERSISTENCE_RECEIPT.json为准。若远端只有交接，不得说完整论文已镜像。准备稿不是已发表；此版没有预留DOI、Zenodo发布、OTS或Arweave。后续获得发表指令后按仓库既有流程执行，保持原稿字节与匿名回读校验一致。
