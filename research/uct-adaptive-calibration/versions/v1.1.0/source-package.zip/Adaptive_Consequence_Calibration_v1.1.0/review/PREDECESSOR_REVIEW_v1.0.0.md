# Final scientific review — UCT-GD-2026-01 v1.0.0

Internal human-directed, substantially AI-assisted audit. This is not an independent referee report or a certification that every possible objection has been exhausted.

## Decision

**Prepare as a single scoped theoretical/computational preprint, not another isolated GD checkpoint.** The claim is an integrated mechanism-and-identification analysis connecting regulation, formative learning, mutable evaluation, reference-based recovery and counterexamples. The added result is not a proof of experience, personal identity or the historical evolution of consciousness. It is suitable for author-reviewed DOI preservation within this scope. No DOI transaction has been performed.

The early single copying model did not merit its own paper. The current body of work answers a complete narrower question: when organizational adjustment also changes the apparatus evaluating its consequences, which stable reference relations and readings are sufficient, what remains unidentifiable, and what finite experiments reproduce the distinction? This provides a reusable problem/solution/limit package. Simplicity of the algebra and uncertain global priority are explicitly retained.

## Claim-by-claim hostile review

1. **Basal experience is not gated.** No minimum regulation quality, reference standard, report, action policy or calibrated score is made necessary for basal experience. C1/U1 remain theory-relative premises. The apparatus does not measure a quantity of consciousness.
2. **Formation is not phylogeny.** The route can adapt continuously, but the model is not a reconstruction of evolutionary history, infant development, or the emergence of every human self-related relation. No recapitulation claim.
3. **Installed architecture.** Body reference values, evaluator family, mode-switching and learning law are supplied. Only limited parameters adapt. The paper does not claim to evolve all values or all causal structures from nothing.
4. **Body objective is explicit.** Mean squared small-signal deviation is not universal fitness, survival, health, ethics or felt pain. Unbounded OU fluctuations are inconsistent with a literal risk-free survival interpretation.
5. **Noise twins.** The entire declared baseline observation law is equal at p=1. Complete physical organizations are not equal; noise locations differ. Equality after all possible interventions is not asserted.
6. **Variance and muting derivatives.** The Lyapunov identity and derivative signs are directly checked. The generic-k optimum uses (sqrt(a²+(D+k²M)/N)-a)/k, with N=0 handled separately. This correct form is in all final files.
7. **Adaptive convergence.** The one-dimensional expected stationary-feedback statement is conditional. The finite noisy carried-state simulation demonstrates outcomes only under its recorded conditions; it is not a universal stochastic convergence theorem.
8. **Mutable monitor recovery.** r and s may change across held settings but must be fixed or separately calibrated within a mode block. Same body distribution, common input path and true relative factor two are required. Gaussianity is centered and known-dimensional, allowing arbitrary covariance orientation and PSD matrices.
9. **Four modes are not four bits.** Four population probabilities require repeated observations. The new experiments have an explicit large sample budget and an independent-stationary preparation assumption. No information appears without data or a physical reference.
10. **Calibration cannot damage unmodeled control.** Zero/reference probes go into the evaluation monitor, not the continuously operating regulator input. If a device changes the body with its probes, this model does not silently cover it.
11. **Six-mode repair.** Individually calibrated gains/backgrounds relax exact electronics matching but do not remove the shared-path or same-distribution premises. r1=r2 is explicitly excluded.
12. **Minimal query claim.** Necessity applies to predetermined positive radial gain points and arbitrary positive-definite Gaussian covariance, not arbitrary adaptive/directional measurements, known-rank families, bits or computational complexity. Real-root stability supplies valid covariance alternatives; numerical roots are merely illustrative checks.
13. **Physical reference.** An unknown fixed positive reference scale preserves rankings. An independently mutable one does not. The reference need not be external, but its relation must be maintained. Same-path calibration is not self-authentication under unrestricted branch manipulation.
14. **Non-Gaussian counterexample.** Exact rational weights reproduce both body-mode moments and hence all four monitored probabilities while mean squared deviation grows without bound. Covariance positivity and algebra checks cannot certify Gaussianity. This failure is printed, not excluded after seeing the result.
15. **Distribution-relaxed bounds.** A supported second-energy-moment bound yields a valid interval; lower gains trade truncation error against sampling error. The moment bound is independent physical information, not free. The Gaussian exact-recovery theorem and the bounded-moment alternative are different routes.
16. **Finite confidence.** Deterministic interval coverage is conditional on valid joint probability intervals. Exact binomial intervals require independent trials; union bounds must cover all candidates when selecting. A contradictory negative trace interval is rejected. NO_SCORE is not zero cost.
17. **Near muting.** r=0 erases all bodily information from these readings. The O(r²) one-bit local divergence statement assumes fixed 0<s<1; no universal rate at s=1 is asserted.
18. **Temporal precision.** The covariance formula uses joint stationary Gaussian states and fresh comparator randomization. It does not validate binomial IID confidence intervals during arbitrary adaptation.
19. **New study vs old study.** GD0.3 is carried-state online learning with fixed calibration. GD1.0 finite selection uses independent stationary preparations and changing calibration. Both were run, but their unexecuted synthesis is not described as already demonstrated.
20. **Evaluation after selection.** Reported final bodily performance is computed from the selected setting under the specified physical model, separately from the noisy score that selected it. Exploration costs and finite-selection safety are not claimed to be included.
21. **Comparator and budget.** Raw-alarm selection deliberately ignores additional calibration modes. It is an interpretable failure baseline, not the best alternative estimator; there is no efficiency-superiority claim over one-bit covariance literature.
22. **Prior art.** Homeostatic reinforcement learning, reward-tampering causal diagrams, extremum seeking, one-bit/dithered covariance methods, self-test devices, Gaussian transforms, polynomial interpolation and moment bounds are credited. The precise integrated application may be useful without an invented claim of new mathematical foundations.
23. **Metadata and publication.** A completed PDF is not a DOI. Proposed license and metadata remain proposed; prior archive notices persist. No old paper is changed. The authoritative map is not promoted.
24. **Persistence.** A verified remote handoff does not imply a complete PDF/code mirror. Actual scope is recorded separately; local paths are not permanent public URLs.

## Executed verification

Three new scripts were run twice; five primary outputs matched. The old GD0.3 script was rerun and all six main outputs matched originals. Rational checks, full covariance solvers, stationary sampling and temporal-record simulation are distinct methods but all are internal execution, not independent corroboration. No assertion failed. Specific counts and tolerances are in the reproduction receipt and the main results, rather than inflated as measures of originality.

The model's main new experimental results are fixed-setting variance medians: upstream raw .41818 versus calibrated .36364; downstream 2.90260 versus .87879; low upstream 3.05253 versus 1.21970. Each is over 32 seeds, not measured physiology. Other conditions, cost constraints or misspecification can change the comparison.

## Scope left open

A full combined online learner with mutable calibration, carried state, simultaneous uncertainty control and measured exploration cost is not implemented. Endogenous maintenance of references, biological selection of monitoring architectures, arbitrary distribution recovery, unknown-dimensional bodies, and any selected phenomenal interpretation remain open. No one of these is hidden behind the word "self".

The full 913-node historical UCT semantic audit has not been re-performed. The finite GD claim layer is disabled for automatic inference and the completed-map version remains unchanged. This does not undo the proofs stated with explicit premises, but it prevents false integration claims.

## Editorial and operational repairs

The initial general-k optimum expression was corrected before final validation. A failed first LaTeX build due to early hyperref use was fixed without changing scientific content. Needspace was used to keep formula introductions and theorem statements together. The unsupported streaming tool attempt was replaced by synchronous runs. The final PDF was rendered across all 18 pages; important equations and result tables were viewed at full rendered-page size. Fonts are embedded, no overfull boxes remain, and no standalone font files are in the deliverable.
