# Final scientific and deposition-readiness review — v1.1.0

**Work:** UCT-GD-2026-01, Learning What to Preserve Without Silencing the Body.  
**Date:** 13 October 2026.  
**Review status:** internal, author-directed and substantially AI-assisted; not independent peer review.  
**Decision:** final scoped theoretical/computational preprint prepared for DOI deposition. No DOI has been reserved or published by this revision. The original v1.0.0 package is preserved unchanged.

## 1. Scope of this review

The actual v1.0 PDF, complete manuscript source, original three numerical programs, generated results, predecessor review and metadata were inspected. Repository guidance and current research-branch identity were read through the connected GitHub service. Original calibration, selection and precision programs were executed afresh; five primary outputs reproduce the supplied v1.0 bytes. The GD v0.3 adaptive experiment was NOT freshly rerun again in this revision; its immutable archive and prior v1.0 re-execution receipt remain evidence of that earlier execution only. The manuscript now states this chronology explicitly.

The main scalar radial theorem, the fixed-query gain-count theorem and the non-Gaussian moment-twin construction survived review in their stated domains. No independent confirmation of the UCT identity axiom or a particular experience is claimed. A complete historical all-node UCT semantic audit was not performed and no map completion version is promoted.

## 2. Substantive changes

### GD25 — Same path does not establish isotropic measurement

The original formula assumes exp(-r ||x||^2) in a fixed physical metric. A shared wire is not proof of that assumption. The new Proposition 5 uses exactly shared input paths: (Sigma,G)=(I,I) and (diag(1,4),diag(1,1/4)) have the same reference e1 and the same body probability at EVERY radial gain, although true traces are two and five. This does not refute the original theorem because the second transducer violates its explicitly isotropic premise; it prevents applying the theorem outside that premise.

A stronger obstruction persists even when G is exactly known. G=diag(1,4), Sigma_a=diag(1,2), Sigma_b=diag(8,1/4) share weighted eigenvalues {1,8}; all radial body gains and all same-device references match, but physical traces are three and 8.25. More accurate gain calibration alone cannot recover the missing orientation information.

Theorem 6 adds a constructive but conditional repair: zero plus directional reference vectors whose vv^T span the symmetric matrices determine G by classical polarization. The vectors e_i and e_i+e_j give n(n+1)/2 reference directions. A PHYSICALLY implemented H=G^(-1/2) then restores an isotropic evaluation input without redefining physical body coordinates. Numerical re-labeling of already recorded radial bits does not implement this repair. Singular metrics do not admit the inverse. Known reference directions, held calibration, no feedback effect on the plant and actual actuator/evaluation-path support remain required.

For imperfect equalization K=H^T G H, independent eigenvalue bounds k_L I <= K <= k_U I give J/k_U <= tr(Sigma) <= J/k_L where J=tr(K Sigma). This is an interval, not a point guarantee. The interval becomes unbounded if the required positive lower sensitivity bound is absent. Finite directional calibration and physical implementation error are not claimed solved by exact-population numerical examples.

### GD26 — Actual improvement versus evidence sufficient to recommend it

The original point-estimate comparison selected the empirically smallest recovered score. Its success under the known simulator is retained without being recast as a confidence certificate. The final revision applies the paper's already stated simultaneous-interval rule to all 21 candidate settings: 84 mode columns per seed, with overall alpha=.05 per decision family.

The same archived samples, not new data, yield certified improvement over the fixed p=1 incumbent in 4/32 upstream runs and 0/32 downstream and low-noise runs. The latter two incumbents are already population-optimal, so withholding a change is appropriate. All 2,016 tested intervals happened to contain the simulator truth, and no accepted change was worse; this is not a claim of 100% universal coverage. Coverage is 95% per family under its assumptions, not one joint 95% guarantee for all 96 families. Unresolved comparisons retain the baseline rather than being assigned zero cost.

This conservative audit is NOT a statistically optimal method, an online variable-evaluator learner, or a survival/safety certificate. Transient and exploration cost, arbitrary temporal dependence, policy adaptivity and model misspecification remain outside the theorem. A more efficient likelihood-based method is possible future work, not an executed result.

### GD27 — Mean offsets and fixed target references

The exact calibration target was clarified as fixed dimensionless physical deviations. A nonzero Gaussian mean contributes ||mu||^2 to total squared deviation and adds the standard exponential term to the Gaussian quadratic transform. The example mu=(1,0), Sigma=diag(.2,.4), r=.5, s=.8 has actual deviation 1.6 while misapplying the centered formula gives about .97363. The paper does not silently remove a physical setpoint error by recentering observations. The independently moment-bounded non-Gaussian alternative covers total energy without a zero-mean premise.

## 3. Computational and input checks

Four programs were executed synchronously. The three inherited programs reproduce their five original primary outputs. The added final verifier was run twice and its three primary outputs match exactly. Eight final output files therefore have exact repeat receipts.

The new checks include: three symbolic directional/metric examples; 400 metric reconstructions across dimensions 2–6; 1,200 equalized body probabilities; 400 nonideal metric bounds; five full-rank reference designs; 500 valid score-box enclosures; 13 malformed inputs; two explicit abstention/inconsistency cases; and all 2,016 archived candidate settings. General results rely on proofs, not these finite counts.

`calibration_safeguards.py` is an additional validated interface. It screens ordered probability boxes, positive physical scales and positive-definite metrics; it does NOT prove Gaussianity or wiring authenticity, and does not claim to screen every possible incompatibility. The inherited point-estimate program is deliberately unchanged so its historical output is not silently rewritten. These are research tools, not deployment certification.

One requested streaming shell mode was unavailable. No result is claimed from that failed tool attempt; all counted executions used synchronous commands. No scientific assertion failed during the counted runs.

## 4. Originality, sources and theory scope

The contribution remains a mechanism/recovery/failure analysis in a particular mutable-evaluator setting. Gaussian integration, interpolation, polarization, inverse square roots, binomial confidence intervals and eigenvalue inequalities are inherited mathematics. The revision cites Chen, Chi and Goldsmith (2015) for established quadratic-measurement recovery work. It neither reproduces that paper's claimed efficiency nor invents a new foundation for covariance estimation.

The previous literature-access ledger is retained, and new access is documented independently. Several primary records were revisited; eLife and PMC pages returned browser challenges for the homeostatic-learning source in this round. No fresh full-text review of those blocked pages is claimed. Searches were targeted, not exhaustive; absence of a same-title result does not prove worldwide priority.

UCT motivation is preserved: regulation, calibration, learning and scoring are organizational relations, not new gates for basal experience. Continuity of a parameter family does not establish a phylogenetic route or continuity of every human experience label. Neither the body score nor a monitor's performance is identified with mineness, suffering, intelligence or a number of subjects. Existing C1/U1 commitments remain conditional theory premises, not empirically validated by this work.

## 5. Deposit and preservation boundaries

This revision is the same work, version 1.1.0, not an additional independent paper. It does not overwrite a published record or another manuscript. The DOI metadata is a proposal; the DOI field remains unset. The user asked for the final DOI manuscript, not a publication transaction in this turn. No Zenodo draft, publication, OTS proof, Bitcoin confirmation, Arweave upload, cost or timestamp is invented.

The final PDF must be deposited as the frozen file, not regenerated silently. Any actually reserved DOI inserted later changes the final bytes and requires a new final manifest and readback verification. After separately authorized publication, follow the repository's actual DOI -> OTS -> verified proof -> Arweave flow. Manuscript/code license proposals do not override notices inside unchanged predecessor archives.

## 6. Remaining limitations

The origin and endogenous maintenance of the installed reference architecture are open. A combined online, carried-state, confidence-certified learner with mutable calibration was not executed. Full unknown-dimensional or unrestricted-distribution recovery is not supplied. Directional calibration does not solve general sensor tampering. The work is ready for a scoped preprint deposit; it is not a final solution of consciousness, a universal theory of physiological value or a claim of independent peer review.
