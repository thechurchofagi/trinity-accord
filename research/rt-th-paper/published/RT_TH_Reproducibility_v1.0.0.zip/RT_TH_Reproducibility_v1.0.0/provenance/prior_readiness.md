# Paper readiness and exact overlap boundary

**Review date:** 9 October 2026. **Research result:** RT-RESULT-v0.2.0, combined with TH-v0.1.0 and its explicit map-only clarification. **Decision:** PREPARE_BOUNDED_COMBINED_DRAFT; HOLD_PUBLICATION.

The material supports a self-contained theoretical manuscript about task-relative continuity through changing representations. It does **not** establish a new consciousness axiom, an experimentally verified phenomenal law, a unique subject criterion, or historically novel invariant theory.

## Contribution against previously published and project work

| Candidate contribution | Earlier source | What may be retained here |
|---|---|---|
| Every admitted actual process has experience; embedding preserves continuing local experience | UCT I C1/U1/P3 | Inherited premise and boundary, not novelty |
| Fixed genuine capability differences imply full experiential type differences | UCT III C:P1 | Conditional application only; no scalar strength claim |
| Global loops can obstruct tracking | Published TA19 §5, monodromy fixed-sheet necessity | Mathematical antecedent explicitly cited; route action here is on task states, not selves |
| A selected target can survive differences that do not preserve the full type | R149:NULL_TARGET; UCT III fiber sufficiency | Existing scope distinction applied concretely |
| Changing one code while compensating its reader preserves function | R177:COMPENSATED_FEATURE_PRESERVATION | Inherited single-route case; do not publish it again as new |
| Minimal adequate information is task-relative | C:P2_COORD; R127:P1; R133:MESSAGE_COVER; pending AC action-calibration record | Route-only tag count is a specialization, not a new universal principle |
| Shared-event charts must compose consistently | CG coherent-sharing work | Contrast with different-time transfers: a legitimate physical loop can change state |
| Relational memory can move; stale decoder and inaccessible information differ | TH preceding checkpoint | Include as an unpublished component with its original identity, not as independently rediscovered |
| One reader across unknown reversible routes | RT1/RT2 | Central organizing result: exact target invariance, quotient and proof under full-domain/no-side-source contract |
| Calibration cost, residual error, nonlinear preserved information | RT3–RT5 and S3 example | A checkable unified diagnostic suite with explicit counterconditions; specializations of classical mathematics |

## External comparison

Gao, Brodzki and Mukherjee (arXiv:1610.09051v3) already relate synchronization and holonomy. Rule and O'Leary (PNAS 2022, DOI 10.1073/pnas.2106692119) model readers tracking changing neural codes using plasticity and redundancy. Rule et al. (eLife 2020, DOI 10.7554/eLife.51121) address stable task information despite changing activity. Grover and Bourgerie (arXiv:2607.19514v2, 2026) distinguish sensitivity to learned connections from evidence that holonomy itself mediates a task. Access scope is documented in the research note. These works prevent a claim that changing-code continuity or holonomy-based reasoning itself is new.

## Why a draft is reasonable

The combined TH/RT argument answers one bounded question with matching definitions, a positive criterion, calibration requirements, quantitative consequences and failed-assumption controls. It replaces a vague demand for an unchanging core with testable *task-relative* conditions without deleting local experience or confusing representation with full ontology. An independent reader can reproduce all model claims and disagree with the conditional UCT interpretation separately.

## Why immediate public release is not yet recommended

The distinctive value is synthesis and explanatory application; the exact combination's historical priority is unverified. A fuller theorem-level comparison of the nearest synchronization/invariant-statistics literature could further narrow the novelty claim. The finite constructions do not identify any real human quale. The current paper draft needs an independent mathematical/interpretive critique, source-access completion and an explicit decision on whether to publish as a modest theoretical synthesis rather than a foundational consciousness breakthrough. Large new human experiments and a unique-subject theory are **not** prerequisites for writing this bounded paper.

No DOI reservation, journal submission, OTS request or Arweave payment is performed. The existing MGTD methods paper is a separate published work and has not been edited.
