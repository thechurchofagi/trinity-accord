# Task-Relative Continuity Through Changing Representations
## Reversible Handoffs, Route Ambiguity, and the Limits of Stable Readout

**Hongju Liu**  
Independent researcher, Shenzhen, China  
**Candidate manuscript:** RT-TH-PAPER-v0.1.0 · 9 October 2026  
**Status:** Unpublished discussion draft; not peer reviewed; no DOI assigned. Substantial AI assistance under the author's direction is disclosed. This draft organizes the RT-RESULT-v0.2.0 research note and the inherited TH checkpoint; it is not another independent result or completed external publication.

## Abstract

A physical component may continue to exist while losing a task-specific memory, and a memory may remain recoverable while an installed reader misinterprets it. The earlier TH checkpoint separated these cases for relational memory transferred between changing carriers. Here we add multiple reversible transfer routes whose identities are unavailable to a fixed reader. For a finite full-domain model, a common target decoder exists exactly when the target is invariant under all relative route transformations. The resulting orbit quotient describes every exactly retained target, rather than only linear readouts or complete-state reconstruction. Route metadata need distinguish only distinct target-reader functions; its minimum alphabet is their number. We give a sharp two-route average-error expression and an exact uniform-group decoding formula. A three-register example retains Hamming weight perfectly under unknown permutations while permitting only 3/4 optimal recovery of the original first bit and 1/2 optimal recovery of the full ordered state. This also exposes the inadequacy of interpreting the dimension of invariant linear readouts as the total preserved information. We distinguish actual temporal transfer from coordinate identifications of the same event, and apply the results to UCT only conditionally on independently grounded processes and targets. The mathematics is largely classical invariant theory and statistical decision theory. The contribution is a scoped synthesis and a reproducible continuation of the project's existing arguments, not a claim that holonomy, dynamic cores, calibration, or factorization are newly discovered.

## 1. The precise question and inherited commitments

The question is not whether a register, cell or system becomes experiential only after acquiring a stable reader. UCT I v1.2 C1 is a tokenwise structural–experiential identity commitment; U1 gives nonempty experience to admitted actual processes. P3 distinguishes genuine termination from persistence while embedded in a larger process [U1]. A local process whose memory coding changes need not cease to exist. Conversely, persistence of its material carrier is not a proof that a particular former content is preserved.

TH20261009-v0.1.0 already established three scoped possibilities: shared-mask transfer preserves a relational target; an invertible reversal preserves recoverability but defeats an uncompensated reader; independent refresh removes target information from the stipulated complete reading cut [T]. Its finite-field rank criterion concerns uniform linear signal-plus-noise channels. It does not cover every nonlinear target or every unknown family of invertible recodings.

R177 already proves single-map compensated decoding. CORE/CG already handles consistent identifications of shared physical events and interface-complete assembly. R149 distinguishes target-preserving equivalence from complete-type preservation. TA19 already uses monodromy for global subject tracking. AC20261009, a separately pending record, counts calibration ambiguities for unknown action-port permutations [U2–U5]. None of these should be presented again as a new finding.

The remaining concrete question is: **when several actual handoff routes are possible, what can one reader preserve without knowing which route occurred, and what route information is minimally needed for a fixed target?** The route can be a chain of actual transformations, not merely a label assigned to a stored state. A mathematical route family becomes a physical claim only after mechanism, episode, ports and information access are independently justified.

## 2. Model and boundaries

Let X and Y be nonempty finite sets of equal size. Let P be a nonempty finite set of routes, each with a bijection T_p:X→Y. Fix a target f:X→A, with finite image. Every x is allowed on every route: the comparison domain is the Cartesian product P×X. The reader observes y=T_p(x), knows the family, and must return f(x). It has no route identity, timestamp that reveals the route, retained mask, external answer source, or other route-correlated information. The reader is chosen before the particular p and x.

This is a zero-error contract first, requiring correctness for all p,x. Probability distributions are introduced only in Sections 6–7. A bijective route need not preserve f or any particular physical role. It only preserves the full source state conditional on knowing the route.

A task target is independently fixed: changing the target from the original first bit to the number of set bits changes the task. Such a change may provide a useful alternative, but it is not a solution to the first task. An observer's target f is not automatically a named quale.

For a diagram of interfaces with invertible edge transfers, all compositions considered must respect their source/target types. Repeated traversal of a feedback loop occurs at different times; an unrolled event graph can remain acyclic. Reversing an edge in an algebraic comparison need not mean that the physical implementation can run backward. The finite family of actually admitted routes, not arbitrary imagined paths, defines the application.

## 3. Exact target-preserving transport

Fix a reference route p0 and let H_p=T_p0^{-1}∘T_p be a permutation of X. Let Γ be the group generated by the H_p.

### Proposition RT1 — route-blind decoder criterion

There is a single decoder d:Y→A satisfying

    d(T_p(x)) = f(x)     for every p∈P and x∈X                         (1)

if and only if

    f(γ(x)) = f(x)       for every γ∈Γ and x∈X.                       (2)

When it exists, d=f∘T_p0^{-1} works.

**Proof.** Equation (1) on the reference route uniquely determines d on all Y, since T_p0 is onto. Substitution on route p gives f∘H_p=f. Invariance under a bijection implies invariance under its inverse, and composition preserves invariance, so all Γ leave f invariant. Conversely, (2) implies f∘H_p=f for each route, and the proposed d satisfies (1). No source probability is used. ∎

Equivalent pairwise form: the reader functions r_p=f∘T_p^{-1} must all be equal. Relative transformations are the finite-route analogue of loop transport. In a connected graph where reverse transformations are admitted algebraically, existence of compatible interface readouts follows by choosing reference paths and requiring all loop transports to preserve the target. It is unnecessary for every loop transport to be the identity.

**Important special cases.** For full-state recovery f=id_X, (1) requires all T_p to be the same map. For a selected target, different T_p can be harmless. For one known route, compensation is immediate; that is the inherited R177 result, not the present multi-route obstruction.

### Proposition RT2 — maximal retained target algebra

Let π:X→X/Γ assign each x its Γ-orbit. Then a target admits a common decoder exactly when it factors as f=bar_f∘π. Thus the orbit quotient retains every exactly route-insensitive distinction; if it has k orbits, there are 2^k invariant Boolean targets.

**Proof.** Condition (2) is exactly constancy on each orbit. Define bar_f on each orbit by any representative. Conversely any such factor is invariant. Assigning independent Boolean values to k orbits proves the count. ∎

This is ordinary quotient factorization [U2, E1]. “Maximal” is relative to the stated blind-reader route family, not a maximal conscious subject or a privileged physical grain. Knowing all f-values for invariant targets still need not reconstruct the source state or full physical organization.

### A crucial distinction from CG

CG identifies multiple descriptions of **one and the same event**. Those identification maps must compose consistently; a nontrivial return that identifies two distinct states violates that proposed atlas. RT instead compares **different actual transfer histories**. A route may legitimately change a state on returning to an interface. Nontrivial loop action is not a contradiction in the physical process. It becomes an obstruction only to a specified path-independent decoding requirement. Applying CG's identity condition to every physical temporal loop would forbid ordinary computations such as toggling a bit.

## 4. How much calibration information is required?

Suppose a tag c(p) is delivered with y. The tag is a deterministic function of the route, not of x, and each tag selects a preinstalled decoder. The original full-domain assumption remains.

### Proposition RT3 — exact route-tag alphabet

The smallest number of tag values that allows exact f-recovery is

    L_min = | { f∘T_p^{-1} : p∈P } |.                                (3)

**Proof.** All routes receiving one tag must share a decoder. Since every route reaches every y, they must have identical reader functions on all Y. Hence each distinct function requires a distinct tag. Conversely, tag the equivalence class of r_p and install that function as decoder. ∎

For several future targets, replace f by their joint answer vector. A smaller task family can require fewer route labels. For a full finite group Γ acting on X,

    L_min = |Γ| / |Stab_Γ(f)|,
    Stab_Γ(f) = {γ : f∘γ=f}.                                         (4)

This is the orbit–stabilizer identity for the action on reader functions. Equations (3)–(4) are applications of existing task-fiber/calibration mathematics, including C:P2_COORD, R127:P1, R133:MESSAGE_COVER and AC, not an independently new information-theoretic principle [U2, U5].

The tag's construction, memory, timing and communication are not free. If the route occurred without an observable or retained trace, the theorem gives a required distinction, not a mechanism that magically discovers it. Adding a tag changes the reader's information interface; compare full systems under a common resource contract before using a UCT fixed-J implication.

**Restricted-domain counterexample.** With X={0,1,2,3}, f=(0,1,1,0), routes I and T=(1,0,2,3), and route-specific supports {0,2} and {0,3}, one decoder d=(0,0,1,0) succeeds without a tag. The full-domain reader functions differ. Thus (3) cannot be applied after silently replacing P×X by a narrower route-dependent domain.

## 5. Linear readouts do not exhaust retained content

For X=F_q^d and invertible linear relative transfers H_1,...,H_k, scalar linear targets have the form f_l(x)=l x. They are invariant exactly when l(H_i−I)=0 for every generator. Therefore

    dim { invariant scalar linear readouts }
      = d − rank [ H_1−I | H_2−I | ... | H_k−I ].                      (5)

**Proof.** The admissible row vectors are the annihilator of the sum of the images of H_i−I. Rank–nullity gives (5). Invariance under generators gives invariance under their group. ∎

Equation (5) counts a vector space of *linear readouts*. It does not count all invariant functions. In particular, the target quotient X/Γ need not be a vector-space quotient. Conflating (5) with total recoverable content would repeat the kind of model-class mistake exposed by the earlier OO nonlinear counterexample.

### Three memory positions with unknown permutation

Take X={0,1}^3 and let the route family be all six permutations of the three positions. Adjacent swaps generate this group and do not commute. The four orbits are states with Hamming weight 0, 1, 2, and 3, of sizes 1,3,3,1.

The number of set bits is preserved exactly without a route tag. The original first bit is not. All source states retain their conditional invertibility; no memory bit is destroyed merely by a known permutation.

| Target | Distinct route-reader functions | Route-blind exact? | Optimal untagged accuracy under the uniform contract |
|---|---:|---:|---:|
| Parity | 1 | yes | 1 |
| Number of set bits | 1 | yes | 1 |
| Original first bit | 3 | no | 3/4 |
| Full original ordered triple | 6 | no | 1/2 |

The invariant scalar linear space is only the parity direction (dimension one). Nevertheless the nonlinear Hamming-weight target has four possible values. There are sixteen invariant Boolean functions, not merely the two linear scalar functions. Four distinguishable categories can be represented with two fixed-length bits; this does not claim that their entropy under the uniform source is exactly two bits.

For the first-bit task, a three-valued tag tells which final position contains the original first bit. Full source ordering needs six route classes. The complete path through a large circuit may contain much more detail than either of these minimal task tags.

## 6. Quantitative error without exact calibration

### Proposition RT4 — sharp two-route average-error penalty

Let X be uniform, choose p or q with probability 1/2 independently of X, and expose only y. Define

    δ = |{ y : r_p(y) ≠ r_q(y) }| / |X|.

For any common decoder, including randomized decoders, its separate error probabilities satisfy e_p+e_q≥δ. The highest average success is

    A* = 1 − δ/2.                                                    (6)

**Proof.** At each y with differing required answers, a shared answer cannot be correct for both routes; the summed conditional error is at least one. Uniform bijections make y uniform on each route. Sum over y. Choosing r_p throughout attains equality in average error. Randomization can balance the two route errors when minimax balance is desired; deterministic minimax equality is not asserted in all finite cases. ∎

### Proposition RT5 — uniform finite-group Bayes law

If the actual route is independently uniform over all elements of Γ and X is uniform, then

    A*(f;Γ) = (1/|X|) Σ_{orbit O} max_a | O ∩ f^{-1}(a) |.            (7)

**Proof.** Given y, the compatible x fill its orbit with equal posterior probability: orbit–stabilizer gives the same number of group elements mapping each x to y. For each orbit choose the most common target value; average over its |O| equally likely output states. ∎

For the original first bit in the three-position example, target counts within the weight-one and weight-two orbits are 1 versus 2. Thus A*=(1+2+2+1)/8=3/4. For full ordered state recovery, one correct representative per orbit gives four correct representatives out of eight, or 1/2.

Equations (6)–(7) are not valid after an arbitrary change to the source or route probabilities. The exact invariant-target theorem does not need a uniform distribution; the quantitative formula does. Route-dependent source preparation can also reveal route identity through y, so the stipulated independence matters.

## 7. Passive recoding, actual change, and temporal side information

For source and destination relabelings a and b, let T'_p=b∘T_p∘a^{-1}, and f'=f∘a^{-1}. The existence of a common decoder, the number of reader classes, and optimal error with transported distributions are unchanged. Relative route groups are conjugated, and their orbits correspond. All physical ports, target meaning, noise and interventions must move with the description. Rewiring the actual device while leaving a task tied to the original physical source is not this passive operation.

A simple failure control illustrates the scope. With a bit target and routes identity or complement, y alone cannot decode the original bit exactly. If a retained clock/route bit p accompanies y, x=y XOR p is exact. The original impossibility was about the blind interface, not the joint state (y,p). In an actual recurrent system, the reader's state may already encode sufficient route history; it must then be included rather than declared absent by fiat.

This is consistent with TH's reused-mask control: an apparently lost memory can reappear because a correlated variable was omitted from the cut. Neither checkpoint proves universe-level information destruction, nor that information is absent whenever an experimental decoder fails.

If transfers are noninvertible, loss can occur within a known route before the present route-ambiguity issue arises. TH's linear signal/nuisance criterion and the original map's general fiber criterion supply the appropriate earlier test. RT does not solve arbitrary noisy or lossy transfer by calling it a permutation.

## 8. Conditional interpretation for UCT

The distinctions established here are target-relative physical-model distinctions: (i) persistence of a carrier, (ii) recoverability conditional on a transfer path, (iii) availability to a particular path-blind consumer, (iv) compatibility of its installed reader, and (v) continuity of a fixed task relation. None is identical by definition to having experience, retaining a human quale, or remaining one numerical subject.

Where a physically grounded actual comparison supplies common complete K, episode/time, mechanism, actual ports and consumer use, and a genuinely different isomorphism-invariant capability J under one fixed evaluation, original C:P1 gives a difference in complete experiential structural types under C1 [U1, U2]. Separately, a grounded K-definable temporal relation can be transported by R157's parameter-preserving structural correspondence. An abstract target f or a selected invariant by itself supplies neither actual realization nor a named phenomenal bridge.

**Positive consequence.** A target can survive considerable change of carrier coordinates or routing, provided all admitted relative transports preserve that target or the reader receives and uses adequate correction information. The requirement is target-specific: preserving count need not preserve order. This helps articulate why preserving one ability cannot establish full experiential identity, and why losing one input or one reader does not imply annihilation of the remaining processes' experience.

**No local exclusion.** Under U1/P3, an independently persisting local process remains experiential even if route ambiguity makes its former target inaccessible to a larger consumer. No fixed decoder, trivial holonomy, memory capacity, task score, global clock, or subject selector is added to the basal axiom. Type sameness, numerical token identity and lineage remain different questions.

## 9. Prior work and claim-level novelty

The group/holonomy theory of synchronization is a major mathematical antecedent. Gao, Brodzki and Mukherjee explicitly relate synchronizability to holonomy and group actions [E1]. The present target-stabilizing condition is weaker than demanding global identity synchronization, but follows from standard invariance and factorization. No first-priority claim for this mathematical extension is made.

Rule and O'Leary model how readout plasticity, redundancy and recurrent feedback can track changing neural codes [E2]. That does not contradict RT's blind arbitrary-route bound: their readouts have history and structured learning constraints, rather than an unknown arbitrary route with no compensating state. Rule et al. also examine stable task information despite changing population activity and possible readout-weight adaptation [E3]. These are relevant mechanisms/constraints, not empirical verification of RT or UCT.

Grover and Bourgerie's 2026 primary preprint measures and intervenes on learned connection/holonomy in sheaf networks, while explicitly distinguishing sensitivity to the learned connection from proof that holonomy itself drives the task [E4]. This reinforces why observing a mathematical structure and an output score is insufficient to establish actual mechanistic use or phenomenology. Only its current abstract/metadata were read here; no replication of its experiments is claimed.

Internally, TA19 already contains monodromy, R149 target-null equivalence, CG coherent gluing, R177 compensated readout, R127/R133 task-sufficient coding, and AC port-calibration counts. RT therefore contributes an **integrated task-sensitive transport analysis and exact diagnostic examples**, not a replacement of those results. TH adds the complementary stochastic-loss and migrating-support cases. The division of labor is recorded in `paper/PAPER_READINESS.md`.

A targeted search is not an exhaustive novelty clearance. A relevant informal 2026 sheaf/drift commentary was also encountered, but it is not used as theorem authority. The history of the exact synthesis remains unverified. No unsupported claim that competitors cannot express these cases is warranted.

## 10. MGTD application and map integration

The inherited 722 nodes, 343 active rules and 203 contexts were reviewed using full statement/scope packets; all ten suspended rule records were separately retained and inspected. This is a fresh all-item **compatibility** review with RT and TH, not independent reproof of every unchanged result or revalidation of external datasets. Exact unchanged source/proof records remain pinned. The resulting ledger has a decision and rationale per old item; reviewed-open premises remain open.

The review made two important changes to the proposed narrative. First, loop consistency and sufficient calibration cannot be claimed new given TA19, R149 and AC. Second, physical path transport must not inherit the identity-cocycle law of same-event CG charts. No old rule is reactivated and no new rule has an old conclusion as its head. Pending AC and R185 remain non-premise references, not silently completed modules.

The TH integration clarifies a conjunction: its original three specific refresh regimes and its general correlated-noise family must share a common protocol definition, not be treated as literally the same special-case parameter assignment. A separate `TH20261009:PROTOCOL_BASE` makes this explicit, and the correlation rule cites it. TH's mathematical results do not change.

The candidate map version is local until a repository write actually succeeds. A complete local audit and a hash-verified file are distinct from a remote commit. See `LOCAL_STATE.json`, `MAP_AUDIT.json`, `CHANGELOG.md` and the per-item `REVIEW_LEDGER.json` for exact census and status. C1, named-feeling bridges and QC10/IA-QC11/QC12/QC13 are not newly discharged.

## 11. Executed checks and reproduction

`python code/check_transport.py --output results/MODEL_RESULTS_rerun.json` uses the standard library and exact integers/Fractions. It checks 9,216 route/target cases against direct decoder enumeration, 9,216 minimal-tag partitions, 9,216 group-orbit Bayes values, 9,216 two-route error bounds, 576 invariant-algebra counts and 27,648 transported-coordinate cases. The invariant linear-space formula is tested on every pair of invertible 2×2 generators over F2 and F3 (36 and 2,304 pairs). The three-register noncommuting example and explicit failed assumptions are checked separately.

Counts refer to finite constructions, not independent evidence of a universal theorem or consciousness. General claims are supported by the written proofs. All inputs and limitations are retained. Earlier TH checks are rerun separately and labelled inherited regression, not counted as newly discovered results.

## References and source-access scope

[U1] Liu, H. (2026). Unified Consciousness Theory I, version 1.2. DOI 10.5281/zenodo.23131575. Frozen source `A_UCT_I_v1_2.md`, especially §§2–6. Physical actuality, C1/U1/P3 and selected-versus-complete interpretation retained.

[U2] Liu, H. (2026). Unified Consciousness Theory III, version 1.0. DOI 10.5281/zenodo.23137088. §5 on fixed-capability and fiber criteria, and the frozen v1.0.0 map's R127/R133/R149/R157 records. Sources and map reviewed, not newly empirically validated.

[U3] Liu, H. (2026). Selecting and Tracking Conscious Subjects: Symmetry, Monodromy, and an IIT 4.0 Case Study, version 1.0. Frozen source `TA19_v1_0.md`, §5. Explicit internal prior monodromy, not a new RT discovery.

[U4] Liu, H. (2026). CG20261008 coherent sharing/interaction checkpoint and R177 executed feature domain/compensation records. Frozen source commit 48b131a3ae8f7ac003ff5a2ce9c8d36111b2ea3c. Source text and current effective map read.

[U5] AC20261009 Action Calibration, research result v1.0.0; pending in branch head 11c1af83fa7e9eabca8351b67dfe162f59da7dd1. Handoff and exact summarized claims read through the connected repository; not an established premise or a full independent re-audit of AC.

[T] TH20261009, Temporal Handoff of Relational Memory, v0.1.0. User-provided prior research package. Original proof, model map and code preserved; this turn's integration changes are explicit.

[E1] Gao, T., Brodzki, J., and Mukherjee, S. The Geometry of Synchronization Problems and Learning Group Actions. arXiv:1610.09051v3 (2019; first submitted 2016). https://arxiv.org/abs/1610.09051v3 . Abstract/metadata read; no full theorem-by-theorem priority clearance.

[E2] Rule, M. E., and O'Leary, T. (2022). Self-healing codes: How stable neural populations can track continually reconfiguring neural representations. PNAS 119(7), e2106692119. DOI 10.1073/pnas.2106692119. Primary abstract via PubMed PMID35145024 and Cambridge repository; PMC direct full-text request met a browser challenge.

[E3] Rule et al. (2020). Stable task information from an unstable neural population. eLife 9:e51121. DOI 10.7554/eLife.51121. Publisher-indexed discussion read; direct webpage returned a browser challenge. No raw-data analysis.

[E4] Grover, A., and Bourgerie, R. (2026). Do Sheaf Neural Networks Use Holonomy? A Measure–Intervene–Control Study. arXiv:2607.19514v2, revised 22 August 2026. https://arxiv.org/abs/2607.19514v2 . Abstract/metadata read; no experimental replication.

**Publication decision:** sufficient material for a bounded combined theory draft and independent criticism, not sufficient evidence for a new foundational consciousness-law claim. No public release is initiated in this checkpoint.


## Draft declarations

The human author supplied the research program, conceptual constraints and originating thought-experiment discussions. AI assistance contributed literature comparison, derivations, finite checks and writing. Author-side compatibility review is not independent peer review. All empirical or named-phenomenal application obligations remain explicit. Approval of each final passage, external priority clearance and publication authorization are not represented as completed. The attached code is a finite mathematical verification package, not a consciousness experiment.
