# Temporal Handoff of Relational Memory
## Migrating supports, readout misbinding, and correlation-sensitive retention

**Research identity:** TH20261009 · result version **0.1.0** · 9 October 2026.  
**Project:** Hongju Liu's UCT experience–intelligence–self research.  
**Method:** MGTD methods preprint v1.0.1, DOI 10.5281/zenodo.23241982.  
**Inherited completed map:** UCT-MAP-v1.0.0, FA20261008.  
**Observed repository head:** `11607e7edd2893252aef362f2ac3a4195bc3d566`.  
**Status:** Analytic results and executed finite checks; **candidate map module, not an established map release**. No new DOI, OTS, Arweave transaction, or publication. Substantial AI assistance in analysis, coding, writing and audit. No independent peer review.

## 0. Question and research delta

The author's question is not which small component is entitled to have experience. UCT already assigns nonempty experience to every admitted actual process through C1/U1 and does not extinguish a continuing local process by embedding it in a larger one. The present question is narrower and operational: **what must persist for an earlier target to remain available to a later action when the physical memory carriers change?**

The prior CORE module distinguished target-relative minimal supports from a unique consciousness core. R184 studied target retention during obstruction. R185, a currently pending checkpoint, separates a shared occurrence from synchronized copies and asks about cross-scale role membership. The present note adds a temporal handoff witness with matched local records, a correlation-sensitive accuracy law, a complete-cut recovery criterion, and a counterexample that identifies the exact independence premise needed for irreversible loss. These results do not discharge R185's actual-membership or named-feeling obligations.

**Specific increment:** preserve, invert-but-retain, and erase a target through different joint handoff laws while matching every recorded single-register history and both endpoint population snapshot distributions. Derive an exact capability formula and distinguish stored information from an actually installed reader. Generalize through finite-field linear systems, and repair an initially tempting but false claim that target-independent future noise alone prevents recovery.

The mathematics is an application of established information theory, finite-field linear algebra, coding, and causal mediation. Dynamic cores and substrate replacement have major predecessors. Historical priority for this exact package is unverified; there is no claimed discovery of a new general consciousness law.

## 1. Frozen distinctions and scope

Four levels must not be merged:

1. **An actual physical process**, its episode, physical carriers, boundary ports, time, and complete constitutive organization.
2. **A scientific model or observation protocol** that represents selected parts of that organization.
3. **A task** about recovering an earlier target and using it in an output.
4. **A particular experiential relation or named feeling**, which is not identified by the task label alone.

The experiments below are finite mathematical constructions, not brain measurements. Carrier letters do not establish physical actuality. A real application must independently anchor registers, transition mechanisms, clock, noise sources, intervening transfers, actual readers and boundary inputs. A probability law is not automatically a complete description of one actual episode. A finite-field coordinate is not a phenomenal magnitude.

The goal variable is a uniformly distributed bit \(\tau\), initially supplied once. A scored action is correct exactly when its output equals \(\tau\). An **installed reader** is the declared actual algorithm in the model. **Best decoding accuracy** means the best estimator with access only to the specified retained observation. The latter can bound an installed reader, but an analyst's decoder is not thereby implemented in a real system.

A **complete causal cut for this task** includes all information, memory, side channels, retained random seeds and boundary resources that can influence the later reader. It need not be the entire universe. The relevant condition is that downstream processing has one source-independent conditional law given this cut. This is inherited in substance from R127:MEDIATION and R127:RECOVERY. The cut is not a subject boundary.

## 2. Thought experiment: a memory crosses to different carriers

Let \(\eta,\xi,\zeta\) be independent fair bits, independent of \(\tau\). At the initial time,

\[
(A,B,C,D)=(\tau\oplus\eta,\eta,0,0).
\]

Neither A nor B alone reveals \(\tau\). Together they do: \(A\oplus B=\tau\). All statements concern recoverable task information, not the presence or absence of either carrier's experience.

Use a two-stage, copy-before-clear protocol. First create new values in C and D while preserving A and B. Then reset the old A,B memory values. This supplies an explicit handoff interval rather than a magical disappearance at an instantaneous cut. Transfer machinery and clocks are part of any actual realization; no claim is made that the whole device has no stable necessary controller.

### 2.1 Shared refresh: the relation survives

Copy with a common fresh flip:

\[
C=A\oplus\xi,\qquad D=B\oplus\xi.
\]

After resetting A,B, the new pair still gives

\[
C\oplus D=\tau.
\]

The minimal **decoding** support at the initial endpoint is \(\{A,B\}\); at the final endpoint it is \(\{C,D\}\). Their intersection is empty. During the intermediate copy stage, both pairs are present. A physical removal claim requires the separately specified copy/reset implementation; minimum decoding supports are not automatically minimum lesion supports.

**Result TH-T1:** an exact target can be handed off between disjoint memory-register supports. A fixed permanently target-informative register is not a necessary condition of task-memory continuity in this model. This does not prove that every biological brain lacks a stable necessary network, that all components can be removed at once, or that numerical subjective identity is preserved.

### 2.2 Reversed refresh: the information survives but the reader is wrong

Change only the second rule:

\[
C=A\oplus\xi,\qquad D=B\oplus\xi\oplus1.
\]

Now \(C\oplus D=\tau\oplus1\). The unchanged XOR reader is always wrong. A predeclared compensated reader \(1\oplus C\oplus D\) is always correct.

**Result TH-T2:** failure of an installed reader does not imply loss of the target information. The convention mismatch is an actual encoding/consumer mismatch, not a mere passive renaming of a complete system. A passive recoding transports the reader as well and preserves its task.

### 2.3 Independent refresh: the target is no longer recoverable from the retained cut

Use independent flips:

\[
C=A\oplus\xi,\qquad D=B\oplus\zeta.
\]

Then \(C\oplus D=\tau\oplus\xi\oplus\zeta\), with the final parity uniformly independent of \(\tau\). The whole retained pair is independent of \(\tau\), not just its XOR. After clearing A,B and excluding any retained masks or correlated boundary source, **every** reader of C,D has optimal accuracy one half.

This is a theorem about a complete declared information interface. An experimental decoder that happens to perform at chance would not prove the same conclusion about a brain. Reset is coarse-grained: microscopic environmental records or heat are not claimed to vanish from the universe. Any such record that can reach the later reader under the declared resource/intervention contract must be included in the cut; otherwise the claimed completeness fails.

### 2.4 Exact matches and nonmatches

Across shared, reversed and independent refresh, the complete conditional distribution of **each single physical register's three-time recorded history** (initial, copy, reset), given each \(\tau\), is identical. The full four-register **unconditional** distributions at the initial and final endpoints are also identical.

The complete intermediate four-register joint distribution is **not** matched: it contains the old–new relation that distinguishes the mechanisms. Joint cross-register histories, joint noise sources, actual constituent rosters and complete open mechanisms are not matched either. One must not turn the observation match into complete-organization equality.

| Handoff / installed reader | Installed accuracy | Best accuracy from final C,D |
|---|---:|---:|
| Shared flip / XOR | 1 | 1 |
| Reversed flip / unchanged XOR | 0 | 1 |
| Independent flips / XOR | 1/2 | 1/2 |
| Reversed flip / compensated XOR | 1 | 1 |

This distinguishes **where the target is supported**, **whether it remains recoverable**, and **whether the installed reader uses the correct relation**.

## 3. A continuous family: correlation, not marginal noise rate

Let the two fresh flip variables be \(Z_1=\xi\) and \(Z_2=\xi\oplus E\), where \(E\sim\mathrm{Bernoulli}(\epsilon)\), \(0\leq\epsilon\leq1\), is independent of the past. Both \(Z_1,Z_2\) are fair for every \(\epsilon\). Hence every register's marginal noise statistics are unchanged. Their disagreement rate is \(\epsilon\).

The final readout is

\[
Y=C\oplus D=\tau\oplus E.
\]

For the unchanged XOR reader,

\[
J_{\rm installed}=1-\epsilon.
\]

For a decoder that knows the installed law and can invert its answer,

\[
\boxed{J_{\rm best}=\max(\epsilon,1-\epsilon)
=\frac{1+|1-2\epsilon|}{2}.}\tag{1}
\]

**Proof.** Conditional on C,D, the only source-dependent statistic is their parity: the independent uniform mask makes each of the two pairs of a given parity equally likely. The parity agrees with \(\tau\) with probability \(1-\epsilon\), and its complement agrees with probability \(\epsilon\). The Bayes-optimal choice gives (1).

At \(\epsilon=0\), target retention is exact. At \(\epsilon=1\), it is also exact but oppositely encoded. At \(\epsilon=1/2\), the final cut contains no target information. This is a functional distinction, not an experience-existence threshold. Synchrony magnitude or a shared rate of noise cannot by itself order task performance.

For k independent handoffs with fresh parity errors E_i, the final bit is \(\tau\oplus E_1\oplus\cdots\oplus E_k\). Therefore

\[
\boxed{J_k^*=\frac{1+|\prod_{i=1}^k(1-2\epsilon_i)|}{2}.}\tag{2}
\]

**Proof.** The signed parity expectation factors: \(\mathbb E[(-1)^{\oplus_iE_i}]=\prod_i\mathbb E[(-1)^{E_i}]\). Optimal inversion gives the absolute value. Independence across stages is essential. One perfectly random parity-error stage destroys task information at the declared complete Markov interface; many imperfect fresh stages degrade it. Physical elapsed time is not interchangeable with the number of computational handoffs, so this is not a consciousness-speed formula.

## 4. General finite-field recovery criterion

Let \(\tau\) be uniform on \(\mathbb F_q^d\), and let nuisance \(\eta\) be independently uniform on \(\mathbb F_q^k\), where \(\mathbb F_q\) is a finite field. A complete model cut is

\[
X=H\tau+G\eta+b,
\]

with fixed known matrices and a fixed known offset b. All source information available to the reader is in X. Define

\[
\rho(H,G)=\operatorname{rank}[G\ H]-\operatorname{rank}G.
\]

**Result TH-T3:**

\[
0\leq\rho\leq d,\qquad
\boxed{\sup_{\widehat\tau(X)}\Pr[\widehat\tau=\tau]=q^{\rho-d}.}\tag{3}
\]

Consequently perfect recovery is possible iff \(\rho=d\). Equivalently, a linear decoder D exists with \(DH=I_d\) and \(DG=0\) (and the known b subtracted).

**Proof.** Work in the quotient of the observation space by \(\operatorname{im}G\). The induced map \(\bar H:\tau\mapsto H\tau+\operatorname{im}G\) has rank \(\rho\). Given an observed X, compatible source states form a coset of

\[
K=\{\delta\tau:H\delta\tau\in\operatorname{im}G\},
\]

which has dimension \(d-\rho\). Uniform independent nuisance makes their likelihoods equal, and the prior is uniform. Exactly \(q^{d-\rho}\) target values have equal posterior mass, yielding (3), for arbitrary nonlinear or randomized estimators as well. If \(\rho=d\), \(\bar H\) is injective and its inverse on its image extends linearly to the quotient observation space, giving D. Conversely D forces injectivity.

This is standard linear information geometry applied to the specified target. It is not a measure of phenomenology. The probability is for the entire d-component target being correct, not the earlier OO parity-question average. The nonlinear/bent-function examples in OO therefore do not contradict (3): their encoder/model class and score contract differ.

For an installed linear observation port Z=RX, the same argument gives

\[
\rho_{\rm port}=\operatorname{rank}[RG\ RH]-\operatorname{rank}(RG)
\leq\rho_{\rm stored}.
\]

Even optimal downstream decoding cannot undo information discarded by the port. A fixed decoder can be worse still. This is the distinction between stored source discrimination, operative access, and correct use.

## 5. Composition, loss, and coordinate transport

Suppose a new complete cut is generated by

\[
X^+=FX+E\xi+c,
\]

where \(\xi\) is fresh and independent of the **entire previous source/noise history**, not merely marginally independent of \(\tau\). Its parameters are

\[
H^+=FH,\qquad G^+=[FG\ E].
\]

**Result TH-T4:** \(\rho(H^+,G^+)\leq\rho(H,G)\). No later processing with the same complete-cut Markov property can restore target distinctions lost at that cut without new information.

One proof is data processing; directly, every old indistinguishable source difference H delta-tau in im G remains indistinguishable after F and after new nuisance is added. Hence the kernel of the quotient source map can only grow.

Without new noise, define

\[
K_0=\{v:Hv\in\operatorname{im}G\},\quad
K_1=\{v:Hv\in\operatorname{im}G+\ker F\}.
\]

Then

\[
\boxed{\rho(H,G)-\rho(FH,FG)=\dim K_1-\dim K_0.}\tag{4}
\]

Thus a handoff can preserve connectivity and have many active components while losing exactly those source directions that become masked by its joint kernel. Counting paths does not compute (4).

For an invertible change of state coordinates S, both signal and nuisance transform, and

\[
\rho(SH,SG)=\rho(H,G).
\]

Preserving the actual task also transforms the reader and any future mechanisms, offsets and noise. Replacing an encoding but leaving the old reader or independent-noise placement fixed is a physical change, not passive coordinate covariance.

### 5.1 A branch-cancellation control

Suppose two distinct copies hold \(U=\tau,V=\tau\). Both retain the target, but an XOR consumer outputs zero. Removing one input from that consumer restores target recovery. The two retained memories have not lost \(\tau\); the selected readout has discarded it. Each incoming variable can affect the XOR gate under independent local perturbation even though changing the common original source changes neither final output value. No claim about a particular philosophical definition of actual causation is inferred from this example; the actual installed consumption mechanism must be recorded independently.

This demonstrates why constitutive participation, total source-to-output effect, and selected task benefit must be distinguished. It does not refute interface-complete composition, which already requires the correct joint operation.

## 6. An important failed generalization: repeated noise can restore an apparently erased target

Consider

\[
X_1=\tau\oplus E,\qquad X_2=X_1\oplus E=\tau,
\]

where E is a single fair bit independent of \(\tau\) reused at the next step. Looking only at X_1, best accuracy is 1/2; looking at X_2, it is 1. Each occurrence of E is marginally independent of the target.

This refutes the loose assertion that *noise independent of the target is enough to forbid recovery*. It does not refute TH-T4. The intervening interface X_1 omits the retained E that reaches the later consumer. The complete cut is (X_1,E), which perfectly determines \(\tau\). Equivalently, the second reused mask is not fresh independent noise conditional on the past.

This is an explicit MGTD repair: retain the counterexample, strengthen the independence/complete-cut hypothesis, and block downstream citations from silently dropping it. It is inherited in principle from complete-cut mediation and familiar one-time-pad cancellation, not newly discovered information theory.

## 7. What can follow for UCT, and what cannot

### 7.1 Positive conditional application

If an actual implementation independently supplies a same-episode, physically faithful organization and capability contract, then the shared versus independent handoffs have different true target-retention capabilities. Under C1 and the inherited fixed-J rule C:P1, their complete experiential structural types differ. Under the parameter-preserving C1 transport of R157, a physically grounded K-definable temporal transfer relation has a corresponding structural relation inside the admitted process's experience.

This is a **conditional organizational result**, not an independent validation of C1. An unmeasured probability kernel, an analyst's matrix or a finite code trace does not discharge actual realization. The source task tau is not identified with a quale.

### 7.2 Local experience is not deleted

When old memory values are reset, the old target relation may cease to be supported by those registers. If their local physical processes continue, U1 still applies to them. Likewise, independent refresh can destroy this memory while the refreshed local processes and the larger currently running organization remain actual. “No retained information about this target” does not mean “no experience.”

Nothing in the rank criterion is an admission or consciousness threshold. A cell, calculator or artificial agent is not excluded because it lacks this kind of memory. The result says nothing about all local experiences remaining unchanged after physical alteration.

### 7.3 Selected continuity is weaker than complete experiential identity

Preserving tau through a handoff establishes one target-relative continuity, not numerical identity of a first-person subject or equality of complete Phi across episodes. Source-lineage identity, relation-occurrence identity and numerical phenomenal identity remain separate. In particular, distinct refreshed or copied occurrences do not become one physical occurrence just because they carry the same bit; this respects the pending R185 distinctions.

The general lesson is conditional but useful: a stable experience-related capability can depend on a **temporally organized relation**, not one permanently informative material piece. Finding a universal human experiential core remains a separate task, not a precondition for this result and not something settled by this finite memory model.

## 8. Existing neuroscience and adversarial comparison

Tononi and Edelman already formulated a dynamic-core hypothesis [1]. Chalmers' organizational-invariance thought experiments already analyze neuron replacement [2]. Hence neither dynamic membership nor replacing components while retaining a pattern is a first claim here. UCT differs in its stated non-exclusion of basal local experience, but this note does not establish that it outperforms those theories empirically.

Murray et al. found stable population-level working-memory coding alongside heterogeneous temporal activity of single neurons [3]. This is compatible with separating stable target information from fixed individual activity patterns. It neither demonstrates the four-register handoff nor verifies unchanged subjective experience.

A particularly relevant limitation is that their population analysis uses a pseudopopulation. It cannot, by that fact alone, settle a same-trial cross-unit noise-correlation claim of the kind that distinguishes our handoff twins. The present theoretical counterexample specifies an evidential requirement; it is not a reanalysis of their raw data or a criticism that their own stated conclusion is invalid.

Finite-field network transfer has extensive prior theory [4]. Our rank and noise calculations are explicit specializations. A successful formal witness is useful as a research constraint even when its mathematical ingredients are known. The publishable novelty of the full UCT interpretation is not established by the search performed here.

## 9. MGTD record of this cycle

**D0, initial question:** Does continued target-guided action require a fixed informative memory part, and can local activity certify successful handoff?

**D1, opposing witnesses:** Shared, reversed and independent copy/reset protocols refute both “fixed memory carrier necessary” and “matching local records sufficient.” The contrast is about a specified task, not subjective disappearance.

**D2, conditional repair:** A complete-cut separation criterion, and its finite-field rank specialization, identify when the target is retained. The installed reader is checked separately.

**D3, adversarial refinement:** The reused-mask counterexample shows that marginal independence from the target is inadequate. Complete causal mediation or fresh history-conditional randomness is retained as a simultaneous premise.

**D4, map audit and freeze:** The entire v1.0.0 graph and 1,278-item review ledger were loaded locally from the hash-verified supplied archive. Existing records are unchanged; global ID/reference/active-suspension checks and a fresh-namespace conservative-extension check are executed. Relevant old assumptions and proofs are specifically compared to the new claims. However, a new manual item-by-item semantic review of every old record has **not** been performed. The inherited v1.0.0 judgments remain historical evidence, not a new completed audit. Thus the new map module remains `PENDING_MAP / AUDIT_INCOMPLETE`; no completed map-version pointer is advanced.

This is not reported as a completed full MGTD integration. It is a versioned research checkpoint with successful finite checks and explicit unfinished integration obligations.

## 10. Executed checks and reproducibility

Run:

```text
python code/check_handoff.py --output results/MODEL_RESULTS_rerun.json
python code/check_map.py --root .
```

The first command independently computes finite source-to-state distributions using exact integer/Fraction arithmetic. Executed scope:

- 6,666 matrix/Bayes cases over the tested fields F2 and F3;
- the four handoff/readout variants with equal conditional single-register histories;
- 6,400 dynamic fresh-noise monotonicity checks;
- 1,408 invertible-recoding and exact-loss checks;
- 21 rational correlation-parameter cases and 125 independent three-stage sequences;
- duplicated-route cancellation and reused-noise/omitted-side-channel counterexamples.

An initial test compared string representations of Counters, which incorrectly depended on insertion order. It failed and was corrected to compare the actual distributions. This software failure is retained in `results/FAILED_CHECK_HISTORY.md`; it is not recast as a theoretical discovery.

The second command checks map wiring and enumerates candidate open-obligation frontiers. It does not perform natural-language semantic review. The package retains the exact completed base map and ledger so the reader does not need to reconstruct them from a partial excerpt.

## 11. Next decisive question and stopping boundary

The next scientific question is not “how can we add more information-theory nodes?” It is whether one independently specified, experience-related temporal target in an actual biological or artificial episode has a grounded transfer/consumer relation that can distinguish latent retention from actual use. The full map review must first be completed before this candidate is promoted. A neural decoder or self-description alone will not supply the missing bridge.

The present result is material for a future paper. It is not enough to announce an independent major consciousness breakthrough or to publish a new DOI automatically. No proof of individual qualia, a unique subject, an experience scalar, or model consciousness is claimed.

## References and read scope

[1] Tononi, G., and Edelman, G. M. (1998). Consciousness and complexity. *Science*, 282(5395), 1846–1851. DOI: 10.1126/science.282.5395.1846. Primary abstract and author lab bibliographic entry read. Related original exposition: Edelman, G. M., Gally, J. A., and Baars, B. J. (2011), Biology of Consciousness, *Frontiers in Psychology*, 2:4, DOI 10.3389/fpsyg.2011.00004, publisher HTML inspected.

[2] Chalmers, D. J. (1995). Absent Qualia, Fading Qualia, Dancing Qualia. Author-hosted text: https://consc.net/papers/qualia.html . Organizational-invariance and replacement passages inspected; not evidence for empirical truth of UCT.

[3] Murray, J. D., Bernacchia, A., Roy, N. A., Constantinidis, C., Romo, R., and Wang, X.-J. (2017). Stable population coding for working memory coexists with heterogeneous neural dynamics in prefrontal cortex. *PNAS*, 114(2), 394–399; online 27 December 2016. DOI: 10.1073/pnas.1619449114. Publisher abstract, methods description of pseudopopulations and stable/dynamic decoding discussion read. No new raw-data analysis.

[4] Koetter, R., and Médard, M. (2003). An algebraic approach to network coding. *IEEE/ACM Transactions on Networking*, 11(5), 782–795. DOI: 10.1109/TNET.2003.818197. Publisher metadata and author-uploaded original text/abstract inspected. The calculations in this note are independently proved; no theorem-level historical novelty clearance is asserted.

[5] Liu, H. (2026). UCT I v1.2, UCT III v1.0, and UCT-MAP-v1.0.0. Frozen source archive supplied by the author; base SHA-256 `40d17cd5f61ebcc1bfcea65eb59c3c730208bcfcf69ba92e2f615a993584e3ce`. Key inherited nodes: A:C1, A:U1, A:ACTUAL_TOKEN; C:FIXED_J, C:P1, C:P2_COORD, C:P3; R127:MEDIATION, R127:RECOVERY, R127:PAIR_MODEL; R157:COORDINATE_TRANSPORT; R183 and R184. R185 is a pending, nonpremise comparison at the repository head cited above.

[6] Liu, H. (2026). Map-Guided Theory Development, v1.0.1. DOI: 10.5281/zenodo.23241982. Supplied manuscript/reproduction package used for protocol. Method completion, theory truth, actual realization, review coverage and storage receipt are distinct states.
