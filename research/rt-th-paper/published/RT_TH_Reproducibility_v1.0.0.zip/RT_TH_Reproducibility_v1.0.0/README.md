# Reproduction

Run `python code/check_transport.py --output new_RT.json`, `python code/check_handoff.py --output new_TH.json`, and `python code/check_review_cases.py --output new_review.json`. Python standard library only. Each program verifies finite mathematical claims, not actual subjective experience. See review/REVIEW_REPORT.md for limits and provenance.
