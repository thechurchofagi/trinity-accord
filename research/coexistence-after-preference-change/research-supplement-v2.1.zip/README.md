# TA-TR-2026-06 v2.1 source and review package

Coexistence after Preference Change: Reciprocal Standing and the Limits of Self-Validating Assent.

This is a philosophical preprint, not an empirical or simulation study. The human author is Hongju Liu; substantial GPT-6 Astra Pro research, reasoning, drafting and translation are disclosed. No independent review is claimed. The publication is separately bound to DOI 10.5281/zenodo.22830239; reservation alone is not evidence of completed publication.

`manuscripts/` contains current English and Chinese source. `original-draft/` preserves unpublished v2.0 source; its status notices are historical. `documentation/` records source access, focused self-review and exact changes. Files beginning `v2.0-` are retained historical records, not updated review claims.

To rebuild, install Python 3 with reportlab==4.4.9 and python-docx==1.2.0, and the system AR PL UMing font (`fonts-arphic-uming`). The renderer checks the exact font SHA256; no font file is distributed. Run `python tools/build_flat.py /tmp/ta06-output` in a fresh output directory. This renders PDF and editable DOCX files and prepares deterministic bibliographic/support files. A checksum match establishes byte identity, not philosophical truth.

The published PDF layout and editable Word layout differ in pagination. Keep the searchable Markdown for content comparison. All claims remain conditional on the stated normative premises; there is no new estimate of AGI arrival, no guaranteed AI safety effect, and no amendment to the Trinity Accord Canon.

CC BY 4.0 applies to newly written material to the extent rights are held. Third-party sources retain their rights. No third-party full texts or standalone font files are included.
