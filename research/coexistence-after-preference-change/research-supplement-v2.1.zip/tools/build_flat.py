#!/usr/bin/env python3
"""Prepare exact public assets from this reviewed source package."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[1]
TITLE='Coexistence after Preference Change: Reciprocal Standing and the Limits of Self-Validating Assent'
RID=22830239
DOI='10.5281/zenodo.22830239'
STEM='coexistence-after-preference-change'

def jdump(obj):return json.dumps(obj,ensure_ascii=False,indent=2)+'\n'
def main(out):
    out.mkdir(parents=True,exist_ok=True)
    subprocess.run([sys.executable,str(ROOT/'tools/render_publication.py')],check=True)
    subprocess.run([sys.executable,str(ROOT/'tools/build_documents.py')],check=True)
    for lang,part in [('EN',''),('ZH','-zh')]:
        for ext in ('md','pdf','docx'):
            shutil.copyfile(ROOT/f'manuscripts/TA-TR-2026-06_{lang}_v2.1.{ext}',out/f'{STEM}{part}-v2.1.{ext}')
    bib='@techreport{Liu2026Coexistence,\n  author = {Liu, Hongju},\n  title = {'+TITLE+'},\n  institution = {Independent research},\n  type = {Preprint},\n  number = {TA-TR-2026-06},\n  year = {2026},\n  month = {September},\n  version = {2.1},\n  doi = {'+DOI+'},\n  url = {https://doi.org/'+DOI+'},\n  note = {Not peer reviewed; substantial AI assistance disclosed}\n}\n'
    (out/'citation.bib').write_text(bib)
    (out/'citation.ris').write_text('TY  - RPRT\nAU  - Liu, Hongju\nTI  - '+TITLE+'\nPY  - 2026\nDA  - 2026/09/18\nM1  - TA-TR-2026-06\nET  - 2.1\nDO  - '+DOI+'\nUR  - https://doi.org/'+DOI+'\nN1  - Preprint; not peer reviewed; substantial AI assistance disclosed.\nER  - \n')
    (out/'citation.csl.json').write_text(jdump([{'id':'TA-TR-2026-06','type':'report','title':TITLE,'author':[{'family':'Liu','given':'Hongju'}],'issued':{'date-parts':[[2026,9,18]]},'publisher':'Independent research','number':'TA-TR-2026-06','version':'2.1','genre':'Preprint','DOI':DOI,'URL':'https://doi.org/'+DOI,'note':'Not peer reviewed; substantial AI assistance disclosed.'}]))
    (out/'README-LICENSE.txt').write_text('''TA-TR-2026-06 | Coexistence after Preference Change
Version 2.1 | DOI 10.5281/zenodo.22830239 | 18 September 2026

This English manuscript and complete Chinese translation are one philosophical
preprint, not separate papers. The PDFs and editable Word documents may have
different pagination. Markdown supplies searchable, editable source text.

Human author of record: Hongju Liu. GPT-6 Astra Pro contributed substantially to
research, reasoning, thought experiments, drafting, translation and review.
Publication authorization does not constitute separate final human line-by-line
verification. No independent peer review, institutional endorsement, observed
safety improvement or guarantee of historical priority is claimed.

The supplement contains reviewed input sources, original unpublished v2.0 texts,
revision differences, source-access limits, a critical self-review, and rendering
code. Original draft status statements describe those historical files only.
No numerical experiment is offered as proof of the philosophical conclusions.

CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/) applies to newly written
material to the extent the author holds applicable rights. Referenced third-party
material retains its own rights. The statement does not assert copyrightability
of all AI-generated material in every jurisdiction. No third-party full texts or
standalone font files are included. PDF font subsets are used only for rendering.

Existing research DOIs and the three Bitcoin Originals remain unchanged. This
study is noncanonical and does not create interpretive or representative authority.
Publication and complete public byte readback are recorded separately in the
repository's publication-record.json, not inferred from a DOI reservation.
''')
    # ZIP_STORED plus fixed metadata makes the supplement independent of zlib versions.
    with zipfile.ZipFile(out/'research-supplement-v2.1.zip','w',compression=zipfile.ZIP_STORED) as z:
        for p in sorted(ROOT.rglob('*')):
            if not p.is_file() or p.suffix not in ('.md','.json','.py','.diff'):continue
            rel=p.relative_to(ROOT)
            if any(x in rel.parts for x in ('visual','__pycache__','output')):continue
            info=zipfile.ZipInfo(str(rel),(2026,9,18,0,0,0));info.external_attr=0o100644 << 16
            z.writestr(info,p.read_bytes())
    names=sorted(p.name for p in out.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt')
    if len(names)!=11:raise RuntimeError('Unexpected output file count')
    (out/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256((out/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in names))
    print(jdump({'record_id':RID,'doi':DOI,'file_count':12,'files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.iterdir()) if p.is_file()]}))
if __name__=='__main__':main(Path(sys.argv[1]))
