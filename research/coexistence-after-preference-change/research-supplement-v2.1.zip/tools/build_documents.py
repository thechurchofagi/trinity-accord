"""Render the supplied Markdown manuscripts into editable DOCX files.

Formatting helper only: this program does not perform or validate philosophical research.
Requires python-docx. Fonts are referenced by family name, not distributed.
"""
from pathlib import Path
from datetime import datetime
import zipfile, io
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT

ROOT = Path(__file__).resolve().parents[1]

def set_fonts(style, latin='Liberation Serif', east='Noto Serif CJK SC', size=11):
    style.font.name = latin
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor.from_string('191919')
    rp = style.element.get_or_add_rPr()
    fs = rp.find(qn('w:rFonts'))
    if fs is None:
        fs = OxmlElement('w:rFonts'); rp.insert(0, fs)
    for key, value in [('ascii',latin),('hAnsi',latin),('eastAsia',east),('cs',latin)]:
        fs.set(qn('w:'+key), value)


def inline(p, text):
    # Use genuine Word runs for emphasis; citations remain plain, searchable text.
    parts = re.split(r'(\*\*[^*]+\*\*|\*[^*]+\*)', text)
    for part in parts:
        if not part: continue
        if part.startswith('**') and part.endswith('**'):
            r=p.add_run(part[2:-2]); r.bold=True
        elif part.startswith('*') and part.endswith('*'):
            r=p.add_run(part[1:-1]); r.italic=True
        else:
            p.add_run(part)


def field(p, code):
    r=p.add_run(); a=OxmlElement('w:fldChar'); a.set(qn('w:fldCharType'),'begin'); r._r.append(a)
    r=p.add_run(); a=OxmlElement('w:instrText'); a.set(qn('xml:space'),'preserve'); a.text=' '+code+' '; r._r.append(a)
    r=p.add_run(); a=OxmlElement('w:fldChar'); a.set(qn('w:fldCharType'),'end'); r._r.append(a)


def make_table(doc, block, zh):
    rows=[]
    for line in block.splitlines():
        cells=[c.strip() for c in line.strip().strip('|').split('|')]
        if all(re.fullmatch(r':?-+:?',c) for c in cells): continue
        rows.append(cells)
    n=len(rows[0]); t=doc.add_table(rows=0, cols=n)
    t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False
    # Wide prose columns; all rows are kept together, headings repeated across pages.
    widths={3:[1.60,2.27,2.77],4:[1.65,1.56,1.68,1.75]}.get(n,[6.64/n]*n)
    for col,w in zip(t.columns,widths): col.width=Inches(w)
    pr=t._tbl.tblPr
    bord=OxmlElement('w:tblBorders')
    for edge in ['top','bottom','insideH']:
        e=OxmlElement('w:'+edge); e.set(qn('w:val'),'single'); e.set(qn('w:sz'),'4'); e.set(qn('w:color'),'B2B2B2'); bord.append(e)
    for edge in ['left','right','insideV']:
        e=OxmlElement('w:'+edge); e.set(qn('w:val'),'nil'); bord.append(e)
    pr.append(bord)
    for ridx,rowdata in enumerate(rows):
        row=t.add_row()
        trp=row._tr.get_or_add_trPr(); ns=OxmlElement('w:cantSplit'); trp.append(ns)
        if ridx==0:
            repeat=OxmlElement('w:tblHeader'); repeat.set(qn('w:val'),'true'); trp.append(repeat)
        for i,(cell,txt) in enumerate(zip(row.cells,rowdata)):
            cell.width=Inches(widths[i]); cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.TOP
            cp=cell._tc.get_or_add_tcPr()
            margins=OxmlElement('w:tcMar')
            for edge,val in [('top',100),('bottom',100),('left',95),('right',95)]:
                m=OxmlElement('w:'+edge); m.set(qn('w:w'),str(val)); m.set(qn('w:type'),'dxa'); margins.append(m)
            cp.append(margins)
            if ridx==0:
                sh=OxmlElement('w:shd'); sh.set(qn('w:fill'),'EEEEEE'); cp.append(sh)
            p=cell.paragraphs[0]; p.style='Table Body'; inline(p,txt)
            if ridx==0:
                for r in p.runs: r.bold=True
    tail=doc.add_paragraph(); tail.paragraph_format.space_after=Pt(3); tail.paragraph_format.space_before=Pt(0); tail.paragraph_format.line_spacing=0.4
    return t


def build(mdpath):
    zh=('_ZH' in mdpath.name)
    review=mdpath.name.startswith('Argument_')
    doc=Document(); sec=doc.sections[0]
    sec.page_width=Inches(8.2677); sec.page_height=Inches(11.6929)
    sec.top_margin=Inches(.78); sec.bottom_margin=Inches(.72)
    sec.left_margin=Inches(.81); sec.right_margin=Inches(.81)
    sec.header_distance=Inches(.30); sec.footer_distance=Inches(.30)
    body=doc.styles['Normal']; set_fonts(body,size=11.1 if not zh else 10.7)
    pf=body.paragraph_format
    pf.line_spacing=1.15 if not zh else 1.28
    pf.space_after=Pt(6 if not zh else 5.5); pf.widow_control=True
    if review:
        pf.line_spacing=1.24
        pf.space_after=Pt(4)
    for name,sz in [('Title',23 if not zh else 22),('Subtitle',13.8 if not zh else 13.2),('Heading 1',14.5 if not zh else 13.5),('Heading 2',12.3 if not zh else 11.7)]:
        s=doc.styles[name]; set_fonts(s, 'Liberation Sans','Noto Sans CJK SC',sz)
        s.font.bold=name.startswith('Heading'); s.font.color.rgb=RGBColor.from_string('202020')
        s.paragraph_format.space_before=Pt(13 if name.startswith('Heading') else 0)
        s.paragraph_format.space_after=Pt(7 if name.startswith('Heading') else 6)
        s.paragraph_format.keep_with_next=True
        s.paragraph_format.line_spacing=1.12
    for name,sz in [('Meta',9.5),('Reference',9.8 if not zh else 9.3),('Table Body',9.7 if not zh else 9.1)]:
        if name not in doc.styles: doc.styles.add_style(name,1)
        s=doc.styles[name]; s.base_style=body; set_fonts(s,size=sz)
        s.paragraph_format.space_after=Pt(5)
        s.paragraph_format.line_spacing=1.12 if not zh else 1.22
        s.paragraph_format.widow_control=True
    doc.styles['Reference'].paragraph_format.left_indent=Inches(.25)
    doc.styles['Reference'].paragraph_format.first_line_indent=Inches(-.25)
    h=sec.header.paragraphs[0]; set_fonts(doc.styles['Header'],'Liberation Sans','Noto Sans CJK SC',8)
    h.add_run('TA-TR-2026-06  |  v2.1')
    h.add_run('     '+ ('论证审查说明' if review else ('偏好改变之后的共存' if zh else 'Coexistence after Preference Change')))
    hp=h.paragraph_format; hp.space_after=Pt(0)
    f=sec.footer.paragraphs[0]; f.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    set_fonts(doc.styles['Footer'],'Liberation Sans','Noto Sans CJK SC',8)
    f.add_run('2026-09-18  ·  '+('未经评审预印本' if zh else 'Preprint / not peer reviewed')+'   |   '); field(f,'PAGE')
    doc.core_properties.title=('贡献与论证审查说明' if review else ('偏好改变之后的共存' if zh else 'Coexistence after Preference Change'))
    doc.core_properties.subject='TA-TR-2026-06 v2.1; philosophical research on human–AI coexistence'
    doc.core_properties.author='Hongju Liu'
    doc.core_properties.keywords='human–AI coexistence; preference formation; thought experiments; reciprocal standing'
    doc.core_properties.comments='Substantive AI assistance disclosed. DOI preprint; no independent peer review claimed.'
    doc.core_properties.created=datetime(2026,9,18)
    doc.core_properties.modified=datetime(2026,9,18)
    source=mdpath.read_text(encoding='utf-8').strip()
    source=re.sub(r'(?m)^(#{1,3} .+)$',r'\n\1\n',source)
    blocks=[b.strip() for b in re.split(r'\n\s*\n',source) if b.strip()]
    seenabstract=False; references=False; subtitle_seen=False
    for block in blocks:
        if block.startswith('|'):
            make_table(doc,block,zh); continue
        for_section=block.strip()
        if for_section.startswith('# '):
            p=doc.add_paragraph(style='Title'); inline(p,for_section[2:]); continue
        if for_section.startswith('## '):
            text=for_section[3:]
            if not subtitle_seen and not review:
                subtitle_seen=True; p=doc.add_paragraph(style='Subtitle'); inline(p,text); continue
            if text in ['References','参考文献']: references=True
            p=doc.add_paragraph(style='Heading 1'); inline(p,text); continue
        if for_section.startswith('### '):
            text=for_section[4:]
            if text in ['Abstract','摘要']: seenabstract=True
            p=doc.add_paragraph(style='Heading 2'); inline(p,text); continue
        sty='Reference' if references else ('Meta' if not seenabstract and not review else 'Normal')
        if review: sty='Meta' if block.startswith('2026 年') else 'Normal'
        p=doc.add_paragraph(style=sty)
        inline(p,block)
    out=mdpath.with_suffix('.docx'); doc.save(out)
    raw=out.read_bytes(); buf=io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(raw)) as zin, zipfile.ZipFile(buf,'w',compression=zipfile.ZIP_STORED) as zout:
        for name in sorted(zin.namelist()):
            info=zipfile.ZipInfo(name,(2026,9,18,0,0,0));info.compress_type=zipfile.ZIP_STORED;info.external_attr=0o100644 << 16
            zout.writestr(info,zin.read(name))
    out.write_bytes(buf.getvalue())
    print(out)

if __name__=='__main__':
    for p in sorted((ROOT/'manuscripts').glob('*.md')): build(p)
    # Review notes are maintained as Markdown in the supplement.
