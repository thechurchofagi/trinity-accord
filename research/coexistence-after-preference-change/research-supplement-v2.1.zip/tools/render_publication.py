#!/usr/bin/env python3
"""Deterministic readable PDFs. This checks layout, not philosophical validity."""
from pathlib import Path
import hashlib, html, re, sys
import reportlab
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT
FONT=Path('/usr/share/fonts/truetype/arphic/uming.ttc')
FONT_SHA='fe952e55617275142d9cefd4d79eade4df446517b0478b2567d9bc7df49f70e2'
if reportlab.Version != '4.4.9': raise RuntimeError('Reviewed renderer version required')
if hashlib.sha256(FONT.read_bytes()).hexdigest()!=FONT_SHA: raise RuntimeError('Reviewed CJK font differs')
pdfmetrics.registerFont(TTFont('UMing',str(FONT),subfontIndex=0))
pdfmetrics.registerFontFamily('UMing',normal='UMing',bold='UMing',italic='UMing',boldItalic='UMing')
TITLE='Coexistence after Preference Change: Reciprocal Standing and the Limits of Self-Validating Assent'
DOI='10.5281/zenodo.22830239'

def inline(text,zh=False):
    text=html.escape(text)
    text=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',text)
    text=re.sub(r'\*([^*]+)\*',r'<i>\1</i>',text)
    text=text.replace('₀','<sub>0</sub>').replace('₁','<sub>1</sub>')
    if not zh: text=text.replace('ł','<font name="UMing">ł</font>')
    text=text.replace('\n','<br/>')
    return text

def render(md:Path,out:Path):
    zh='_ZH_' in md.name
    bodyfont='UMing' if zh else 'Times-Roman'
    headfont='UMing' if zh else 'Helvetica-Bold'
    fs=10.3 if zh else 11.0
    styles={
      'body':ParagraphStyle('body',fontName=bodyfont,fontSize=fs,leading=15.4 if zh else 14.0,spaceAfter=7,alignment=TA_LEFT if zh else TA_JUSTIFY,wordWrap='CJK' if zh else None,allowWidows=0,allowOrphans=0),
      'title':ParagraphStyle('title',fontName=headfont,fontSize=21 if zh else 23,leading=29,spaceAfter=8,keepWithNext=True),
      'subtitle':ParagraphStyle('subtitle',fontName=headfont,fontSize=13.4,leading=19,spaceAfter=13,keepWithNext=True),
      'h1':ParagraphStyle('h1',fontName=headfont,fontSize=13.4,leading=18,spaceBefore=12,spaceAfter=7,keepWithNext=True),
      'h2':ParagraphStyle('h2',fontName=headfont,fontSize=11.5,leading=16,spaceBefore=9,spaceAfter=6,keepWithNext=True),
      'meta':ParagraphStyle('meta',fontName=bodyfont,fontSize=9.4,leading=13.7,spaceAfter=12),
      'ref':ParagraphStyle('ref',fontName=bodyfont,fontSize=9.1 if zh else 9.7,leading=13.3,spaceAfter=6,wordWrap='CJK' if zh else None,splitLongWords=1,leftIndent=18,firstLineIndent=-18),
      'cell':ParagraphStyle('cell',fontName=bodyfont,fontSize=8.5 if zh else 9.2,leading=12.3,spaceAfter=0,wordWrap='CJK' if zh else None),
    }
    def par(t,style): return Paragraph(inline(t,zh),styles[style])
    text=md.read_text().strip(); text=re.sub(r'(?m)^(#{1,3} .+)$',r'\n\1\n',text)
    blocks=[s.strip() for s in re.split(r'\n\s*\n',text) if s.strip()]
    story=[]; abstract=False; subtitle=False; refs=False
    width=595.275590551-104
    for b in blocks:
        if b.startswith('|'):
            rows=[]
            for line in b.splitlines():
                cells=[c.strip() for c in line.strip().strip('|').split('|')]
                if all(re.fullmatch(r':?-+:?',c) for c in cells):continue
                rows.append(cells)
            n=len(rows[0]); weights={3:[.25,.35,.40],4:[.27,.23,.25,.25]}.get(n,[1/n]*n)
            data=[[par(('<b>'+c+'</b>') if False else c,'cell') for c in r] for r in rows]
            table=Table(data,colWidths=[width*w for w in weights],repeatRows=1,hAlign='LEFT')
            table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('LINEABOVE',(0,0),(-1,0),.7,colors.black),('LINEBELOW',(0,0),(-1,0),.5,colors.grey),('LINEBELOW',(0,-1),(-1,-1),.7,colors.black),('ROWBACKGROUNDS',(0,0),(-1,0),[colors.HexColor('#eeeeee')])]))
            story += [Spacer(1,4),table,Spacer(1,10)];continue
        if b.startswith('# '):story.append(par(b[2:],'title'));continue
        if b.startswith('## '):
            s=b[3:]
            if not subtitle: subtitle=True;style='subtitle'
            else:style='h1'
            if s in ('References','参考文献'):refs=True
            story.append(par(s,style));continue
        if b.startswith('### '):
            if b[4:] in ('Abstract','摘要'):abstract=True
            story.append(par(b[4:],'h2'));continue
        story.append(par(b,'ref' if refs else ('body' if abstract else 'meta')))
    def page(c,d):
        c.saveState(); w,h=d.pagesize
        c.setFont('Helvetica',7.7);c.drawString(52,h-30,'TA-TR-2026-06  |  v2.1  |  Coexistence after Preference Change')
        c.setStrokeColor(colors.HexColor('#b8b8b8'));c.setLineWidth(.3);c.line(52,h-37,w-52,h-37)
        c.setFont('Helvetica',7.7);c.drawString(52,28,'Preprint / not peer reviewed  |  '+DOI);c.drawRightString(w-52,28,str(d.page))
        c.restoreState()
    doc=SimpleDocTemplate(str(out),pagesize=(595.275590551,841.88976378),rightMargin=52,leftMargin=52,topMargin=50,bottomMargin=47,title=TITLE,author='Hongju Liu',subject='Philosophical preprint; TA-TR-2026-06 v2.1',pageCompression=1,invariant=1)
    doc.build(story,onFirstPage=page,onLaterPages=page)

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    for p in sorted((root/'manuscripts').glob('*_v2.1.md')):
        render(p,p.with_suffix('.pdf'));print(p.with_suffix('.pdf'))
