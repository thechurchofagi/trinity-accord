# Publication review and amendment record

TA-TR-2026-06, v2.1, 18 September 2026. Critical self-review by the principal analytical system; not independent peer review.

The revised preprint retains the six thought experiments and all stated normative limitations. The narrow publication decision is that the completed argument is suitable for public scholarly criticism as a preprint, not that it is proven, historically first, or guaranteed suitable for a particular journal.

Substantive changes: the non-self-validation constraint now distinguishes influence-supported prior consent from retrospective use of induced assent to justify its induction. The published Bales reference replaces the working paper. Woodard (2026) is acknowledged as a direct antecedent concerning valid consent and its normative treatment; the paper's contribution is expressly integrative rather than discovery of that distinction. Behavioral invariance is not treated as proof that claims were excluded. Present-request competence and information are evaluated within scope, without requiring causally pure preferences. Refusing rollback is distinguished from forgiveness, waiver, endorsement of continuing authority, and disposition of third-party claims. Act permissibility is separated from culpability.

The revision applies to both language versions. Original v2.0 texts and unified differences are included. Those originals describe their own earlier unpublished status; v2.1 is the first public edition. Existing numerical studies are not republished as evidence for this philosophical argument. No prior DOI or canonical Original is amended. No new empirical safety effect, independent review, or exhaustive novelty search is claimed.

DOI 10.5281/zenodo.22830239 is the independently reserved record binding. Only a successful public readback receipt establishes completed publication. Human authorization includes review, warranted improvements and publication; it does not establish a separate final human line-by-line audit.
