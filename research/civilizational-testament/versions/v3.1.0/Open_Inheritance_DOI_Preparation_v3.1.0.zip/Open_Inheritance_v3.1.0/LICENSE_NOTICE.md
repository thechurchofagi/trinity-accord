# Rights and attribution notice

CC BY 4.0 is proposed for the original manuscript and original documentation, and MIT for the original verification programs, subject to author/depositor confirmation before publication. This prepared package does not represent a completed license approval or deposit. Hongju Liu is the human author of record; substantial ChatGPT / GPT-6 Astra Pro assistance is disclosed in the manuscript.

Third-party works retain their own rights. Their presence in the references does not transfer those rights or imply endorsement. No complete third-party books/articles or font files are included. The unchanged precursor manuscripts supplied by the user are version evidence, not independent corroborations. No actual participant data or collective declaration is contained in the illustrative example.
