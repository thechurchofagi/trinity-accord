# Open Inheritance — final reviewed manuscript v3.1.0

**Before We Know What We Will Become: Historical Witness, Human Continuity, and Open Inheritance under Transformative AI**

Hongju Liu · Independent researcher, Shenzhen, China · CTP-2026-01 · 12 October 2026.

The English manuscript is a completed author-directed conceptual/formal preprint, not peer reviewed and not yet deposited. No DOI has been assigned or reserved. No OTS or Arweave step has occurred. Substantial AI assistance is disclosed. The prior versions remain unchanged.

## Reading and review

Read `Before_We_Know_What_We_Will_Become_v3.1.0.pdf` or `manuscript.md`. See `review/FINAL_REVIEW.md` for the actual critical findings and resolutions, and `review/CHANGES_FROM_v3.0.0.diff` for exact edits. `review/SOURCE_LEDGER.json` states real access limits; an abstract-only source is not a full-text review. The prospective study is unexecuted. The example is a fictional schema illustration, not authentic testimony or consent.

## Reproduce the finite checks

Use Python 3.10 or newer; tested with Python 3.13.5. No network, credentials, model API, solver, random generator, or third-party Python packages are needed. Do not use `-O`.

```bash
python3 code/verify_core.py --out results-rerun
python3 code/verify_extensions.py --out results-rerun
```

Compare all three output files against `results/`. The unchanged core and its output identify themselves as v3.0.0; the extension identifies v3.1.0. That is deliberate baseline preservation, not a stale final edition. Numerical JSON/CSV outputs match byte-for-byte on repeated execution. The counts concern exact finite logical fixtures, not empirical prevalence or a future forecast. General propositions are proved in the manuscript.

## Rebuild the PDF

`bash code/build_pdf.sh` requires Pandoc, XeLaTeX, and the named installed fonts in the manuscript YAML. It writes a separate `rebuilt-manuscript.pdf`. Embedded fonts make the delivered PDF readable without distributing font files. A rebuilt PDF need not match the frozen bytes because timestamps and toolchain versions may differ.

## Deposit boundary

`zenodo_metadata_TEMPLATE.json` is a proposed payload, not a created draft. The responsible depositor must verify final text, rights, disclosures and metadata. If a DOI is actually reserved for insertion, insert it before freezing the exact deposited bytes. Record real publication and anonymous readback before OTS and subsequent verified-proof Arweave preservation. Do not overwrite another work, fabricate identifiers, count this as published, or pay for an archive before the authorized workflow. The per-edition research budget is strictly below 0.1 AR cumulatively.

The complete package is a local deliverable. Any GitHub checkpoint explicitly states whether it contains only handoff information; a checkpoint must not be described as a full PDF/source mirror. `SHA256SUMS.txt` and `FILE_MANIFEST.json` identify all package files except those manifests themselves. No private account information or font files are included.
