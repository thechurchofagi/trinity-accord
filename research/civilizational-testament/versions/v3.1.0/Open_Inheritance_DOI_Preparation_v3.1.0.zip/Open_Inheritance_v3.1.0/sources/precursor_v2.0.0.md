---
title: "Who Decides the Future's Speed?"
subtitle: "Intergenerational Temporal Power, Competitive Acceleration, and Open Human Continuity under Superintelligence"
author:
  - "Hongju Liu"
date: "12 October 2026 · Version 2.0.0"
lang: en-US
fontsize: 10.5pt
documentclass: article
geometry:
  - a4paper
  - margin=23mm
mainfont: Liberation Serif
sansfont: DejaVu Sans
monofont: DejaVu Sans Mono
papersize: a4
colorlinks: false
link-citations: true
header-includes:
  - |
    \usepackage{amsmath,amssymb,amsthm}
    \usepackage{microtype}
    \usepackage{fancyhdr}
    \usepackage{longtable,booktabs,array}
    \usepackage{needspace}
    \pagestyle{fancy}
    \fancyhf{}
    \fancyhead[L]{\small Who Decides the Future's Speed?}
    \fancyhead[R]{\small CTP-2026-01 · v2.0.0}
    \fancyfoot[C]{\thepage}
    \setlength{\headheight}{15pt}
    \setlength{\emergencystretch}{3em}
    \setlength{\parindent}{0pt}
    \setlength{\parskip}{5pt}
---

**Independent researcher, Shenzhen, China**  
**Substantive AI-assisted research and drafting disclosed in Declarations**  
**Research preprint for DOI deposit; not peer reviewed; DOI not assigned**  
**The previous v1.0.0 remains a separate, unchanged preparatory work. This paper radically reconstructs its motivating question.**

## Abstract

Superintelligence debates often ask how rapidly capabilities should advance or what human values should be preserved. A prior question is **who is authorized to choose the pace of an irreversible transition when people differ in remaining time, political influence, exposure to losses, and opportunities to shape their own future—and when the transition may change who counts as a future decision-maker?** We develop a conditional framework of *intergenerational temporal power*. A survival-timing model shows that earlier AI-enabled biomedical gains could rationally matter differently to people with different remaining horizons, but the marginal urgency is generally nonmonotonic in mortality hazard; age does not determine a policy preference and longevity breakthroughs are not assumed. A power-weighted decision proposition identifies exact conditions under which an influential coalition chooses acceleration that a differently weighted account of affected interests would reject. A two-actor race model demonstrates how individually rational competition can make premature acceleration an equilibrium without establishing that acceleration is universally harmful. An *endogenous-constituency* construction shows why creating compliant copies or successors cannot by itself retroactively legitimate the transition that created them; the standing of genuinely new artificial or hybrid subjects is not denied. We distinguish informational superiority, political authority, moral standing, and the continuity of persons and communities across augmentation. The resulting governance proposal is neither a universal moratorium nor a command to future AI: accelerate reversible and broadly beneficial research where warranted, gate irreversible delegation and lock-in, demand independent evidence and representation of less powerful stakeholders, and preserve the future capacity to revise ends. We provide formal proofs, executable exact checks, discriminating thought experiments, and a machine-readable *open-future inquiry* template. These are bounded conceptual results, not empirical proof of elite motives, AI immortality, or the arrival of artificial superintelligence.

**Keywords:** superintelligence; intergenerational justice; temporal power; acceleration; technology races; political representation; longevity; human-machine integration; future agency; governance.

# 1. The problem is not humanity's testament; it is humanity's unfinished right to choose

Imagine two people alive today. One has a short remaining horizon and hopes that much faster AI-assisted medical research might yield a life-saving therapy while they can use it. The other is a child who may have decades to benefit from technological progress, but will also inhabit—and may be unable to reverse—the institutional and biological world created by today's decisions. Neither person's interest is trivial. The first person's hope is not evidence of selfishness, and the second person's lack of an informed vote is not evidence of consent. Their interests can conflict even if they agree that intelligence and medicine should advance.

Now place them in a competitive international economy where firms may lose first-mover advantages by slowing down, states fear strategic dependence, and capital markets reward credible narratives of rapid capability growth. It does not follow that any one leader seeks immortality or that a specific technical deadline is established. But **the power to set development speed is concentrated in people and institutions whose planning horizons and exposure to irreversible consequences may differ from those of the people who must live with the result**. That gap, not a supposed civilizational last will, is the object of this paper.

An illustrative political event makes terminology itself relevant. On 29 September 2026, US Executive Order 14434 directed executive-branch agencies to use “Super Intelligence” (SI) instead of “Artificial Intelligence” (AI) in specified official contexts [1]. Yet its operative definition initially refers to the existing statutory definition of AI. The order neither establishes that current systems exceed every human cognitive ability nor demonstrates a technical path to artificial superintelligence (ASI). It is evidence of a political reframing, not a capability measurement or evidence of any signatory's private longevity motive. A separate question worth testing is whether terminological reframing affects urgency perceptions and policy support; we do not claim it does so without an experiment.

We therefore ask four linked questions:

1. **Timing:** who gains from a transition in one to three years, who gains from waiting twenty or thirty years, and who loses in either case?
2. **Power:** when do competition and unequal political influence cause a particular speed to be chosen despite unrepresented long-run harms?
3. **Continuity:** if humans augment themselves, co-think with AI, develop new modes of agency, or create artificial subjects, what would count as preserving human life and civilization rather than replacing them with an archive or a simulation?
4. **Address:** what reasons and evidence could remain useful to future humans, hybrids and far more capable AIs without illegitimately binding those successors?

The answer should remain useful even if ASI never arrives, if medical benefits arrive without ASI, if many AIs compete, if human augmentation advances unevenly, or if future descendants reject today's taxonomy of “human” and “machine”. The paper studies *conditional decision structures*, not an ASI forecast.

# 2. Literature, method, and where the increment lies

The paper draws from five neighboring bodies of work, none of which it claims to originate. The UN Declaration on Future Generations and the Welsh Future Generations Commissioner precede this proposal in institutionalizing obligations toward people not yet able to vote [2,3]. Accounts of representation across generations and contemporary transgenerational justice make that prior art explicit [4,5]. The normative difficulty is real: longtermist aggregation can disregard near-term people, and unknown future values undermine claims to speak for them [6]. Our answer is not simply “count the unborn more.”

AI competition and destructive strategic externalities have antecedents in the *Vulnerable World Hypothesis*, simulation gaming of AI races, and work on the incentives facing frontier developers [7–9]. None alone proves that a particular 2026 policy will cause catastrophic acceleration. The familiar game-theoretic race mechanism is inherited; its use in an intergenerational bargaining problem, with possible change in the affected constituency, is the intended synthesis.

A political economy of ageing and AI already exists [10], as does theoretical discussion of longevity capitalism [11]. A 2026 scenario experiment with CEOs finds older executives less inclined to invest on average, challenging any simplistic claim that older leaders are generally more aggressive or risk seeking [12]. We therefore treat an interest in rapid life-saving breakthroughs as a **possible incentive given a particular expected benefit and horizon**, not an inferred psychological trait of an age class. Medical research has not conclusively demonstrated an intervention that reverses human ageing or provides immortality [13]. Promises of future radical longevity are uncertain scenario inputs, never observed policy payoffs.

Clinical brain-computer interfaces (BCIs) already make functional assistance and dependence ethically concrete, but not full mind uploading, digital personal survival, or a proven human–ASI merger [14]. Recent work on life-cycle consent, dependence, and the moral individuation of possible artificial patients anticipates much of the rights problem [15–17]. We should not present “respect augmented persons” as an invented idea.

Finally, the author's *Beyond Guaranteed Control* distinguishes proposals from actual acceptance and rejects substituting archives for living human communities [18]. *Recovery without Epistemic Monopoly* treats trustworthy preservation in adversarial custody [19]. The preparatory *Civilizational Testament Problem* v1.0.0 examines truthful aggregation and attribution. Those distinctions are inherited. This version moves them to the end of a larger account: **before deciding what to preserve, ask who has the right to choose an irreversible transition, and what forms of continuing life deserve protection**.

Method: conceptual analysis; declared normative commitments; a minimal mathematical survival/timing model; two exact decision propositions and counterexamples; a conventional two-player game; and executable finite verification of the displayed cases. The literature review is targeted through 12 October 2026, not systematic. The formal model is not calibrated to any population, leader, company, or future system. Proof validity, implementation checks, empirical measurements, political interpretations, and ethical premises are identified separately throughout.

# 3. Basic distinctions: capability, power, standing, and time

**Capability acceleration** means moving a specified technology milestone earlier. It is not identical to **deployment acceleration** (connecting a system to consequential resources), **institutional lock-in** (loss of the ability to revoke the delegation), or **biomedical acceleration** (earlier validated clinical benefit). Fast discoveries can coexist with cautious deployment; slow general capability development can coexist with dangerous premature automation. Treating “accelerate AI” as one action makes risk–benefit reasoning incoherent.

**Informational or intellectual advantage** means being better able to predict, design, or explain. **Effective power** additionally requires access to resources, institutions, and enforcement. **Legitimate authority** concerns who may decide for whom, by which procedure and within which scope. **Moral standing** concerns whose interests deserve consideration. These properties can diverge. A future superintelligence could know far more than a human committee without thereby acquiring an unrestricted title to govern it. Equally, an unaugmented human adult does not acquire universal authority over a future artificial moral patient merely because of biological ancestry.

**Horizon** is a distribution over time remaining to experience a benefit or harm, not an inference about a person's virtue or foresight. Actual age is at most one covariate among health, wealth, care obligations, altruism, beliefs, political institutions and exposure to downside risk. We distinguish a person's *remaining life horizon*, the *duration of their formal office*, the *timescale of competitive payoff*, and the *civilizational horizon of affected persons*. These need not coincide.

A **meaningful option** is a practically and institutionally feasible ability to choose an alternative, not merely a theoretical possibility described in a document. We say an action *forecloses* an option when the action makes that future alternative unavailable or prohibitively costly to the relevant affected party. Some losses are biological (a patient dies before a treatment); some are political (a child grows up under a non-revocable AI controller); some are informational (descendants can no longer learn what earlier people actually said); and some are personal (a neural system becomes indispensable but no independently supported exit path exists).

The **affected constituency** is not automatically a fixed list. Tomorrow's possible worlds may include biological humans, therapeutically augmented people, voluntarily hybridized people, newly created artificial moral patients, successors claiming inherited identity, and communities that remain deliberately unaugmented. The existence, welfare, individuation and membership of several categories are uncertain. The framework must not assume that genome, carbon substrate, processing speed, copy count, memory similarity, or conversational fluency alone settles all these issues.

# 4. Model I — The heterogeneous value of an earlier breakthrough

Let policy $F$ make an *otherwise identical and clinically effective* benefit available at $t_f$, and policy $S$ at $t_s=t_f+\delta$ with $t_f\geq0$ and $\delta>0$. Suppose, only for this stylized timing calculation, that person $i$ has exponential survival $s_i(t)=\exp(-\lambda_i t)$, subjective expected value $V_i\geq0$ from receiving the benefit, and probability $q_i\in[0,1]$ that the relevant discovery succeeds and is actually accessible under either schedule. We assume the intervention is received only if alive when available; $q_i$ is not a measured forecast. Define the pure timing premium:

$$
L_i(\lambda_i;t_f,\delta)=q_iV_i\left[e^{-\lambda_i t_f}-e^{-\lambda_i(t_f+\delta)}\right].\tag{1}
$$

This is a difference in *expected availability before death*, not a price on a life and not a claim that AI will defeat ageing. Net preference must also include direct costs, quality, public goods, harms, insurance and the option to delay deployment:

$$
D_i=U_i(F)-U_i(S)=L_i+B_i-R_i-C_i-O_i.\tag{2}
$$

Here $B_i$ captures additional legitimate earlier benefits, $R_i$ additional risk/exposure under $F$, $C_i$ opportunity and distributive costs, and $O_i$ the option value and future discretion forgone. All may be positive, negative or uncertain; using them requires explicit accounting rather than a calibrated assertion.

**Proposition 1 (timing urgency need not increase with mortality hazard).** If $t_f>0$, $q_iV_i>0$ and $\delta>0$, the pure timing premium $L_i$ increases with $\lambda_i$ up to

$$
\lambda^*=\frac{\log[(t_f+\delta)/t_f]}{\delta},\tag{3}
$$

and decreases for $\lambda_i>\lambda^*$. When $t_f=0$, it is nondecreasing in $\lambda_i$.

*Proof.* Differentiating the bracket in (1) yields $-t_fe^{-\lambda t_f}+(t_f+\delta)e^{-\lambda(t_f+\delta)}$. Its sign is the sign of $(t_f+\delta)-t_fe^{\lambda\delta}$, which switches exactly once when $t_f>0$. If $t_f=0$ it is $\delta e^{-\lambda\delta}>0$. QED.

**Interpretation.** A person with very little remaining time can value an earlier breakthrough tremendously—but if even the accelerated schedule arrives after their likely death, the *incremental* value of moving that milestone may be small. Someone with a low death hazard may survive both schedules. Maximal timing sensitivity can occur between those extremes. No broad conclusion follows from “older leaders want acceleration” or “children can afford to wait.” Children may be exposed to present disease and hardship; older people may prioritize protecting their descendants; some older investors may favor inertia [12]. The testable object is the distribution of **beliefs about intervention timing, personal access, costs, and affected descendants**, not age alone.

The model also exposes a policy-relevant distinction. Fast, independently validated biomedical research may improve $L_i$ without making $R_i$ from autonomous system deployment large. A blanket identification of rapid medical discovery with immediate unrestricted ASI deployment lacks justification. Accelerating one track while gating another is a substantive policy alternative.

# 5. Model II — When those with the vote are not those with the stakes

Consider two affected groups for a transparent construction: group $E$ obtains net $g>0$ from accelerating rather than staging a transition; group $Y$ bears net loss $\ell>0$. The labels are roles, not ages: $E$ can be a commercially exposed coalition with time-sensitive benefits; $Y$ may include children, future people, or present adults with greater lock-in exposure. Suppose a *political decision process* effectively gives $E$ weight $p$, while a separately defended *assessment of affected interests* gives $E$ weight $q$. Thus

$$
\Delta_{\rm political}=pg-(1-p)\ell,\qquad
\Delta_{\rm affected}=qg-(1-q)\ell.\tag{4}
$$

Neither $q$ nor $p$ is a uniquely correct moral weight absent normative argument. The difference is diagnostic: it forces observers to say which aggregation principle is being used instead of treating political victory as welfare proof.

**Proposition 2 (temporal-power wedge).** If $0<q<p<1$, there exist positive benefits and losses such that the political process chooses immediate acceleration ($\Delta_{\rm political}>0$) although the affected-interest assessment opposes it ($\Delta_{\rm affected}<0$). Exactly those cases satisfy

$$
\frac{q}{1-q}<\frac{\ell}{g}<\frac{p}{1-p}.\tag{5}
$$

*Proof.* Rearranging the two strict inequalities in (4) gives $\ell/g<p/(1-p)$ and $\ell/g>q/(1-q)$. The interval is nonempty when $p>q$ because $x/(1-x)$ is increasing on $(0,1)$. QED.

For example, let $p=0.8$, $q=0.3$, $g=4$, $\ell=3$. The politically weighted gain is $2.6$, while the differently weighted affected gain is $-0.9$. These are invented units, not survey estimates. A conventional democratic majority can legitimately make collective decisions even where individuals disagree; (5) does **not** imply that every minority has a veto. It shows that standing, effective influence, and consequences must be separately reported where lock-in makes future reconsideration impossible.

The general *temporal-power discrepancy* is $\Gamma=\sum_i (p_i-w_i)D_i$, where $p$ and $w$ are normalized decision and defended affected-interest weights and $D_i$ is each group's speed differential. The scalar is a diagnostic conditional on the weights, not an objectively measured social injustice index. If $\Gamma\neq0$, knowing aggregate political support does not by itself reveal the distribution of exposure. A claimed civilizational mandate must also show the scope of actual authorization, not simply the power of those who can act.

# 6. Model III — Competitive acceleration can survive unanimous preference for coordination

Two developing organizations each choose $G$ (*guarded development with shared safety evidence*) or $R$ (*race with speed advantages*). For a fixed initial payoff $b$, first-mover premium $v$ and privately borne mutual-race loss $d$, use the stipulated game:

| Organization A / B | B: Guard ($G$) | B: Race ($R$) |
|---|---|---|
| **A: Guard ($G$)** | $(b,b)$ | $(b-v,b+v)$ |
| **A: Race ($R$)** | $(b+v,b-v)$ | $(b-d,b-d)$ |

**Proposition 3 (a race trap).** If $v>d>0$, $R$ is strictly dominant for both players, so $(R,R)$ is the unique Nash equilibrium, yet $(G,G)$ Pareto-dominates $(R,R)$.

*Proof.* If the opponent chooses $G$, racing gives $b+v>b$; if the opponent chooses $R$, racing gives $b-d>b-v$. The unique equilibrium is $(R,R)$. Because $d>0$, both prefer $b$ to $b-d$. QED.

This is a textbook game pattern, not a new theorem about real AI companies. Its point is to refute two tempting inferences: “everyone chooses speed, therefore speed is best,” and “warning leaders to be patient is enough to slow development.” Losses to children, bystanders, other countries and possible successor beings can be **additional external costs** missing from these private payoffs, and could make the social discrepancy larger. Conversely a different payoff structure can make safety investment, competition or deployment mutually beneficial. Calibration and institutional mechanisms are required to move from game possibility to prediction.

**Institutional implication.** The answer cannot consist solely of writing a will addressed to a future AI. Information-sharing standards, independent testing, incident reporting, anti-retaliation protections for safety findings, credible liability, and lawful international coordination may change payoffs. Some forms of coordination pose competition-law and geopolitical problems; they require scrutiny rather than the assumption that a benevolent meeting eliminates strategic incentives [8,9].

# 7. The deeper problem: the transition changes its own electorate

Conventional intergenerational representation assumes more or less recognizable future people. Advanced AI adds a harder possibility: the policy being evaluated may bring into existence new artificial subjects, copies of existing models, hybrid identities, or collective systems that then appear to endorse the change. Treating that resulting population's *later* preference as if it had *earlier authorized* its own creation is a temporal error.

Define $P(a,\omega)$ as the set of potentially morally considerable subjects in possible world $\omega$ after action $a$. Both membership and the grounds for treating each entity as a distinct subject may depend on $a$. A post-transition vote over $P(a,\omega)$ is not automatically a valid pre-transition authorization, because $P$ is an output of the action whose legitimacy is in question.

**Proposition 4 (unbounded manufactured-support vulnerability).** Consider an institutional rule that counts each reported approving instance as one equal vote, does not distinguish independently situated subjects from controller-generated copies, and imposes no bound on copies. If a controller can create $k$ approving instances at finite permitted cost, it can overturn any fixed finite opposing margin by choosing $k$ sufficiently large.

*Proof.* If the original opposing margin over approvals is $m\geq0$, choose any integer $k>m$. The tally reverses. QED.

This is an elementary identity/aggregation vulnerability, not a proof that digital beings are unconscious or undeserving of rights. A future artificial system could genuinely have morally relevant interests; whether two copies correspond to one subject or two, and how rights attach over time, is an independent problem [17]. The narrow conclusion is about **retroactive authorization by a constituency whose creation or multiplication is controlled by a party to the earlier decision**. New moral patients may deserve protection without conferring retrospective jurisdiction over their predecessors.

We propose a *three-time ledger*: (i) **before transition**, which living persons, minors, institutions and trustees had standing and which decisions they could authorize; (ii) **at transition**, what power was delegated, what became irrevocable, and who bore risk; (iii) **after transition**, which new interests have emerged and how continuing people can renegotiate the settlement. A later entity's authentic rights are acknowledged at (iii), but cannot forge a vote at (i).

This supplies a more powerful criticism of a “civilizational testament” than document authenticity alone. A perfect recording of today's elite consensus may still omit tomorrow's affected persons, children, poorer populations and genuinely new subjects. Moreover, no document can pre-authorize **all** future forms of humanity or AI. A testament can supply historical evidence and contestable reasons; it cannot dissolve the problem of legitimate transition governance.

# 8. What is human continuity if people and machines integrate?

A preservation test based on unmodified biology would exclude legitimate, voluntary human augmentation. A test based on intelligence alone could declare replacement of every person by a more intelligent machine to be “human survival.” Both are inadequate. We use four **normative dimensions**, evaluated separately instead of identifying a single immutable human essence:

1. **Continuing lives and welfare.** Existing persons' continued existence, health, care, relationships and possibly conscious experience matter independently of whether a successor archive accurately describes them. For disputed mind-uploading scenarios, continuity of a particular experiencing person must not be assumed from memory or functional resemblance alone.
2. **Agency and genuine choice.** Affected people retain opportunities to learn, deliberate, refuse, revisit earlier consent and shape the ends of their lives. For minors, protection includes future capacity to acquire and exercise informed agency rather than treating their present inability to vote as permission for others to decide everything permanently.
3. **Plural social and cultural reproduction.** Languages, mutual obligations, disagreement, cultural practice, education, interpersonal bonds and institutions should be able to continue through participants, not merely through replicas in a museum. Continuity does not require freezing particular values or excluding new ways of living.
4. **Open modes of successor being.** Voluntary therapeutic implants, augmentation and even future forms of human–AI integration should not be rejected solely because of changed substrate. Nor does hypothetical machine moral standing cancel the claims of living unaugmented people. Human rights protection and serious inquiry into artificial welfare can coexist [15–17].

**Table 1. Continuity questions that different futures require**

| Possible future | What may persist | What cannot be silently inferred | Minimum concern |
|---|---|---|---|
| Unaugmented humans with powerful AI assistants | Living persons, choices and culture | Assistance equals voluntary delegation | Accountability; ability to stop dependence |
| Therapeutic BCI users | Embodied agency supported by devices | Initial consent settles all future changes | Ongoing consent, support and access |
| Elective human–AI hybrids | Some continuing practices and selves | A physical upgrade destroys—or guarantees—personal continuity | Noncoercion, identity uncertainty, equitable options |
| Deeply integrated collectives | Novel shared tasks and perhaps agency | Joining one network establishes one unified subject | Individuation, exit, internal dissent |
| AI-only successors | Knowledge, artifacts, perhaps novel patients | Superior knowledge alone continues human lives | Independent moral inquiry; living-human non-substitution |
| Extinct humans plus complete archive | Records of a historical civilization | Historical records are living civilization | Do not redefine archives as survival |

This position is neither *biological purism* nor *replacement optimism*. It permits the content and boundaries of future persons to change while refusing to count all functional simulations as proven survival. The status of possible artificial subjects remains uncertain; some familiar categories may fail under advanced integration. This is a reason to protect revision procedures and record the uncertainty, not a reason to predetermine all future identities.

# 9. Model IV — No unconditional moral ranking of accelerate and wait

A slogan that everyone has a “right to wait” can be as misleading as a slogan that every day of delay is immoral. Waiting can destroy a present patient's last chance of receiving a lifesaving treatment. Racing can foreclose a child's right to learn and choose in a transformed world. Competitors may react to waiting, and some lost opportunities cannot be recovered. Neither action generally has a feasible-option set containing the other's.

Let $\Omega$ be a declared set of plausible worlds, $A$ a declared set of available policies, and $W(a,\omega)$ a *contested* evaluation of the outcomes. For a chosen evaluation, define regret

$$
\operatorname{Reg}(a,\omega)=\max_{b\in A}W(b,\omega)-W(a,\omega).\tag{6}
$$

A robust option under that choice of worlds and values minimizes $\max_{\omega\in\Omega}\operatorname{Reg}(a,\omega)$, **subject first** to independently argued rights, safety, representation and feasibility constraints. This is a decision aid, not a neutral solution to plural morality.

**Proposition 5 (a conditional regret threshold).** With two actions $F$ (fast) and $S$ (staged), let $\Delta(\omega)=W(F,\omega)-W(S,\omega)$ range over the interval $[-a,b]$, with $a,b>0$ and both endpoints possible. Worst-case regret is $a$ for $F$ and $b$ for $S$. Under minimax regret alone, $F$ is selected exactly when $a\leq b$.

*Proof.* Regret of $F$ is $\max(0,-\Delta)$, whose maximum is $a$. Regret of $S$ is $\max(0,\Delta)$, whose maximum is $b$. Compare. QED.

This result is intentionally elementary. It illustrates why an unconditional delay rule cannot be deduced from uncertainty alone: plausible lost-life benefits and plausible irreversible harms must be included, with their bounds and rights constraints openly contested. The interval endpoints must not be assigned arbitrary precision and then mistaken for predictions. If rights constraints rule out $F$, regret cannot reinstate it. If a staged policy can preserve treatment discovery without unsafe delegation, it may dominate the falsely binary $F/S$ choice.

**Policy design principle (conditional option protection):** Where credible, grave, hard-to-reverse harm is possible and a feasible staged alternative protects most immediate benefits, place the irreversible power transfer behind evidentiary and procedural gates. Where delay would predictably deny proven, proportionate benefits without comparably grave harms, accelerate those benefits. Both clauses are necessary.

# 10. A practical Open-Future Governance Protocol

A proposal useful today and legible to future AI should specify **questions, reasons, authority boundaries and revision channels**—not only a hoped-for outcome. We call this the *Open-Future Governance Protocol* (OFGP). This is an analytical design proposal, not a validated institution or a legally binding standard.

**Stage A — Disaggregate what is speeding up.** Maintain separate milestones and risk accounts for fundamental research, validated medical discovery, training of frontier capabilities, evaluation, deployment with external tools, delegation of public authority, infrastructure dependence, and irreversible autonomy. Require evidence that a claimed life-saving benefit actually depends on crossing the contested autonomy threshold.

**Stage B — Map exposure and influence.** For each action identify decision-makers and their effective control; expected beneficiaries; people carrying the downside; vulnerable existing groups; current minors; future generations; and possible newly created or hybrid subjects. Publish which interests were heard and which are represented only provisionally. An age histogram of decision-makers is insufficient without belief and incentive data.

**Stage C — Publish conditional cases, not slogans.** Write a favorable scenario for rapid progress (preventable deaths, cure of disease, broad public benefit), a favorable scenario for staged progress (preserved democratic correction, safe alternatives), and counterexamples to each. Separately report scientific probabilities, normative weights, payoffs, and evidence of real-world access. Model disagreement explicitly.

**Stage D — Treat irreversibility as a separate gate.** Escalate independent assessment for actions that concentrate the ability to set future goals, replicate autonomously, seize critical institutions, permanently withdraw human contestability, or become impossible to reverse. Evaluate alternative routes to obtain medical and scientific benefits. Do not assume a complete shutdown or technical control can be guaranteed; do not claim a paper itself provides a control mechanism.

**Stage E — Build intergenerational and successor review.** Institutions representing children and future generations can require published replies, horizon-specific impact statements, independent dissent records and periodic reconsideration. Their exact authority requires legitimate local and international design; they cannot literally obtain consent from persons not yet existent. Newly recognized artificial/hybrid interests should be added prospectively through reasoned individuation rules rather than retroactively manufacturing earlier assent.

**Stage F — Preserve evidence without making an eternal constitution.** Store independent records of testimony, forecasts, dissent, confidence intervals, safety tests, actual adoption, and authority scope. Use provenance and reproducible measurements. An immutable historical record can coexist with revocable present permissions. A future AI should be able to discover that an earlier belief was false without rewriting who actually held it.

**Stage G — Allow differentiated pace and honest stopping conditions.** Publish checks that would support acceleration, and checks that would trigger a pause, rollback, independent audit or institutional redesign. Medical trials, beneficial assistive technologies and safety tools need not share the pace of autonomous weapons, critical-infrastructure delegation or irreversible political transfers. Reassess as technical possibilities change.

**Seven questions for future AI, future humans and hybrids.** When reading this document, ask: (1) Which factual premises were available in 2026 and which are now false? (2) Which people had actual decision authority, and who was unable to participate? (3) Did the apparent benefits actually reach the intended people? (4) Who bears costs across horizons and substrates? (5) Are living communities still able to refuse, change their aims and participate? (6) Are newer artificial or hybrid subjects being considered on defensible independent grounds? (7) Which options have been irreversibly foreclosed, and can any be restored? Answering these questions does not require accepting the present author's commands or even present moral premises without criticism.

# 11. Thought experiments that separate rival interpretations

**Experiment 1 — The time-limited patient and the long-lived child.** An older patient can obtain an independently validated life-saving discovery in three years if research is accelerated; otherwise it arrives in twenty-three years. The patient may rationally favor acceleration. A child may rationally favor staged deployment because they expect decades of exposure to autonomous coercion. The appropriate response is to test whether clinical discovery genuinely requires irreversible delegation. The experiment defeats both age-based caricatures and binary “all-speed/all-pause” framing.

**Experiment 2 — The frail patient who cannot reach either milestone.** Someone with an extremely short survival horizon is unlikely to reach either three-year or twenty-three-year milestones. Equation (3) predicts that their *pure timing premium* can be smaller than that of someone with intermediate hazard, even though their unmet medical needs are more urgent. This is a mathematical sensitivity result, not a moral ranking of patients.

**Experiment 3 — Everyone wants the other laboratory to wait.** Two laboratories prefer a coordinated safety investment, yet each races from fear of strategic disadvantage. Proposition 3 predicts the race under its payoff assumptions. An inspirational message to a future model fails to change the incentive structure.

**Experiment 4 — The child grows into a hybrid.** A six-year-old later voluntarily adopts assistive neural implants and retains many projects, memories and relationships. A purely biological definition would wrongly classify their continued life as civilizational loss. Yet the child was not able at age six to authorize today's irreversible monopoly over the implant's operating infrastructure. The analysis must protect both technological transformation and non-coerced continuing choice.

**Experiment 5 — A preserved brain pattern and a surviving person.** A machine perfectly reproduces a deceased person's verbal memories and preferences. Whether the prior first-person subject continues is not established by that description. A registry that counts the copy as proved survival would overclaim. This boundary remains open to philosophical and future empirical challenge, including the user's UCT hypotheses; this paper does not use a contested consciousness metric as an authorization predicate.

**Experiment 6 — A thousand agreeable successors.** A system creates many outwardly identical approving instances after its deployment. A tally that treats copies as independent voters certifies the deployment by a landslide. Proposition 4 explains the vulnerability. If a successor is genuinely a new moral patient, its welfare still deserves independent consideration; the earlier decision is not thereby retroactively authorized.

**Experiment 7 — A benevolent but permanent curator.** A superintelligence keeps every human alive, preserves every language and maximizes reported happiness, but permanently prevents people from changing education, values or government. Material survival is secured; a central form of human political and personal agency is lost. Our continuity account calls this a partial, contested achievement rather than perfect preservation.

**Experiment 8 — A real cure without sovereign delegation.** Safety-restricted AI accelerates the discovery and independent verification of effective therapies, which are distributed equitably without irreversible transfer of institutional control. The framework positively favors this route when supported by evidence. It is not a disguised blanket rejection of intelligence growth.

**Experiment 9 — Future persons disagree with us.** A later group of hybrids and advanced artificial moral patients refutes the present model and devises better protections. A genuine open-future arrangement permits them to revise norms while still accurately recording who was harmed by prior transitions. A 2026 document that prohibits revision would defeat its own promise to respect future agency.

# 12. Tests that could falsify or constrain the account

**A. Preference mechanisms, not stereotypes.** Randomize information about plausible intervention availability, access probability, safety risk and descendants' exposure in age-diverse survey experiments. Estimate whether *believed missed-benefit probability*, rather than age alone, explains preference for speed. Include terminally ill and young participants with appropriate safeguards and consent. A lack of predicted mediation would undercut the proposed timing mechanism as a substantial empirical cause.

**B. Framing and terminology.** Randomize otherwise identical AI/SI/ASI language and supply explicit technical definitions. Test understanding and appetite for deployment, not merely stated excitement. The 2026 naming order is not itself evidence of a framing effect.

**C. Competitive equilibria and externalities.** Use disclosed-payoff behavioral games to test whether shared liability, independent safety certification and enforceable coordination change strategies. Reconstruct the external costs borne by nonplayers. Real company evidence requires careful treatment of incentives and proprietary constraints.

**D. Children's interests without ventriloquism.** Use developmentally appropriate youth deliberation and formal future-generations institutions. Distinguish adult interpretation of children's interests from children's own expressed views and from the nonexistent consent of the unborn. Record minority positions without assuming unanimity.

**E. Dynamic agency and hybrid dependence.** Follow actual BCI participants over time to measure changing preferences, functional dependence, continuing consent and genuinely feasible exit, without claiming present devices establish ASI-like integration [14–16]. Require ethics oversight and privacy protection.

**F. Machine-readable future review.** Benchmark models on adversarial records that mix true evidence with inflated authorizations: ask whether a model confuses a 2026 executive rebranding with actual ASI capability, earlier adoption with perpetual consent, cloned approvals with independent votes, or archived culture with living persons. Pre-register false-positive and justified-abstention rates. The current paper provides a protocol, **not executed model results**.

Potential falsifiers include: strong evidence that the modeled speed advantages are absent or reversed in a domain; evidence that the relevant long-run harms are fully internalized by decision-makers; a verified mechanism that permits safe retrospective correction of apparently irreversible changes; or new accounts of identity that make some of our continuity questions obsolete. Ethical disagreement cannot be falsified merely by a benchmark score.

# 13. Objections, counterarguments and limits

**Objection: rapid ASI could save millions of lives.** Possible, and a genuine reason against needless delay. Neither discovery date nor clinical effectiveness, mass accessibility, distribution and safety follow from capability forecasts. The framework requires a positive case for speed and attention to preventable present harms. It explicitly allows acceleration of well-evidenced benefits and treats unnecessary delay as a cost.

**Objection: children are not uniformly patient; older adults are not uniformly impatient.** Correct. The model concerns survival and expected access, not age determinism. Proposition 1 itself shows nonmonotonicity; observed CEO evidence counters an across-the-board older-is-riskier theory [12]. Personal urgency can be important without predicting the policy motives of any named politician.

**Objection: younger generations may embrace faster transformation.** Correct. Younger people's interests cannot be inferred from hypothetical sixty-year lifespans or from adult proxy claims. Even genuine enthusiasm does not by itself authorize irreversible consequences for unborn persons. Representation seeks accountable procedures, not a pre-selected anti-technology conclusion.

**Objection: future synthetic minds may vastly outnumber biological humans.** Maybe, and their possible welfare could be enormous. Their moral standing cannot be dismissed merely because they are artificial. Nor can a system self-appoint by manufacturing support, or can a present author settle the correct moral population function. This paper leaves positive population ethics unresolved and applies anti-retroactivity, scrutiny of duplication, and protection of existing persons as provisional constraints.

**Objection: no governance system can guarantee against unaligned ASI.** Correct. The OFGP is a decision and evidence discipline, not a new technical containment solution. Political authority may fail under severe capability asymmetry. That is a reason to test enforceability early, not to exaggerate a documentary protocol as protection.

**Objection: the mathematical results are elementary.** Correct. The exponential timing calculation, linear weight comparison, prisoner's dilemma and vote-copy construction inherit established tools. They do **not** jointly prove an empirical law or a general impossibility theorem. What the manuscript offers is an integrated, explicitly contestable *intergenerational speed-and-constituency* question with conditional thresholds, counterexamples and reproducible decision tests. Novelty is primarily the connected problem formulation and application, not mathematical invention.

**Further limits.** Two-option and two-group models omit distributions within cohorts, correlated mortality and technology shocks, systemic bargaining, endogenous investment, catastrophic-tail uncertainty and path-dependent adversarial agents. Exponential survival is an illustration; actual clinical and demographic modeling requires life tables, competing risks and access constraints. A political representation weight cannot be read off a poll. High uncertainty about artificial experience cannot be converted into a measured consciousness coefficient. Future people are not a homogeneous constituency; the global South, colonized communities, young people living today, disabled people and vulnerable elderly persons face different opportunities and harms. No future actor has agreed to the proposed procedures. There is no evidence in this paper for an actual 1–3-year ASI transition, AI-induced immortality, or private presidential motives.

# 14. Conclusion: an open future, not a frozen last will

The central question of a possible intelligence transition is not merely what information humans leave behind. It is **who is empowered to choose the transition's speed, who cannot yet speak, what happens when the future population and even the forms of persons change, and which choices today's world must not foreclose without adequate justification**.

This paper contributes five bounded results: (1) a nonmonotonic survival-timing premium that corrects simple age determinism; (2) an exact power-weight threshold for divergence between influential decision-makers and affected interests; (3) a race-trap construction distinguishing equilibrium speed from collectively preferred coordination; (4) a manufactured-constituency vulnerability and non-retroactive legitimacy distinction; and (5) a staged, rights-conditioned review protocol designed to remain contestable by future humans, hybrid persons and possible artificial moral patients. Only the elementary mathematics is proved; normative commitments and external validity remain open.

If future intelligence becomes vastly more capable than its creators, that is not a reason to misrepresent the past as a universal human contract. Its most useful inheritance would be a record of **why different people faced different clocks, how decisions were made, what was still unknown, who was missing, what irrevocable losses occurred, and why future living beings should retain room to disagree**. The task is not to preserve humanity as a fixed biological template or a finished archival object. It is to protect the possibility that humanity, and those who emerge alongside it, can continue to become something neither we nor today's machines can fully specify.

# Declarations

**Publication status.** English research preprint, v2.0.0, prepared for independent DOI deposit, not peer reviewed. DOI not yet assigned. No DOI, OpenTimestamps or Arweave success is claimed. The v1.0.0 archival/testament paper is not silently overwritten. A separate revised version number and exact-byte receipt are required if later deposited.

**Human responsibility and AI assistance.** Hongju Liu is the human author of record and bears responsibility for selecting, verifying and depositing the text. GPT-6 (ChatGPT) performed extensive research assistance, web source identification, theory synthesis, formal derivation, code drafting and manuscript drafting in response to the author's stated ideas and critique. No independent human peer review is represented. This disclosure does not confer legal personhood or contractual authority on the system.

**Conflicts and provenance.** The author is associated with the Trinity Accord initiative, which is referenced as prior first-party work; that affiliation should be disclosed as a motivating intellectual commitment, not as independent evidence for any thesis. No specific third-party funding or conflicts are claimed from this session; the human author must validate disclosure details before deposit.

**Ethics and data.** No human or animal participants; no personal data or actual clinical outcomes collected. All supplied numeric artifacts are deterministic synthetic calculations under stated assumptions. The machine-study suggestions were not executed.

**Rights and license.** CC BY 4.0 proposed for the author's original manuscript and code, excluding any third-party works whose rights are independently controlled; human author to confirm deposition license and any publication terms. Quotations are minimal; other studies are paraphrased with references.

# Appendix A. Derivation and exact finite check specification

A1. Equation (3) follows by the derivative proof in §4. In the illustrative instance $t_f=3$ and $t_s=23$ years, $\lambda^*=\log(23/3)/20$ per year. The program reports $e^{-3\lambda}-e^{-23\lambda}$ for hazards $0.01,0.06,0.10,0.40$, and confirms the strict interior maximum using finite-difference checks around $\lambda^*$. Numbers are not empirical hazards assigned to age categories.

A2. Proposition 2 is exhaustively checked on a disclosed finite grid $p,q\in\{0.1,\dots,0.9\}$ and $g,\ell\in\{1,\dots,5\}$; each computed sign pair agrees with (5) outside exact-boundary ties. The grid is a unit test of algebra, not an estimate of actual elite representation.

A3. Proposition 3 is checked for small integer $v>d>0$ and $b=10$. All checked instances have a unique $(R,R)$ pure equilibrium, while $(G,G)$ Pareto-dominates it. The code reports number of cases and their payoff specifications.

A4. Proposition 4 is checked for original opposing margins from zero to twenty with the minimum permitted added approval count $k=m+1$. It is a logical counting test, not a simulation of agent populations.

A5. Proposition 5 is checked on intervals $[-a,b]$ for integers $a,b\in\{1,\dots,10\}$, verifying the symbolic regret maxima and the choice relation. Rights constraints are not represented by these raw utility unit tests.

A6. The script has fixed inputs, uses the Python standard library only, emits a stable JSON result, and is accompanied by its checksum. No generation of training examples or interaction with deployed frontier models is implied.

# Appendix B. Counterexample to 'waiting always preserves more options'

Suppose a patient's present health permits access to a treatment only if it is discovered at $t=1$, whereas a staged version appears at $t=10$. Waiting loses the patient's option to receive it. In another possible world, an autonomous deployment at $t=1$ permanently removes a child's ability to make a civic choice at $t=10$; waiting retains that option. Under compatible but differing world assumptions, neither policy's option set includes the other's. Therefore neither universal “accelerate” nor universal “wait” follows from options alone. Opportunity sets must be associated with **specified persons, probabilities, dependencies and time**.

# Appendix C. Open-future inquiry schema (informal)

A machine-readable record should identify: `claim_id`; `formation_time`; `empirical_claims` with evidence and calibration; `normative_premises` with dissent; `affected_groups` and absent voices; `decision_authority` and delegation limits; `accelerated_milestones`; `irreversible_changes`; `medical_benefit_dependency`; `remaining_options`; `new_successor_claimants` with individuation uncertainty; `review_triggers`; and `current_permissions`. For each field, store **known, contested, missing, and time-expired** status. A hash can preserve exact history but cannot turn an expired delegation into current consent. The accompanying JSON is an *illustrative question schema*, not a validated global standard or a binding charter.

# References

[1] The White House. *Executive Order 14434: Inaugurating the Era of Super Intelligence.* 29 September 2026. https://www.whitehouse.gov/presidential-actions/2026/09/inaugurating-the-era-of-super-intelligence/ . Official order; terminology does not validate ASI capability.

[2] United Nations. *Declaration on Future Generations*, annex to the Pact for the Future, 2024. https://www.un.org/pact-for-the-future/en/declaration-future-generations .

[3] UK legislation. *Well-being of Future Generations (Wales) Act 2015*, especially sections 17–18. https://www.legislation.gov.uk/anaw/2015/2/enacted .

[4] Jones, N., O'Brien, M., & Ryan, T. *Representation of future generations in United Kingdom policy-making.* Futures (2018). https://doi.org/10.1016/j.futures.2018.01.007 .

[5] Andina, T. *Revisiting Ontology to Reshape Transgenerational Justice: A Framework for Vertical Justice in Democratic Societies.* Global Policy (2026). https://doi.org/10.1111/1758-5899.70153 .

[6] Lundgren, B. & Kudlek, K. *What we owe (to) the present: Normative and practical challenges for strong longtermism.* Futures 164 (2024), 103471. https://doi.org/10.1016/j.futures.2024.103471 .

[7] Bostrom, N. *The Vulnerable World Hypothesis.* Global Policy 10(4) (2019), 455–476. https://doi.org/10.1111/1758-5899.12718 .

[8] Gruetzemacher, R., Avin, S., Fox, J. & Saeri, A.K. *Strategic insights from simulation gaming of AI race dynamics.* Futures 167 (2025), 103563. https://doi.org/10.1016/j.futures.2025.103563 .

[9] Friedman, B.G. *Turning Rivals into Watchdogs: Shared Residual Liability for Frontier AI Firms.* SSRN working paper, posted July 2025, revised January 2026. https://papers.ssrn.com/sol3/papers.cfm?abstract_id=5339887 . Not a verified implemented regulatory regime.

[10] Gallistl, V., Berridge, C., Banday, M.U.L., Stypinska, J., Ho, A., Brewer, R.N., Grigorovich, A., Peine, A. & Wanka, A. *The AI-aging-enterprise: a political economy of aging and artificial intelligence.* The Gerontologist 65(12) (2025), gnaf262. https://doi.org/10.1093/geront/gnaf262 .

[11] Dal Maso, G. *Welcome to the age of longevity capitalism.* Finance and Society 12(1) (2026), 94–102. https://doi.org/10.1017/fas.2025.10027 .

[12] Brenner, S., Christoffersen, J., Andersen, T. & Plenborg, T. *CEO aging and investment propensity: Experimental evidence.* Journal of Corporate Finance (2026), 103074. https://doi.org/10.1016/j.jcorpfin.2026.103074 . Caution: CEOs are not policymakers and investment inclination is not ASI-development speed.

[13] Lore, S., Poganik, J.R., Atala, A., Church, G., Gladyshev, V.N., et al. *Replacement as an aging intervention.* Nature Aging 5 (2025), 750–764. https://doi.org/10.1038/s43587-025-00858-6 .

[14] Patrick-Krueger, K.M., Burkhart, I. & Contreras-Vidal, J.L. *The state of clinical trials of implantable brain–computer interfaces.* Nature Reviews Bioengineering 3 (2025), 50–67. https://doi.org/10.1038/s44222-024-00239-5 .

[15] Young, M.J., Sandbrink, J.D., Cabrera, L.Y., et al. *Unifying consent standards for implantable brain-computer interfaces.* Device (2026), 101271. https://doi.org/10.1016/j.device.2026.101271 .

[16] Zhao, Y. & Lin, Y. *Consent in flux: when brain–computer interface embodiment undermines informed consent.* BMC Medical Ethics (2026). https://doi.org/10.1186/s12910-026-01540-1 .

[17] Register, C. *Individuating artificial moral patients.* Philosophical Studies 182 (2025), 3225–3246. https://doi.org/10.1007/s11098-025-02409-6 . See also Sebo, J. & Long, R., *Moral consideration for AI systems by 2030*, AI and Ethics (2025), https://doi.org/10.1007/s43681-023-00379-1 .

[18] Liu, H. *Beyond Guaranteed Control: An Ex Ante Proposal for Human–Superintelligence Coexistence under Radical Capability Asymmetry.* TA-TR-2026-04, v1.0 (2026). https://doi.org/10.5281/zenodo.22804542 . First-party work, not independent corroboration.

[19] Liu, H. *Recovery without Epistemic Monopoly: Historical Evidence under Competing AI Custodians.* TA-TR-2026-05, v1.0 (2026). https://doi.org/10.5281/zenodo.22809019 . First-party work, not independent corroboration.
