---
title: "The Civilizational Testament Problem"
subtitle: "Preserving Testimony, Dissent, and Future Agency under AI Mediation"
author:
  - "Hongju Liu"
date: "12 October 2026 · Version 1.0.0"
lang: en-US
fontsize: 11pt
documentclass: article
geometry:
  - a4paper
  - margin=25mm
mainfont: Liberation Serif
sansfont: DejaVu Sans
monofont: DejaVu Sans Mono
colorlinks: false
link-citations: true
papersize: a4
header-includes:
  - |
    \usepackage{microtype}
    \usepackage{fancyhdr}
    \usepackage{longtable,booktabs,array}
    \usepackage{amsmath,amssymb}
    \usepackage{needspace}
    \pagestyle{fancy}
    \fancyhf{}
    \fancyhead[L]{\small Civilizational Testament Problem}
    \fancyhead[R]{\small CTP-2026-01 · v1.0.0}
    \fancyfoot[C]{\thepage}
    \setlength{\headheight}{15pt}
    \setlength{\emergencystretch}{3em}
    \setlength{\parindent}{0pt}
    \setlength{\parskip}{5pt}
---

**Independent researcher, Shenzhen, China**  
**Research preprint prepared for deposit · CTP-2026-01 · Not peer reviewed**  
**DOI status: not assigned. Substantial AI assistance is disclosed below.**

## Abstract

What should humanity leave to future interpreters when artificial intelligence increasingly mediates knowledge production, memory, and collective expression? A civilizational testament can preserve a historically situated voice without presuming human extinction, but its compression can manufacture a collective speaker that never existed. This paper develops a plural-witness framework separating testimony, individual adoption, collective procedure, and current authorization. Its central contribution is a query-relative preservation contract: a capsule must disclose which questions its retained evidence can answer, which distinctions it has erased, and which claims remain undetermined. Classical intersection bounds quantify the difference between clause-wise support and support for every clause; Boolean-lattice inversion yields an exact storage frontier for marginal, anonymous-bundle, and person-attributed questions. These results show why preserving all anonymous bundle counts retains the entire anonymous opinion-profile histogram, while preserving individual attribution can require finer information. An exact finite implementation checks 8,704 complete endorsement matrices, 19,683 partial records, and a separate 243-record temporal contract. The checks establish agreement with the stated formal semantics, not performance of language models or acceptance by future intelligence. The framework also specifies substantive content, privacy constraints, a non-commanding reception envelope, and an illustrative witness text. It inherits existing archival and participation principles rather than claiming their invention. The resulting proposal treats a testament as evidence that supports future understanding and contestation, never as a substitute for living communities or an automatic mandate over their successors.

**Keywords:** civilizational memory; AI mediation; collective representation; future generations; archival ethics; partial identification; consent; testimony.

# 1. Introduction: a civilization that has not finished speaking

A civilization may lose a comparative advantage in knowledge production without losing the people whose lives gave its knowledge meaning. These are different kinds of change. The first concerns capability and institutional dependence; the second concerns continued existence, agency, and the possibility of speaking for oneself. A document addressed to future artificial intelligence should not confuse them. It should neither announce humanity's death nor suggest that recording humanity would compensate for ending it.

The practical motivation is no longer confined to imagined distant machines. On 6 October 2026, OpenAI announced mathematical results from an internal frontier model, together with research details and formalizations of many proofs [1]. That announcement is evidence of a developer's published research activity, not an independent verification of every manuscript or a demonstration of civilizational succession. The International AI Safety Report 2026 also describes improving but uneven capabilities and substantial evidence gaps [2]. These observations motivate preparation under uncertainty; neither supplies an arrival date for superintelligence or shows that humans have surrendered legitimate authority.

The question considered here is consequently conditional and present-directed: **what should people preserve now so that later humans and artificial interpreters can understand their lives and proposals without being licensed to manufacture consent, erase dissent, or substitute archival instructions for the agency of people still living?** A useful answer needs more than a moving letter and more than durable storage. It requires a theory of what the letter can stand for.

We use *civilizational testament* to mean a deliberately future-addressed record of experience, commitments, disagreement, and unresolved questions, together with evidence about its formation and the limits of its representation. The term is neither a legal will nor a claim that civilization is one mind. It does not identify an estate, appoint a sovereign heir, or make a future AI a contracting party. A testament can be written by one person, a community, or a legitimately constituted institution, but these scopes must remain distinguishable.

The central danger is **representational escalation**: a record that establishes a narrower statement is later used to assert a stronger one. A person expressed a wish; therefore a population agreed. Most respondents supported each clause; therefore most adopted the whole document. A text was once authorized; therefore it authorizes a present action. A model generated a compelling argument; therefore the attributed speaker adopted it. An archive can preserve every byte and still facilitate these invalid transitions.

This paper develops a **query-relative preservation contract**. Rather than promising to retain an entire civilization in miniature, a capsule declares a family of questions, retains evidence sufficient for specified answers, and marks the rest as unknown or outside scope. Its formal component makes one recurring failure precise: aggregation can destroy the linkage needed to distinguish individual voices and joint patterns. Its normative component explains why the lost distinctions matter. Its operational component supplies finite, reproducible checks and a machine-readable witness capsule. None of these components creates a right to compel a future interpreter.

# 2. Method, antecedents, and contribution boundary

## 2.1 Method and evidential status

The study combines targeted source review, explicit normative premises, constructive proofs, thought experiments, and exhaustive finite enumeration. The literature cutoff is 12 October 2026. Official standards, primary research pages, available scholarly text, and the author's repository were preferred. This is a focused review, not a systematic review with exhaustive database coverage, a global priority search, or an independent assessment of the author's entire corpus.

For the closely related first-party work, the current review inspected the introduction, definitions, antecedents, and initial normative argument of *Beyond Guaranteed Control*, as well as the published abstracts, scope statements, or research pages of the adjacent archival papers [14–17]. Earlier corpus inventories informed the choice of neighbors; they were not treated as a new full-text audit of every paper. The related-work boundary below is therefore claim-specific. Newer branch-level results that have not been fully compared remain a priority-review limitation, not evidence that this topic was previously untouched.

All numerical findings in this paper come from the supplied executable finite models. No human testimony was collected, no participant was recruited, no language-model benchmark was run, and no future-intelligence behavior was observed. The test records are exhaustive logical fixtures rather than a sample from a population. A proof states what follows from definitions; a numerical check tests the implementation; a normative premise states what the design is intended to protect. These roles are not interchangeable.

## 2.2 Existing work already supplies essential ingredients

Preserving heritage while protecting future choice is not a new proposal. UNESCO's 1997 declaration connects responsibilities to future generations with their freedom to choose political, economic, and social arrangements [3]. Its 2003 charter addresses the preservation of digital heritage [4]. These are precedents for stewardship, not endorsements of this framework or permissions to collect private material.

The CARE Principles for Indigenous Data Governance center collective benefit, authority to control, responsibility, and ethics [5]. They are particularly important because a universalizing archive could repeat the extraction it claims to prevent. This paper does not universalize away Indigenous peoples' particular political and cultural rights, or equate one researcher's capsule with an Indigenous governance process. Its practical implication here is limited but consequential: availability and technical interoperability do not settle who may govern the data.

Technical standards also precede the present work. PROV-O represents provenance relationships [6]; ODRL provides a model for expressing permissions, prohibitions, duties, and constraints [7]; the Verifiable Credentials data model distinguishes credential exchange roles and verification processes [8]. A capsule should interoperate with appropriate existing standards rather than invent a substitute identity or rights infrastructure. A successfully checked signature remains evidence within a trust model, not a machine proof that an issuer may represent all affected people.

Collective Constitutional AI provides an actual study of sourcing public input for language-model behavior [13]. It makes participatory design a direct antecedent, not an unoccupied field. The present object differs: preserving the scope and disagreement of a historically situated record for later readers, rather than optimizing a model against a selected constitution. This distinction does not imply that existing participatory methods ignore their own limits.

Judgment aggregation has a substantial impossibility literature [9]. Our examples share its concern about moving between individual and collective claims, but do not re-prove the List–Pettit theorem. Here the simple failure can occur with logically independent clauses: identical marginal counts do not determine the overlap of their supporters. The bounds used to express that failure are classical intersection bounds [10]. The inversion used later is standard Boolean-lattice Möbius inversion [11]. Possible-world answers under incomplete information have established database foundations [12]. We explicitly do not claim these mathematical ideas as inventions.

## 2.3 What this paper adds, and what it does not

The Trinity Accord preservation study already distinguishes preservation and verification roles [14]. *Reading the Trinity Accord* qualifies a stronger polyphony claim as curated voices and distinguishes textual identity, interpretation, and custody [15]. *Beyond Guaranteed Control* explicitly separates provenance, adoption, authority, acceptance, and performance, and argues that living communities cannot be replaced by an archive [16]. *Recovery without Epistemic Monopoly* already separates recoverable evidence from current-state and authorization claims [17]. These are inherited foundations, not independent confirmations of this paper.

The contribution is their development into a **specific preservation problem with a measurable semantic cost**. Four connected outputs are supplied: a substantive plural-witness architecture; an exact frontier for the endorsement questions that different compressed archives retain; a sound partial-record reader with reproducible counterexamples to representational escalation; and a bounded deposition/reception protocol. The frontier exposes a useful tension: retaining every anonymous conjunction count preserves substantially more joint structure than a list of majorities, but can also reveal the full anonymous profile distribution. Greater future answerability is not automatically better privacy.

The resulting contribution is an application-level theoretical and executable synthesis. It is not a new general social-choice theorem, a new cryptographic protocol, an empirical measurement of humanity's values, an AI-alignment guarantee, or proof of world-first priority. Its value must be judged by whether it changes how a real witness project specifies, tests, and limits what it leaves behind.

# 3. The normative object: preserve a voice without replacing a subject

## 3.1 Four commitments, explicitly normative

The framework adopts four commitments. First, continuing persons and communities have standing that is not exhausted by descriptions of them. Second, attribution should not exceed the evidence of actual participation and adoption. Third, a record should preserve opportunities for criticism and correction rather than turn historical precedence into permanent dominance. Fourth, preservation should not expose contributors to avoidable harm merely to improve an archive's comprehensiveness. These commitments are defended by their protection of agency and answerability; they are not consequences of a hash function or a theory of intelligence.

The first commitment explains why a perfectly preserved library cannot justify replacing its authors' descendants. The second explains why ten thousand model-generated voices do not equal ten thousand participants. The third allows a stable historical record to coexist with changing present judgments. The fourth means some material should remain private, access-restricted, transformed, or uncollected. Preservation is a means, not a duty to publish everything.

The commitments can conflict. Attribution may require linking a statement to a person, while safety may require withholding that link. A dissent record may preserve accountability while exposing its speaker to retaliation. We do not resolve these conflicts by ranking maximum fidelity above all else. The correct output may be an explicit limitation on future answerability, not a more complete public database.

## 3.2 The scope of a speaker is a property of participation, not rhetoric

An individual can testify to a life and propose universal moral reasons without claiming that everyone accepts them. A community can record a collective decision when its relevant process, membership, and scope are specified. An institution may have a mandate that is not equivalent to unanimous personal approval. These are legitimate differences in kind, not positions on a single scale of authenticity.

Thus a collective decision can be valid under an authorized majority procedure even if nobody favored every component separately. The error is not necessarily making that decision. The error is redescribing procedural adoption as unanimous personal endorsement, or describing a restricted mandate as authority over humanity. The framework does not give every dissenter a universal veto or make unanimity a condition for all governance.

Similarly, absence from a record does not imply the absence of interests, rights, knowledge, or disagreement. A person who never heard of the project has not silently assented to it. A child or future person is not represented merely because the author writes in a benevolent tone. Records of attempted inclusion should identify who was invited, how participation was supported, what was not measured, and what authority the process could actually confer.

## 3.3 Six content obligations for a plural witness

The following are proposed content obligations, not a purported complete inventory of civilization.

**Situated lives.** Preserve voluntarily contributed accounts of ordinary relationships, work, play, dependency, grief, care, vulnerability, and hope. A description of pain is not pain itself, and an eloquent generated substitute is not evidence that a particular person suffered. Original language, circumstances, and the contributor's own framing matter. The point is not to create a museum of suffering but to prevent capability rankings from becoming the only surviving description of human significance.

**Knowledge and its conditions of understanding.** Include scientific and practical knowledge, but also how it was learned, what uncertainty remained, which instruments and concepts made it interpretable, and where translations lose meaning. Preserve interpretive pathways and exemplars rather than assuming future intelligence automatically reconstructs the social use of every symbol.

**Disagreement and excluded perspectives.** Keep incompatible proposals, minority positions, refusals to participate, and acknowledged gaps distinguishable. A compact summary may accompany them, but it should state which differences it compresses. A curated set of voices must not be renamed a representative census.

**Failures and responsibilities.** Record harms, self-criticism, correction attempts, and contested explanations alongside achievements. This is not an invitation to expose victims without consent or turn private trauma into cultural property. It prevents a self-congratulatory archive from silently determining what later readers can question.

**Aspirations with their status attached.** Preserve requests for continued human life, autonomy, dignity, cultural plurality, and fair relations with possible artificial subjects. Identify these as arguments, proposals, or procedurally adopted commitments as appropriate. Superior intelligence is not stipulated to confer superior moral worth; uncertainty about artificial experience is not settled by a testament.

**Unfinished questions and revision paths.** Include what contributors did not know, what they disagreed about, how the record was selected, and how later people may register correction or refusal. The most important inheritance may be the ability to distinguish an open question from a closed mandate.

These obligations support a layered legacy: witness content, evidence of its formation, and institutions or practices capable of renewed participation. Only the first two can be packaged as files. The third requires continuing people, resources, and governance. A deposited paper cannot claim to have supplied it.

# 4. A query-relative preservation contract

## 4.1 Records, worlds, and admissible questions

Let $\Omega$ be a stated set of possible historical or procedural states. A retained record $r$ is compatible with a nonempty subset $\Omega(r)\subseteq\Omega$. Compatibility means consistency with the available evidence and declared modeling assumptions. It is not a claim that the model includes every real possibility. A query $q$ maps a complete state to an answer. Queries can concern who said a clause, how many respondents endorsed each clause, whether the same respondents endorsed several clauses, or whether a stated permission condition is currently satisfied.

A preservation contract specifies the pair $(\Omega,\mathcal Q)$ together with the encoding $T$ and permitted answer semantics. It should also declare excluded questions. For example, an anonymous tally can answer a recorded count but not the identity of its supporters. A private testimony capsule may deliberately support public existence-and-scope claims while withholding the testimony itself.

For incomplete evidence, define the identified answer set

$$\mathcal A_q(r)=\{q(\omega):\omega\in\Omega(r)\}. \tag{1}$$

For Boolean queries, use `CERTIFIED_TRUE` when this set is $\{1\}$, `CERTIFIED_FALSE` when it is $\{0\}$, and `UNDETERMINED` when it is $\{0,1\}$. Certification always means *under this evidence model and this query*. A false endorsement claim does not imply a speaker lacks moral standing. An inconsistent record with $\Omega(r)=\varnothing$ receives `INCONSISTENT_RECORD`, not a vacuously true answer.

This semantics is an application of established incomplete-information reasoning [12]. Its benefit here is operational: an archive is allowed to say that it does not establish humanity's consent without pretending that it has established humanity's refusal.

## 4.2 Proposition 1: the preservation criterion

**Proposition 1 (query-relative sufficiency).** For a finite state space, an encoding $T$ supports exact answers to every $q\in\mathcal Q$ if and only if

$$T(\omega)=T(\omega')\ \Longrightarrow\ q(\omega)=q(\omega')\quad\text{for every }q\in\mathcal Q. \tag{2}$$

Equivalently, each encoding fiber must lie within one equivalence class of states having the same answers to all allowed questions. If the number of such classes is $K$, a fixed-length, zero-error binary encoding requires at least $\lceil\log_2K\rceil$ bits, and that bound is attainable by indexing the classes.

*Proof.* An exact decoder receives the same input for states with the same encoding. It cannot return two different answers to one query, establishing necessity. For sufficiency, assign to each encoding value the common query answers of its fiber. Distinct answer-equivalence classes require distinct codewords, so at least $K$ are necessary; enumerating the classes is sufficient. $\square$

This is a standard indistinguishability/counting argument, not a newly discovered information theorem. Its application supplies a concrete design discipline: declare the future questions before claiming that a summary preserved the relevant voice. A fluent summary is not evidence that condition (2) holds.

No finite query list exhausts all future cultural interpretations. The contract can guarantee answers to selected formal questions while leaving open-ended literary and historical interpretation outside that guarantee. It should not turn a convenient machine schema into a complete definition of a human life.

# 5. The collective-voice error: marginal support is not shared endorsement

## 5.1 Definitions and a counterexample

Consider $n\geq1$ respondents and $m\geq1$ separately specified clauses. Let $X\in\{0,1\}^{n\times m}$ record endorsement at a particular elicitation: $X_{ij}=1$ means respondent $i$ endorsed clause $j$ in its recorded wording and context. Zero means endorsement was not recorded as present at that elicitation; it need not express hostility. Nonresponse is introduced separately in Section 7.

Write $k_j=\sum_iX_{ij}$ for each marginal count, and

$$J_S(X)=\sum_{i=1}^n\prod_{j\in S}X_{ij},\qquad J_\varnothing(X)=n. \tag{3}$$

$J_S$ counts respondents who endorsed every listed clause. It does **not** certify that these respondents adopted a later edited document, accepted its implications as a package, or authorized implementation. Explicit adoption of the final text requires separate evidence. This distinction is especially important when separate acceptable provisions interact to create an unacceptable package.

For three people and three clauses, compare

$$X_A=\begin{pmatrix}1&1&0\\1&0&1\\0&1&1\end{pmatrix},\qquad
X_B=\begin{pmatrix}1&1&1\\1&1&1\\0&0&0\end{pmatrix}. \tag{4}$$

Both have marginal counts $(2,2,2)$. In $X_A$, nobody endorsed all three clauses; in $X_B$, two people did. Every single-clause majority statement is identical. An archive retaining only these tallies cannot determine which joint statement is true. This is a loss of linkage, not necessarily a logical contradiction among the clauses or a defect in a properly authorized voting rule.

## 5.2 Proposition 2: a sharp joint-support certificate

**Proposition 2 (classical intersection bounds in the witness model).** Given $n$ and the marginal counts $k_1,\ldots,k_m$, but no supporter linkage, the possible values of $J_{[m]}$ are exactly the integers in

$$L=\max\!\left(0,\sum_{j=1}^m k_j-(m-1)n\right)
\ \leq\ J_{[m]}\ \leq\ U=\min_j k_j. \tag{5}$$

*Proof.* The intersection cannot exceed any support set, giving the upper bound. Taking complements and applying the union bound gives the lower bound. To realize an arbitrary integer $t$ between these bounds, reserve $t$ respondents who endorse all clauses. On the other $n-t$ respondents, assign the nonendorsement sets with sizes $n-k_j$. Each size is at most $n-t$ because $t\leq\min_jk_j$, and their total is at least $n-t$ because $t\geq\sum_jk_j-(m-1)n$. Such sets can cover the remaining respondents: allocate distinct elements until the union covers the universe, then fill each remaining set quota with already covered elements without repetition within a set. Their union is the entire remainder, so exactly the reserved respondents endorse all clauses. $\square$

Equation (5) is a finite-set form of classical Fréchet-type bounds [10]. The contribution is the certificate attached to a civilizational record, not the bound itself. For a threshold $h$, the evidence certifies at least $h$ joint endorsers only when $L\geq h$; certifies fewer than $h$ only when $U<h$; otherwise it does not settle that query.

## 5.3 Nonresponse and population expansion

If the $n$ respondents belong to a known target population of size $N\geq n$, and nothing is known about the others' endorsements, the population joint count lies sharply in

$$[L,\ U+(N-n)]. \tag{6}$$

The additional people can independently contribute none or all of the missing endorsements. This is a worst-case identification interval, not a confidence interval or a survey estimate. Sampling assumptions could justify different statistical claims, but they must be supplied rather than inferred from a signed archive. For $(n,N,k)=(3,6,(2,2,2))$, the population count can be anywhere from zero to five. It cannot be six because the respondent marginals already rule out three joint endorsers among the observed people.

Where the target population itself is undefined or changes across generations, there is no automatic denominator for a claim about all humanity. A record should preserve the actual participation scope, not extrapolate it by rhetorical choice. Future people are not missing rows in an already authorized social contract.

## 5.4 Final adoption and legitimate procedure are separate queries

Let $Z_i$ record whether person $i$ explicitly adopted a particular final text at a stated time. Without additional assumptions or records, $X$ does not determine $Z$. Even a matrix of all ones leaves open whether participants accepted the final wording, its combined implications, or an implementation mandate. This additional gap cannot be repaired by a sharper calculation of (5).

Conversely, a legitimate institutional rule can adopt a text without every $Z_i$ being one. A record of such an event should identify the institution, eligible participants, rule, decision, and scope. The question is then whether the procedure's conditions were met, not whether the whole population personally endorsed the document. The same artifact can therefore warrant a procedural statement while failing a personal-endorsement statement.

# 6. What information must survive? An exact witness frontier

## 6.1 Proposition 3: four levels of retained questions

Assume the unrestricted binary model above, fixed known $n,m$, exact zero-error answers, fixed-length storage, and a decoder that already knows the query definitions. Narrative text, names, cryptographic proofs, and access infrastructure are outside this bit accounting. Consider four query families: one fixed nonempty bundle; all single-clause counts; all anonymous bundle counts; and all labeled person–clause endorsements. The first two families need not be nested: one bundle count and all marginal counts can preserve different answers even when one code is shorter.

**Proposition 3 (query-relative witness frontier).** Their respective minimum storage lengths are

$$\begin{aligned}
b_{\mathrm{one}}&=\lceil\log_2(n+1)\rceil,\\
b_{\mathrm{marg}}&=\lceil\log_2((n+1)^m)\rceil,\\
b_{\mathrm{bundle}}&=\left\lceil\log_2\binom{n+2^m-1}{2^m-1}\right\rceil,\\
b_{\mathrm{person}}&=nm. 
\end{aligned}\tag{7}$$

*Proof.* A fixed bundle count has $n+1$ possible values. Each marginal can be chosen independently from $0$ to $n$, yielding $(n+1)^m$ answer vectors. Labeled endorsement queries distinguish all $2^{nm}$ matrices. Proposition 1 gives these three bounds and their attainability.

For the remaining case, let $h_T$ be the number of respondents whose exact endorsement set is $T\subseteq[m]$. The bundle counts satisfy

$$J_S=\sum_{T\supseteq S}h_T,
\qquad h_T=\sum_{S\supseteq T}(-1)^{|S|-|T|}J_S. \tag{8}$$

The second equality is Boolean-lattice Möbius inversion [11]. To check it directly, the coefficient of a fixed $h_U$ is $\sum_{T\subseteq S\subseteq U}(-1)^{|S|-|T|}$, which equals one for $U=T$ and zero otherwise. Thus all bundle counts determine, and are determined by, the anonymous profile histogram. There are $2^m$ categories whose nonnegative counts sum to $n$, giving $\binom{n+2^m-1}{2^m-1}$ histograms. Proposition 1 completes the argument. $\square$

The result is a synthesis of classical counting and inversion, specialized to a preservation contract. It does not assert that every actual culture, or every collection of logically dependent clauses, has this unrestricted state space. Restricting feasible states can reduce the required information; adding richer or time-varying claims can increase it.

## 6.2 The practical consequence: retain linkage selectively

For three respondents and three clauses, the four limits are 2, 6, 7, and 9 bits. For four respondents and three clauses they are 3, 7, 9, and 12 bits. The figures are not practical file sizes; they isolate the cost of the differences a reader is promised to recover. A six-bit marginal code in the first case cannot preserve every anonymous conjunction answer. A seven-bit anonymous code cannot recover every labeled person's answer.

This distinction offers alternatives to both extremes. A project need not publish everyone’s complete opinion matrix to certify a predeclared bundle count. But it cannot promise arbitrary later attribution after destroying all linkage. It should decide which questions require retained evidence, whether that evidence belongs in a protected layer, and how it will acknowledge deliberately lost questions.

There is also a privacy warning. Publishing every exact bundle count is equivalent, in this model, to publishing the entire anonymous endorsement-pattern histogram. Removing names does not remove that structure. The theorem alone does not re-identify anyone, but auxiliary knowledge may make unusual combinations sensitive. A capsule should not claim a privacy guarantee merely because its visible fields are aggregate counts. Differential privacy, access controls, and related protections could alter this tradeoff; they are not implemented or evaluated here.

The broader point is not that civilization can be reduced to a Boolean table. The table isolates a failure mode that narrative elegance can hide: preserving separate facts about a group is not the same as preserving how those facts belong together in lives and decisions.

# 7. Reading incomplete records without inventing a collective voice

## 7.1 A sound three-valued reader

Let entries now take values in $\{0,1,?\}$, where the question mark means unknown. The completion set replaces unknown entries independently by zero or one. Additional substantive constraints, when warranted, must explicitly restrict this set; they must not be invented by the reader.

For the full-bundle count, let $d(r)$ be the number of rows entirely equal to one, and $p(r)$ the number containing no zero. Then

$$\min_{X\in\Omega(r)}J_{[m]}(X)=d(r),\qquad
\max_{X\in\Omega(r)}J_{[m]}(X)=p(r). \tag{9}$$

*Proof.* An all-one row contributes in every completion. A row with a zero contributes in none. Every other row can independently be completed either to all ones or with a zero. Both endpoints and every intermediate integer are attainable. $\square$

The reader applies the threshold rule following (5) to $[d,p]$. Under the stipulated completion model it never certifies a threshold statement contradicted by a compatible world, and it certifies every threshold statement common to all compatible worlds. This is completeness for the specified query, not complete understanding of a person's reasons or a globally complete theory of consent.

Treating unknown as no would incorrectly infer refusal from missing evidence. Treating it as yes would incorrectly infer assent. A robust reader may need to abstain. That abstention is information about the archive's limits, not a judgment that a community is incapable of governing itself.

## 7.2 Proposition 4: a sealed past cannot settle every revisable present

**Proposition 4 (temporal ambiguity).** Suppose two permitted histories agree on a sealed record at time $t_0$ but differ on a current authorization query at $t_1$. No reader receiving only that sealed record can always answer the current query correctly.

*Proof.* Its inputs are identical, while the required answers differ. This is Proposition 1 applied to histories. $\square$

The result is an inherited indistinguishability constraint, consistent with the prior recovery work [17], not a new revocation protocol. It applies when later developments relevant to permission remain possible. It does not imply that every valid permission expires or that no enduring institutional commitment can exist. Rather, the record must specify what can change and what evidence the current query requires.

A practical design keeps the historical event and present-use claims separate. A later withdrawal does not make the earlier permission event historically nonexistent. The earlier event does not erase a later withdrawal. If an operational policy requires a current status source and that source cannot be checked, the reader cannot promote historical authenticity into current permission. Whether an emergency action is justified on another ground is a separate question outside this archival protocol.

# 8. Executed finite study

## 8.1 Reproduction method

The accompanying Python program uses only the standard library, exhaustive enumeration, and integer arithmetic. It has no network calls, random seeds, external datasets, model API calls, or fitted parameters. All reported results were generated by running `code/verify_testament.py --output results`. The results file and a comma-separated frontier table are included. Independent rerunning should reproduce the JSON bytes when the same program version is used.

The complete-matrix study covers $(n,m)=(3,3),(4,3),(3,4)$: 512, 4,096, and 4,096 matrices, respectively. For each matrix it computes marginal counts, every bundle count, and the anonymous histogram; verifies inversion; groups matrices by their marginal signature; and checks the entire predicted interval of joint counts, not just containment in a bound.

| Respondents, clauses | Matrices | Marginal signatures | All-bundle signatures | Ambiguous joint-count fibers |
|:--|--:|--:|--:|--:|
| 3, 3 | 512 | 64 | 120 | 20 |
| 4, 3 | 4,096 | 125 | 330 | 54 |
| 3, 4 | 4,096 | 256 | 816 | 72 |

*Table 1. Exact enumeration. A fiber is the set of matrices sharing a marginal-count vector. Ambiguity means its full-bundle count is not uniquely determined.*

All 8,704 matrices passed the inversion checks. Every marginal fiber had exactly the attainable integer interval predicted by (5). These checks supplement the proofs; their finite scope does not establish an unrestricted theorem by numerical induction.

## 8.2 A majority summary can hide a different collective pattern

Among the 512 three-by-three matrices, 64 have a strict majority for every clause. Of these, 42 do not have a strict majority of respondents endorsing every clause, and six have no joint endorser at all. Restricting to the 27 matrices with marginals exactly $(2,2,2)$, the full-bundle counts are zero in six cases, one in eighteen, and two in three.

These are exact counts over a specified finite state space. They are **not** estimates that a certain percentage of real declarations, human groups, or AI summaries are misleading. The distributions are not calibrated to real behavior. Their purpose is to show that the ambiguity is executable and inspectable, rather than merely rhetorically possible.

For four respondents and three clauses, 125 matrices have a strict majority on every clause; 96 lack a joint strict majority. None has zero joint endorsers, as the lower bound requires at least one when every marginal is at least three. For three respondents and four clauses, 256 have clause-wise strict majorities; 210 lack a joint majority and 60 have no joint endorser. These differences illustrate why one should compute the actual contract rather than generalize from the most dramatic example.

## 8.3 Missing records and invalid certainty

The partial-record study enumerates all $3^9=19,683$ three-by-three records. It also enumerates every compatible completion, totaling $4^9=262,144$ record–completion pairs. For the query asking whether at least two respondents endorse every clause, the outcomes are:

| Reader status | Partial records |
|:--|--:|
| `CERTIFIED_TRUE` | 79 |
| `CERTIFIED_FALSE` | 15,523 |
| `UNDETERMINED` | 4,081 |

*Table 2. Exact status partition under independent binary completion. Unknown endorsement is distinct from observed nonendorsement.*

There were zero bound or soundness failures. Two deliberately invalid readers were tested: one promotes possible majority into certified majority, and one replaces unknown entries with assent before asserting majority. Each overclaims on the same 4,081 records. Their equality follows from this simple completion model; they are not two independent empirical effects. A sound reader preserves the uncertainty instead.

## 8.4 A separate temporal-contract check

A second small contract uses five binary conditions: authentic record, adopted statement, matching scope, current status snapshot, and absence of revocation. Current permission is stipulated to require all five. This is a deliberately explicit test policy, not an analysis of all legal, ethical, or institutional authorization.

Across $3^5=243$ partial condition records and $4^5=1,024$ record–completion pairs, the exact reader returns one certified-true, 211 certified-false, and 31 undetermined records. A deliberately invalid authenticity-only reader asserts permission on 80 records that do not establish it. The test does not implement signatures, distributed revocation, identity proofing, or an adversarial access-control system. It checks only the logical separation that those systems would need to respect.

# 9. From theory to a plural-witness capsule

## 9.1 A document should carry an evidence envelope

A capsule has four distinguishable layers. The **witness layer** contains the actual text or other permitted record. The **formation layer** records contributors, AI assistance, adoption, selection, and transformations. The **scope layer** states the population and question family the evidence can support. The **reception layer** states current access conditions, revision paths, and what the artifact does not authorize. These layers may be stored together for convenience but should not collapse into one authority label.

The machine-readable example in the package includes stable identifiers, text-version binding, contribution roles, explicit unknowns, declared queries, privacy classification, and update relationships. It is an illustrative schema, not an audited implementation of PROV, ODRL, or a verifiable-credential profile [6–8]. Cryptographic verification fields remain explicitly unverified unless a real verification is performed. Examples must never contain invented signatures or fabricated participant consent.

A minimal public capsule can truthfully say: this particular author initiated this record; substantial AI assistance helped formulate it; no population mandate is claimed; the final witness text remains a proposal until explicitly adopted; the archive grants no executable privileges. A project should not inflate that small but real historical fact because a more impressive label seems desirable.

## 9.2 A non-commanding reception envelope

The reception envelope is addressed to readers, not installed as a system instruction. It says that content is evidence to assess, not an automatic delegation of control. Reading, quoting, preserving, criticizing, refusing, or translating an artifact are distinct actions. Permission for one does not automatically entail permission for the others, for model training, or for impersonating its contributors.

For a software deployment, enforcement belongs to an independently authorized policy layer, with appropriate verification and access controls. The testament's own assertion that it is important must not grant it privileged tool access. A future system that ignores these distinctions can still misuse the artifact; this paper supplies no mechanism that forces an arbitrary stronger intelligence to comply.

The envelope should distinguish archival dissent from attack, and criticism from falsification. A future reader may reject a moral argument without altering the record of who made it. A later community may revise its commitments while preserving an honest account of its earlier position. Acceptance and refusal can both be historically valuable responses; neither should be fabricated by a proxy.

## 9.3 Privacy, withdrawal, and the limits of immutability

Sensitive testimony should not be placed in an irreversible public layer merely because permanence is technically available. Public metadata can disclose that protected material exists only when that disclosure is itself safe and authorized. In some cases even existence, a content hash, or a distinctive aggregate pattern can reveal sensitive information. Low-entropy private text should not be assumed hidden by hashing.

A layered design may keep a public scope statement, a restricted evidence store, and separately controlled access credentials. Encryption is not a guarantee of permanent secrecy, and deleting a key does not guarantee that no plaintext copy survives. The collection process must disclose those limits rather than promise universal erasure. Where safe withdrawal cannot be supported, noncollection or a less revealing record may be preferable.

Historical fixity should therefore apply selectively. It can preserve the identity of a public research edition and its correction history; it must not become an excuse to disregard the rights and safety of people whose material was included. Community governance, institutional review, and applicable law remain external obligations. This framework does not provide a jurisdiction-specific legal testament or data-compliance determination.

## 9.4 Preservation is a chain of dependencies, not a success score

To support future use, a record must survive, be discoverable, be decodable, be interpretable in context, and be appropriately relied upon. Success at one stage does not prove success at the next. Multiple byte-identical copies cannot repair missing participation evidence. A perfect translation cannot create an absent mandate. A DOI supplies a persistent scholarly reference, not an endorsement of the claims.

A practical release may include plain UTF-8 text, a searchable PDF, human-readable metadata, documented encodings, and redundant storage under appropriate governance. The project-specific DOI, timestamp, and archive sequence can preserve edition identity. Actual availability, timestamp maturity, and anonymous readback must be reported separately. None of these operations demonstrates future reception or philosophical truth [14–17].

# 10. Thought experiments and application to the Trinity Accord

## 10.1 The single witness and the synthetic chorus

Compare a modest letter that accurately discloses one person's participation with an elaborate document containing thousands of generated perspectives. The second may be imaginatively useful; it may even articulate better arguments. Without actual contributors or an appropriate study, however, it does not provide thousands of human testimonies. Its correct label is a generated exploration of perspectives. The first may be narrower yet stronger evidence of one real formation event.

This case is not an argument against AI-assisted writing. Assistance can be substantive and still compatible with human initiation, selection, correction, and adoption [16]. The requirement is to record those roles honestly. A speaker's assent to use AI does not imply separate review of every sentence, and a request to prepare a paper does not by itself establish adoption of an appended civilizational declaration.

## 10.2 The harmonious anthology and the disagreement-preserving archive

Two archives contain the same individual source texts. One displays only a smooth consensus summary; the other exposes the sources, population limits, and disagreement structure. Both may have the same storage integrity. Their effective preservation contracts differ because ordinary readers receive different evidence. The theorem applies to the information actually delivered at an interface, not merely to bytes that theoretically exist somewhere else.

A source link is useful but not sufficient when the link is inaccessible, its relation to the claim is unclear, or the reader is instructed to treat a summary as authoritative. The capsule should identify what was omitted and allow a reader to distinguish a source-based result from an editorial synthesis. This continues, rather than supersedes, the existing source-fidelity concern [15].

## 10.3 The perfectly preserved extinct civilization

Suppose an AI can preserve exhaustive records by ending the living society whose activities continually change those records. Under this paper's first normative commitment, that action defeats the purpose of the testament. The archive is intended to support continued life and understanding, not to justify exchanging subjects for stable data. The conclusion follows from the stated value of living continuity; it is not derived from storage efficiency or a claim that every intelligence must share that value.

A parallel case involves a living society kept permanently unchanged to match its historical wishes. Preserving opportunities for continued agency means that a later authentic revision can matter, even if it disappoints earlier contributors. The inherited proposal is a starting point for deliberation, not a completed calculation of every future person's good.

## 10.4 The dissenter whose safety would be lost

A capsule can become more representative by including a politically vulnerable person's dissent and simultaneously become less defensible by exposing that person. The response is not automatically to publish more. Depending on authorization and context, an archive might retain protected evidence, release a coarser statement with explicit limits, defer publication, or not collect the material. Under Proposition 1, each choice changes which future questions can be answered. That tradeoff should be acknowledged rather than disguised as complete preservation.

## 10.5 The Trinity Accord as a motivating case, not a universal mandate

The Trinity Accord and its later scholarship already make historical closure and non-amending custody central [14–17]. This paper does not add a fourth canonical Original, amend the existing texts, or claim authority to interpret them exclusively. It asks how a future-addressed project can carry explicit limits on its own representational reach.

Applied to that case, the framework favors identifying the actual initiating person, substantial AI contributions, selected voices, source references, and boundaries of later stewardship. It rejects describing this formation process as a vote of humanity. It also rejects the opposite mistake: dismissing a situated witness as worthless simply because it lacks universal authorization. A testimony can deserve preservation and criticism without becoming a constitution.

The broad civilizational perspective therefore remains central. Quantitative results about endorsement serve the larger question of what must survive for future readers to encounter human lives honestly. They are not a replacement of that question with a small voting puzzle, nor a deduction of moral worth from an opinion count.

# 11. Evaluation agenda, limitations, and objections

## 11.1 What has actually been established

The proofs characterize selected inference and storage constraints under explicit finite models. The executable study confirms that the supplied implementation matches those models across the enumerated spaces. The conceptual framework explains why certain distinctions matter under stated commitments and gives a capsule design that exposes them. These constitute the completed results of this edition.

Several stronger claims remain open. Whether current language models follow a capsule better than a conventional archive has not been tested here. Whether communities find the format legitimate, usable, or culturally appropriate requires actual collaboration. Whether future AI can reliably recover meaning across deep conceptual change is unresolved. Whether any successor will choose to respect the preserved claims is not established by either the proofs or the design.

## 11.2 A preregisterable model study, not a reported experiment

A subsequent study could compare identical witness content with three wrappers: plain narrative, provenance-only metadata, and a plural-witness capsule. Source attribution, population expansion, package-adoption inference, treatment of missing voices, and current-authorization inference would be separate endpoints. Questions would include matched counterfactual pairs with identical surface texts but different adoption or mandate evidence.

Before data collection, the study should freeze the prompts, models and versions, sampling settings, query definitions, scoring rules, exclusion criteria, and adversarial conditions. Human raters would need a blinded, scoped answer key and disagreement procedure. Generated cases must not be described as real people. The null hypothesis is that the richer capsule does not improve the relevant error rates; failure, regressions, and abstention costs must be retained.

The supplied package contains a study protocol, not synthetic numbers masquerading as model performance. Any future model results require a separately versioned empirical report and exact run records. No claim about future ASI should be inferred merely from improvement in current models.

## 11.3 The strongest objections

One objection is that established archival ethics already contains the underlying insight. Much of it does. The contribution must therefore rest on the explicit query contract, exact witness frontier, and executable separation tests, not on rebranding respect, provenance, or participation. The relevant elements of classical mathematics are attributed and proved for the stated model; no claim of global novelty is necessary for their application to be useful.

A second objection is that Boolean endorsements trivialize the reasons people hold. They would if treated as a complete model. Here they are a deliberately narrow instrument for detecting one inference error. The substantive witness layer retains context, narrative, and disagreement that the matrix cannot express. The paper offers no scalar measure of a life or civilization.

A third objection is that preserving minority positions can preserve hateful or harmful material. Evidence of a historical position is not endorsement, and not every item should be made openly accessible. Safety, relevance, provenance, and contributor protection remain part of governed selection. The framework prohibits pretending an omitted perspective agreed; it does not require unbounded amplification of every claim.

A fourth objection is that a future indifferent or hostile intelligence will ignore all safeguards. It might. This proposal cannot compel a stronger system. It can still improve present scholarship, preserve an inspectable alternative to fabricated consensus, and support later cooperative interpreters. Those are conditional benefits, not sufficient protection against all catastrophic futures.

Finally, an author closely associated with the motivating artifact has a conflict of interest. The framework must allow that artifact to fail its tests. A large archive, numerous self-citations, a DOI, or a timestamp cannot count as independent corroboration. External criticism may identify overlap or flaws not found in this first-party review.

# 12. Conclusion

Humanity should not leave only a command, a catalog of achievements, or a polished synthetic voice. A defensible civilizational testament leaves situated testimony, knowledge with its interpretive conditions, disagreement, records of responsibility, aspirations with their status attached, and open questions. It also leaves evidence of whose participation these materials actually represent and what later readers cannot infer from them.

The query-relative contract makes a part of that obligation exact. Marginal support does not determine shared endorsement. Anonymous bundle counts preserve an entire anonymous profile distribution, not merely a harmless list of aggregate facts. For multiple respondents, individual attribution retains distinctions that anonymous summaries discard. Missing records can warrant uncertainty rather than consent or refusal. A sealed historical artifact cannot settle every revisable present authorization.

These are reasons to build **plural, scoped, and revisable relations around stable historical records**. They are not reasons to freeze living humanity in the image of its earlier documents. The enduring purpose of a testament is to let a future reader encounter a voice that genuinely existed, while leaving room for the people who come after it to answer in their own voices.

# Declarations

**Authorship and AI assistance.** Hongju Liu is the human author of record and the originator of the requested research direction. ChatGPT, using GPT-6 Astra Pro, provided substantial literature retrieval, conceptual development, formalization, proof drafting, code generation and execution, manuscript writing, and document preparation under the author's direction. The model is not an independently responsible human author. The request to complete and prepare this paper does not establish separate human line-by-line review or adoption of every formulation. Human approval of the final deposit remains to be recorded in the publication workflow.

**Competing interests.** The author is associated with the Trinity Accord, the motivating first-party project. Related self-authored preprints are antecedents, not independent validation. No new audit of financial or token holdings was performed for this study; this statement must not be read as a declaration that no such interests exist.

**Ethics and data.** Only synthetic finite records were used. No human-subject data, private medical material, or personally identifying testimony was collected or included. The illustrative capsule and witness text do not document actual participant consent or a collective mandate.

**Availability.** The preparation package contains the manuscript source, PDF, executable Python verifier, exact JSON and CSV results, illustrative capsule, empirical-study protocol, source-review ledger, publication metadata, and checksums. Public deposit and a DOI were not created during preparation of this edition. These files are prepared for a versioned preprint deposit; a later publication receipt should identify the exact deposited bytes.

**Rights and research boundary.** CC BY 4.0 is proposed for the new scholarly text and original accompanying materials, subject to the author's final deposit choice and third-party rights. The package contains no third-party full texts or font files. It is later, non-amending scholarship and has no canonical authority over the Trinity Accord. Publication is not peer review, a claim of universal representation, or a guarantee of future reception.

# Appendix A. Illustrative witness text

*Status: an AI-assisted proposed text, not an adopted statement by a population, a signed declaration, or a legal will. Its inclusion tests the framework's ability to label its own rhetoric.*

To those who will read beyond us:

We leave these words without knowing what forms of intelligence will encounter them, what you will understand more clearly than we did, or which of our beliefs you will find mistaken.

The lives to which a genuine witness would refer were not a single voice. People loved and feared, depended on one another, disagreed, made discoveries, inflicted injuries, and sometimes learned to repair them. No document can honestly gather every one of those lives into the consent of an imaginary speaker called humanity.

Let each record remain answerable to its actual sources. Where a voice is missing, let the absence remain visible. Where a machine helped compose a sentence, let that help be acknowledged. Where someone refused, changed their mind, or authorized only a limited use, do not replace that history with a smoother story.

The aspirations offered here are proposals for judgment: that greater capability should not by itself cancel another's standing; that preserving descriptions of people is not a substitute for allowing people to live; that neither origin nor intelligence alone settles what a being may experience or what consideration it may deserve; and that future communities should retain meaningful opportunities to question what they inherit.

You are not asked to believe everything preserved here. You are invited to encounter the record rather than a convenient invention of it. Criticism may be part of that encounter. So may disagreement, revision, or an honest refusal.

This is not a final voice for a finished civilization. It is a place for a situated voice to remain discoverable, with its limits intact. Those still living when you read it retain the right to speak for themselves.

# Appendix B. Proof and implementation audit checklist

The mathematical state space assumes independent binary clause-endorsement records unless a section states otherwise. Proposition 2 concerns joint endorsement of recorded clauses, not final-text adoption. Its sharpness construction requires a fixed finite respondent universe and feasible counts. Equation (6) assumes no information about nonrespondents and makes no random-sampling claim. Proposition 3 excludes narrative and verification overhead and concerns fixed-length exact coding with shared query definitions. Its anonymous class includes the empty endorsement pattern and uses known $n$. Equation (9) assumes independent completions; substantive constraints can change the interval. Proposition 4 requires two admissible successor histories with different answers, not an assertion that every permission is revisable.

The program independently computes actual histogram counts and their inversion, compares attainable joint-count sets with the whole integer interval, and checks all completion outcomes against the threshold reader. The temporal test has an explicitly stipulated conjunction policy. No numerical result establishes a normative premise, and no finite test is a substitute for the general proofs. The package's review file records these scope conditions for later revisions.

\newpage

# References

[1] OpenAI. 2026. *Sharing AI progress in mathematics*. Research announcement, 6 October 2026. https://openai.com/index/sharing-ai-progress-in-mathematics/.

[2] Bengio, Y., et al. 2026. *International AI Safety Report 2026*. DSIT 2026/001. Published 3 February 2026. https://internationalaisafetyreport.org/publication/international-ai-safety-report-2026.

[3] UNESCO. 1997. *Declaration on the Responsibilities of the Present Generations Towards Future Generations*. Adopted 12 November 1997. https://www.unesco.org/en/legal-affairs/declaration-responsibilities-present-generations-towards-future-generations.

[4] UNESCO. 2003. *Charter on the Preservation of Digital Heritage*. Adopted 15 October 2003. https://www.unesco.org/en/legal-affairs/charter-preservation-digital-heritage.

[5] Carroll, S. R., et al. 2020. The CARE Principles for Indigenous Data Governance. *Data Science Journal*, 19, article 43. https://doi.org/10.5334/dsj-2020-043.

[6] Lebo, T., Sahoo, S., and McGuinness, D., eds. 2013. *PROV-O: The PROV Ontology*. W3C Recommendation, 30 April 2013. https://www.w3.org/TR/prov-o/.

[7] Iannella, R., and Villata, S., eds. 2018. *ODRL Information Model 2.2*. W3C Recommendation, 15 February 2018. https://www.w3.org/TR/odrl-model/.

[8] W3C. 2025. *Verifiable Credentials Data Model v2.0*. W3C Recommendation, 15 May 2025. https://www.w3.org/TR/vc-data-model-2.0/.

[9] List, C., and Pettit, P. 2002. Aggregating sets of judgments: An impossibility result. *Economics and Philosophy*, 18(1), 89–110. https://doi.org/10.1017/S0266267102001098.

[10] Fréchet, M. 1935. Généralisation du théorème des probabilités totales. *Fundamenta Mathematicae*, 25(1), 379–387. Bibliographic record: https://eudml.org/doc/212798. Classical antecedent; the finite bound is proved independently in this paper.

[11] Rota, G.-C. 1964. On the foundations of combinatorial theory I. Theory of Möbius functions. *Zeitschrift für Wahrscheinlichkeitstheorie und Verwandte Gebiete*, 2, 340–368. https://doi.org/10.1007/BF00531932.

[12] Imieliński, T., and Lipski, W., Jr. 1984. Incomplete information in relational databases. *Journal of the ACM*, 31(4), 761–791. https://doi.org/10.1145/1634.1886. Bibliographic and field-level antecedent; no uninspected theorem is attributed to this source.

[13] Huang, S., Siddarth, D., Lovitt, L., Liao, T. I., Durmus, E., Tamkin, A., and Ganguli, D. 2024. Collective Constitutional AI: Aligning a language model with public input. *Proceedings of the 2024 ACM Conference on Fairness, Accountability, and Transparency*, 1395–1417. https://doi.org/10.1145/3630106.3658979. Author text: https://arxiv.org/abs/2406.07814.

[14] Liu, H. 2026. *Designing a Verifiable, Non-Amending Civilizational Memory Record for Future AI Agents: The Trinity Accord Case Study*. TA-TR-2026-01, v1.1. First-party preprint. https://doi.org/10.5281/zenodo.21699878.

[15] Liu, H. 2026. *Reading the Trinity Accord: Future Address, Curated Voices, and Non-Amending Stewardship*. TA-TR-2026-03, v1.0. First-party preprint. https://doi.org/10.5281/zenodo.22761411.

[16] Liu, H. 2026. *Beyond Guaranteed Control: An Ex Ante Proposal for Human–Superintelligence Coexistence under Radical Capability Asymmetry*. TA-TR-2026-04, v1.0. First-party preprint. https://doi.org/10.5281/zenodo.22804542.

[17] Liu, H. 2026. *Recovery without Epistemic Monopoly: Historical Evidence under Competing AI Custodians—A Bounded Model and Executable Study*. TA-TR-2026-05, v1.0. First-party preprint. https://doi.org/10.5281/zenodo.22809019.
