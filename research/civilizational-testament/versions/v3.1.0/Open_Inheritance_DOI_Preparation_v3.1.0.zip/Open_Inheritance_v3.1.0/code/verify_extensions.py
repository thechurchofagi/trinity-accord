#!/usr/bin/env python3
"""Exact checks for v3.1 observation and finite-horizon scope corrections.

Synthetic, explicitly finite logical cases only. No persons, model API calls,
probabilities, historical prevalence estimates, or inferred moral judgments.
Run without -O. The baseline module is preserved byte-for-byte from v3.0.0.
"""
from __future__ import annotations
import argparse
from collections import Counter
from itertools import combinations, product
import json
from pathlib import Path
from typing import Sequence
from verify_core import partitions, query_cover_minimum


def require(condition: bool, context: object) -> None:
    if not condition:
        raise AssertionError(context)


def indices(mask: int, n: int) -> tuple[int, ...]:
    return tuple(i for i in range(n) if mask & (1 << i))


def evidence_catalogs(n: int, max_size: int) -> list[tuple[int, ...]]:
    """Distinct, nonempty compatible-history sets whose union is all histories."""
    full = (1 << n) - 1
    found = []
    for size in range(1, max_size + 1):
        for catalog in combinations(range(1, full + 1), size):
            union = 0
            for mask in catalog:
                union |= mask
            if union == full:
                found.append(catalog)
    return found


def observed_formula(family: Sequence[int], query: Sequence[int],
                     catalog: Sequence[int], m: int) -> tuple[int | None, str]:
    """Reduce each evidence state to its common label and common response set."""
    evidence_query, evidence_gamma = [], []
    label_clash = False
    empty_common = False
    for mask in catalog:
        hs = indices(mask, len(family))
        labels = {query[h] for h in hs}
        label_clash |= len(labels) != 1
        joint = (1 << m) - 1
        for h in hs:
            joint &= family[h]
        empty_common |= joint == 0
        evidence_query.append(query[hs[0]])
        evidence_gamma.append(joint)
    if label_clash:
        return None, 'historical_label_clash'  # priority if both obstacles occur
    if empty_common:
        return None, 'empty_common_response'
    return query_cover_minimum(evidence_gamma, evidence_query, m), 'feasible'


def observed_direct(family: Sequence[int], query: Sequence[int],
                    catalog: Sequence[int], m: int) -> int | None:
    """Brute-force all record partitions, checking every compatible pair directly."""
    for encoding in partitions(len(catalog)):
        valid = True
        for symbol in sorted(set(encoding)):
            histories = {h for e, label in enumerate(encoding) if label == symbol
                         for h in indices(catalog[e], len(family))}
            labels = {query[h] for h in histories}
            if len(labels) != 1:
                valid = False
                break
            if not any(all(family[h] & (1 << a) for h in histories) for a in range(m)):
                valid = False
                break
        if valid:
            return max(encoding) + 1
    return None


def observation_checks() -> dict:
    n, m = 3, 3
    catalogs = evidence_catalogs(n, 3)
    counts: Counter[str] = Counter()
    costs: Counter[str] = Counter()
    for family in product(range(1, 1 << m), repeat=n):
        for query in partitions(n):
            ideal = query_cover_minimum(family, query, m)
            require(ideal is not None, ('ideal', family, query))
            for catalog in catalogs:
                formula, reason = observed_formula(family, query, catalog, m)
                direct = observed_direct(family, query, catalog, m)
                require(direct == formula, ('observation', family, query, catalog, direct, formula))
                counts['cases'] += 1
                counts[reason] += 1
                if formula is not None:
                    require(formula >= ideal, ('observation price', family, query, catalog))
                    costs[str(formula)] += 1
                    if formula > ideal:
                        counts['strict_symbol_cost_increases'] += 1
            singleton = (1, 2, 4)
            perfect, reason = observed_formula(family, query, singleton, m)
            require(perfect == ideal, ('perfect observation', family, query))
            counts['perfect_observation_equalities'] += 1
    triangle = (3, 6, 5)
    pair_catalog = (3, 5, 6)
    triangle_observed, _ = observed_formula(triangle, (0, 0, 0), pair_catalog, 3)
    require(triangle_observed == 3, 'triangle observed')
    require(query_cover_minimum(triangle, (0, 0, 0), 3) == 2, 'triangle ideal')
    require(observed_formula(triangle, (0, 1, 2), pair_catalog, 3)[0] is None,
            'distinct labels must not be fabricated from ambiguous evidence')
    return {
        'history_count': n, 'action_count': m,
        'distinct_evidence_catalog_count': len(catalogs),
        'catalog_scope': '1 to 3 distinct nonempty subsets of 3 histories, union all histories',
        **dict(sorted(counts.items())),
        'feasible_symbol_cost_distribution': dict(sorted(costs.items())),
        'strict_price_fixture': {'response_masks': triangle, 'evidence_masks': pair_catalog,
                                'query': [0, 0, 0], 'ideal_symbols': 2, 'observed_symbols': 3},
        'infeasibility_count_rule': 'label clashes counted first when both failure conditions occur'
    }


def all_binary_query_checks() -> dict:
    counts = Counter()
    for n in (1, 2, 3, 4):
        for record in partitions(n):
            all_recoverable = True
            witness = None
            for query in product((0, 1), repeat=n):
                recoverable = all(len({query[i] for i in range(n) if record[i] == k}) == 1
                                  for k in set(record))
                counts['record_query_cases'] += 1
                if not recoverable:
                    all_recoverable = False
                    witness = query
            injective = len(set(record)) == n
            require(all_recoverable == injective, ('universal queries', n, record, witness))
            counts['record_partitions'] += 1
    return dict(counts)


def backward_viable(transitions: tuple, acceptable: tuple[int, ...],
                    state_count: int, action_count: int) -> tuple[int, ...]:
    """Fully observed, finite horizon, adversarial nonempty successor sets."""
    horizon = len(transitions)
    viability = [0] * (horizon + 1)
    viability[-1] = acceptable[-1]
    for t in reversed(range(horizon)):
        for s in range(state_count):
            if not acceptable[t] & (1 << s):
                continue
            if any(transitions[t][s][a] != 0 and
                   transitions[t][s][a] & ~viability[t + 1] == 0
                   for a in range(action_count)):
                viability[t] |= (1 << s)
    return tuple(viability)


def brute_policy_viable(transitions: tuple, acceptable: tuple[int, ...],
                        state_count: int, action_count: int) -> int:
    """Enumerate all deterministic Markov policies and every resulting branch."""
    horizon = len(transitions)
    union_good_starts = 0
    for policy in product(range(action_count), repeat=horizon * state_count):
        for start in range(state_count):
            if not acceptable[0] & (1 << start):
                continue
            reachable = 1 << start
            safe = True
            for t in range(horizon):
                next_mask = 0
                for s in indices(reachable, state_count):
                    successors = transitions[t][s][policy[t * state_count + s]]
                    if successors == 0:
                        safe = False
                        break
                    next_mask |= successors
                if not safe or next_mask & ~acceptable[t + 1]:
                    safe = False
                    break
                reachable = next_mask
            if safe:
                union_good_starts |= 1 << start
    return union_good_starts


def temporal_checks() -> dict:
    counts = Counter()
    distribution = Counter()
    n, m, horizon = 2, 2, 2
    for flat in product(range(1, 1 << n), repeat=horizon*n*m):
        transitions = tuple(tuple(tuple(flat[t*n*m + s*m + a] for a in range(m))
                                  for s in range(n)) for t in range(horizon))
        counts['transition_systems'] += 1
        for terminal in range(1 << n):
            acceptable = (3, 3, terminal)
            recursive = backward_viable(transitions, acceptable, n, m)[0]
            direct = brute_policy_viable(transitions, acceptable, n, m)
            require(recursive == direct, ('temporal', transitions, terminal, recursive, direct))
            counts['system_terminal_constraint_cases'] += 1
            distribution[str(recursive)] += 1
            if terminal not in (0, 3) and recursive == 0:
                counts['nonempty_terminal_but_no_viable_initial_state'] += 1
    # A supported exit is different from a nominal contract or a failed vendor promise.
    step = ((0b0010, 0b0100), (0b1000, 0b1000),
            (0b0100, 0b0100), (0b1000, 0b1000))
    scenario = (step, step)
    safe_sets = (0b0111, 0b0111, 0b0111)
    with_support = backward_viable(scenario, safe_sets, 4, 2)
    without_step = ((0b0010, 0b0010),) + step[1:]
    without_support = backward_viable((without_step, without_step), safe_sets, 4, 2)
    require(with_support[0] & 1 != 0 and without_support[0] & 1 == 0,
            'funded exit fixture')
    # Partial observation: per-state actions do not imply a common implementable action.
    hidden_gamma = (0b01, 0b10)
    require(all(hidden_gamma) and hidden_gamma[0] & hidden_gamma[1] == 0,
            'nonanticipation fixture')
    return {
        'state_count': n, 'action_count': m, 'horizon': horizon,
        'constraints': 'all states admitted at t=0 and t=1; every terminal subset tested',
        'successors': 'every state/action/time successor set is nonempty; all 3^8 systems tested',
        'policies_per_system_terminal_case': m ** (horizon*n),
        **dict(sorted(counts.items())),
        'initial_viability_mask_distribution': dict(sorted(distribution.items())),
        'exit_fixture': {'state_labels': ['initial', 'dependent', 'supported', 'harm'],
                         'with_supported_exit_viability_masks': with_support,
                         'without_supported_exit_viability_masks': without_support},
        'partial_observation_counterexample_response_masks': hidden_gamma
    }


def run(out: Path) -> dict:
    if not __debug__:
        raise RuntimeError('Do not use Python -O: the preserved core uses assertions.')
    out.mkdir(parents=True, exist_ok=True)
    result = {
        'version': '3.1.0',
        'study_type': 'exact bounded logical fixtures; NOT empirical data or future predictions',
        'observation': observation_checks(),
        'all_binary_queries': all_binary_query_checks(),
        'temporal': temporal_checks(),
        'assertion_failures': 0
    }
    (out/'extension_results.json').write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.out), indent=2, sort_keys=True))
