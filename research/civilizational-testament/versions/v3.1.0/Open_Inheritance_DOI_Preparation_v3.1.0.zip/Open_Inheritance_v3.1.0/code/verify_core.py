#!/usr/bin/env python3
"""Exact finite checks for the open-inheritance response criterion.

No model API, human data, forecasts, or third-party packages are used.
A family is a tuple of bitmasks of feasible AND admissible responses.
A query partition specifies which historical distinctions must be retained.
"""
from __future__ import annotations
import argparse
import csv
import itertools
import json
from collections import Counter
from pathlib import Path
from typing import Iterable, Sequence


def partitions(n: int) -> list[tuple[int, ...]]:
    """Canonical restricted-growth encodings of every set partition."""
    if n < 1:
        raise ValueError('n must be positive')
    result: list[tuple[int, ...]] = []
    def extend(prefix: tuple[int, ...]) -> None:
        if len(prefix) == n:
            result.append(prefix)
            return
        for label in range(max(prefix) + 2):
            extend(prefix + (label,))
    extend((0,))
    return sorted(result, key=lambda x: (max(x) + 1, x))


def blocks(labels: Sequence[int]) -> list[tuple[int, ...]]:
    return [tuple(i for i, label in enumerate(labels) if label == k)
            for k in sorted(set(labels))]


def intersection(values: Iterable[int], full_mask: int) -> int:
    result = full_mask
    for value in values:
        result &= value
    return result


def valid_encoding(family: Sequence[int], query: Sequence[int],
                   record: Sequence[int], m: int) -> bool:
    for block in blocks(record):
        if len({query[i] for i in block}) != 1:
            return False
        if intersection((family[i] for i in block), (1 << m) - 1) == 0:
            return False
    return True


def partition_minimum(family: Sequence[int], query: Sequence[int],
                      record_partitions: Sequence[Sequence[int]], m: int) -> int | None:
    """Independent brute-force decoder/record partition test."""
    for record in record_partitions:
        if valid_encoding(family, query, record, m):
            return max(record) + 1
    return None


def cover_minimum(family: Sequence[int], m: int) -> int | None:
    """Minimum number of actions hitting every response set."""
    if any(value == 0 for value in family):
        return None
    best = m + 1
    for menu in range(1, 1 << m):
        if all(menu & value for value in family):
            best = min(best, menu.bit_count())
    return best


def query_cover_minimum(family: Sequence[int], query: Sequence[int], m: int) -> int | None:
    total = 0
    for block in blocks(query):
        cost = cover_minimum([family[i] for i in block], m)
        if cost is None:
            return None
        total += cost
    return total


def run_checks(out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    m = 3
    full = (1 << m) - 1
    rows: list[dict] = []
    results: dict = {
        'version': '3.0.0',
        'study_type': 'deterministic exhaustive logical fixtures; NOT empirical data',
        'action_count': m,
        'meaning_of_sets': 'stipulated feasible-and-admissible response sets, not inferred ethics',
        'domains': [],
    }
    for n in (3, 4):
        parts = partitions(n)
        counters: Counter[str] = Counter()
        minimum_histogram: Counter[int] = Counter()
        pairwise_but_not_joint = 0
        for family in itertools.product(range(1, full + 1), repeat=n):
            counters['nonempty_families'] += 1
            k = cover_minimum(family, m)
            assert k is not None
            minimum_histogram[k] += 1
            pairwise = all(family[i] & family[j]
                           for i in range(n) for j in range(i + 1, n))
            if pairwise and intersection(family, full) == 0:
                pairwise_but_not_joint += 1
            for query in parts:
                direct = partition_minimum(family, query, parts, m)
                formula = query_cover_minimum(family, query, m)
                assert direct == formula, (n, family, query, direct, formula)
                counters['query_partition_cases'] += 1
                rows.append({'n': n,
                             'response_masks': '-'.join(map(str, family)),
                             'query_partition': '-'.join(map(str, query)),
                             'minimum_record_symbols': direct})
            for h in range(n):
                for a in range(m):
                    bit = 1 << a
                    if family[h] & bit:
                        continue
                    larger = list(family)
                    larger[h] |= bit
                    k2 = cover_minimum(larger, m)
                    assert k2 is not None and k2 <= k
                    counters['single_option_addition_cases'] += 1
                    if k2 < k:
                        counters['strict_memory_cost_reductions'] += 1
        # Include empty response sets: any such history is individually infeasible.
        for family in itertools.product(range(full + 1), repeat=n):
            if any(value == 0 for value in family):
                assert cover_minimum(family, m) is None
                assert partition_minimum(family, (0,) * n, parts, m) is None
                counters['infeasible_families_with_empty_set'] += 1
        results['domains'].append({
            'history_count': n,
            'number_of_query_partitions': len(parts),
            **dict(sorted(counters.items())),
            'minimum_symbols_without_mandatory_distinctions': dict(sorted(minimum_histogram.items())),
            'pairwise_compatible_but_no_joint_response': pairwise_but_not_joint,
        })
    # The three-history triangle: each pair admits a common continuation; the trio does not.
    triangle = (0b011, 0b110, 0b101)
    assert all(triangle[i] & triangle[j] for i in range(3) for j in range(i + 1, 3))
    assert intersection(triangle, full) == 0
    assert cover_minimum(triangle, m) == 2
    assert query_cover_minimum(triangle, (0, 1, 2), m) == 3
    # Introducing a genuinely admissible common response reduces the action-related cost.
    with_common = tuple(v | 0b1000 for v in triangle)
    assert cover_minimum(with_common, 4) == 1
    assert query_cover_minimum(with_common, (0, 1, 2), 4) == 3
    # Perfect knowledge does not repair an empty feasible-and-admissible response set.
    assert query_cover_minimum((0b001, 0), (0, 1), m) is None
    # A constant future trace/approval cannot recover different past authorization bits.
    prior_authorization = (0, 1)
    later_approval = (1, 1)
    constant_predictions = [(bit, bit) for bit in (0, 1)]
    errors = [sum(p != t for p, t in zip(pred, prior_authorization))
              for pred in constant_predictions]
    assert min(errors) == 1
    results['counterexamples'] = {
        'triangle': {'response_masks': triangle, 'minimum_symbols': 2,
                     'minimum_symbols_with_distinct_historical_labels': 3},
        'triangle_plus_genuinely_admissible_common_response': {
            'response_masks': with_common, 'minimum_symbols': 1,
            'minimum_symbols_with_distinct_historical_labels': 3},
        'empty_response_set': 'no sound continuation even with complete identification',
        'same_later_approval_different_past_authorization': {
            'past': prior_authorization, 'later': later_approval,
            'minimum_errors_over_two_constant_decoders': min(errors),
            'note': 'a stipulated identification counterexample, not AI performance'},
    }
    results['totals'] = {
        key: sum(d.get(key, 0) for d in results['domains'])
        for key in ('nonempty_families', 'query_partition_cases',
                    'single_option_addition_cases', 'strict_memory_cost_reductions',
                    'infeasible_families_with_empty_set')
    }
    results['assertion_failures'] = 0
    (out_dir / 'exact_results.json').write_text(
        json.dumps(results, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    with (out_dir / 'query_partition_results.csv').open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path,
                        default=Path(__file__).resolve().parents[1] / 'results')
    args = parser.parse_args()
    result = run_checks(args.out)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
