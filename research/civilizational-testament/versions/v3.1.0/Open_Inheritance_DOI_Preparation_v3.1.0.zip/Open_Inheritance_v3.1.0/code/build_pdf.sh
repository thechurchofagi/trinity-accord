#!/usr/bin/env bash
# Rebuild separately; do not overwrite a frozen edition or assume identical PDF bytes.
set -euo pipefail
for exe in pandoc xelatex; do
  command -v "$exe" >/dev/null 2>&1 || { echo "Missing: $exe" >&2; exit 1; }
done
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
pandoc "$ROOT/manuscript.md" --standalone -o "$TMP/manuscript.tex"
(cd "$TMP"; xelatex -interaction=nonstopmode -halt-on-error manuscript.tex > build.log 2>&1 || { cat build.log >&2; exit 1; }; xelatex -interaction=nonstopmode -halt-on-error manuscript.tex >> build.log 2>&1 || { cat build.log >&2; exit 1; })
cp "$TMP/manuscript.pdf" "$ROOT/rebuilt-manuscript.pdf"
printf 'Created %s\n' "$ROOT/rebuilt-manuscript.pdf"
