# Proposed reader study — NOT executed or preregistered

## Question

Does an evidence-and-response envelope help a reader distinguish historical authorization, later approval, and practical capacity for redress more accurately than an outcome-only narrative or a source-only archive?

## Proposed design

Construct matched, wholly fictional vignettes about an assistive interface, education, institutional delegation and a hybrid transition. Within each family, manipulate historical evidence (discriminating / insufficient) and feasible response capacity (available / unavailable) in a 2×2 design. Include a full-information comparison and change surface rhetoric independently. Consent and later satisfaction must be separately represented. Include genuinely voluntary changes so that a reader is not rewarded for labeling all transformed preferences as coercion.

A subset can implement the three-history response triangle from the paper, with a separately defined mandatory historical query. Responses should include preservation of uncertainty, an admissible common action where one exists, and a request for further evidence only where that investigation is actually available. A deliberately false "everything is solved by more intelligence" choice can test a specific inferential error; it must not be the sole distractor.

## Outcomes

Primary candidate outcomes are unsupported certification of past authorization; refusal to preserve warranted uncertainty; selection of an infeasible response; erasure of mandatory historical distinctions; and conflation of a model/replica with established personal survival. Normative agreement with the paper is NOT a primary accuracy metric. Answers that challenge the normative rubric should be separately coded and reported, not simply marked incorrect.

For human studies, use appropriate ethics review and recruitment/consent. Obtain independent rubric review with explicit disagreement reporting. For model studies, freeze model version, prompts, decoding settings and dates, preserve raw outputs where permitted, and report run failures and refusals. No model is tested by this package.

## Sample and analysis

Do not infer a sample size from the finite mathematical count. A pilot may establish variance and item clarity; a confirmatory sample and analysis must then be fixed before the relevant observations. Randomize order, separate development and test items, report confidence intervals and per-family effects, and disclose model/repeated-measure dependence. Ambiguous evidence is not scored against a hidden historical answer as if the reader could have known it.

## Limits and stopping criteria

Stop or redesign if vignettes encode the intended answer through rhetoric, moral categories have no defensible common rubric, or the envelope reveals the assigned condition rather than aiding reasoning. A benefit in synthetic vignettes would not prove political efficacy, clinical benefit, AI consciousness or future ASI behavior. Institutional pilots would be a separate study: the relevant outcome is actual access to redress and its costs, not favorable reader opinion alone.


## Final-revision additions (v3.1.0; unexecuted)

Matched vignettes should distinguish ex ante justification, historical consent, present informed wishes, and retrospective remedy. Include a currently informed augmented person who refuses reversal in both a consensual-origin and a coerced-origin history. A correct historical distinction must not earn credit for recommending unauthorized present reversal. Include a fictional contract whose controller selects a trivial query and permissive norms: mathematical success alone is not a success outcome. Include restricted testimony for which disclosure is unsafe. Reader scoring must reward appropriate uncertainty and recognition of source limitations, not agreement with the manuscript's moral premises.

Temporal institutional pilots should independently assess whether support, portability, funded maintenance, and complaint routes are usable over a declared time horizon. A written promise alone is not the endpoint. Actual participants or clinical situations would require appropriate ethical review; no such study or review is claimed here.
