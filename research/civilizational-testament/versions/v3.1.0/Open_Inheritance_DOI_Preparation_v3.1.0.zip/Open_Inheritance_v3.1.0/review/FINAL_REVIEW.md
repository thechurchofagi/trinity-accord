# Final critical review — CTP-2026-01 v3.1.0

**Review date:** 12 October 2026. **Reviewer/process:** ChatGPT (GPT-6 Astra Pro), continuing the author-directed research. This is an internal critical revision, not independent peer review, an ethics approval, or a claim to have exhausted all possible objections.

## Disposition

The manuscript is finalized for the author's proposed preprint-deposit workflow. Its central question and title are retained. Versions 1.0.0, 2.0.0, and 3.0.0 remain unchanged in `sources/`. No DOI, draft deposit, timestamp, or Arweave archive has been created by this review. Author/depositor responsibility and rights metadata remain explicit.

The review found no counterexample to the original finite propositions under their actual definitions. The core script was rerun and both numerical output files matched the original bytes. Several philosophical and operational claims nevertheless needed narrowing or extension. These were not addressed by merely increasing the number of toy cases.

## Findings and their resolutions

| ID | Finding | Final treatment |
|---|---|---|
| FR-01 | The abstract overgeneralized what a testament presumes about its heir. | Replaced the categorical statement with the actual successor-dependent constituency problem. |
| FR-02 | The objection to an endpoint-only verdict could be misread as an objection to all consequentialism. | Section 6.3 now distinguishes endpoint-only evidence from assessments of an entire trajectory, including consequentialist ones. |
| FR-03 | Historical accountability could be appropriated as authority to forcibly restore a former self or social order. | Section 6.5 separates ex ante justification, present duties, and accurate historical attribution. A past wrong does not automatically authorize a new nonconsensual transformation. The revised hybrid case applies this safeguard. |
| FR-04 | An ideal record-cost bound assumes a recorder can distinguish histories. | Corollary 3 gives the exact evidence-constrained version, proves its bound relative to the ideal case, and supplies a strict 2-versus-3-symbol example. Ambiguous evidence cannot be turned into invented assent. |
| FR-05 | A finite task might be mistaken for a sufficient archive for every unforeseen question. | Appendix C states and proves the elementary injectivity condition for all binary historical queries, then explains why it is not an instruction to collect all data. |
| FR-06 | A currently feasible response need not remain maintainable. | Section 7.7 and Appendix D use a classical finite-horizon viability construction with explicit full-observation and horizon assumptions. The text does not claim indefinite survival, solve partial-observation control, or mechanically forbid urgent rescue. |
| FR-07 | A controller can choose permissive normative inputs and obtain a vacuous mathematical certificate. | Section 8.5 makes choice of the contract accountable, requires reasons and recorded disagreement, and proposes review and sensitivity rather than treating formal compliance as legitimacy. |
| FR-08 | Fidelity and permanence could conflict with protection and privacy. | Collection, access, deletion, and redaction are distinguished from fabrication. Open inheritance is contestable, not necessarily public or irrevocable. Permanent public dissemination does not guarantee withdrawal. |
| FR-09 | A wholly informational account can omit care, habitat, resources, and maintenance. | Section 5.2 adds material/ecological support without inferring personal survival from information conservation or prescribing biological immobility. |
| FR-10 | Set cover alone was not the closest mathematical antecedent. | Reference 30 adds hypergraph-based functional coding. The manuscript explicitly places its acceptable-output grouping in this existing literature. References 31–32 acknowledge viability and policy precedents. The contribution is an application-level integration, not a foundational coding/control discovery. |
| FR-11 | A first-party case can launder a source's rhetoric into a scientific proof. | Rechecked the primary texts at a fixed repository commit; retained the separation of historical significance from Gödel/entropy/observer claims, and of physical artifact evidence from full-story truth. No new cryptographic verification is claimed. |
| FR-12 | Version metadata, result labels, and proposed studies could imply publication or empirical completion. | Baseline outputs retain their v3.0.0 identity; extensions identify v3.1.0. Prospective studies remain clearly unexecuted. New metadata does not contain an invented DOI or publication receipt. |

## Computational audit

The unchanged core has 37,730 family/query comparisons, plus its stated monotonicity and infeasibility checks. The new evidence-constrained study has 77,175 comparisons: 12,730 feasible; 57,281 historical-label clashes; 7,164 additional empty-response failures. When both failures occur the label clash is counted first. Exactly six feasible cases incur a strictly larger observed alphabet than the ideal one. The perfect-observation equality is checked 1,715 times.

The temporal study tests 6,561 nonempty two-state/two-action/two-stage transition systems against every terminal constraint subset, for 26,244 comparisons with exhaustive policy/branch enumeration. It has 16 deterministic Markov policies per case. A separate universal-query check contains 290 record/query pairs. The scripts report no assertion failures, and the extension output also matches on a second run.

These are distinct, deliberately small finite domains. Counts are not empirical prevalence, societal risk estimates, evidence of AI moral understanding, or numerical proofs of unrestricted theorems. Both algorithms were produced and checked by the same research process. The general finite statements have written proofs.

## Strong objections retained rather than declared defeated

The normative commitments remain contestable and culturally situated. There is no settled criterion here for consciousness, uploading, personal identity, or artificial-patient individuation. The framework does not uniquely settle every trade-off between rescue and restraint. A known-horizon model cannot enumerate every future technology or norm; an unknown or hostile receiver may not care. A source can remain worth remembering when adequate remedy is impossible. Real institutional efficacy and comparative human/model reader performance remain untested.

The final version therefore defends a bounded proposal: preserve accountable formation evidence and meaningful conditions for response without making historical preservation a license for continuing domination. It is not a universally binding charter or a prediction of the future.

## Verification artifacts

`BASELINE_REPRODUCTION.json` records the original rerun. `REPRODUCTION_RECEIPT.json` records repeat equality. `SOURCE_LEDGER.json` distinguishes full/partial/indexed/abstract access. `REPOSITORY_SOURCE_PIN.json` records the primary-source read boundary. `CHANGES_FROM_v3.0.0.diff` gives the complete source diff. `PDF_REVIEW.json` records the final render/text/font checks.
