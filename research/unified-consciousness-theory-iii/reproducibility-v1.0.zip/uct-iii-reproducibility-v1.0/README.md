# UCT III v1.0 - computational reproducibility supplement

This supplement accompanies Hongju Liu, *Unified Consciousness Theory III: Organization, Intelligence, and Experience—From Inorganic Processes to Artificial Agents*, theoretical preprint v1.0 (4 October 2026).

## Scope

The files reproduce finite mathematical checks and explicitly stipulated circuit and decision models described in the manuscript. They contain **no human, animal, COGITATE, biological laboratory, or pretrained language-model data**. The calculations do not establish that structural-experiential identity C1 is empirically true, compute a consciousness score, or demonstrate a UCT-exclusive observable prediction. Finite enumeration supplements the analytical arguments; it does not replace their general proofs.

The historical R14, R16, and R18 labels and dated result filenames are retained to preserve traceability and code hashes. They are internal calculation identifiers, not manuscript version numbers.

## Contents and dependencies

- `scripts/uct_iii_r14_circuit_model.py`: delayed-input task, matched one-bit circuits, noisy retention, stipulated configuration transmission, and a closure counterexample.
- `scripts/uct_iii_r16_task_coverage_audit.py`: checks output-only distributions against target-output distributions. It imports the R14 `run` function; both scripts must remain in the same directory.
- `scripts/uct_iii_r18_memory_value_audit.py`: finite decision-value and correlated-environment memory calculations.
- `expected_results/`: the three complete archived JSON result files.
- `run_checks.py`: isolated re-execution, comparison with archived results, timeouts, and captured logs.
- `logs/`: the successful release-preparation execution logs and environment report.
- `SHA256SUMS`: integrity hashes of every packaged file except the manifest itself.
- `LICENSE.md`: license notice for original material.

Only Python's standard library is required. The release checks were run under the interpreter identified in `logs/run_report.json`. Python 3.9 or newer is recommended. No network, API key, GPU, model weights, pip installation, or external dataset is required. Run with ordinary Python, without `-O`, because assertions implement verification checks.

## Reproduce

Extract the ZIP, enter its top-level directory, and run:

```bash
python3 run_checks.py
```

The wrapper copies the three scripts to a temporary isolated directory and runs them sequentially, allowing 60 seconds per script. Logs and a run report are written to `reproduced_outputs/`; packaged scripts and reference results are not overwritten. The checks require equality of decoded JSON values. The report also records byte equality; harmless differences in floating-point serialization across Python/platform versions can affect byte equality independently of decoded-value equality.

The R14 probability and accuracy calculations use exact fractions. Entropy and mutual-information diagnostics use floating-point logarithms with an explicit numerical tolerance. R16 probability comparisons use exact fractions. R18's finite decision checks use exact integer sums, and its memory examples use exact fractions. Thus, "exact checks" does not mean that every entropy diagnostic uses symbolic arithmetic.

The scripts may also be run directly from `scripts/`; they will write the named result JSON files beside themselves. The wrapper is preferable when preserving the archived package unchanged.

To verify the archive's extracted-file integrity on systems with GNU coreutils:

```bash
sha256sum -c SHA256SUMS
```

## Expected results and negative findings

| Check | Coverage | Principal result and limit |
|---|---|---|
| R14 | 1,024 input/noise trace pairs, 4,096 scored steps per circuit configuration; 12 exact noise cases; 24 descendant cases | Baseline accuracy is 1/2 for both configurations; one readout edit raises A to 1 while B remains at 1/2 in the noiseless example. Equal register/gate counts do not establish equal physical energy costs or equal total intelligence. |
| R16 | Horizons 1-6 after warm-up; 21,840 input trace pairs; 3 noise cases and 48 bounded-score indicator checks; 8 reduced-memory interventions | Post-edit output-only laws agree, but the target-output joint laws differ. An output-only comparator therefore omits the task relation needed for scoring. No complete rival phenomenal assignment or negative-consciousness verdict is established. |
| R18 | All 6,560 nonzero binary joint tables with unnormalized cell weights in {0,1,2}; 15 environment/noise pairs | 2,592 tables show a strict decision gain; 3,968 have equal optimized value. Of the equal-value cases, 3,008 still contain conditionally informative added signals. Information need not improve a fixed decision. |

Further negative findings retained in the result files:

- Perfect memory of the past has no current-prediction advantage in the specified independent environment.
- Alternating environments can favor an inverted use of memory.
- A positive gross capability advantage can be outweighed by the separately stipulated cost.
- Sweeping environmental parameters changes the evaluation context; it is not a fixed-J comparison for NESIG.
- Mathematical circuit labels are not automatically complete ontic process types, and reduced clock-tick descriptions do not establish a hardware recurrence classification.
- Configuration inheritance is a stipulated transmission model, not a measurement of organismal evolution or online learning.

## License and attribution

Original supplement material is made available under CC BY 4.0 to the extent rights are held by the author. Cite the accompanying paper when using this supplement. The analytical tools and cited prior work retain their existing attribution and rights; this license does not relicense third-party works. No third-party papers or private worklogs are included.

See `LICENSE.md` for the license link and notice.
