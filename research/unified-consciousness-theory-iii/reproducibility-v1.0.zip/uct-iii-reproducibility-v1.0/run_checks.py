#!/usr/bin/env python3
"""Re-run the published finite checks in an isolated directory (stdlib only)."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
JOBS = [
    ('R14', 'uct_iii_r14_circuit_model.py', 'UCT_III_R14_Circuit_Results_20261004.json'),
    ('R16', 'uct_iii_r16_task_coverage_audit.py', 'UCT_III_R16_Task_Coverage_Results_20261004.json'),
    ('R18', 'uct_iii_r18_memory_value_audit.py', 'UCT_III_R18_Memory_Value_Results_20261004.json'),
]


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=ROOT/'reproduced_outputs')
    parser.add_argument('--timeout', type=int, default=60,
                        help='Maximum seconds per script (default: 60).')
    args = parser.parse_args()
    if args.timeout <= 0:
        parser.error('--timeout must be positive')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    outcomes=[]
    with tempfile.TemporaryDirectory(prefix='uct-iii-v1-checks-') as td:
        work=Path(td)
        for _, script, _ in JOBS:
            shutil.copyfile(ROOT/'scripts'/script, work/script)
        for label, script, result in JOBS:
            process=subprocess.run([sys.executable, str(work/script)], cwd=work,
                                   capture_output=True, text=True, timeout=args.timeout)
            log=(f'Command: python3 {script}\nExit code: {process.returncode}\n\n'
                 f'STDOUT\n{process.stdout}\nSTDERR\n{process.stderr}')
            log=log.replace(str(work), '<isolated-check-directory>')
            (args.output_dir/f'{label}.log').write_text(log)
            if process.returncode:
                raise RuntimeError(f'{label} failed; inspect its log.')
            actual=work/result;expected=ROOT/'expected_results'/result
            semantic_match=json.loads(actual.read_text())==json.loads(expected.read_text())
            byte_match=actual.read_bytes()==expected.read_bytes()
            if not semantic_match:
                shutil.copyfile(actual,args.output_dir/result)
                raise AssertionError(f'{label}: result differs from the archived result.')
            outcomes.append({'check':label,'status':'PASS','result':result,
                             'exact_json_value_match':semantic_match,'byte_match':byte_match,
                             'result_sha256':sha256(actual)})
            print(f'{label}: PASS; exact JSON match; byte match={byte_match}')
    report={'status':'PASS','evidence_type':'finite mathematical and synthetic circuit checks only',
            'python':platform.python_version(),'implementation':platform.python_implementation(),
            'platform':platform.platform(),'timeout_seconds_per_script':args.timeout,
            'scripts_run':outcomes,'human_animal_or_pretrained_model_data':False}
    (args.output_dir/'run_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print('All three checks passed. No empirical consciousness inference is made.')


if __name__=='__main__':
    main()
