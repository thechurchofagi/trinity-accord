# License

Copyright (c) 2026 Hongju Liu.

Unless otherwise indicated, original material in this supplement is licensed under the Creative Commons Attribution 4.0 International License (CC BY 4.0), to the extent rights are held by the author.

License summary: https://creativecommons.org/licenses/by/4.0/

Legal code: https://creativecommons.org/licenses/by/4.0/legalcode

Attribution should identify Hongju Liu and the accompanying *Unified Consciousness Theory III* theoretical preprint v1.0, preserve the license notice, and indicate changes where applicable. No endorsement is implied.

Citations, ideas, and material attributable to other authors retain their original attribution and applicable rights. This notice does not license third-party material or imply that cited scientific methods originated with this supplement.
