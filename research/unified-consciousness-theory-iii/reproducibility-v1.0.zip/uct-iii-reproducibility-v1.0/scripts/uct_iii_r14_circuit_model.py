"""UCT III: matched one-bit circuits under a fixed delayed-input task.

Exact truth-table and finite-trace checks; no biological or human data.
The scalar score is Pr(Y_t == X_(t-1)), after one warm-up input.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import math


def entropy(probabilities):
    return -sum(float(p) * math.log2(float(p)) for p in probabilities if p)


def run(x, n, w, r):
    memory = 0
    trace = []
    for t, (xt, nt) in enumerate(zip(x, n)):
        y = memory if r else xt
        trace.append({"t": t, "x": xt, "n": nt, "memory_before": memory,
                      "y": y, "target": x[t-1] if t else None})
        memory = xt ^ (w & nt)
    return trace


def exact_case(w, r, epsilon):
    accuracy = F(0)
    joint = {(a, b): F(0) for a, b in product((0, 1), repeat=2)}
    for xp, np, xc, error in product((0, 1), repeat=4):
        p = F(1, 8) * (epsilon if error else 1-epsilon)
        memory = xp ^ (w & np) ^ error
        y = memory if r else xc
        accuracy += p * (y == xp)
        joint[xp, memory] += p
    px = [sum(joint[x, m] for m in (0, 1)) for x in (0, 1)]
    pm = [sum(joint[x, m] for x in (0, 1)) for m in (0, 1)]
    information = entropy(px) + entropy(pm) - entropy(joint.values())
    return accuracy, entropy(pm), information


def main():
    sequences = list(product((0, 1), repeat=5))
    totals = {(w, r): 0 for w, r in product((0, 1), repeat=2)}
    denominator = 0
    for x, n in product(sequences, repeat=2):
        traces = {(w, r): run(x, n, w, r) for w, r in totals}
        assert [z["y"] for z in traces[0, 0]] == [z["y"] for z in traces[1, 0]]
        for key in totals:
            totals[key] += sum(z["y"] == z["target"] for z in traces[key][1:])
        denominator += 4
    scores = {key: F(value, denominator) for key, value in totals.items()}
    assert scores == {(0, 0): F(1, 2), (1, 0): F(1, 2), (0, 1): F(1), (1, 1): F(1, 2)}
    noise_cases = []
    descendants = []
    for epsilon in [F(0), F(1, 4), F(1, 2)]:
        for w, r in totals:
            score, h, info = exact_case(w, r, epsilon)
            expected = (1-epsilon) if (w, r) == (0, 1) else F(1, 2)
            assert score == expected
            assert abs(h-1) < 1e-12
            expected_info = 1-entropy([epsilon, 1-epsilon]) if w == 0 else 0
            assert abs(info-expected_info) < 1e-12
            noise_cases.append({"w": w, "r": r, "epsilon": str(epsilon),
                                "score": str(score), "memory_entropy_bits": h,
                                "target_memory_information_bits": info})
        for mu in [F(0), F(1, 10), F(1, 2), F(1)]:
            for w in (0, 1):
                score0 = exact_case(w, 0, epsilon)[0]
                score1 = exact_case(w, 1, epsilon)[0]
                mean = (1-mu)*score0 + mu*score1
                formula = F(1, 2) + mu*(F(1, 2)-epsilon) if w == 0 else F(1, 2)
                assert mean == formula
                descendants.append({"w": w, "epsilon": str(epsilon), "mu": str(mu),
                                    "mean_descendant_score": str(mean)})
    # Closure witness with states A0, B0, A1, B1 and score partition.
    mu = F(1, 10)
    kernel = [[1-mu, 0, mu, 0], [0, 1-mu, 0, mu], [0, 0, 1, 0], [0, 0, 0, 1]]
    scores_ordered = [F(1, 2), F(1, 2), F(1), F(1, 2)]
    high_prob = [sum(F(kernel[i][j]) for j, score in enumerate(scores_ordered) if score == 1)
                 for i in range(4)]
    assert high_prob[0] == mu and high_prob[1] == 0
    # With beta=1 and no additional architecture cost, subsequent selection
    # raises the A1 fraction from 1/10 to 4/31; there are no A1 descendants of B0.
    after_selection = mu*2 / ((1-mu)*F(3, 2) + mu*2)
    assert after_selection == F(4, 31) and after_selection > mu
    example_x = (0, 1, 1, 0, 1, 0)
    example_n = (1, 0, 1, 1, 0, 0)
    output = {
        "status": "PASS", "evidence_type": "synthetic clocked circuit model; no empirical consciousness evidence",
        "protocol": {"inputs": "independent fair X,N", "task": "Y_t equals X_(t-1)",
                     "order": "read stored bit; emit output; update memory", "warmup_excluded": True,
                     "memory_update": "M_(t+1)=X_t XOR (w AND N_t) XOR E_t",
                     "readout": "Y_t=X_t if r=0 else M_t",
                     "config_inheritance": "w fixed; r=0 changes to 1 with probability mu; r=1 remains 1"},
        "trace_input_pairs_exhausted": len(sequences)**2,
        "scored_steps_per_architecture": denominator,
        "baseline_outputs_identical_for_every_tested_trace": True,
        "scores": {f"w{w}_r{r}": str(v) for (w,r),v in scores.items()},
        "noise_cases": noise_cases, "descendant_cases": descendants,
        "kernel_witness": {"states": ["A0", "B0", "A1", "B1"], "mu": str(mu),
                           "probability_next_score_one": list(map(str, high_prob)),
                           "same_current_score_different_next_distribution": True},
        "A1_fraction_after_subsequent_selection_beta1": str(after_selection),
        "example_traces": {f"w{w}_r{r}": run(example_x, example_n, w, r) for w, r in totals},
        "limits": ["Equal gate/register counts are not equal measured energy costs.",
                   "Genotype-like configuration copying is distinct from online learning.",
                   "C1 applies to actual valid process types, not automatically to mathematical circuit labels.",
                   "This finite task does not equate total intelligence across architectures."]
    }
    path = Path(__file__).with_name("UCT_III_R14_Circuit_Results_20261004.json")
    path.write_text(json.dumps(output, indent=2)+"\n")
    print(json.dumps({k:v for k,v in output.items() if k not in ["noise_cases", "descendant_cases", "example_traces"]}, indent=2))


if __name__ == "__main__":
    main()
