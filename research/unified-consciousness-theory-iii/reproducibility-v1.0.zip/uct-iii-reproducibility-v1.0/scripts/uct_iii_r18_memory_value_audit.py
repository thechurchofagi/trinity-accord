"""Exact checks for UCT III R18's finite decision-value application.

Mathematical distributions only; no biological data or consciousness measure.
Run: python3 uct_iii_r18_memory_value_audit.py
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib
import json


def frac(x):
    return str(x)


def decision_audit():
    """All nonzero 2 x 2 x 2 joint tables with unnormalized weights 0,1,2.

    Binary prediction utility is 1[a=z]. Exhaustive deterministic policies
    independently check optimized values and the common-optimum criterion.
    """
    cells = list(product(range(2), repeat=3))  # x,m,z
    n = strict = equal = informative_but_no_gain = 0
    for weights in product(range(3), repeat=8):
        total = sum(weights)
        if not total:
            continue
        table = dict(zip(cells, weights))
        old_scores = [sum(w for (x, m, z), w in table.items() if p[x] == z)
                      for p in product(range(2), repeat=2)]
        new_scores = [sum(w for (x, m, z), w in table.items() if p[2*x+m] == z)
                      for p in product(range(2), repeat=4)]
        old, new = max(old_scores), max(new_scores)
        formula_old = sum(max(sum(table[x,m,z] for m in range(2))
                              for z in range(2)) for x in range(2))
        formula_new = sum(max(table[x,m,z] for z in range(2))
                          for x,m in product(range(2), repeat=2))
        assert (old,new) == (formula_old,formula_new)
        assert new >= old
        common_every_x = True
        conditionally_informative = False
        for x in range(2):
            common = {0,1}
            tx = sum(table[x,m,z] for m,z in product(range(2), repeat=2))
            if not tx:
                continue
            for m in range(2):
                row = [table[x,m,z] for z in range(2)]
                tm = sum(row)
                if not tm:
                    continue
                common &= {a for a in range(2) if row[a] == max(row)}
                for z in range(2):
                    tz = sum(table[x,mm,z] for mm in range(2))
                    conditionally_informative |= table[x,m,z]*tx != tm*tz
            common_every_x &= bool(common)
        assert (new == old) == common_every_x
        n += 1
        strict += new > old
        equal += new == old
        informative_but_no_gain += conditionally_informative and new == old
    return dict(tables=n, strict_gain=strict, equal_value=equal,
                informative_but_no_decision_gain=informative_but_no_gain,
                checks="PASS", scope="binary prediction payoff; general theorem proved analytically")


def memory_audit():
    rows = []
    for alpha, eps in product([F(i,4) for i in range(5)], [F(0),F(1,4),F(1,2)]):
        joint = {(m,z): F(0) for m,z in product(range(2), repeat=2)}
        for prev, flip, noise in product(range(2), repeat=3):
            p = F(1,2)*(1-alpha if flip else alpha)*(eps if noise else 1-eps)
            joint[prev ^ noise, prev ^ flip] += p
        assert sum(joint.values()) == 1
        baseline = max(sum(p for (m,z),p in joint.items() if z==a) for a in range(2))
        policies = list(product(range(2), repeat=2))
        scores = [sum(p for (m,z),p in joint.items() if policy[m]==z) for policy in policies]
        best = max(scores)
        gain = abs(2*alpha-1)*(F(1,2)-eps)
        assert baseline == F(1,2)
        assert best == baseline + gain
        # Separate stipulated fitness map with beta=1 and positive weights.
        cost_checks = []
        for cost in sorted({F(0),gain,gain+F(1,10)}):
            w0, w1 = 1+baseline, 1+best-cost
            assert w0 > 0 and w1 > 0
            after = w1/(w0+w1)  # initial memory architecture fraction 1/2
            assert (after > F(1,2)) == (gain > cost)
            assert (after == F(1,2)) == (gain == cost)
            cost_checks.append(dict(cost=frac(cost), memory_frequency_after=frac(after),
                                    net_advantage=frac(gain-cost)))
        rows.append(dict(alpha=frac(alpha), epsilon=frac(eps), baseline=frac(baseline),
                         memory_accuracy=frac(best), gain=frac(gain),
                         optimal_policies=[list(p) for p,s in zip(policies,scores) if s==best],
                         fitness_checks=cost_checks))
    return dict(cases=len(rows), checks="PASS", rows=rows)


def main():
    results = dict(round="R18", date="2026-10-04", status="mathematical checks only",
                   assumptions=["finite state, observation, added-information and action sets",
                                "fixed evaluation and bounded utility",
                                "enlarged ideal policy class contains all baseline policies",
                                "memory example has stationary fair symmetric Markov environment",
                                "independent memory noise and no informative current cue",
                                "fitness map separately stipulated; no organism inferred to attain optimum"],
                   finite_decisions=decision_audit(), correlated_environment=memory_audit(),
                   negative_findings=["informative signals can have zero value for a fixed decision",
                                      "perfect past memory has zero current-prediction value at alpha=1/2",
                                      "alternating environments can favor inverted memory",
                                      "positive gross capability gain can have negative net fitness effect",
                                      "environment sweeps are not fixed-J comparisons for NESIG"],
                   code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    output = Path(__file__).with_name("UCT_III_R18_Memory_Value_Results_20261004.json")
    output.write_text(json.dumps(results,indent=2)+"\n")
    print(json.dumps(dict(output=str(output), finite_decisions=results["finite_decisions"],
                          memory_cases=results["correlated_environment"]["cases"], checks="PASS")))


if __name__ == "__main__":
    main()
