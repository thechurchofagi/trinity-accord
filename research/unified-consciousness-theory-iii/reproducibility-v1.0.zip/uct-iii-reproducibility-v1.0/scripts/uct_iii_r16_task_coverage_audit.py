"""Exact checks of the existing R14 circuit's scored and unscored observations.

This is a synthetic comparison audit, not a phenomenal assignment or experiment.
Reuses R14's execution function without changing its task or transmission model.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib
import json

from uct_iii_r14_circuit_model import run

ROOT = Path(__file__).resolve().parent


def tv(p, q):
    return sum(abs(p.get(k, F(0)) - q.get(k, F(0))) for k in p.keys() | q.keys()) / 2


def scored_law(w, epsilon):
    result = {(target, output): F(0) for target, output in product((0, 1), repeat=2)}
    for target, mask, error in product((0, 1), repeat=3):
        weight = F(1, 4) * (epsilon if error else 1 - epsilon)
        output = target ^ (w & mask) ^ error
        result[target, output] += weight
    assert sum(result.values()) == 1
    return result


def main():
    sequences = []
    for horizon in range(1, 7):
        inputs = list(product((0, 1), repeat=horizon + 1))
        counts = [Counter(), Counter()]
        for x, n in product(inputs, repeat=2):
            for w in (0, 1):
                trace = run(x, n, w=w, r=1)[1:]
                counts[w][tuple(row['y'] for row in trace)] += 1
        denominator = len(inputs) ** 2
        laws = [{key: F(value, denominator) for key, value in c.items()} for c in counts]
        assert laws[0] == laws[1]
        assert len(laws[0]) == 2 ** horizon
        assert set(laws[0].values()) == {F(1, 2 ** horizon)}
        sequences.append({'horizon_after_warmup': horizon,
                          'input_trace_pairs': denominator,
                          'output_laws_identical': True,
                          'each_output_word_probability': str(F(1, 2 ** horizon))})

    noise_results = []
    for epsilon in (F(0), F(1, 4), F(1, 2)):
        a, b = scored_law(0, epsilon), scored_law(1, epsilon)
        score_a = sum(p for (target, output), p in a.items() if target == output)
        score_b = sum(p for (target, output), p in b.items() if target == output)
        marginal_a = {y: sum(p for (t, output), p in a.items() if output == y) for y in (0, 1)}
        marginal_b = {y: sum(p for (t, output), p in b.items() if output == y) for y in (0, 1)}
        assert tv(marginal_a, marginal_b) == 0
        assert score_a == 1 - epsilon and score_b == F(1, 2)
        assert tv(a, b) == score_a - score_b == F(1, 2) - epsilon
        # For a finite alphabet, extrema over all [0,1]-valued scores occur
        # at these indicator vertices. This is a check, not the general proof.
        keys = list(a)
        max_score_gap = F(0)
        for values in product((0, 1), repeat=len(keys)):
            gap = abs(sum(v * (a[k] - b[k]) for k, v in zip(keys, values)))
            assert gap <= tv(a, b)
            max_score_gap = max(max_score_gap, gap)
        assert max_score_gap == tv(a, b)
        noise_results.append({'epsilon': str(epsilon),
                              'joint_alphabet': ['target', 'output'],
                              'A1_joint': {f'{t}{y}': str(p) for (t, y), p in a.items()},
                              'B1_joint': {f'{t}{y}': str(p) for (t, y), p in b.items()},
                              'A1_accuracy': str(score_a), 'B1_accuracy': str(score_b),
                              'output_marginal_tv': '0', 'scored_joint_tv': str(tv(a, b)),
                              'bounded_score_vertices_checked': 16})

    # Same reduced old-memory intervention, fixed incoming values, one update:
    # both initial memories produce the same next memory. A hardware return
    # verdict cannot be inferred because subcycle/register physics is omitted.
    reset_checks = []
    for w, x, n in product((0, 1), repeat=3):
        successors = [x ^ (w & n) for old_memory in (0, 1)]
        assert successors[0] == successors[1]
        reset_checks.append({'w': w, 'x': x, 'n': n, 'successors_from_M0_M1': successors})

    output = {'status': 'PASS',
              'evidence_type': 'exact synthetic audit of the unchanged R14 circuit',
              'source_R14_code_sha256': hashlib.sha256((ROOT / 'uct_iii_r14_circuit_model.py').read_bytes()).hexdigest(),
              'source_R14_task': 'Pr(Y_t = X_(t-1)); warmup excluded',
              'post_edit_output_sequence_checks': sequences,
              'joint_score_noise_checks': noise_results,
              'reduced_tick_memory_intervention_checks': reset_checks,
              'interpretation': {'all_horizon_output_equality': 'Analytic iid argument; finite checks are supplementary.',
                                 'rival_complete_phenomenal_assignment': 'NOT ESTABLISHED',
                                 'rival_negative_consciousness_verdict': 'NOT ESTABLISHED',
                                 'empirical_evidence': 'NONE'},
              'limits': ['Output-only laws omit the target-output relation needed to score the task.',
                         'Equality averaged over preparation is not equality at every intrinsic state.',
                         'A circuit configuration edit is not automatically a native operation.',
                         'No hardware timing, recurrence certificate, or complete UCT type was added.']}
    destination = ROOT / 'UCT_III_R16_Task_Coverage_Results_20261004.json'
    destination.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({'status': output['status'], 'sequence_horizons': len(sequences),
                      'input_pairs_total': sum(s['input_trace_pairs'] for s in sequences),
                      'noise_cases': len(noise_results), 'indicator_scores_checked': 48,
                      'reduced_memory_interventions': len(reset_checks),
                      'rival_assignment': 'NOT ESTABLISHED'}, indent=2))


if __name__ == '__main__':
    main()
