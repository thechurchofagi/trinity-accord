# Recovery without Epistemic Monopoly
## 不让保管权垄断过去

TA-TR-2026-05 · version 1.0 · 17 September 2026

**Status:** completed research manuscript and reproducibility package. Not peer reviewed. Zenodo DOI for version 1.0: `10.5281/zenodo.22809019`. The English and Chinese manuscripts describe the same study, not two independent papers. The four prior DOI identifiers remain references only and are not overwritten by this deposit.

**中文说明：** 本包包含完整英文论文、对应中文全文、可编辑Markdown、实际运行的本地程序、原始逐配置结果、文献及证据账本、修订记录和校验和。这不是下一步工作指令，也不需要使用者另外招募参与者或调用付费AI。三位一体协定只作为有固定来源的文献式案例，没有改动正本、冻结档案、旧DOI或生产网站。

## Read first

- `manuscript/paper_en.md`: English manuscript, all numbered sections and 25 references.
- `manuscript/paper_zh.md`: full corresponding Chinese manuscript.
- `results/study_results.json`: machine-readable primary outcomes and scope.
- `research/EVIDENCE-LEDGER.md`: what each claim is supported by and what it cannot establish.
- `research/REVISION-LOG.md`: AI-led critical revision, including the retained baseline tie.
- `research/references.json`: bibliographic metadata and exactly what source ranges/types were inspected.

## Reproduce the experiments

Use Python 3.10 or later, standard library only. From this directory:

```bash
python3 src/study.py --out reproduced
python3 src/check_results.py --results reproduced
```

Use a new output directory. The script writes only under the specified output path, replacing its own named result files if reused. It makes no network requests, calls no AI model, does not extract an untrusted archive, and never executes archived instructions. All people and events inside the four experimental JSON files are fictional fixtures. No credentials, real personal data, system-access permissions or cloud accounts are required.

The included `results/` were actually generated during this study. `src/check_results.py` is a separate symbolic recount and arithmetic check: it does not import the primary reader. It was written by the same AI system, so it is **not an independent external audit**. The included tests and finite enumerations may also have defects; their successful execution is not a universal security certificate.

The substantive CSV and JSON results are deterministic. `environment.json` will differ on another machine or Python version. PDF bytes may also differ with font/TeX versions and build timestamps; document hashes identify this delivered version, not a promise of cross-platform PDF byte determinism. Files in `qa/` retain the actual repeatability and document-check reports for this delivery.

## What was executed

- E1: 250 recovery configurations (125 ordered custodian states × reference available/unavailable), four policies, 1,000 policy evaluations and 4,000 object evaluations.
- E2: 72 structured source/status/directive/permission configurations, three explicit policies, 216 policy evaluations. A dispatch is a recorded Boolean, not an executed real action.
- E3: 58 subsets across five dependency topologies. The cuts are conditional on the listed domain model and a trusted reader, not a measurement of the actual Trinity Accord network.
- 19 named sanity checks; 580 single-bit mutations, one per original byte position.
- A second complete execution with matching substantive files, plus a separately implemented arithmetic cross-check.

No human-subject study, adaptive attack optimization, adversarial prompt trial, trained agent, real multi-agent competition, production attack, new whole-chain verification, or fresh full archive cold recovery was performed.

## Files and result fields

`E1_runs.csv` and `E1_objects.csv` distinguish exact candidates, altered candidates, and independently matched sources. A candidate returned by a weak retrieval policy is **not automatically an authenticity attestation**. Promoting that candidate to verified history is a separate application error. `oracle_exact_available` is used only by the evaluator, not by the pinned reader.

`E1_queries.csv` reports exact support for four singleton queries and one joint query. This is source-support recovery with known file identities, not semantic question-answering by a model.

`E2_runs.csv` separates old source identity, stipulated current registry evidence, and stipulated scope-specific permission. Current permission is provided as structured ground truth; understanding a human's natural-language permission is not tested. A historical snapshot can legitimately be exported without being represented as the latest snapshot.

`E3_subsets.csv` and `E3_summary.json` list domain sets, surviving paths and minimum cuts. The independent-route cut is not a cost or probability estimate. A hidden shared dependency can invalidate it.

`mutation_checks.csv` verifies that the chosen changed payloads do not match a prior digest. It is not a cryptographic collision-resistance test.

## The important negative result

With the independent reference available, PINNED and SCOPED **tie**: each selects all 412 exact objects that are obtainable across the enumerated configurations and selects no altered object. The extra reporting layer recovers no additional bytes. It adds scoped gap and authority/status outputs. Their value to human users or real models has not been measured. Against reliable existing verification, the contribution is a bounded conformance artifact and integration argument, not a new storage breakthrough.

## Build the PDFs

PDFs are supplied. Optional rebuilding requires Pandoc, XeLaTeX, normal LaTeX packages, and the installed fonts named in the script:

```bash
bash src/build_pdf.sh ./pdf_build
```

`manuscript/header.tex` supplies page layout. Fonts are not distributed in this package. Rebuilding is not required to reproduce experimental results.

## Contribution, interest, and rights

Hongju Liu initiated the research concern, approved the direction and commissioned completion. GPT-6 Astra Pro performed substantive research, modeling, coding, execution, interpretation, adversarial self-critique, English/Chinese drafting and packaging. Approval of the direction is not represented as separate claim-by-claim approval of the final text. Liu is the proposed accountable human author of record; dissemination responsibility cannot be transferred to a model.

Liu initiated the motivating Trinity Accord and is its Guardian. This relationship is disclosed and is not independent validation. No independent peer review, external human code audit, institutional sponsorship or final human line-by-line verification is claimed.

New text, code and fixtures are supplied under CC BY 4.0 to the extent applicable rights are held. Referenced third-party materials retain their own rights. The notice does not assert that generated material necessarily has copyright in every jurisdiction. See `LICENSE.txt`.
