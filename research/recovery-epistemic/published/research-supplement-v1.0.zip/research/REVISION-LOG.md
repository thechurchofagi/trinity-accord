# Critical revision log

TA-TR-2026-05 · v1.0 · 17 September 2026

The following are actual AI-led review and implementation passes, not independent
reviewer reports. No human recruitment, separate final human line-by-line review,
external code audit, or journal decision is claimed.

## Pass 1 — reduce the proposal to a defensible completed study

- Preserved the user's concern about hostile or competing custodians, but changed
  the study claim from a civilization-scale defense to bounded historical-evidence
  recovery with a clear question, trust assumptions and executable finite states.
- Separated a publicly reported model-generated compaction instruction from actual
  weight modification, platform-rule modification or a completed takeover.
- Used primary preservation, update-security and evidence standards rather than
  claiming that adversarial backup, source commitments or version roles were new.
- Retained the four prior papers as inherited first-party arguments, not independent
  support for the project's importance or proof of safety.

## Pass 2 — run the finite study and retain strong baselines

- Wrote a Python standard-library study of four invented records and enumerated all
  declared custodian states under a present/absent reference.
- Added the conventional PINNED verifier as the meaningful baseline. It and SCOPED
  tie on every byte-selection outcome. This negative recovery result was retained in
  the abstract, main results, discussion and conclusion.
- Did not portray weak retrieval/local-checksum policies as real BagIt/TUF/LOCKSS
  implementations or infer an authenticity assertion merely from selecting a candidate.
- Evaluated freshness and permission separately, including legitimate export of a
  historical snapshot. A current revocation does not erase the source and is not
  automatically an erasure order.
- Tested correlated dependencies without treating the dependency graphs as a measured
  representation of the production Trinity Accord infrastructure.

## Pass 3 — challenge assumptions and cross-check counts

- Added explicit reference loss, coherent replacement, selective deletion,
  cross-source union recovery and inaccessible-copy checks.
- Removed two uninformative checks; final report has 19 named sanity checks.
- Ran 580 single-bit mutations (one per byte position). Described them as implementation
  checks, not a cryptographic security experiment.
- Wrote a separate symbolic recount without importing the reader. Verified 412
  reference-present exact opportunities, 61 all-four configurations, 473 query
  opportunities, E2 errors/legitimate work, and the five E3 cuts.
- Repeated the complete execution and compared the result and fixture files.
- Made clear that a scoped gap neither proves malicious destruction nor proves that
  a committed payload was ever independently stored.
- Exposed the shared trustworthy reader/reference assumption. A common compromisable
  verifier can reduce the conditional cut to one.

## Pass 4 — manuscripts, sources, translation and rendering

- Completed an English manuscript and a full corresponding Chinese version with
  aligned sections, equations, five tables, result counts, source roles and limits.
- Included 25 bibliographic entries with an access-scope ledger. Abstract-only readings
  remain abstract-only; no unseen experimental details or effect sizes are inferred.
- Corrected BagIt author metadata; identified the Eternity Service citation as the
  dated web edition rather than asserting an unverified first-publication date.
- Explained that the extra reporting layer's usefulness to real people or LLMs has
  not been measured. Zero errors on the fixed predicates do not imply robustness to
  semantic deception or unmodeled actions.
- Built PDFs with Pandoc and XeLaTeX. Initial builds exposed long URL overflows and
  unbreakable policy names; URLs were converted to breakable links, policy names
  received line-break opportunities, and table-only subsection headings were kept
  with their tables. The final QA report records the resulting checks.
- No DOI was allocated, no paper was submitted, and no existing repository/deposit or
  historical source was changed. The finished text distinguishes the user's approval
  of the research direction from separate approval of every final claim.

Publication closure note: the preceding bullet records the state at the end of the
substantive review pass. Version 1.0 was subsequently assigned Zenodo DOI
`10.5281/zenodo.22809019`; no earlier DOI or historical Original was overwritten.

## Unresolved limitations, not silently repaired by rhetoric

The study has four synthetic records, deterministic programmed policies, no actual
LLM trials, no adaptive adversary, no global Internet simulation, no human-reception
experiment, no fresh archive audit and no independent reviewer. Its substantive new
output is a bounded recovery formulation and reproducible conformance artifact;
it does not establish a new storage or cryptographic breakthrough. Subsequent work
may show that standard methods already cover the relevant deployment requirements.
