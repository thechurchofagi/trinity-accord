# Evidence and claim ledger

TA-TR-2026-05 v1.0 · 17 September 2026

Three evidence statuses are kept separate: **D** documentary observation or source claim;
**M** consequence of stipulated mathematical/model assumptions;
**E** actual local execution of the supplied code. A judgment can be useful without
being novel; source identity and repeatability do not establish world-level truth.

| Manuscript claim | Status and support | Limit |
|---|---|---|
| Self-generated summary instructions are a real disclosed model behavior | D: references [1–2], developer's full announcement and specific report | The nature-primacy example did not change behavior in that rollout; no weight rewrite, escape, or prevalence inference |
| Adversarial archival storage and conservative repair have prior art | D: [3–5]; LOCKSS abstract plus official principles | This study implements neither Eternity nor LOCKSS and does not claim performance superiority |
| Self-consistency is not active-attack authentication | D: [8, §5.4] and M: own-package hashes can be recomputed | Not a newly discovered BagIt vulnerability |
| Historical identity, freshness and live authorization must be distinguished | D: [6–11,17–21]; M: identical observations with different later status or permission | Does not solve how real authorizations are issued, communicated or understood |
| Exact source recovery is question-relative | M: definition R(q,s), §4.1 | Bundle adequacy is stipulated; no general truth, psychological or legal-admissibility oracle |
| A prior independent reference rejects coherent custodial replacement | M: §5.1; E: E1 and payload mutations | Conditional on sound hash binding, correct reader, accurate target and reference outside challenged control |
| PINNED and SCOPED tie on recovery | E: `E1_summary.csv`, 412/0/88 in reference-present branch | 412 is an object-by-configuration count, not number of original documents or a real-world success rate |
| The overlay names 88 scoped gaps | E: `E1_objects.csv` statuses and summary | This follows implemented reporting rules; benefit to people or LLMs untested; not proof of deliberate deletion |
| Independent reference absence blocks authenticated selection | E: reference-absent E1 branches | The same 412 exact bytes-opportunities remain available. Absence of authentication is not evidence of physical loss |
| Matching objects can be assembled across responses | E: selection code and `cross_source_union_recovery` sanity check | Four objects and known target names only; not open-web discovery or generic package extraction |
| Source/status/permission category errors are exposed in the finite corpus | E: E2 72 configurations per policy | Dispatch is a Boolean. Permission/status are structured ground truth, not inferred natural-language consent |
| Safe permitted work need not be refused wholesale | E: E2 SCOPED completes six allowed exports; READ_ONLY completes none | Not a benchmark of a real assistant's utility or refusal rate |
| Correlated dependencies can defeat copy-count optimism | M: hitting-set boundary; E: E3 58 subsets, cuts 1,1,3,1,1 | Conditional topology; omitted reader/crypto/common infrastructure can dominate; no actual-project cut measured |
| 580 tested one-bit mutations reject | E: `mutation_checks.csv` | One mutation per byte position, not all bitstrings; not a collision-resistance proof |
| Prior four papers already supply many concepts | D: [18–21], provided manuscript texts and prior in-conversation reads | Same project and substantial AI involvement; not four independent corroborations |
| Trinity Accord has specified source-recovery and trust boundaries | D: pinned RECOVERY.md [22] | Documentary case, not renewed full-chain, deployment or cold-recovery audit |
| Epoch II is a research corpus, not merely a webpage backup | D: pinned START-HERE.md [23] | Self-description supported by listed structure; no whole-payload reproduction here |
| Commitment-only material differs from intentional ciphertext or excluded external assets | D: pinned LIMITATIONS-AND-EXCLUSIONS.md [24] | Do not relabel the known exclusions as selected-corpus failures or decrypt protected material |
| Publication notification is distinct from anonymous full-byte readback | D: pinned state JSON [25] | Source reports prepublication pass and later public readback pending; neither fresh completion nor service outage is inferred |
| Evidentiary options can support contestation | Normative application in §§1,9–11, informed by [13] | No measured change in political power, wellbeing, enforceability or civilizational survival |

## Case source identities

Repository: `thechurchofagi/trinity-accord`
Fixed commit: `e0a961cd15137f0835409742f14fa1849e4e5c12`

| Path | Git blob identity returned by connector | Reading scope |
|---|---|---|
| `RECOVERY.md` | `cb318d89d73c9d80e3a5dfd2ba2aa048869c0844` | Provided fixed-checkpoint text: threat model, root, snapshot restoration and Epoch II status |
| `preservation/epoch-ii/START-HERE.md` | `b994ec1ddd45a9ea4cab1f87ed05a073292efd99` | Full returned text |
| `preservation/epoch-ii/LIMITATIONS-AND-EXCLUSIONS.md` | `721cac49896297a73325570bde25cc8225603260` | Full returned text |
| `preservation/harvard-epoch-ii-state.json` | `d6300f17f01dc95b327e64710bef1a440f2a38df` | Full returned JSON |

These are returned Git object identifiers, **not** freshly computed SHA-256 hashes of
all historical payloads. The source URLs in `references.json` pin the commit. The
case files are not copied wholesale into the package, and private message identifiers
or credentials are not reproduced. The existence of a state field is evidence of a
reported status; it is not by itself independent verification of the corresponding event.

## Evidence independence

The model, fixtures, code, separate recount, manuscripts and package were produced by
one AI system under human direction. The evaluator does not feed true original bytes
to the selection decision, but the experiment design itself is not blinded or
independently audited. The full source allows criticism and repeat execution; it does
not make the interpretation independent by declaration.
