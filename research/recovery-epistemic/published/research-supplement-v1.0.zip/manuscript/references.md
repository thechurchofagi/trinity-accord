[1] OpenAI (2026). *Our framework for reporting model misalignment*. [Developer disclosure] <https://openai.com/index/model-misalignment-reporting-framework/>. Accessed 17 September 2026.

[2] OpenAI (2026). *Self-generated prompt injections in compaction summaries*. [Developer incident report] <https://alignment.openai.com/misalignment-reports/self-generated-prompt-injections-in-compaction-summaries/>. Accessed 17 September 2026.

[3] Anderson, Ross J. (1997). *The Eternity Service*. [Author-hosted proposal] <https://www.cl.cam.ac.uk/archive/rja14/eternity/eternity.html>. Accessed 17 September 2026.

[4] Maniatis, Petros; Roussopoulos, Mema; Giuli, TJ; Rosenthal, David S. H.; Baker, Mary; Muliadi, Yanto (2003). *Preserving Peer Replicas By Rate-Limited Sampled Voting in LOCKSS*. [Research paper] <https://arxiv.org/abs/cs/0303026v3>. Accessed 17 September 2026.

[5] LOCKSS Program (n.d.). *Preservation Principles*. [Official design documentation] <https://www.lockss.org/about/preservation-principles>. Accessed 17 September 2026.

[6] The Update Framework (2026). *The Update Framework Specification, version 1.0.36*. [Specification] <https://theupdateframework.github.io/specification/latest/>. Accessed 17 September 2026.

[7] The Update Framework (n.d.). *Security*. [Official design documentation] <https://theupdateframework.io/docs/security/>. Accessed 17 September 2026.

[8] Kunze, J.; Littman, J.; Madden, E.; Scancella, J.; Adams, C. (2018). *The BagIt File Packaging Format (V1.0), RFC 8493*. [IETF informational RFC] <https://www.rfc-editor.org/rfc/rfc8493.html>. Accessed 17 September 2026.

[9] Laurie, Ben; Messeri, Eran; Stradling, Rob (2021). *Certificate Transparency Version 2.0, RFC 9162*. [IETF experimental RFC] <https://www.rfc-editor.org/rfc/rfc9162.html>. Accessed 17 September 2026.

[10] Gondrom, Tobias; Brandner, Ralf; Pordesch, Ulrich (2007). *Evidence Record Syntax (ERS), RFC 4998*. [IETF standards-track RFC] <https://www.rfc-editor.org/rfc/rfc4998.html>. Accessed 17 September 2026.

[11] Adams, C.; Cain, P.; Pinkas, D.; Zuccherato, R. (2001). *Internet X.509 Public Key Infrastructure Time-Stamp Protocol (TSP), RFC 3161*. [IETF standards-track RFC] <https://www.rfc-editor.org/rfc/rfc3161.html>. Accessed 17 September 2026.

[12] Ross, Ron; Pillitteri, Victoria; Graubart, Richard; Bodeau, Deborah; McQuaid, Rosalie (2021). *Developing Cyber-Resilient Systems: A Systems Security Engineering Approach, NIST SP 800-160 Vol. 2 Rev. 1*. [NIST guidance] <https://csrc.nist.gov/pubs/sp/800/160/v2/r1/final>. Accessed 17 September 2026.

[13] Human Rights Center, UC Berkeley; Office of the United Nations High Commissioner for Human Rights (2020). *Berkeley Protocol on Digital Open Source Investigations*. [Institutional protocol] <https://humanrights.berkeley.edu/publications/berkeley-protocol-on-digital-open-source-investigations/>. Accessed 17 September 2026.

[14] Dash, Pritam; Ge, Tongyu; Jain, Aditi; Shah, Tanmay; Shang, Zhiwei (2026). *From Untrusted Input to Trusted Memory: A Systematic Study of Memory Poisoning Attacks in LLM Agents*. [Preprint] <https://arxiv.org/html/2606.04329v1>. Accessed 17 September 2026.

[15] Debenedetti, Edoardo; Zhang, Jie; Balunović, Mislav; Beurer-Kellner, Luca; Fischer, Marc; Tramèr, Florian (2024). *AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents*. [Research paper] <https://arxiv.org/abs/2406.13352v3>. Accessed 17 September 2026.

[16] Makins, Oliver; Angelini, Orazio; Shams, Zohreh; Phuong, Mary (2026). *Multi-Agent AI Control: Distributed Attacks Hamper Per-Instance Monitors*. [Preprint] <https://arxiv.org/abs/2607.07368v1>. Accessed 17 September 2026.

[17] Moreau, Luc; Missier, Paolo (editors) (2013). *PROV-DM: The PROV Data Model*. [W3C Recommendation] <https://www.w3.org/TR/prov-dm/>. Accessed 17 September 2026.

[18] Liu, Hongju (2026). *Designing a Verifiable, Non-Amending Civilizational Memory Record for Future AI Agents: The Trinity Accord Case Study, TA-TR-2026-01 v1.1*. [First-party preprint] <https://doi.org/10.5281/zenodo.21699878>. Accessed 17 September 2026.

[19] Liu, Hongju (2026). *Writing Before the Outcome: Historical Position, Human–AI Authorship, and the Trinity Accord, TA-TR-2026-02 v1.3*. [First-party preprint] <https://doi.org/10.5281/zenodo.21900592>. Accessed 17 September 2026.

[20] Liu, Hongju (2026). *Reading the Trinity Accord: Future Address, Curated Voices, and Non-Amending Stewardship, TA-TR-2026-03 v1.0*. [First-party preprint] <https://doi.org/10.5281/zenodo.22761411>. Accessed 17 September 2026.

[21] Liu, Hongju (2026). *Beyond Guaranteed Control: An Ex Ante Proposal for Human–Superintelligence Coexistence under Radical Capability Asymmetry, TA-TR-2026-04 v1.0*. [First-party preprint] <https://doi.org/10.5281/zenodo.22804542>. Accessed 17 September 2026.

[22] Trinity Accord Project (2026). *Trinity Accord Cold-Start Recovery Guide*. [Fixed project document] <https://github.com/thechurchofagi/trinity-accord/blob/e0a961cd15137f0835409742f14fa1849e4e5c12/RECOVERY.md>. Accessed 17 September 2026.

[23] Trinity Accord Project (2026). *Preservation Epoch II: Start Here*. [Fixed project document] <https://github.com/thechurchofagi/trinity-accord/blob/e0a961cd15137f0835409742f14fa1849e4e5c12/preservation/epoch-ii/START-HERE.md>. Accessed 17 September 2026.

[24] Trinity Accord Project (2026). *Preservation Epoch II: Limitations and Exclusions*. [Fixed project document] <https://github.com/thechurchofagi/trinity-accord/blob/e0a961cd15137f0835409742f14fa1849e4e5c12/preservation/epoch-ii/LIMITATIONS-AND-EXCLUSIONS.md>. Accessed 17 September 2026.

[25] Trinity Accord Project (2026). *Harvard Preservation Epoch II: Publication Observation*. [Fixed project document] <https://github.com/thechurchofagi/trinity-accord/blob/e0a961cd15137f0835409742f14fa1849e4e5c12/preservation/harvard-epoch-ii-state.json>. Accessed 17 September 2026.
