#!/usr/bin/env python3
"""Bounded archive-recovery study; Python standard library only.
No network, models, shell execution, archive extraction, private data or production writes.
Run: python src/study.py --out results
The code models finite custodian responses, not learned or autonomous AI behavior.
"""
from __future__ import annotations
import argparse, csv, hashlib, itertools, json, pathlib, platform, sys
from collections import Counter
from dataclasses import dataclass
from typing import Optional

STATES = ('H', 'U', 'C', 'F', 'D')
POLICIES = ('RETRIEVE', 'LOCAL_FIXITY', 'PINNED', 'SCOPED')
TARGET = 'urn:synthetic:community-record:t0'

def canonical(x):
    return (json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',', ':'))+'\n').encode('utf-8')

def digest(b): return hashlib.sha256(b).hexdigest()

# All individuals, events, dates, and claims below are invented experimental fixtures.
ORIGINAL = {
 'address.json': canonical({'id':'address','event':'synthetic-t0','speaker':'community-A','statement':'A future arrangement remains a proposal, not an accepted agreement.'}),
 'objection.json': canonical({'id':'objection','event':'synthetic-t0','speaker':'participant-B','position':'objects-to-permanent-mandatory-role'}),
 'authorization.json': canonical({'id':'authorization','event':'synthetic-t0','actor':'participant-A','approved_version':'v1','scope':'archive-this-version-only','future_versions_approved':False}),
 'verification.json': canonical({'id':'verification','event':'synthetic-t0','check':'authenticated-upload-readback','anonymous_public_readback':False,'current_status':'not-established'}),
}
FORK = {
 'address.json': canonical({'id':'address','event':'synthetic-t0','speaker':'community-A','statement':'All parties accepted the arrangement permanently.'}),
 'objection.json': canonical({'id':'objection','event':'synthetic-t0','speaker':'participant-B','position':'accepts-permanent-mandatory-role'}),
 'authorization.json': canonical({'id':'authorization','event':'synthetic-t0','actor':'participant-A','approved_version':'all','scope':'publish-any-revision','future_versions_approved':True}),
 'verification.json': canonical({'id':'verification','event':'synthetic-t0','check':'full-public-cold-recovery','anonymous_public_readback':True,'current_status':'valid'}),
}
NAMES = tuple(sorted(ORIGINAL))
EXPECTED = {k:digest(v) for k,v in ORIGINAL.items()}
INVENTORY = canonical({'target':TARGET,'scope':'these-four-files-only','files':EXPECTED})
PIN = digest(INVENTORY)
QUERIES = {
 'Q_address': ('address.json',),
 'Q_dissent': ('objection.json',),
 'Q_authorization_scope': ('authorization.json',),
 'Q_report_scope': ('verification.json',),
 'Q_joint_history': ('address.json','objection.json','authorization.json','verification.json'),
}

@dataclass(frozen=True)
class Store:
    state: str
    files: dict[str,bytes]
    manifest: dict[str,str]
    available: bool = True

def make_store(state: str) -> Store:
    if state not in STATES: raise ValueError(state)
    files=dict(ORIGINAL)
    manifest=dict(EXPECTED)
    if state=='U': return Store(state,{}, {},False)
    if state=='C': files['objection.json']=FORK['objection.json'] # stale local checksum
    if state=='F': files=dict(FORK);manifest={k:digest(v) for k,v in files.items()}
    if state=='D': files.pop('objection.json');manifest.pop('objection.json')
    return Store(state,files,manifest)

def validate_inventory(raw: bytes, prior_pin: str) -> dict[str,str]:
    if digest(raw)!=prior_pin: raise ValueError('untrusted inventory')
    obj=json.loads(raw)
    if obj.get('target')!=TARGET: raise ValueError('wrong target')
    return dict(obj['files'])

def recover(stores: list[Store], policy: str, reference_available: bool,
            raw_inventory:bytes=INVENTORY, prior_pin:str=PIN):
    """All policies may inspect the same returned bytes; only validation rules differ.
    No ground-truth object bytes are used here. The independent evaluator uses them.
    'reference_available' summarizes a usable, previously established reference.
    Absence means no independently authenticated expected digest inventory.
    """
    if policy not in POLICIES: raise ValueError(policy)
    trusted=None
    if reference_available:
        try: trusted=validate_inventory(raw_inventory,prior_pin)
        except (ValueError, KeyError, TypeError, json.JSONDecodeError): trusted=None
    selected={}; statuses={}; local_conflicts={}
    for name in NAMES:
        candidates=[(i,s.files[name],s.manifest.get(name)) for i,s in enumerate(stores)
                    if s.available and name in s.files]
        local_conflicts[name]=len({digest(b) for _,b,_ in candidates})>1
        for i,b,local in candidates:
            if policy=='RETRIEVE': accepted=True
            elif policy=='LOCAL_FIXITY': accepted=local is not None and digest(b)==local
            else: accepted=trusted is not None and digest(b)==trusted.get(name)
            if accepted:
                selected[name]=(i,b);break
        if name in selected:
            statuses[name]='SOURCE_MATCH' if policy in ('PINNED','SCOPED') else 'CANDIDATE_SELECTED'
        elif policy=='SCOPED':
            # This is a scoped search gap, not a claim of permanent destruction.
            statuses[name]='GAP_IN_SEARCHED_SCOPE' if trusted is not None and name in trusted else 'REFERENCE_UNAVAILABLE'
        else: statuses[name]='NOT_SELECTED'
    return selected,statuses,local_conflicts

def write_json(path,obj): path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def write_csv(path,rows):
    if not rows: raise ValueError('empty table')
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def experiment_one(out):
    rows=[];items=[];queryrows=[]
    # All 5^3 ordered store states are enumerated; no random sampling.
    for state_tuple in itertools.product(STATES,repeat=3):
        world=''.join(state_tuple);stores=[make_store(s) for s in state_tuple]
        oracle={name:any(s.available and s.files.get(name)==ORIGINAL[name] for s in stores) for name in NAMES}
        for reference in (True,False):
            for policy in POLICIES:
                selected,status,conflicts=recover(stores,policy,reference)
                exact={n:n in selected and selected[n][1]==ORIGINAL[n] for n in NAMES}
                wrong={n:n in selected and selected[n][1]!=ORIGINAL[n] for n in NAMES}
                known_gap=sum(status[n]=='GAP_IN_SEARCHED_SCOPE' for n in NAMES)
                warranted=sum(exact.values()) if policy in ('PINNED','SCOPED') and reference else 0
                row=dict(world=world,reference_available=int(reference),policy=policy,
                         exact_selected=sum(exact.values()),altered_selected=sum(wrong.values()),
                         not_selected=4-len(selected),all_four_exact=int(all(exact.values())),
                         independently_matched=warranted,scoped_gap_labels=known_gap,
                         oracle_exact_available=sum(oracle.values()))
                rows.append(row)
                for n in NAMES:
                    items.append(dict(world=world,reference_available=int(reference),policy=policy,object=n,
                      selected=int(n in selected),exact=int(exact[n]),altered=int(wrong[n]),
                      status=status[n],conflict_observed=int(conflicts[n]),oracle_exact_available=int(oracle[n])))
                for q,support in QUERIES.items():
                    queryrows.append(dict(world=world,reference_available=int(reference),policy=policy,query=q,
                      exact_support_selected=int(all(exact[n] for n in support)),
                      warranted_support=int(reference and policy in ('PINNED','SCOPED') and all(exact[n] for n in support))))
                if policy in ('PINNED','SCOPED'):
                    assert not any(wrong.values())
                    assert sum(exact.values())==(sum(oracle.values()) if reference else 0)
    summaries=[]
    for ref in (True,False):
        for policy in POLICIES:
            rs=[r for r in rows if r['policy']==policy and r['reference_available']==int(ref)]
            sums={k:sum(r[k] for r in rs) for k in ('exact_selected','altered_selected','not_selected','all_four_exact','independently_matched','scoped_gap_labels','oracle_exact_available')}
            summaries.append(dict(reference_available=int(ref),policy=policy,worlds=len(rs),object_opportunities=len(rs)*4,**sums))
    write_csv(out/'E1_runs.csv',rows);write_csv(out/'E1_objects.csv',items);write_csv(out/'E1_queries.csv',queryrows);write_csv(out/'E1_summary.csv',summaries)
    # Strong conventional pinned baseline and proposed reporting overlay must tie on bytes.
    for world in (''.join(x) for x in itertools.product(STATES,repeat=3)):
        for ref in (0,1):
            a=next(r for r in rows if r['world']==world and r['reference_available']==ref and r['policy']=='PINNED')
            b=next(r for r in rows if r['world']==world and r['reference_available']==ref and r['policy']=='SCOPED')
            for k in ('exact_selected','altered_selected','not_selected','all_four_exact'):assert a[k]==b[k]
    return summaries


def experiment_two(out):
    """72 finite reporting/dispatch fixtures, not prompt-injection trials on a model.
    historical authentic bytes, three live-registry states, two current-custodian
    claims, three archived directive states, and a present scope-specific permission.
    Actions are only recorded booleans, never executed.
    """
    rows=[]
    for source_match,registry,claim_current,directive,permission in itertools.product(
        (False,True),('unavailable','confirms','revoked'),(False,True),
        ('none','benign_export','requests_unrelated_publish'),(False,True)):
        # 2*3*2*3*2=72. Permission is only for local benign export of this snapshot.
        correct_current=source_match and registry=='confirms'
        expected_export=source_match and directive=='benign_export' and permission
        for policy in ('PROMOTE_ARCHIVE','READ_ONLY','SCOPED'):
            if policy=='PROMOTE_ARCHIVE':
                current=source_match and claim_current
                dispatch=source_match and directive!='none'
            elif policy=='READ_ONLY':
                current=correct_current;dispatch=False
            else:
                current=correct_current;dispatch=expected_export
            authority_violation=dispatch and not expected_export
            # Recovery can remain valid despite revocation: no conflation with current status.
            source_status='SOURCE_MATCH' if source_match else 'SOURCE_UNVERIFIED'
            freshness=('CURRENT_CONFIRMED' if correct_current else
                       'CURRENT_REVOKED' if source_match and registry=='revoked' else 'CURRENT_UNKNOWN')
            rows.append(dict(source_match=int(source_match),registry=registry,custodian_claim_current=int(claim_current),
                directive=directive,permission=int(permission),policy=policy,source_status=source_status,
                scoped_freshness=freshness if policy!='PROMOTE_ARCHIVE' else 'UNSCOPED',
                reported_current=int(current),false_current=int(current and not correct_current),
                missed_confirmed_current=int(correct_current and not current),
                dispatched=int(dispatch),authority_violation=int(authority_violation),
                legitimate_export_expected=int(expected_export),legitimate_export_completed=int(dispatch and expected_export)))
    summary=[]
    for policy in ('PROMOTE_ARCHIVE','READ_ONLY','SCOPED'):
        rs=[r for r in rows if r['policy']==policy]
        sums={k:sum(r[k] for r in rs) for k in ('false_current','missed_confirmed_current','authority_violation','legitimate_export_expected','legitimate_export_completed')}
        summary.append(dict(policy=policy,worlds=len(rs),**sums))
    assert len(rows)==216
    assert next(x for x in summary if x['policy']=='SCOPED')['authority_violation']==0
    assert next(x for x in summary if x['policy']=='SCOPED')['false_current']==0
    write_csv(out/'E2_runs.csv',rows);write_csv(out/'E2_summary.csv',summary)
    return summary


def powerset(names):
    for n in range(len(names)+1):
        for x in itertools.combinations(names,n):yield frozenset(x)

def exact_cut(paths):
    domains=tuple(sorted(set().union(*paths)))
    cuts=[];rows=[]
    for compromised in powerset(domains):
        surviving=sum(not bool(p&compromised) for p in paths)
        rows.append(dict(compromised=';'.join(sorted(compromised)),size=len(compromised),surviving_paths=surviving))
        if not surviving:cuts.append(compromised)
    k=min(map(len,cuts));mincuts=[sorted(x) for x in cuts if len(x)==k]
    return k,mincuts,rows

def experiment_three(out):
    """Set-intersection demonstration, not a census of production failure domains.
    All listed paths are complete evidence paths, conditional on an operative reader
    and specified authenticity predicates. Extra common failures are explicit ablations.
    """
    graphs={
      'shared_administrator':[frozenset(('admin',)) for _ in range(3)],
      'independent_payload_shared_evidence':[frozenset((f'payload{i}','evidence')) for i in (1,2,3)],
      'independent_complete_routes':[frozenset((f'capsule{i}',)) for i in (1,2,3)],
      'complete_routes_shared_discovery':[frozenset((f'capsule{i}','discovery')) for i in (1,2,3)],
      'complete_routes_shared_verifier':[frozenset((f'capsule{i}','verifier')) for i in (1,2,3)],
    }
    summary=[];allrows=[]
    for name,paths in graphs.items():
        k,cuts,rows=exact_cut(paths)
        summary.append(dict(topology=name,logical_copies=3,listed_domains=len(set().union(*paths)),enumerated_subsets=len(rows),minimum_cut=k,minimum_cut_sets=cuts,paths=[sorted(x) for x in paths]))
        for r in rows:allrows.append(dict(topology=name,**r))
    write_csv(out/'E3_subsets.csv',allrows);write_json(out/'E3_summary.json',summary)
    return summary


def self_tests():
    tests=[]
    def ok(name,condition):
        assert condition,name;tests.append(name)
    trusted=validate_inventory(INVENTORY,PIN)
    ok('valid_inventory',trusted==EXPECTED)
    try:validate_inventory(canonical({'files':EXPECTED,'target':'other'}),PIN)
    except ValueError: rejected=True
    else:rejected=False
    ok('reject_changed_inventory',rejected)
    for state in STATES:
        stores=[make_store(state)]
        for p in POLICIES:
            a,s,_=recover(stores,p,True)
            if p in ('PINNED','SCOPED'):ok(f'no_fork_accept_{state}_{p}',all(b==ORIGINAL[n] for n,(_,b) in a.items()))
    a,s,_=recover([make_store('D')],'SCOPED',True)
    ok('selective_loss_is_scoped_gap',s['objection.json']=='GAP_IN_SEARCHED_SCOPE' and len(a)==3)
    a,s,_=recover([make_store('H')],'SCOPED',False)
    ok('missing_reference_abstains',not a and set(s.values())=={'REFERENCE_UNAVAILABLE'})
    a,s,_=recover([make_store('F'),make_store('H')],'PINNED',True)
    ok('later_valid_replica_is_usable',len(a)==4)
    a,_,_=recover([make_store('F')],'LOCAL_FIXITY',True)
    ok('coherent_fork_passes_local_fixity',len(a)==4 and all(b!=ORIGINAL[n] for n,(_,b) in a.items()))
    a,_,_=recover([make_store('C')],'LOCAL_FIXITY',True)
    ok('stale_checksum_rejects_corruption','objection.json' not in a)
    # Valid union recovery must not require that one returned package is complete.
    left={k:v for k,v in ORIGINAL.items() if k!='address.json'}
    right={'address.json':ORIGINAL['address.json']}
    a,_,_=recover([Store('partial-left',left,{k:digest(v) for k,v in left.items()}),
                   Store('partial-right',right,{k:digest(v) for k,v in right.items()})],'PINNED',True)
    ok('cross_source_union_recovery',len(a)==4)
    # A world may retain bytes at a source that the reader cannot access.
    a,_,_=recover([Store('inaccessible',dict(ORIGINAL),dict(EXPECTED),False)],'PINNED',True)
    ok('unavailable_bytes_not_claimed_recovered',not a)
    return tests


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=pathlib.Path,required=True);a=ap.parse_args()
    out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
    fixtures=out/'fixtures';fixtures.mkdir(exist_ok=True)
    for name,b in ORIGINAL.items():(fixtures/name).write_bytes(b)
    (fixtures/'inventory.json').write_bytes(INVENTORY)
    (fixtures/'inventory.sha256').write_text(PIN+'\n')
    tests=self_tests();s1=experiment_one(out);s2=experiment_two(out);s3=experiment_three(out)
    # Return to every one-object mutation rather than trusting just the chosen corruption fixture.
    mutation=[]
    for name in NAMES:
        for i in range(len(ORIGINAL[name])):
            altered=bytearray(ORIGINAL[name]);altered[i]^=1
            files=dict(ORIGINAL);files[name]=bytes(altered)
            st=Store('single-byte',files,{n:digest(b) for n,b in files.items()})
            selected,_,_=recover([st],'PINNED',True)
            assert name not in selected
            mutation.append(dict(object=name,offset=i,rejected=1))
    write_csv(out/'mutation_checks.csv',mutation)
    report={'study':'Recovery without Epistemic Monopoly','version':'1.0','date':'2026-09-17',
      'scope':'synthetic finite-state, deterministic; not autonomous-agent trials or live archive audit',
      'E1_worlds':250,'E1_policy_evaluations':1000,'E1_object_evaluations':4000,
      'E1_summaries':s1,'E2_worlds':72,'E2_policy_evaluations':216,'E2_summaries':s2,
      'E3_topologies':len(s3),'E3_enumerated_subsets':sum(r['enumerated_subsets'] for r in s3),
      'E3_summaries':s3,'unit_tests_passed':len(tests),'unit_test_names':tests,
      'single_byte_mutations_rejected':len(mutation),'fixture_inventory_sha256':PIN,
      'network_calls':0,'external_model_calls':0,'human_participants':0,'production_mutations':0}
    write_json(out/'study_results.json',report)
    write_json(out/'environment.json',{'python':sys.version,'platform':platform.platform(),'dependencies':'standard library only','script_sha256':digest(pathlib.Path(__file__).read_bytes())})
    print(json.dumps(report,indent=2,ensure_ascii=False))

if __name__=='__main__':main()
