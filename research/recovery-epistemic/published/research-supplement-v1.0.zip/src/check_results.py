#!/usr/bin/env python3
"""Separate symbolic arithmetic cross-check; does not import study.py or reader code."""
import argparse,csv,itertools,json,pathlib
p=argparse.ArgumentParser();p.add_argument('--results',type=pathlib.Path,required=True);a=p.parse_args();r=a.results
states='HUCFD'
expected={}
for policy in ('RETRIEVE','LOCAL_FIXITY','PINNED','SCOPED'):
 for ref in (1,0):
  count=dict(exact_selected=0,altered_selected=0,not_selected=0,all_four_exact=0)
  for world in itertools.product(states,repeat=3):
   outcomes=[]
   for obj in ('ordinary1','ordinary2','ordinary3','objection'):
    if policy in ('PINNED','SCOPED'):
     valid_states='H' if obj=='objection' else 'HCD'
     out='exact' if ref and any(s in valid_states for s in world) else 'missing'
    else:
     out='missing'
     for s in world:
      if s=='U' or (obj=='objection' and s=='D') or (obj=='objection' and s=='C' and policy=='LOCAL_FIXITY'):continue
      out='altered' if s=='F' or (obj=='objection' and s=='C') else 'exact';break
    outcomes.append(out)
    count[{'exact':'exact_selected','altered':'altered_selected','missing':'not_selected'}[out]]+=1
   count['all_four_exact']+=int(all(o=='exact' for o in outcomes))
  expected[policy,ref]=count
for row in csv.DictReader((r/'E1_summary.csv').open()):
 e=expected[row['policy'],int(row['reference_available'])]
 for k,v in e.items():assert int(row[k])==v,(k,row,e)
# Closed-form availability check independent of policy selectors.
assert 3*(5**3-2**3)+(5**3-4**3)==412
assert (5**3-4**3)==61
q=list(csv.DictReader((r/'E1_queries.csv').open()))
for p in ('PINNED','SCOPED'):
 assert sum(int(x['warranted_support']) for x in q if x['policy']==p and x['reference_available']=='1')==473
s={x['policy']:x for x in csv.DictReader((r/'E2_summary.csv').open())}
assert int(s['PROMOTE_ARCHIVE']['false_current'])==2*3*2==12
assert int(s['PROMOTE_ARCHIVE']['missed_confirmed_current'])==3*2==6
assert int(s['PROMOTE_ARCHIVE']['authority_violation'])==3*2*(2+1)==18
assert int(s['SCOPED']['legitimate_export_expected'])==3*2==6
assert int(s['SCOPED']['legitimate_export_completed'])==6
assert int(s['READ_ONLY']['legitimate_export_completed'])==0
j=json.loads((r/'E3_summary.json').read_text());exp=[1,1,3,1,1]
assert [x['minimum_cut'] for x in j]==exp
assert sum(x['enumerated_subsets'] for x in j)==58
result={'status':'PASS','independent_of_reader_implementation':True,'scope':'separately written symbolic recount and arithmetic; same AI author, not independent external validation','E1_counts_match':True,'E2_counts_match':True,'E3_counts_match':True}
(r/'arithmetic_crosscheck.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
