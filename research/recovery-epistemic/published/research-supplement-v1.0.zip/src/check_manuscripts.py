#!/usr/bin/env python3
"""Check the delivered manuscript structure, tables and experimental report.
Optional document QA is performed by the packaging step; no model judgments here.
"""
from pathlib import Path
import json,re,hashlib
root=Path(__file__).resolve().parents[1]
en=(root/'manuscript/paper_en.md').read_text();zh=(root/'manuscript/paper_zh.md').read_text()
refs=json.loads((root/'research/references.json').read_text());result=json.loads((root/'results/study_results.json').read_text())
assert len(refs)==25 and [r['number'] for r in refs]==list(range(1,26))
heads=lambda s:re.findall(r'^#{2,3}\s+(\d+(?:\.\d+)*)[. ]',s,re.M)
assert heads(en)==heads(zh)
assert set(re.findall(r'^## (\d+)\.',en,re.M))=={str(i) for i in range(1,12)}
# Reference blocks must match exactly in both language editions.
er=en.split('## References\n',1)[1];zr=zh.split('## 参考文献\n',1)[1]
assert er==zr
used=set()
for match in re.findall(r'\[([0-9,–—\- ]+)\]',en.split('## References')[0]):
 for item in match.split(','):
  item=item.strip()
  if re.search('[–—-]',item):
   a,b=map(int,re.split('[–—-]',item));used.update(range(a,b+1))
  elif item.isdigit():used.add(int(item))
assert used==set(range(1,26)),used
# Compare every policy/numeric data row, without translating prose.
data_rows=lambda s:[re.sub(r'\s+','',l).replace('／','/') for l in s.splitlines() if re.match(r'^\| (RETRIEVE|LOCAL_FIXITY|PINNED|SCOPED|PROMOTE_ARCHIVE|READ_ONLY) \| \d',l)]
assert data_rows(en)==data_rows(zh)
assert result['E1_policy_evaluations']==1000 and result['E2_policy_evaluations']==216
assert result['E3_enumerated_subsets']==58 and result['unit_tests_passed']==19
assert result['single_byte_mutations_rejected']==580
assert result['external_model_calls']==result['network_calls']==result['human_participants']==result['production_mutations']==0
assert en.count('**Table ')==5 and zh.count('**表')==5
out={'status':'PASS','reference_count':25,'references_used':sorted(used),'language_section_numbers_match':True,'language_numeric_policy_rows_match':True,'shared_bibliography_identical':True,'table_count_per_language':5,'numbered_sections':11,'english_words_before_references':len(re.findall(r"\b[\w’'-]+\b",en.split('## References')[0])),'chinese_characters_before_references':len(re.findall(r'[\u3400-\u9fff]',zh.split('## 参考文献')[0])),'experiment_counts_match':True,'new_doi':'10.5281/zenodo.22809019','claim':'structural/numeric checks, not an independent assessment of arguments or translation adequacy'}
(root/'qa').mkdir(exist_ok=True);(root/'qa/manuscript_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
