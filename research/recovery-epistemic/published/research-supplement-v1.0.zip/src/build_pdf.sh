#!/usr/bin/env bash
# Rebuild PDFs from the corresponding Markdown manuscripts; no network used.
# Requires pandoc, xelatex, the named fonts, and LaTeX packages listed in header.tex.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$ROOT/qa/pdf_build}"
mkdir -p "$OUT/en" "$OUT/zh"
for LANG in en zh; do
  STRETCH=1.08
  [[ "$LANG" == zh ]] && STRETCH=1.15
  pandoc "$ROOT/manuscript/paper_${LANG}.md" --standalone \
    --from markdown+tex_math_dollars --to latex --shift-heading-level-by=-1 \
    -H "$ROOT/manuscript/header.tex" \
    -V mainfont='Liberation Serif' -V sansfont='Liberation Sans' \
    -V monofont='DejaVu Sans Mono' -V CJKmainfont='Noto Serif CJK SC' \
    -V CJKsansfont='Noto Sans CJK SC' -V CJKmonofont='Noto Sans CJK SC' \
    -V fontsize=11pt -V geometry='margin=24mm' -V papersize=a4 \
    -V linestretch="$STRETCH" -V colorlinks=false \
    -o "$OUT/$LANG/paper_${LANG}.tex"
  python3 - "$OUT/$LANG/paper_${LANG}.tex" <<'PYTEX'
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
for name in ('LOCAL_FIXITY','PROMOTE_ARCHIVE','READ_ONLY'):
    s=s.replace(name.replace('_',r'\_'),name.replace('_',r'\_\allowbreak{}'))
# Keep table-only subsection headings with the following caption and rows.
for marker in (r'\subsection{7.3 ', r'\subsection{7.4 '):
    s=s.replace(marker, r'\Needspace{15\baselineskip}'+marker)
# Keep a table's prose caption near its first rows.
s=s.replace(r'\textbf{Table ',r'\Needspace{8\baselineskip}\textbf{Table ')
s=s.replace(r'\textbf{表',r'\Needspace{8\baselineskip}\textbf{表')
p.write_text(s)
PYTEX
  for PASS in 1 2; do
    xelatex -interaction=nonstopmode -halt-on-error \
      -output-directory="$OUT/$LANG" "$OUT/$LANG/paper_${LANG}.tex" \
      > "$OUT/$LANG/compile-${PASS}.txt" 2>&1
  done
done
printf 'Built PDFs in %s\n' "$OUT"
