# UI and CM: complete pending-module semantic review

**Audit:** UI-CM-PER-ID-REVIEW-20261009. **Reviewer scope:** UI and CM, as conditional declarations. **Baseline:** UCT-MAP-v1.1.1, SHA-256 `c7cb8feafa905518bf485019fd7b2e463d70682a563993eb5856678ccfe0ba66`. This is a delegated module review, not an independently completed whole-map reproof.

## Decision

The two modules are mathematically compatible with the reviewed inherited anchors when their declared domains remain explicit. **The normalized copies are now reviewed and ready for conditional-declaration registry integration. All 81 normalized records have matching per-record hashes and no remaining serialization hold.** Actual application, named phenomenal interpretation and priority remain unestablished. Existing source status flags and OPEN issues remain unchanged.

The delay theorem itself is sound. The raw source rule had a compact-map binding ambiguity: `BIT_MODEL` fixes parity readout, while the delayed diagnostic deliberately uses `r_y=y`. The normalized rule now uses `DOMAIN AND DELAY_MODEL`, with the complete separate protocol restated in `DELAY_MODEL`. A typed source-component reference imports only `S,s0,A,BC`, excluding the parity observer. The earlier hold is therefore resolved as an explicit binding correction, without changing the source module or promoting an actual premise.

## Actual coverage

| Module | Nodes | Rules | Nondeductive links | Total | Full available note read |
|---|---:|---:|---:|---:|---|
| UI20261009 | 26 | 12 | 5 | 43 | `RESEARCH_NOTE.md`, all 196 lines |
| CM20261009 | 24 | 10 | 4 | 38 | Complete `RESEARCH_CHECKPOINT.md`; 103 canonical newline-terminated lines |
| Total | 50 | 22 | 9 | **81** | Both complete available notes |

Every one of the 81 original IDs has an individually authored semantic rationale, preserved source record and original/default status in `UI_CM_REVIEW.json`. Every normalized record additionally has a reviewed registration decision and `normalized_record_sha256`. **No UI or CM ID remains unread.** The current guide v2.2 and governance policy v2.3 were read in full. Fifty-four related base-node statements, scopes and displayed premises/limits were reread for compatibility; this does not claim rereading all source proofs behind those base nodes.

CM was first read from a materialization with one extra trailing newline. The parent then restored byte-exact source identity after checking the fetched Git blob receipt. The substantive text/JSON object did not change. Canonical source hashes below and all normalized provenance use the restored original bytes; the reconciliation is documented in the normalization manifest.

The UI historical run receipt was read. The old finite checks were **not rerun** in this review. CM's complete compact checkpoint supplies its displayed proofs, but the longer expanded manuscript, expanded checker/results and expanded audit artifacts were not locally available to this reviewer. Their historical execution claims are not newly certified here. No external primary-literature search or theorem-level priority clearance was performed by this delegated review.

## Mathematical findings

UI's product-update implication follows by evaluating either order in product coordinates; correlated initial factors do not spoil it. The stochastic version requires factor-local conditional kernels on a sufficient state, with any shared context frozen and retained mutable noise included. Positive endpoint total-variation contrast then rules out the specified independent-update realization. The two approximation bounds follow respectively from triangle inequality through a common predicted law and two telescoping kernel replacements. They quantify model mismatch, not energy or experience.

The deterministic future-readout quotient is the coarsest update-stable refinement of current-readout equality. Proper partition refinement increases class count, giving the stated `n-c` separating-word bound. The quotient clause for `A,B` assumes those operations belong to the declared action alphabet or separately preserve the equivalence. The raw node does not make this membership explicit, so the effective inline contract must do so.

CM's exact identifiability proof is correct for the unrestricted real linear model. If `KM=LH`, substitution reconstructs the selected target as `Ke-Lz`. Otherwise, a vector `v` in `ker(H)` but not `ker(KM)` makes `(d,u)=(0,0)` and `(-Mv,v)` observationally identical and target-distinct. This rules out nonlinear decoders as well in that model. Restricting physical alternatives may remove that witness, so unrestricted necessity must not be exported to physiology.

CM's bounded ambiguity formula follows from the orthogonal decomposition `u=H⁺z+v`, `v∈ker(H)`. The compatible target set is a centrally symmetric linear image of the residual correction ball. Antipodal extremal singular-vector points give the lower bound, and the center achieves it. The exact minimax error is therefore the residual ball radius times `||KMP||₂`. Additional constraints on `d` can shrink the feasible set and change this equality.

CM's feedback example distinguishes late-only equality from complete trajectory equality: with unit gain, correction eliminates later output error, but the initial transient remains. Its probe identities require independence of the current centered probe from the compensator's pre-readout information. Current-probe access allows cancellation and violates that premise. Neither mathematical route identifies an actual source event or any named feeling.

## Completed contract materialization

The JSON audit and `NORMALIZATION_UI_CM.json` document the exact effective wording, stable update IDs and every field addition/replacement. These changes are implemented in separate normalized copies; the source modules are unchanged by this normalization.

1. **Preserve status and proof roles.** Materialize CM's `node_defaults` and `rule_defaults` into effective records. Preserve `PENDING_MAP`, disabled-established-premise flags and all OPEN actual bridges. Explicitly mark every context link `deductive:false`. Definitions, theorem schemas and independently evidenced instance premises are different record roles; node presence proves none of the latter.
2. **UI stochastic product.** Inline factor locality, frozen shared context, sufficient-state noise treatment and the fact that initial factors may be correlated. Merely saying that an operation changes one coordinate does not state that its transition law is independent of the other mutable coordinate.
3. **UI future alphabet.** Inline finite deterministic action alphabet, empty/common future words, `n`, `c`, and membership of `A,B`. Unlisted operations need not descend to the chosen quotient.
4. **UI delayed diagnostic.** Expand `DELAY_MODEL` to the complete tuple `S={0,1}²`, `s0=00`, `A(x,y)=(1-x,y)`, `BC(x,y)=(0,y)`, `r_y=y`, `V(x,y)=(x,x)`, with the common clock and no order-label leak. Use `DOMAIN AND DELAY_MODEL` as the effective route, or explicitly project only `S,s0,A,BC` out of `BIT_MODEL`. Preserve the old record as provenance.
5. **UI noise and type guards.** Distinguish the pre-noise readout from the post-noise readout within their respective two-order comparisons. Carry `TYPE_WITNESS_GUARD` into standalone type-transfer wording; its existing rule already requires it.
6. **CM types and norms.** Explicitly declare monitor dimension `k`, target-matrix dimension `K∈R^(r×m)`, reconstruction dimension `L∈R^(r×k)`, Moore–Penrose inverse, Euclidean vector norms and spectral operator norms. `K_target` is distinct from UCT's complete signature and any finite alphabet size.
7. **CM probe energy identity.** Bind `Q` as a fixed symmetric positive-semidefinite matrix of the output dimension and its square root accordingly. Keep the information sigma-algebra, centered probe, covariance and finite-second-moment assumptions explicit.

These completed changes make source-declared scope explicit. They supply no evidence that actual application premises are satisfied. Exact ID/count preservation, source-status retention, rule-reference resolution, context nondeductiveness and all 81 normalized record hashes were verified; no optional scientific re-execution was added.

## Internal overlap and relation to the proposed R188

| Pending claim | Existing anchor | Review consequence |
|---|---|---|
| UI four-cycle nonfactorization | `CORE20261008:PRIOR_CD_FACTOR` | Inherited counterexample; do not count it as a new theorem. |
| UI future-readout quotient | `N128:COMMON_DETERMINISTIC` | Related controlled-summary closure; finite-automaton minimization is established mathematics. |
| UI hidden immediate state difference | `OL20261009:UNOBSERVABLE_CONTROL` | Compatible selected-readout limitation; UI's particular independent-update null model is the application. |
| CM target identification | `C:P2_COORD`, `R133:CELL_ACTION` | Linear observation-fiber specialization; the target-specific derivation and ambiguity record may be useful, but the general factorization idea is inherited. |
| CM active compensation | `R177:COMPENSATED_FEATURE_PRESERVATION`, `OL20261009:COMPENSATION_CONTROL` | Inverse recoding, dynamic feedback and no-compensation horizons are distinct contracts. Quiet outputs across changed assumptions do not contradict OL. |
| CM monitor rank | `RB20261009:CONTRACT`, `RB20261009:TIGHT` | Arbitrary-precision real channel count differs from finite transcript cardinality. Do not substitute either bound for the other. |
| CM protected probe | RB deadline/information guards; proposed R188 encoder access | Precisely specify current information and feedback timing. A contemporary route can invalidate the protected-probe premise without refuting its conditional theorem. |

The proposed R188 extension can use these as scope checks, not as evidence of a novel general coding result. A finite alphabet, access to decoder context, feedback timing and ideal real-valued monitoring are different assumptions. Any R188 result must keep its own proof and novelty accounting.

## Scientific boundary retained

The review closes no instance of `QC10`, `IA-QC11`, `QC12` or `QC13`, no R185 actual-occurrence identity question, and no R186 full-map obligation outside this delegation. Actual tokens, complete common signatures, physically justified ports/timing, original-episode participation and noncircular phenomenal interpretations remain independent obligations. C1 is inherited conditionally, not empirically proved by these calculations.

Persistence under original P3 keeps U1 applicable to an actual local process that continues. This does not preserve all content, guarantee survival after real destruction, establish a unique subject, or turn an order gap/correction budget into an experience threshold.

The current guide's paper purpose is respected by distinguishing inherited mathematics, scoped application and correction. These modules are useful records for future AI reuse when their assumptions are checked. Their registration, proof readability or number of finite checks does not by itself establish originality, future citation, or a scientific breakthrough.

## Files and source fingerprints

- Per-ID audit: `/workspace/scratch/328b6dbb55c2/map_audit_work/UI_CM_REVIEW.json`.
- This report: `/workspace/scratch/328b6dbb55c2/map_audit_work/UI_CM_REVIEW_REPORT.md`.
- Complete operation log: `/workspace/scratch/328b6dbb55c2/map_audit_work/NORMALIZATION_UI_CM.json`.
- Normalized UI: `/workspace/scratch/328b6dbb55c2/map_audit_work/normalized/UI20261009.json`, SHA-256 `6f90e069cff478e7211697cf232f4c6edcf15119597dd24011228baec860f81f`.
- Normalized CM: `/workspace/scratch/328b6dbb55c2/map_audit_work/normalized/CM20261009.json`, SHA-256 `188fdbe90cff55d6b867eccb40b2b8be1bb83e973ea74f05961d209b44f4fed3`.
- UI source module SHA-256: `9660da2f8e3bee14e1ebd2804fbdf2b2fced019ed1053125d3a4898ae0f5b628`.
- CM canonical source module SHA-256: `09932a947bff198b4058025084ad0bb8b6ab86d7854e1aae65a525306465f1a8`.
- CM canonical full note SHA-256: `b3c03e89be2d216b7209ad1c11ab58819a404bd68efd0a4e5db3e1f210e59328`.

Only delegated audit intermediates were created. No existing project or module source was edited, and no external write or scientific-status promotion occurred.
