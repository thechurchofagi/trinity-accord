import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/328b6dbb55c2')
OUT = ROOT / 'map_audit_work'
PROJECT = ROOT / 'uct/research/uct-agent-consciousness-workspace'
FILES = {
    'UI20261009': ROOT / 'effective_v111/pending_UI/MAP_EXTENSION.json',
    'CM20261009': PROJECT / 'records/CM20261009_Compensation_Observability/MAP_EXTENSION.json',
}
NOTES = {
    'UI20261009': ROOT / 'effective_v111/pending_UI/RESEARCH_NOTE.md',
    'CM20261009': PROJECT / 'records/CM20261009_Compensation_Observability/RESEARCH_CHECKPOINT.md',
}

# These are individually authored semantic findings, not inferred PASS labels.
UI_NODES = {
 'DOMAIN': 'The two order protocols share preparation, sufficient state, clock, installed actions and passive readout. This rules out preparation drift and direct order-label leakage; it does not establish that a biological or deployed model obeys the contract.',
 'PRODUCT': 'Disjoint deterministic factor maps commute even with correlated initial coordinates. For the stochastic clause, the complete note additionally requires factor-local conditional kernels and frozen context; these clauses must be carried into the effective inline contract.',
 'COMMUTATION': 'The proof sends both orders to (F(a),G(b)), or to the same product of conditional factor kernels. It is a theorem schema PRODUCT=>AB=BA, not evidence that a nominated actual pair commutes; the converse is explicitly false.',
 'ORDER_GAP': 'Total variation compares the same two endpoint laws and lies in [0,1]. Left-to-right row-kernel composition is consistent with the displayed bit table; the number is an operational diagnostic, not an experiential magnitude.',
 'OBSTRUCTION': 'Positive Delta contradicts the common-endpoint consequence of any admitted independent realization. Its useful conclusion is conditional on independently justified Delta>0 and the common protocol; it neither identifies one carrier nor distinguishes coordination from shared storage.',
 'BIT_MODEL': 'The paired devices agree on S, initial 00, A and parity readout while BC and BD are explicitly different installed maps. Their baseline-only single-probe agreement cannot be generalized to all preparations; the paired models are alternatives, not one conjunction of incompatible B maps.',
 'BIT_WITNESS': 'Direct substitution gives initial 0, A-only 1 and B-only 0 in both devices, then 0/1 for the two BC orders and 1/1 for BD. This is an exact finite construction with no physical instantiation or named-feeling inference.',
 'RECODING': 'Simultaneously conjugating both maps and transporting preparation/readout preserves the complete two-protocol law. Changing only one operation or the noise/readout is a different comparison, so passive coordinate freedom cannot manufacture or remove the contrast.',
 'APPROX_PRED': 'The comparison model must predict one common law Q for both orders even if it has a larger hidden space. Merely being described verbally as independent does not supply this equality when clocks, mutable background or order-aware readouts differ.',
 'PRED_BOUND': 'Triangle inequality through Q gives eAB+eBA>=Delta, hence the max bound. The fair-output midpoint demonstrates sharpness only for the two endpoint point masses, not simultaneous fitting of all earlier probes or every constrained model class.',
 'KERNEL_APPROX': 'Uniform row-TV error uses a common aligned sufficient state space and commuting A0,B0. An unidentified coarse state or omitted retained noise would invalidate the uniform-kernel premise; it cannot be supplied by endpoint agreement alone.',
 'KERNEL_BOUND': 'Replace two kernels sequentially in each order and contract TV through later kernels/readout; each route costs epsilonA+epsilonB. The two routes give the displayed factor 2, without claiming a generally optimal constant or a coupling-energy interpretation.',
 'NOISE_MODEL': 'The mixture uses a fresh route draw and the same independent output-flip channel in both orders, with alpha,eta in [0,1]. A model probability of routing is distinct from evidence of a particular actual occurrence.',
 'NOISE_RESULT': 'The BC route suppresses the A-first parity outcome with probability alpha, giving Delta=alpha; the fixed binary-flip channel multiplies the difference by abs(1-2eta). Eta=1/2 destroys this observation while preserving possible hidden dependence.',
 'FUTURE_DOMAIN': 'The full note fixes a finite alphabet of deterministic total updates and all common future words. For the quotient statement about A and B, the effective contract must explicitly say A and B belong to that alphabet (or independently preserve the resulting equivalence).',
 'FUTURE_EQ': 'Equality of every future readout is an equivalence because it is the intersection of equal-output relations over fixed words, including the empty word. It remains relative to the chosen actions/readout and cannot be read as full experiential equivalence.',
 'FUTURE_QUOTIENT': 'Prefixing an allowed action preserves future equality, so each allowed action descends and the coarsest stable refinement proof is sound. The A/B commutation iff clause requires A,B among those allowed actions; no stochastic-bisimulation extension follows.',
 'FINITE_WITNESS': 'Starting with c readout classes, each proper refinement increases class count, so the partition stabilizes within n-c rounds. A first separation in round k gives a word of length at most k. This assumes complete finite actions/state, not a bound on human latency or discovery effort.',
 'DELAY_MODEL': 'The note defines a separate diagnostic with state/update tuple S={0,1}^2,s0=00,A(x,y)=(1-x,y),BC(x,y)=(0,y), readout r_y=y and V(x,y)=(x,x). Importing only the state/update components from BIT_MODEL must be explicit; the parity readout is not retained as the scored observer.',
 'DELAY_WITNESS': 'A then BC ends at 00 and BC then A at 10; r_y initially reads 0 for both, then the common V makes outputs 0/1. The retained difference is an internal state difference, not an order label supplied to a formatter. Rule binding needs the separate diagnostic contract.',
 'LIMITS': 'The order-four permutation cannot act only on a binary factor; same-carrier toggles commute; order leakage can fabricate contrast; coordinating copies can reproduce an operation algebra. The four-cycle nonfactorization is inherited in CORE20261008:PRIOR_CD_FACTOR; no unique-subject or theory-exclusive conclusion is licensed.',
 'REALIZATION': 'This is an unfulfilled actual-application bridge: actual tokens, complete common K and physically installed operations/ports/timing/noise/provenance must be independently grounded. Finite-model correctness or hypothetical intervention sensitivity does not discharge it.',
 'TYPE_WITNESS_GUARD': 'The pair binding correctly assigns commuting operations to one admitted organization and positive contrast to the other. They are properties of different members of one explicit comparison, not contradictory facts about a single token; actual evidence remains open.',
 'TYPE_TRANSFER': 'A complete K-isomorphism would preserve the grounded operator invariant; its difference excludes physical K-isomorphism, and inherited A:C1_OI conditionally transfers this to complete experiential type. TYPE_WITNESS_GUARD must be visible when this node is used alone; no named quality, intensity or capability follows.',
 'PERSIST_GUARD': 'Continuing constitutive support and lineage under original P3 is an independent actual premise. Changed update role need not be termination, but persistence also does not mean unchanged full type or survival of an actually destroyed process.',
 'PERSISTENCE': 'For an independently admitted persisting local token, U1 continues to yield a nonempty experiential carrier. Success, commutation and contrast magnitude add no basal-experience gate and do not prove physical persistence themselves.',
}

UI_RULES = {
 'r_commute': 'Both premises describe one product-coordinate state/update contract; the mathematical schema proves commutation. The stochastic/frozen-context expansion of PRODUCT must be materialized, and declaration presence must not establish an actual product instance.',
 'r_obstruct': 'COMMUTATION is used as the universally quantified implication from PRODUCT, not as an asserted equality of the very instance with Delta>0. The conclusion is the conditional obstruction schema; invoking it for data additionally requires a justified positive order gap.',
 'r_bit': 'DOMAIN fixes the protocol and BIT_MODEL explicitly supplies a paired finite-model alternative with differing B. Direct evaluation proves the table under baseline 00; no all-preparation or empirical conclusion is inherited.',
 'r_recode': 'Conjugation is a theorem over any declared bijection transporting the whole DOMAIN and ORDER_GAP tuple. The rule does not claim that an actual rewiring was merely a coordinate change.',
 'r_pred': 'The shared observation laws and common Q are from the same comparison, so triangle inequality applies. Error bounds from separate or unmatched protocols cannot be spliced into this route.',
 'r_kernel': 'DOMAIN, ORDER_GAP and uniform KERNEL_APPROX refer to the same state alignment, preparation and readout. Commuting A0,B0 provides the zero middle distance after two replacement bounds.',
 'r_noise': 'The bit maps and preparation are reused with one declared mixture and flip readout. Distinguish pre-noise Delta from post-noise Delta_observed rather than assigning two values to one readout law; the complete note makes that distinction.',
 'r_quotient': 'FUTURE_DOMAIN and FUTURE_EQ support the stable equivalence proof. Explicitly bind A,B to the finite action alphabet before applying the final quotient-commutation clause.',
 'r_finite': 'The deterministic full-state refinement proof derives the finite word bound; n and c refer to the same state set and initial readout partition. It gives a model-theoretic existence bound, not a search or neural timing guarantee.',
 'r_delay': 'The raw AND route imports full BIT_MODEL with parity readout and DELAY_MODEL with a different scored readout while declaring same_instance_required. The note proves a separate diagnostic. Hold automatic instantiation until DELAY_MODEL is expanded and the rule imports only its explicit protocol, or a typed projection imports only S,s0,A,BC from BIT_MODEL.',
 'r_type': 'REALIZATION and TYPE_WITNESS_GUARD independently ground the paired complete-K comparison. OBSTRUCTION and RECODING are mathematical proof schemas, not evidence for actual realization. With A:C1_OI the resulting nonisomorphism gives only complete experiential structural-type difference.',
 'r_persist': 'A:ACTUAL_TOKEN and PERSIST_GUARD bind the same actual local process and interval; U1 then continues to apply. The guard imports the original P3 criterion, and its truth remains independent of task success or the map entry.',
}

UI_CONTEXT = {
 'ctx_scope': 'A:K limits ontic inference to a complete common signature; this contextual link does not equate the finite UI model signature with complete organization.',
 'ctx_view': 'A:VIEW correctly identifies the chosen future action/readout menu as a selected view. It supplies no deductive route from behavioral equivalence to experiential identity.',
 'ctx_closure': 'N128:COMMON_DETERMINISTIC supplies related controlled-summary closure on the same sufficient state, but not a physical realization or originality proof for the standard future quotient.',
 'ctx_noscale': 'C:P3 blocks interpreting alpha or a TV contrast as a general experience ranking. The link is a limitation/analogy, not a numerical conversion law.',
 'ctx_capability': 'C:FIXED_J requires true invariant capability under a full common task/policy/resource contract. An observed order contrast is not by itself an intelligence difference.',
}

CM_NODES = {
 'VOCAB': 'The fixed finite real linear coordinates distinguish target matrix K from the UCT constitutive signature. For standalone machine use explicitly declare k and K in R^(r*m), L in R^(r*k), and the vector Euclidean/matrix spectral norms; this is type completion, not a new theorem.',
 'EXACT_MODEL': 'e=d+Mu,z=Hu is a fixed linear model with complete admitted correction inputs. Algebra alone defines a residual; interpreting d as a correction-clamped causal effect additionally needs the stated independent modular/clamp evidence and apparatus boundary.',
 'UNRESTRICTED': 'The necessity and lower-bound witnesses require every real (d,u) pair, not a physiological feasible subset. Keeping this as a domain premise preserves sufficiency of reconstruction even when physical restrictions invalidate necessity.',
 'IDENTIFICATION': 'If KM=LH, substitution gives Kd=Ke-Lz. Otherwise v in ker(H) with KMv!=0 produces (0,0) and (-Mv,v) with equal observations and unequal target; this proves impossibility for any decoder, including nonlinear ones, in the unrestricted class.',
 'FREE_MONITOR': 'Arbitrary ideal real-valued linear monitor design and noiseless real precision are explicit comparison assumptions. They neither establish physical installability nor count finite transcript symbols, bits, tissue regions or energy.',
 'CHANNEL_BOUND': 'Identification forces row(KM) subset row(H), hence rank(H)>=rank(KM); a row basis attains it with an ideal monitor. The count is independent real channels under unrestricted d,u, not the finite alphabet budget of RB/R188.',
 'SUMDIFF_SETUP': 'The two scalar-output monitor designs have the same one-dimensional output but observe different correction combinations. The concrete alternative d=1,u=(-1/2,-1/2) is admitted by the unrestricted exact model.',
 'SUMDIFF': 'Hplus observes u1+u2 and reconstructs d=e-z; Hminus annihilates the equally split correction while e=0, so it cannot distinguish the two targets. Equal observation dimension alone does not imply target sufficiency.',
 'BOUNDED_SETUP': 'The Euclidean correction ball is a genuine fixed model constraint, while d remains unrestricted. Feasible z must lie in im(H) and its least-norm preimage must fit rho; passive recoding must transport the physical budget ellipsoid.',
 'MINIMAX_RADIUS': 'Every compatible correction is H^+z+v with v in ker(H); orthogonality leaves radius s. The target set is a centrally symmetric linear image, so antipodal maximal singular-vector points force minimax radius s||KMP||, attained at the center. Constraints on d could shrink this set and invalidate equality.',
 'FEEDBACK_SETUP': 'The scalar constant disturbance is observed before the next correction update; u0=0 and 0<alpha<=1 fix a causal loop with no omitted input. There is no instantaneous access to future error in this witness.',
 'CAUSAL_MASK': 'Induction gives the two geometric formulas. Alpha=1 makes every t>=1 output zero but leaves a correction trace; t=0 still identifies the disturbance, so late-only agreement must not be reported as full trajectory equivalence.',
 'BUDGET_OBSERVATION': 'Outcome/correction bounds use declared Euclidean units in the exact model. A correction magnitude is not an experience measure or a thermodynamic quantity by notation alone.',
 'BUDGET_GUARD': 'Triangle inequality gives ||d||<=epsilon+||M||rho. In the scalar unit-gain case minimizing |d+u| over |u|<=rho yields max(0,|d|-rho); quiet output without a justified correction bound supplies no comparable finite guarantee.',
 'APPROXIMATE_MODEL': 'The model explicitly includes a bounded remainder and measurement errors with fixed KM=LH. These are deterministic bounds needing calibration; no distribution or independence assumption is required for the subsequent inequality.',
 'ROBUST_RECONSTRUCTION': 'Substitution leaves K times outcome noise/model remainder minus L times monitor noise. Operator-norm triangle bounds give the displayed error; unmodeled correction inputs or changing matrices would require new terms rather than being absorbed without a bound.',
 'PROBE_SETUP': 'The pre-readout information must be independent of a centered current probe; b is measurable from that information and has finite second moment. Independence is a physical timing/access premise, not a conclusion from random-looking samples.',
 'PROBE_IDENTIFICATION': 'Independence and E[xi]=0 remove E[b xi^T] and the quadratic cross term. Bind Q as a fixed symmetric positive-semidefinite matrix of the output dimension; the equations are population identities and give no finite-sample significance by themselves.',
 'PROBE_COUNTERCONTROL': 'Allowing b=-Gxi uses current-probe information and annihilates the outcome, explicitly violating the protected-information premise. It is a boundary counterexample, not evidence against the conditional moment identities.',
 'ACTUAL_BRIDGE': 'Actual P,Q, full common signature, correction-baseline comparison, timing, ports and calibrated decomposition are open independent obligations. A finite correction matrix or successful simulation is not complete actual organization.',
 'NONISOMORPHISM': 'An independently established difference must concern a feature preserved by every complete structural isomorphism of that same actual comparison. An analyst-selected score or label cannot discharge this premise.',
 'TYPE_CONSEQUENCE': 'Under both open actual guards, invariant reduct nonisomorphism excludes full structural isomorphism and inherited A:C1_OI gives complete experiential-type difference. Neither equation (1) alone nor a changed correction trace predicts named quality, magnitude or subject count.',
 'PERSISTENCE': 'This open premise requires continuing constitutive support and lineage of the nominated local actual process under P3. Embedding or a saved variable name supplies neither persistence nor cessation evidence.',
 'NONERASURE': 'When the same local actual token persists, U1 continues to imply nonempty experience independently of compensation success or monitor adequacy. It does not imply unchanged content or survival after actual destructive removal.',
}

CM_RULES = {
 'r_ident': 'VOCAB, EXACT_MODEL and UNRESTRICTED jointly fix the real spaces and observation map. The nullspace witness and factorization proof establish an iff only in that class; no node declaration makes it a physical instance.',
 'r_channels': 'With the same fixed KM and unrestricted disturbances, IDENTIFICATION supplies row containment; FREE_MONITOR permits a row-basis design. Physical monitor feasibility and finite precision remain outside this rule.',
 'r_sumdiff': 'EXACT_MODEL and SUMDIFF_SETUP bind one explicit finite-dimensional comparison. Substitution verifies both identical observations under Hminus and exact reconstruction under Hplus; the monitors are alternative designs.',
 'r_radius': 'BOUNDED_SETUP deliberately replaces unrestricted correction space by a ball while leaving d unrestricted. EXACT_MODEL fixes the observation fiber; orthogonal decomposition and central symmetry prove the exact conditional minimax radius.',
 'r_causal': 'The scalar FEEDBACK_SETUP contains the full recurrence, initial condition and read-before-update order. Induction proves masking only after the initial transient; the route does not infer full-history equality.',
 'r_budget': 'The exact equation and calibrated correction/outcome norms combine by triangle inequality. The scalar minimum is over all bounded scalar corrections; no time-feasible or energy-optimal controller is asserted.',
 'r_robust': 'The single APPROXIMATE_MODEL already includes the fixed row factorization and all bounded errors, so VOCAB suffices for the operator-norm estimate. No statistical independence or exact causal interpretation is derived.',
 'r_probe': 'PROBE_SETUP supplies the same information boundary and fixed G for both population identities. Explicit Q dimensions and PSD meaning should be materialized; a contemporary probe path would invalidate the premise.',
 'r_type': 'Both actual premises and A:C1_OI must hold in the same complete-signature comparison. Registering the conditional rule does not discharge ACTUAL_BRIDGE or NONISOMORPHISM and leaves all named phenomenal interpretations open.',
 'r_persist': 'PERSISTENCE, P3 and U1 refer to the same local actual occurrence and interval. The rule preserves basal nonempty experience only while the constitutive process actually continues, without equating persistence and unchanged content.',
}

CM_CONTEXT = {
 'ctx_fiber': 'C:P2_COORD is the general fiber-constancy/factorization antecedent. CM specializes it to the observation map (d,u)->(d+Mu,Hu); the analogy is inherited and nondeductive unless its full linear-domain proof is used.',
 'ctx_recoding': 'R177 inverse-compensated recoding and CM active feedback masking are distinct mechanisms with different contracts. The link supports comparison and overlap attribution, not a proof that either is physically installed.',
 'ctx_fixedJ': 'A changed realized correction trace is not automatically a change in true capability J. C:FIXED_J keeps policy/resources/timing fixed before any capability-to-type inference.',
 'ctx_richness': 'C:P3 prevents a general scalar experience interpretation of correction budget or outcome quietness. This link supplies a boundary, not a quantitative experiential law.',
}

OPEN_IDS = {
 'UI20261009:REALIZATION', 'UI20261009:TYPE_WITNESS_GUARD', 'UI20261009:PERSIST_GUARD',
 'CM20261009:ACTUAL_BRIDGE', 'CM20261009:NONISOMORPHISM', 'CM20261009:PERSISTENCE',
}
REQUIRED = {
 'UI20261009:PRODUCT': ['UI-C1'],
 'UI20261009:COMMUTATION': ['UI-C1', 'GLOBAL-C2'],
 'UI20261009:FUTURE_DOMAIN': ['UI-C2'],
 'UI20261009:FUTURE_QUOTIENT': ['UI-C2'],
 'UI20261009:DELAY_MODEL': ['UI-C3'],
 'UI20261009:DELAY_WITNESS': ['UI-C3'],
 'UI20261009:TYPE_TRANSFER': ['UI-C4'],
 'UI20261009:r_commute': ['UI-C1', 'GLOBAL-C2'],
 'UI20261009:r_obstruct': ['GLOBAL-C2'],
 'UI20261009:r_noise': ['UI-C5'],
 'UI20261009:r_quotient': ['UI-C2'],
 'UI20261009:r_delay': ['UI-C3'],
 'UI20261009:r_type': ['UI-C4', 'GLOBAL-C2'],
 'CM20261009:VOCAB': ['CM-C1'],
 'CM20261009:PROBE_IDENTIFICATION': ['CM-C2'],
 'CM20261009:r_probe': ['CM-C2'],
}

CONTRACT_UPDATES = [
 {'id':'GLOBAL-C1','required_before':'effective registry serialization',
  'action':'Preserve original source bytes, PENDING_MAP flags, actual_application=NOT_ESTABLISHED and all OPEN. A new registry may register conditional declarations but must not rewrite source-era audit/readiness claims as scientific truth. Materialize CM node_defaults/rule_defaults into each effective record; mark all nine context links deductive:false.',
  'reason':'The effective consumer must not drop status/scope/proof_source/same-instance constraints because they were factored into module defaults.'},
 {'id':'GLOBAL-C2','required_before':'rule instantiation',
  'action':'Distinguish definition declarations, theorem schemas and independently evidenced instance assumptions. Schema presence is not premise truth; a conditional theorem used as a proof dependency is not an assertion that its hypothesis holds for the evaluated token.',
  'reason':'In particular UI COMMUTATION means PRODUCT=>AB=BA; r_obstruct may use this implication without asserting AB=BA for the contrasting model.'},
 {'id':'UI-C1','required_before':'stochastic r_commute use',
  'action':'Expand PRODUCT to a state bijection with frozen e and factor-local maps A(a,b,e)=(F_e(a),b,e), B(a,b,e)=(a,G_e(b),e); in the stochastic case use conditional Markov kernels on the assigned factor, with neither action changing e or omitting mutable retained noise. Initial coordinates may be correlated.',
  'reason':'The node alone says only that each map updates a factor; the complete note supplies locality of kernel dependence, sufficient state and stochastic independence conditions.'},
 {'id':'UI-C2','required_before':'quotient A/B commutation use',
  'action':'Expand FUTURE_DOMAIN: finite nonempty sufficient S, finite alphabet U of deterministic total F_u, fixed r, all finite common words including empty, and A,B are among the admitted F_u (or separately prove they preserve FUTURE_EQ). Define n=|S| and c=|r(S)|.',
  'reason':'Arbitrary external A,B need not descend to the quotient defined by the allowed action alphabet.'},
 {'id':'UI-C3','required_before':'automatic r_delay instantiation',
  'action':'Expand DELAY_MODEL to the full tuple S={0,1}^2,s0=(0,0),A(x,y)=(1-x,y),BC(x,y)=(0,y),r_y(x,y)=y,V(x,y)=(x,x), common two-order preparation/clock/readout and no order leak. Normalize r_delay all_of to [UI20261009:DOMAIN,UI20261009:DELAY_MODEL], retaining BIT_MODEL only as a nondeductive source/proof-component reference; alternatively supply an explicit typed projection importing only S,s0,A,BC.',
  'reason':'BIT_MODEL includes parity readout, whereas the delayed diagnostic intentionally uses r_y. The theorem is sound, but the raw whole-node AND lacks the projection needed for unambiguous same-instance binding.',
  'source_mutation_authorized_by_this_review':False},
 {'id':'UI-C4','required_before':'standalone TYPE_TRANSFER use',
  'action':'Restate TYPE_TRANSFER with REALIZATION AND TYPE_WITNESS_GUARD AND common complete A:K AND A:C1_OI. Require one commuting member and one positive-contrast member of the explicitly paired actual comparison, with fully transported operator structure.',
  'reason':'The active r_type already carries the extra guard; the standalone node wording should not let later readers omit it.'},
 {'id':'UI-C5','required_before':'noise-rule instance binding',
  'action':'Name R0 as the parity readout and R_eta as the common independent flip channel composed with R0. Delta_internal uses R0; Delta_observed uses R_eta. Transport one fixed observer within each two-order comparison.',
  'reason':'Pre-noise and post-noise contrasts are different declared observation instances, not contradictory values of one ORDER_GAP.'},
 {'id':'CM-C1','required_before':'standalone machine-typed use',
  'action':'Declare finite m,p,r,k; M in R^(m*p),H in R^(k*p),K in R^(r*m),L in R^(r*k). Vector norms are Euclidean, matrix norms spectral, H^+ is Moore-Penrose. K_target is distinct from K_UCT and any finite-alphabet K in RB/R188.',
  'reason':'Types/norms are recoverable from the complete checkpoint but partly implicit in the compact VOCAB node.'},
 {'id':'CM-C2','required_before':'probe energy-identity use',
  'action':'Bind xi in R^a,e,b in R^m,G in R^(m*a),Sigma=E[xi xi^T] positive definite, Q a fixed symmetric PSD m-by-m matrix and Q^.5 its PSD square root. State E[xi]=0, xi independent of the compensator pre-readout sigma-algebra, b measurable there, with finite second moments.',
  'reason':'These mathematical types and the access/timing hypothesis make the population identities explicit; no empirical independence or sample significance is supplied.'},
]

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

items=[]
module_results=[]
for module, maps in [('UI20261009',(UI_NODES,UI_RULES,UI_CONTEXT)),('CM20261009',(CM_NODES,CM_RULES,CM_CONTEXT))]:
    path=FILES[module]
    data=json.loads(path.read_text())
    all_reviewed=[]
    for collection, reasons in zip(['nodes','rules','context_links'],maps):
        actual={record['id'].split(':',1)[1] for record in data[collection]}
        assert actual==set(reasons), (module,collection,actual^set(reasons))
        for record in data[collection]:
            id_=record['id'];suffix=id_.split(':',1)[1]
            default_key='node_defaults' if collection=='nodes' else 'rule_defaults' if collection=='rules' else None
            defaults=data.get(default_key,{}) if default_key else {}
            verdict=('ADMIT_OPEN_PREMISE_DECLARATION_ONLY' if id_ in OPEN_IDS else 'ADMIT_CONDITIONAL_DECLARATION_ONLY')
            if id_=='UI20261009:r_delay':
                verdict='HOLD_AUTOMATIC_INSTANTIATION_PENDING_EXPLICIT_PROTOCOL_BINDING'
            elif id_ in REQUIRED:
                verdict='ADMIT_CONDITIONAL_DECLARATION_WITH_REQUIRED_INLINE_CONTRACT'
            if collection=='context_links':
                verdict='ADMIT_NONDEDUCTIVE_CONTEXT_ONLY'
            items.append({
                'id':id_,'module':module,'record_type':collection[:-1],
                'source_path':str(path),'source_file_sha256':sha(path),
                'source_record':record,'inherited_defaults':defaults,
                'effective_record_before_any_new_correction':{**defaults,**record},
                'semantic_read_completed':True,'complete_note_read':True,
                'proof_review':'MANUAL_SCOPED_ARGUMENT_CHECK; HISTORICAL_FINITE_RUNS_NOT_REEXECUTED',
                'review_verdict':verdict,'rationale':reasons[suffix],
                'required_contract_updates':['GLOBAL-C1','GLOBAL-C2']+REQUIRED.get(id_,[]),
                'established_physical_premise':False,'empirical_or_phenomenal_promotion':False,
                'independent_priority_clearance':False,
            })
            all_reviewed.append(id_)
    module_results.append({
        'module':module,'source_file':str(path),'source_sha256':sha(path),
        'full_note':str(NOTES[module]),'full_note_sha256':sha(NOTES[module]),
        'counts':{c:len(data[c]) for c in ['nodes','rules','context_links']},
        'reviewed_ids':all_reviewed,'unreviewed_ids':[],
        'registration_verdict':'CONDITIONAL_DECLARATION_REGISTRY_ADMISSION_WITH_EXPLICIT_CONTRACT_NORMALIZATION',
        'automatic_instantiation_hold_ids':['UI20261009:r_delay'] if module=='UI20261009' else [],
        'scientific_status_preserved':'PENDING_MAP / ACTUAL_APPLICATION_NOT_ESTABLISHED; no OPEN bridge discharged',
        'source_note_limits':('Full 196-line RESEARCH_NOTE read; original historical finite-run receipt read, not rerun.' if module=='UI20261009' else 'Full 104-line compact remote RESEARCH_CHECKPOINT read; expanded longer manuscript and expanded run artifacts are not locally available to this reviewer.'),
    })

related_ids=[
 'A:ACTUAL_TOKEN','A:P3','A:K','A:VIEW','A:C1_OI','A:U1','C:FIXED_J','C:P2_COORD','C:P3',
 'N128:COMMON_DETERMINISTIC','R177:EXECUTED_FEATURE_DOMAIN','R177:COMPENSATED_FEATURE_PRESERVATION',
 'R177:JOINT_SOURCE_FEATURE_DOMAIN','R177:SOURCE_FEATURE_SEPARATION',
 'R133:CELL_ACTION','R133:ENCODER','R133:AVOIDANCE_MODEL','R136:STATIC_SETUP','R136:DELAY_GAP','R136:TASK_ORDER',
 'R137:CONTROL_MODEL','R137:LOCAL_LP','R137:APPROX_INTERFACE','R137:OBSTRUCTION','R137:SEED_MODEL',
 'CORE20261008:TARGET_LEVELS','CORE20261008:CONTRACT','CORE20261008:ACTUAL_BRIDGE',
 'CORE20261008:PERSISTING_INSTANCE','CORE20261008:LOCAL_COPRESENCE','CORE20261008:PRIOR_CG_R',
 'CORE20261008:PRIOR_CG_ANF','CORE20261008:PRIOR_CD_FACTOR',
 'RB20261009:CONTRACT','RB20261009:TIGHT','RB20261009:CERTIFIED_SUCCESS','RB20261009:UNIFORM_RESIDUAL',
 'RB20261009:DEADLINE_BOUND','RB20261009:KEY_MODEL','RB20261009:KEY_CURVE','RB20261009:DELAY_SETUP',
 'RB20261009:DELAY_WITNESS','RB20261009:TIMING_CONTROL',
 'OL20261009:PROJECTION','OL20261009:ZERO','OL20261009:OBSERVABLE','OL20261009:NOISE_CONTRACT',
 'OL20261009:TWIN_MODEL','OL20261009:RESET_NONISO','OL20261009:UNOBSERVABLE_CONTROL',
 'OL20261009:COMPENSATION_CONTROL','OL20261009:PHYSICAL_REDUCT','OL20261009:C1_APPLICATION','OL20261009:OPEN_AGENCY',
]
base_path=ROOT/'effective_v111/UCT_EFFECTIVE_GRAPH.json'
base=json.loads(base_path.read_text())
base_ids={n['id'] for n in base['nodes']}
assert set(related_ids)<=base_ids
review={
 'schema':'uct-scoped-per-id-semantic-review-v1',
 'audit_id':'UI-CM-PER-ID-REVIEW-20261009',
 'reviewer_scope':'Independent delegated semantic reading of UI and CM pending modules and complete available notes; not a whole-base-map audit.',
 'created_utc':datetime.now(timezone.utc).isoformat(),
 'governance':{
  'master_guide':str(PROJECT/'RESEARCH_MASTER_GUIDE.md'),'guide_version_read':'2.2',
  'policy':str(PROJECT/'FORMAL_MAP_REVIEW_POLICY.json'),'policy_version_read':'2.3',
  'publication_goal':'Original durable verifiable reusable knowledge for future AI and researchers; publication/citation count is not a truth or novelty criterion.',
  'source_files_modified':False,'external_writes':False,
 },
 'base':{'path':str(base_path),'release':'UCT-MAP-v1.1.1','sha256':sha(base_path),'related_node_ids_semantically_reread':related_ids,'whole_base_reproof_claimed':False},
 'coverage':{'nodes':50,'rules':22,'context_links':9,'total_records':81,'all_81_semantically_read':True,'unreviewed_module_ids':[],
             'complete_notes_read':{'UI':196,'CM':104},'scientific_verification_code_execution_in_this_review':False,
             'missing_expanded_material':['CM expanded longer manuscript','CM expanded checker/results and expanded audit artifacts'],'external_primary_literature_independently_read_in_this_review':False},
 'open_issues_preserved':['QC10','IA-QC11','QC12','QC13','R185 actual occurrence identity','R186 prior full-map obligations are not discharged by this subreview','All UI/CM actual/phenomenal bridges','Priority comparison beyond the cited limited historical read scope'],
 'modules':module_results,
 'required_effective_contract_updates':CONTRACT_UPDATES,
 'items':items,
 'cross_module_findings':[
  {'ids':['UI20261009:LIMITS','CORE20261008:PRIOR_CD_FACTOR'],'finding':'The four-cycle not equal to two binary same-step factors is inherited, not a new UI mathematical result.'},
  {'ids':['UI20261009:FUTURE_QUOTIENT','N128:COMMON_DETERMINISTIC','OL20261009:UNOBSERVABLE_CONTROL'],'finding':'Future-use readout closure and hidden immediate differences are compatible with existing selected-view limitations; UI gives a specific independent-update null model and deterministic diagnostic.'},
  {'ids':['CM20261009:IDENTIFICATION','C:P2_COORD','R133:CELL_ACTION'],'finding':'CM is a linear observation-fiber specialization of target-constancy/decision sufficiency. The exact kernel witness and bounded ambiguity formulation should be credited as an application unless stronger priority evidence is later obtained.'},
  {'ids':['CM20261009:CAUSAL_MASK','R177:COMPENSATED_FEATURE_PRESERVATION','OL20261009:COMPENSATION_CONTROL'],'finding':'Inverse-compensated recoding, active negative feedback and excluded additional writes are distinct contracts; CM permits correction, whereas OL fixes a no-compensation horizon. No contradiction follows from changing that assumption.'},
  {'ids':['CM20261009:CHANNEL_BOUND','RB20261009:CONTRACT','RB20261009:TIGHT'],'finding':'CM counts arbitrary-precision real linear monitor channels. RB and proposed R188 count finite transcript alphabets under explicit encoder knowledge. Equal symbols K or channel counts must not be equated across those domains.'},
  {'ids':['CM20261009:PROBE_SETUP','CM20261009:PROBE_COUNTERCONTROL','RB20261009:DEADLINE_BOUND'],'finding':'Protection from current probe access is an independent causal timing/information hypothesis. Later R188 feedback models must state when and what encoder/compensator observes; current-probe access invalidates CM orthogonality without refuting its theorem.'},
 ],
 'conclusion':'Both modules can be registered as conditional declarations with the listed effective contract materialization. Hold raw UI r_delay automatic instantiation until its separate-readout binding is explicit. No module registration, mathematical proof or finite check establishes actual or phenomenal premises; no OPEN status is closed.'
}
assert len(items)==81 and len({i['id'] for i in items})==81
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'UI_CM_REVIEW.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'written':str(OUT/'UI_CM_REVIEW.json'),'records':len(items),'related_base_nodes_reread':len(related_ids),'unreviewed_module_ids':[]},ensure_ascii=False))
