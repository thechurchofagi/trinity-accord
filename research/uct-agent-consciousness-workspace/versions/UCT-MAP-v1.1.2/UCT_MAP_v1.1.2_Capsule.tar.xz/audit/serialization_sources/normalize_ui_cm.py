import copy
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/328b6dbb55c2')
WORK = ROOT / 'map_audit_work'
OUT = WORK / 'normalized'
PROJECT = ROOT / 'uct/research/uct-agent-consciousness-workspace'
AUDIT = WORK / 'UI_CM_REVIEW.json'
BASE = ROOT / 'effective_v111/UCT_EFFECTIVE_GRAPH.json'
SOURCE = {
    'UI20261009': ROOT / 'effective_v111/pending_UI/MAP_EXTENSION.json',
    'CM20261009': PROJECT / 'records/CM20261009_Compensation_Observability/MAP_EXTENSION.json',
}
NOTE = {
    'UI20261009': ROOT / 'effective_v111/pending_UI/RESEARCH_NOTE.md',
    'CM20261009': PROJECT / 'records/CM20261009_Compensation_Observability/RESEARCH_CHECKPOINT.md',
}
EXPECTED = {
    'UI20261009': '9660da2f8e3bee14e1ebd2804fbdf2b2fced019ed1053125d3a4898ae0f5b628',
    'CM20261009': '09932a947bff198b4058025084ad0bb8b6ab86d7854e1aae65a525306465f1a8',
}
HASH_SCHEME = 'SHA256 of UTF-8 json.dumps(record,sort_keys=True,ensure_ascii=False,separators=(comma,colon)); normalized records contain no self-hash.'

def file_sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def record_sha(o):
    return hashlib.sha256(json.dumps(o, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()

def write_json(p, data):
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

def diff_fields(before, after):
    result=[]
    for key in sorted(set(before)|set(after)):
        if key not in before:
            result.append({'field':key,'operation':'ADD','after':after[key]})
        elif key not in after:
            result.append({'field':key,'operation':'REMOVE','before':before[key]})
        elif before[key]!=after[key]:
            result.append({'field':key,'operation':'REPLACE','before':before[key],'after':after[key]})
    return result

UI_CORE = {
    'state':'Finite nonempty sufficient state S. Retained seeds, mutable clock/resource/background state and history-dependent control affecting later outcomes are included in S.',
    'actions':'The same named A,B are total deterministic state maps, or fixed Markov kernels on this same sufficient S, in both legal orders.',
    'preparation':'One identical initial preparation s0 or probability law mu for the two orders.',
    'observer':'One fixed passive endpoint readout r:S->Y or readout kernel R after both updates complete, with the same ports, clock, background treatment and no direct order-label input.',
    'composition':'For row kernels mu A B R means A then B then R; for state maps BA(s) means A then B.',
    'scope':'Each comparison fixes its protocol before inspecting outcomes. Different observer protocols are explicitly separately bound.',
}
UI_PRODUCT = {
    'coordinates':'For each declared frozen context e, a bijection h_e:S_e -> S_A(e) x S_B(e); the context is unchanged by both actions.',
    'deterministic':'A_e(a,b)=(F_e(a),b); B_e(a,b)=(a,G_e(b)). F_e has no dependence on mutable b and G_e has no dependence on mutable a.',
    'stochastic':'A_e((a,b),(a_prime,b_prime))=K_A,e(a,a_prime)*1[b_prime=b]; B_e((a,b),(a_prime,b_prime))=1[a_prime=a]*K_B,e(b,b_prime). Sequential draws obey these conditional Markov laws.',
    'noise_and_context':'Correlated initial factor values are allowed. Mutable shared context or reused retained randomness cannot be omitted from sufficient state or silently treated as fresh independent noise.',
}
UI_FUTURE = {
    'domain':'Finite nonempty S and finite alphabet U of deterministic total maps F_u:S->S, with fixed readout r:S->Y.',
    'words':'Every finite common action word w in U*, including the empty word, is allowed. F_w denotes sequential execution of that word.',
    'equivalence':'s~t iff r(F_w(s))=r(F_w(t)) for every w in U*.',
    'named_actions':'A and B in the quotient-commutation statement are among the admitted F_u. An additional action outside U may be used only after separately proving it preserves ~.',
    'sizes':'n=|S| and c=|r(S)|. Proper partition refinement increases the number of classes and gives the bound n-c.',
    'limits':'This deterministic behavioral quotient and action menu is a selected view. No probabilistic-bisimulation extension or experiential equivalence is asserted.',
}
UI_BIT = {
    'state_and_preparation':'S={0,1}^2; s0=(0,0).',
    'maps':'A(x,y)=(1-x,y); BC(x,y)=(0,y); BD(x,y)=(x,0).',
    'paired_models':'BC and BD specify two alternative devices with the same A, preparation and readout. They are not simultaneous definitions of one operation in one device.',
    'observer':'R0(x,y)=x XOR y.',
    'match_scope':'Baseline, A-only and B-only agreement is from s0 only, not every possible preparation.',
}
UI_NOISE = {
    'maps_and_preparation':'Use the S,s0,A,BC,BD maps from UI_BIT; B_alpha=alpha BC+(1-alpha)BD with a fresh routing draw and alpha in [0,1].',
    'internal_protocol':'Compare the two orders using fixed parity readout R0. Delta_internal=TV(mu A B_alpha R0,mu B_alpha A R0).',
    'noisy_protocol':'R_eta is R0 followed by the same independent bit-flip channel of rate eta in [0,1]. Delta_observed=TV(mu A B_alpha R_eta,mu B_alpha A R_eta).',
    'binding':'R0 and R_eta label separate predeclared readout instances; within each instance the two orders use one identical observer.',
    'result':'Delta_internal=alpha and Delta_observed=alpha*abs(1-2*eta).',
}
UI_DELAY = {
    'state_and_preparation':'S={0,1}^2; s0=(0,0).',
    'maps':'A(x,y)=(1-x,y); BC(x,y)=(0,y); V(x,y)=(x,x).',
    'observer':'The scored readout is fixed r_y(x,y)=y for both orders and after the common later action V. The parity readout from BIT_MODEL is not the scored observer of this diagnostic.',
    'protocol':'Same preparation, installed update meaning, physical-model clock/ports/background and endpoint observer in each order; V receives no order label and uses only retained state.',
    'definition_import':'BIT_MODEL supplies only the antecedent state/update construction S,s0,A,BC. The full tuple is restated here; BIT_MODEL is not an additional whole-observer instance premise.',
    'witness':'A then BC ends at (0,0); BC then A ends at (1,0). Immediate r_y is 0 for both, whereas after V the respective outputs are 0 and 1.',
}
UI_ACTUAL = {
    'actual_pair':'Independently admit the nominated actual process tokens, interval, boundaries, constitutive support and source/event provenance.',
    'signature':'Use one physically justified complete A:K. Actual full isomorphisms must preserve the corresponding installed operations, state/preparation, readouts, ports, time and noise structure used by the invariant.',
    'pair_binding':'For type transfer, one member of the paired actual comparison has the commuting pair and the other a justified positive order contrast. Never assign these incompatible properties to one member.',
    'persistence':'For local nonerasure, the same nominated actual local process must continue under original A:P3; embedding or task success alone does not establish persistence.',
    'status':'All actual realization, constitutive-invariant and persistence instance obligations remain OPEN; C1/U1 are inherited conditional theory commitments.',
}

CM_LINEAR = {
    'dimensions':'Finite m,p,r,k; e,d in R^m, u in R^p, z in R^k, q in R^r; M in R^(m*p), H in R^(k*p), K_target in R^(r*m), L in R^(r*k).',
    'notation':'The K in source equations is K_target, the selected linear target projection. It is not K_UCT, a constitutive signature, or K_alphabet, a finite transcript cardinality in RB/R188.',
    'fixed_comparison':'Preparation, target, interval, units, permitted ports/timing/readouts and matrices are fixed independently of the outcomes.',
    'exact_equations':'e=d+M u; z=H u; q=K_target d. u includes every admitted corrective action change and the exact model has no omitted remainder.',
    'norms':'Vector norms are Euclidean; matrix norms are induced spectral norms. H^+ is the Moore-Penrose inverse in these fixed inner products.',
    'causal_limit':'d is a correction-clamped causal effect only with independently justified modular/clamp evidence and the apparatus included in the causal boundary. Otherwise e-Mu is an algebraic residual.',
}
CM_UNRESTRICTED = {
    'domain':'All (d,u) in R^m x R^p are admitted for necessity and the monitor lower bound.',
    'identification':'q is determined by (e,z) iff ker(H) subset ker(K_target M), equivalently row(K_target M) subset row(H), equivalently K_target M=L H for some L.',
    'reconstruction':'If that equality holds, q=K_target e-L z. A violating v in ker(H) produces indistinguishable (d,u)=(0,0),(-Mv,v) with different target.',
    'restriction_limit':'Restricting physically feasible alternatives can weaken necessity; the stated reconstruction remains sufficient when its equations still hold.',
}
CM_BOUNDED = {
    'domain':'The exact linear model with ||u||_2<=rho, rho>=0, and d otherwise unrestricted.',
    'feasibility':'The exact z lies in im(H) and ||H^+ z||_2<=rho.',
    'decomposition':'u0=H^+ z; P=I-H^+H; s=sqrt(rho^2-||u0||_2^2). Every compatible correction is u0+v with v in ker(H) and ||v||_2<=s.',
    'target_set':'{K_target e-K_target M u0-K_target M v: v in ker(H), ||v||_2<=s}.',
    'radius':'The exact conditional minimax Euclidean error is s*||K_target M P||_2, attained by the target-set center.',
    'limits':'Additional constraints on d may reduce the set. Passive coordinate changes transport M,H and the physical correction ellipsoid/norm together; imposing a new round ball is a different constraint.',
}
CM_FEEDBACK = {
    'model':'Scalar constant d; e_t=d+u_t is read before u_(t+1)=u_t-alpha*e_t; u_0=0; 0<alpha<=1; no other inputs.',
    'formula':'For integer t>=0, e_t=d(1-alpha)^t and u_t=-d[1-(1-alpha)^t], with the t=0 zeroth power interpreted as 1.',
    'scope':'Alpha=1 yields e_t=0 only for t>=1; the initial e_0=d remains informative. Late-only agreement does not imply full-trajectory agreement.',
}
CM_APPROX = {
    'dimensions_and_norms':CM_LINEAR['dimensions']+' '+CM_LINEAR['norms'],
    'model':'e=d+Mu+w, ||w||<=epsilon_m; z=Hu; fixed K_target M=L H.',
    'readings':'||e_measured-e||<=epsilon_e; ||z_measured-z||<=epsilon_z; all nonnegative radii independently justified.',
    'bound':'||K_target e_measured-L z_measured-K_target d|| <= ||K_target||(epsilon_e+epsilon_m)+||L||epsilon_z.',
    'limits':'No independence of these bounded errors is assumed. Model calibration and any causal-clamp interpretation remain independent obligations.',
}
CM_PROBE = {
    'dimensions':'xi in R^a; e,b in R^m; fixed G in R^(m*a); Q in R^(m*m) is fixed symmetric positive semidefinite; Q^(1/2) denotes its PSD square root.',
    'model':'e=G xi+b; E[xi]=0; Sigma=E[xi xi^T] is nonsingular; all relevant second moments are finite.',
    'information':'Let F_prior be all compensator information available before the scored readout. xi is independent of F_prior, and b is F_prior-measurable.',
    'population_identities':'E[e xi^T]=G Sigma and E||Q^(1/2)e||^2=tr(QG Sigma G^T)+E||Q^(1/2)b||^2.',
    'countercontract':'If the compensator sees current xi, b=-Gxi is available and e=0. This violates the protected-information premise, not the population identity under that premise.',
    'limits':'No population independence is inferred from random-looking samples; no sample-level significance guarantee or human latency value is supplied.',
}
CM_ACTUAL = {
    'actual_pair':'Independently admitted actual P,Q with the same complete signature, timing, boundaries and physically grounded ports.',
    'model_bridge':'The target, calibrated causal decomposition and physically justified correction-baseline comparison are independently established for that pair; finite operator views are not the full actual organization.',
    'invariant':'A feature preserved by all complete structural isomorphisms is independently shown to differ in the same comparison.',
    'persistence':'For local nonerasure, the nominated local actual process continues with constitutive support and lineage under A:P3.',
    'status':'ACTUAL_BRIDGE, NONISOMORPHISM and PERSISTENCE remain OPEN instance premises. C1/U1 consequences are inherited conditional applications, not actual or phenomenal evidence.',
}

UI_REPLACE = {
    'DOMAIN':{'statement':'Fix a finite nonempty sufficient state/clock, the same total deterministic updates or Markov kernels A,B, identical preparation, and one fixed passive endpoint readout for the two legal orders. Include retained randomness and mutable background state; fix ports/timing/source treatment; no direct order-label input.'},
    'PRODUCT':{'statement':'For each frozen context e, a state bijection exposes factors with A_e(a,b)=(F_e(a),b) and B_e(a,b)=(a,G_e(b)). In the stochastic case the factor-local conditional kernels are K_A,e(a,a_prime)delta_b and delta_a K_B,e(b,b_prime). Neither action changes e or depends on the other mutable factor; initial factors may be correlated and no mutable noise/context is omitted.'},
    'FUTURE_DOMAIN':{'statement':'S is finite nonempty, |S|=n; U is a finite alphabet of deterministic total updates F_u:S->S, fixed readout r has c=|r(S)| classes, and all finite common words including empty are allowed. A and B in the quotient claim belong to U; external actions require a separate equivalence-preservation proof.'},
    'FUTURE_QUOTIENT':{'statement':'On FUTURE_DOMAIN, future-readout equality is the coarsest update-stable refinement of current-readout equality. Every admitted F_u descends to S/~; for admitted A,B, their quotient maps commute iff no common future word distinguishes the two orders from any initial state.'},
    'DELAY_MODEL':{'statement':'In this separately predeclared diagnostic S={0,1}^2,s0=(0,0),A(x,y)=(1-x,y),BC(x,y)=(0,y),r_y(x,y)=y,V(x,y)=(x,x). Both orders use the same preparation/clock/ports and fixed r_y; V receives no order label. Only S,s0,A,BC are inherited from the BIT_MODEL construction; its parity observer is not a scored observer here.'},
    'DELAY_WITNESS':{'statement':'Under DELAY_MODEL, A then BC ends at (0,0), while BC then A ends at (1,0). Their fixed r_y readings are both zero immediately; after the same later V they are respectively zero and one. This is retained-state revelation in the separately fixed r_y protocol.'},
    'TYPE_TRANSFER':{'statement':'For the explicitly paired actual comparison satisfying REALIZATION, TYPE_WITNESS_GUARD, common complete A:K and inherited A:C1_OI, one member has corresponding commuting operations and the other justified positive order contrast. This grounded K-invariant difference excludes full K-isomorphism and implies distinct complete experiential K-types. No named quality, intensity, intelligence level or subject count follows.'},
    'NOISE_MODEL':{'statement':'Reuse BIT_MODEL state/maps/preparation with B_alpha=alpha BC+(1-alpha)BD and a fresh route draw, alpha in [0,1]. R0 is parity; R_eta is R0 followed by the same independent bit-flip channel of rate eta in [0,1]. The two orders share R0 within the internal protocol and R_eta within the separately named noisy protocol.'},
    'NOISE_RESULT':{'statement':'For NOISE_MODEL, Delta_internal=TV(mu A B_alpha R0,mu B_alpha A R0)=alpha; Delta_observed=TV(mu A B_alpha R_eta,mu B_alpha A R_eta)=alpha*abs(1-2eta). These are two explicitly named readout instances.'},
    'PERSIST_GUARD':{'statement':'Independently establish that the same nominated local actual process continues through the declared interval with constitutive support, dynamics, boundary and lineage under the original A:P3 criterion. Embedding or task success alone does not establish persistence; persistence does not imply unchanged complete type.'},
}
CM_REPLACE = {
    'VOCAB':{'statement':'Fix finite m,p,r,k; e,d in R^m,u in R^p,z in R^k,q=K_target d in R^r; M in R^(m*p),H in R^(k*p),K_target in R^(r*m),L in R^(r*k). Source symbol K means K_target, not full K_UCT or finite K_alphabet. Vector norms are Euclidean, matrix norms spectral, and H^+ is Moore-Penrose. Preparation,target,time,units,ports and readouts are independently fixed.'},
    'PROBE_SETUP':{'statement':'Fix e,b in R^m,xi in R^a,G in R^(m*a),e=Gxi+b. E[xi]=0 and Sigma=E[xi xi^T] is nonsingular. xi is independent of the compensator pre-readout information sigma-algebra F_prior, b is F_prior-measurable, and all relevant second moments are finite. For the energy identity Q is a fixed symmetric PSD m-by-m matrix with its PSD square root.'},
    'PROBE_IDENTIFICATION':{'statement':'Under PROBE_SETUP, E[e xi^T]=G Sigma; for the fixed symmetric PSD Q, E||Q^(1/2)e||^2=tr(Q G Sigma G^T)+E||Q^(1/2)b||^2. These are population identities under the declared information/timing contract, not finite-sample significance guarantees.'},
}

OPEN_IDS={
 'UI20261009:REALIZATION','UI20261009:TYPE_WITNESS_GUARD','UI20261009:PERSIST_GUARD',
 'CM20261009:ACTUAL_BRIDGE','CM20261009:NONISOMORPHISM','CM20261009:PERSISTENCE',
}
ACTUAL_UI={'REALIZATION','TYPE_WITNESS_GUARD','TYPE_TRANSFER','PERSIST_GUARD','PERSISTENCE'}
ACTUAL_CM={'ACTUAL_BRIDGE','NONISOMORPHISM','TYPE_CONSEQUENCE','PERSISTENCE','NONERASURE'}

def node_role(record):
    if record['id'] in OPEN_IDS:
        return 'OPEN_INSTANCE_OBLIGATION_DECLARATION'
    kind=record.get('kind','')
    if kind in ['DEFINITION']:
        return 'DEFINITION_SCHEMA'
    if 'PREMISE' in kind or 'ASSUMPTION' in kind:
        return 'DECLARED_MODEL_PREMISE_SCHEMA'
    if 'COUNTEREXAMPLE' in kind or kind=='CONSTRUCTION':
        return 'CONDITIONAL_CONSTRUCTION_OR_COUNTEREXAMPLE_SCHEMA'
    if 'INHERITED' in kind or kind=='CONDITIONAL_UCT_APPLICATION':
        return 'INHERITED_CONDITIONAL_APPLICATION_SCHEMA'
    return 'CONDITIONAL_THEOREM_SCHEMA'

def node_contract(module,suffix):
    if module=='UI20261009':
        if suffix in ACTUAL_UI:
            return {'actual_application':UI_ACTUAL}
        if suffix.startswith('FUTURE_') or suffix=='FINITE_WITNESS':
            return {'deterministic_future_readout':UI_FUTURE}
        if suffix.startswith('DELAY_'):
            return {'common_protocol':UI_CORE,'separate_delayed_readout_protocol':UI_DELAY}
        c={'common_protocol':UI_CORE}
        if suffix in {'PRODUCT','COMMUTATION','OBSTRUCTION','LIMITS'}:
            c['product_hypothesis']=UI_PRODUCT
        if suffix in {'BIT_MODEL','BIT_WITNESS'}:
            c['paired_bit_construction']=UI_BIT
        if suffix in {'NOISE_MODEL','NOISE_RESULT'}:
            c['explicit_readout_instances']=UI_NOISE
        return c
    if suffix in ACTUAL_CM:
        return {'actual_application':CM_ACTUAL}
    if suffix.startswith('PROBE_'):
        return {'protected_probe_model':CM_PROBE}
    if suffix in {'FEEDBACK_SETUP','CAUSAL_MASK'}:
        return {'scalar_causal_feedback':CM_FEEDBACK}
    if suffix in {'APPROXIMATE_MODEL','ROBUST_RECONSTRUCTION'}:
        return {'bounded_approximate_model':CM_APPROX}
    c={'fixed_linear_model':CM_LINEAR}
    if suffix in {'UNRESTRICTED','IDENTIFICATION','CHANNEL_BOUND'}:
        c['unrestricted_identification_domain']=CM_UNRESTRICTED
    if suffix in {'BOUNDED_SETUP','MINIMAX_RADIUS'}:
        c['bounded_correction_domain']=CM_BOUNDED
    return c

RULE_BINDINGS={
 'UI20261009:r_commute':'Instantiate DOMAIN and PRODUCT on the same sufficient state, frozen-context fibers, operations and protocol; the conclusion is the universally quantified conditional implication, not physical evidence of PRODUCT.',
 'UI20261009:r_obstruct':'Use COMMUTATION as the theorem schema PRODUCT=>AB=BA, not as the asserted equation AB=BA for the actual contrasting instance. DOMAIN and ORDER_GAP define one two-order protocol. The output is the conditional schema Delta>0=>no admitted product realization; observed use requires an independently justified positive Delta.',
 'UI20261009:r_bit':'BIT_MODEL is an explicit pair of alternative BC/BD devices with common S,s0,A,R0; instantiate DOMAIN separately for each member with that member\'s B. The paired comparison does not assert BC=BD.',
 'UI20261009:r_recode':'Quantify over a bijection transporting the entire fixed state/update/preparation/readout tuple. DOMAIN/ORDER_GAP are schemas for the original and its transported copy, not evidence that changing one installed route is passive recoding.',
 'UI20261009:r_pred':'DOMAIN, ORDER_GAP and APPROX_PRED use the same two endpoint laws; one Q is compared with both. The larger hidden comparison model is relevant only under that same predicted-law equality.',
 'UI20261009:r_kernel':'Use one aligned sufficient state, commuting A0,B0, uniform row-TV errors and common mu,R for both orders. The telescoping theorem does not supply state alignment from output data.',
 'UI20261009:r_noise':'BIT_MODEL provides state/maps and parity R0; NOISE_MODEL creates B_alpha and names R_eta. Instantiate ORDER_GAP twice, once with R0 and once with R_eta, under the explicitly named internal/noisy protocols. Never conjoin R0=R_eta or assign both Delta values to one observer.',
 'UI20261009:r_quotient':'FUTURE_DOMAIN and FUTURE_EQ use the same S,U,r; the A,B in the conclusion belong to U, so they descend to the quotient.',
 'UI20261009:r_finite':'n,c and the refinement process refer to the same complete finite S,U,r. The conclusion is an existence bound for a separating word, not a physical time or empirical discovery bound.',
 'UI20261009:r_delay':'Instantiate DOMAIN using exactly the full separately declared DELAY_MODEL tuple S,s0,A,BC,r_y,V. BIT_MODEL is not an all_of premise; only its state/update construction is a source component reference. The two orders and common continuation use the same r_y.',
 'UI20261009:r_type':'REALIZATION and TYPE_WITNESS_GUARD bind one explicitly paired actual comparison in common complete A:K; commuting and positive contrast belong to its different members. OBSTRUCTION and RECODING are proof schemas, not actual-instance evidence. A:C1_OI supplies only the inherited conditional complete-type transfer.',
 'UI20261009:r_persist':'Bind A:ACTUAL_TOKEN and PERSIST_GUARD to the same nominated local actual process and interval, with original A:P3 persistence independently supported; then apply the inherited U1 theorem.',
 'CM20261009:r_ident':'All three premises share one fixed e=d+Mu,z=Hu,q=K_target d model and unrestricted real (d,u). The iff is mathematical under that domain; declarations do not certify a physical clamp model.',
 'CM20261009:r_channels':'Use the same fixed KM and unrestricted domain for IDENTIFICATION; FREE_MONITOR permits ideal noiseless arbitrary-precision linear monitor design. The count is rank of real monitor rows, not finite transcript cardinality.',
 'CM20261009:r_sumdiff':'EXACT_MODEL is instantiated in each explicit alternative Hplus/Hminus of SUMDIFF_SETUP with the same target, M and compared (d,u) values. The two alternative monitor designs are not conjoined as one matrix H.',
 'CM20261009:r_radius':'Use the exact linear observation fiber with bounded u but unrestricted d from BOUNDED_SETUP. Do not import unrestricted u from the separate necessity theorem, or extra constraints on d.',
 'CM20261009:r_causal':'FEEDBACK_SETUP supplies the full scalar recurrence, initial condition and read-before-update timing. Late t>=1 conclusions are not claims about equality of the t=0 transient.',
 'CM20261009:r_budget':'The exact equation and stated norms/budgets refer to the same comparison. The scalar residual subclaim minimizes over bounded scalar u with M=1; no controller implementability or timing optimum is asserted.',
 'CM20261009:r_robust':'VOCAB fixes dimensions/norms; APPROXIMATE_MODEL replaces the exact model by its explicit remainder and reading bounds with fixed KM=LH. Do not silently assume w=0 or statistical independence.',
 'CM20261009:r_probe':'Use one fixed probability law and pre-readout information sigma-algebra, centered xi independent of it, measurable b, fixed G and fixed PSD Q. This is an independent protected-probe submodel, not a deduction of those assumptions from the linear compensation model.',
 'CM20261009:r_type':'ACTUAL_BRIDGE and NONISOMORPHISM must independently hold for the same pair of actual tokens, common complete signature and preserved reduct; A:C1_OI then yields only complete experiential-type difference.',
 'CM20261009:r_persist':'PERSISTENCE supplies the continuing actual local token and interval under original P3; apply U1 to that token. Task success, embedding and map registration do not establish the persistence premise.',
}

NORMALIZED_RATIONALES={
 'UI20261009:PRODUCT':'The normalized product definition now explicitly supplies factor-local deterministic maps or conditional kernels, frozen context and sufficient-state noise treatment. Either order applies F_e to a and G_e to b, including the product-kernel case; initial coordinate correlation does not spoil this argument.',
 'UI20261009:FUTURE_DOMAIN':'The normalized finite deterministic domain explicitly includes A,B in U and fixes n,c, all common words and the empty word. Every quotient-action reference is now typed; applying an external action still needs its own preservation proof.',
 'UI20261009:FUTURE_QUOTIENT':'With A,B now explicitly in the finite action alphabet, prefixing an admitted action preserves future equality and all named actions descend. The coarsest stable-refinement and quotient-commutation iff argument is valid in this deterministic selected-view domain.',
 'UI20261009:DELAY_MODEL':'The normalized node explicitly fixes S=bit pairs,s0=00,A,BC,V and the scored r_y observer for both orders. BIT_MODEL is now only the source of the restated state/update construction; the parity observer is not imported into this diagnostic.',
 'UI20261009:DELAY_WITNESS':'The complete normalized delayed protocol gives states 00 and 10 after the two orders, with equal immediate r_y=0. The common V maps them to 00 and 11, giving r_y=0 and 1. This is a retained-state witness within one fixed observer protocol, not supplied order-label information.',
 'UI20261009:TYPE_TRANSFER':'The normalized standalone statement now explicitly includes REALIZATION, TYPE_WITNESS_GUARD, common complete A:K and A:C1_OI. A grounded operator invariant difference excludes full K-isomorphism only in that actual paired comparison; the open realization/invariant premises remain unfulfilled.',
 'UI20261009:r_commute':'The same-instance product premise now includes its complete deterministic/stochastic frozen-context factor-local contract. Direct product-coordinate evaluation proves the conditional commutation schema; the declaration still establishes no nominated physical product realization.',
 'UI20261009:r_noise':'The normalized binding uses ORDER_GAP as a definition schema twice: the internal protocol fixes R0 and the noisy protocol fixes R_eta. Direct binary-law calculation gives alpha and alpha*abs(1-2eta), with one common observer within each two-order comparison.',
 'UI20261009:r_quotient':'The normalized FUTURE_DOMAIN explicitly places A,B in U, so the stable-equivalence proof gives well-defined quotient maps. The route is now fully typed for its final commutation clause, without asserting a stochastic extension.',
 'UI20261009:r_delay':'The normalized AND route is exactly DOMAIN and the fully expanded DELAY_MODEL. Direct state evaluation proves equal immediate r_y outputs and different outputs after common V. BIT_MODEL supplies only the explicitly typed S,s0,A,BC source components, excluding parity readout; the earlier automatic-instantiation binding hold is resolved.',
 'CM20261009:VOCAB':'The normalized vocabulary explicitly fixes m,p,r,k, all matrix/vector dimensions, Euclidean and spectral norms and Moore-Penrose inverse. K_target, K_UCT and K_alphabet are distinct typed symbols, so no real-channel rank is silently read as a finite-bit or experiential count.',
 'CM20261009:PROBE_IDENTIFICATION':'The normalized probe contract fixes dimensions, the centered probe, its independent pre-readout information boundary, finite second moments and symmetric PSD Q. Vanishing cross moments give both displayed population identities; no sample significance or empirical independence is inferred.',
 'CM20261009:r_probe':'The normalized route now binds one probability law, information sigma-algebra, fixed G and dimensionally typed symmetric PSD Q. Independence and centering remove the cross terms and prove the population identities, with actual timing/access support remaining open.',
}

audit=json.loads(AUDIT.read_text())
audit_by_id={x['id']:x for x in audit['items']}
materialization_receipt_path=ROOT/'source_materialization_receipt.json'
materialization_receipt=json.loads(materialization_receipt_path.read_text())
cm_materialization_records=[x for x in materialization_receipt if 'CM20261009_Compensation_Observability' in x['path']]
assert len(cm_materialization_records)==2
for entry in cm_materialization_records:
    assert file_sha(PROJECT/entry['path'])==entry['sha256']
source_reconciliation={
 'receipt_path':str(materialization_receipt_path),'receipt_sha256':file_sha(materialization_receipt_path),
 'changes_by_parent_before_normalization':cm_materialization_records,
 'semantic_change':False,
 'description':'Parent removed the one newline appended during initial materialization only after validating fetched Git blob identity. The reviewed substantive CM text/JSON object is unchanged; normalized provenance uses the current byte-exact originals.',
}
base=json.loads(BASE.read_text())
base_by_id={x['id']:x for x in base['nodes']}
assert len(audit_by_id)==81
OUT.mkdir(parents=True,exist_ok=True)
timestamp=datetime.now(timezone.utc).isoformat()
log={
 'schema':'uct-local-normalization-manifest-v1','normalization_id':'UI-CM-NORMALIZATION-20261009-v1',
 'created_utc':timestamp,'authorization':'Parent delegated reversible local normalized registry copies; no source edits or external writes.',
 'source_modules_modified':False,'source_scientific_status_preserved':True,
 'mathematical_registry_only':True,'enabled_as_established_premises':False,
 'all_actual_and_qc_statuses_remain_OPEN':True,
 'record_hash_scheme':HASH_SCHEME,
 'source_materialization_reconciliation':source_reconciliation,
 'base':{'release':'UCT-MAP-v1.1.1','sha256':file_sha(BASE)},
 'operations':[
  {'id':'N-GLOBAL-1','description':'Preserve source file/hash/raw record/defaults/status; materialize effective CM defaults and source-located proof references.'},
  {'id':'N-GLOBAL-2','description':'Add explicit definition/model/theorem/open-obligation/context roles; registry availability never establishes premise truth or actual/QC closure.'},
  {'id':'N-GLOBAL-3','description':'Mark all contexts nondeductive; inline mathematical/actual comparison contracts, same-instance bindings and source proof-review rationales.'},
  {'id':'N-UI-1','description':'Expand sufficient-state protocol and stochastic frozen-context factor locality.'},
  {'id':'N-UI-2','description':'Bind A,B to the deterministic future-action alphabet and define n,c.'},
  {'id':'N-UI-3','description':'Expand separate delayed readout tuple; change r_delay all_of to DOMAIN and DELAY_MODEL; retain only typed state/update source reference to BIT_MODEL.'},
  {'id':'N-UI-4','description':'Name pre-noise/post-noise observer instances and inline paired complete-K type/persistence guards.'},
  {'id':'N-CM-1','description':'Explicit real dimensions, target/signature/alphabet notation separation, Euclidean and spectral norms, pseudoinverse and model-specific domain restrictions.'},
  {'id':'N-CM-2','description':'Expand protected-probe probability/information types and fixed symmetric PSD Q.'},
  {'id':'N-AUDIT-1','description':'Update every per-ID decision to reviewed normalized conditional/open/context registration and attach normalized record/file hashes; preserve old review verdict and source status.'},
 ],
 'modules':[],'record_operations':[],'unreviewed_ids':[],
}
normalized_records={}

for module in ['UI20261009','CM20261009']:
    source_path=SOURCE[module]
    assert file_sha(source_path)==EXPECTED[module], module
    source=json.loads(source_path.read_text())
    result=copy.deepcopy(source)
    result['schema']='uct-normalized-conditional-map-module/1.0'
    result['source_schema']=source['schema']
    result['source_status']=source['status']
    result['normalization']={
      'id':log['normalization_id'],'version':'1.0','source_file':str(source_path),'source_file_sha256':EXPECTED[module],
      'source_metadata':{k:v for k,v in source.items() if k not in ['nodes','rules','context_links']},
      'source_note':{'path':str(NOTE[module]),'sha256':file_sha(NOTE[module])},
      'source_status_fields_are_historical_and_preserved':True,
      'scope':'Complete available UI/CM module and note semantic reading; conditional registry normalization only. Parent owns whole-current-map descriptor and integration.',
      'reviewed_against_release':'UCT-MAP-v1.1.1','reviewed_against_graph_sha256':file_sha(BASE),
      'module_all_ids_reviewed':True,'source_or_global_scientific_promotion':False,
    }
    result['registration']={
      'status':'REVIEWED_CONDITIONAL_DECLARATIONS_AVAILABLE_FOR_REGISTRY_INTEGRATION',
      'mathematical_registry_availability':True,
      'allowed_use':'Conditional mathematical/definition/model schemas, open-obligation references, and explicitly nondeductive contexts only.',
      'enabled_as_established_premises':False,'node_presence_is_premise_truth':False,
      'actual_application_status':'OPEN','phenomenal_application_status':'OPEN','priority_clearance_status':'OPEN',
      'qc_statuses':{x:'OPEN' for x in ['QC10','IA-QC11','QC12','QC13']},
      'whole_map_descriptor_owned_by_parent':True,
    }
    result['enabled_as_established_premises']=False
    result['mathematical_registry_availability']=True
    result['registry_availability_mode']='CONDITIONAL_SCHEMAS_AND_DECLARATIONS_ONLY'
    result['node_presence_is_premise_truth']=False
    result['all_of_is_conjunction']=True
    result['independent_rules_are_alternatives']=True
    node_lookup={}

    for collection in ['nodes','rules','context_links']:
        records=[]
        for raw in source[collection]:
            id_=raw['id'];suffix=id_.split(':',1)[1]
            default_key='node_defaults' if collection=='nodes' else 'rule_defaults' if collection=='rules' else None
            defaults=copy.deepcopy(source.get(default_key,{})) if default_key else {}
            rec={**defaults,**copy.deepcopy(raw)}
            if collection=='nodes':
                changes=(UI_REPLACE if module=='UI20261009' else CM_REPLACE).get(suffix,{})
                rec.update(copy.deepcopy(changes))
                role=node_role(rec)
            elif collection=='rules':
                role='CONDITIONAL_RULE_SCHEMA'
                if id_=='UI20261009:r_delay':
                    rec['all_of']=['UI20261009:DOMAIN','UI20261009:DELAY_MODEL']
                    rec['definition_component_import']={
                     'from':'UI20261009:BIT_MODEL','components':['S','s0','A','BC'],
                     'not_imported':['parity_readout_R0','whole_BIT_MODEL_observer_instance'],
                     'role':'SOURCE_COMPONENT_REFERENCE_ONLY_NOT_ALL_OF_PREMISE',
                     'complete_restatement':'UI20261009:DELAY_MODEL',
                    }
            else:
                role='NONDEDUCTIVE_CONTEXT'
                rec['deductive']=False
                rec['premise_truth_effect']='NONE'

            rec['source_provenance']={
              'module':module,'source_file':str(source_path),'source_file_sha256':EXPECTED[module],
              'source_record_sha256':record_sha(raw),'source_record_hash_scheme':HASH_SCHEME,
              'source_record':copy.deepcopy(raw),'source_inherited_defaults':defaults,
              'source_status':source['status'],
              'source_note_path':str(NOTE[module]),'source_note_sha256':file_sha(NOTE[module]),
            }
            rec['declaration_role']=role
            rec['conditional_declaration_available']=True
            rec['mathematical_registry_availability']=role not in ['OPEN_INSTANCE_OBLIGATION_DECLARATION','NONDEDUCTIVE_CONTEXT']
            rec['registry_status']='REVIEWED_CONDITIONAL_DECLARATION_ONLY' if role!='NONDEDUCTIVE_CONTEXT' else 'REVIEWED_NONDEDUCTIVE_CONTEXT_ONLY'
            rec['enabled_as_established_premise']=False
            rec['enabled_as_established_premises']=False
            rec['automatic_premise_truth']=False
            rec['node_presence_is_premise_truth']=False
            rec['actual_application_status']='OPEN'
            rec['phenomenal_application_status']='OPEN'
            rec['scientific_promotion']=False
            rec['same_instance_required']=True if collection!='context_links' else False
            rec['source_review_rationale']=audit_by_id[id_]['rationale']
            rec['proof_review_rationale']=NORMALIZED_RATIONALES.get(id_,audit_by_id[id_]['rationale'])
            rec['normalization_contract_updates_applied']=audit_by_id[id_]['required_contract_updates']
            rec['originality_status']='INHERITED_CONDITIONAL_APPLICATION_OR_NEW_APPLICATION; PRIORITY_UNVERIFIED'
            if id_=='UI20261009:LIMITS':
                rec['originality_anchors']=['CORE20261008:PRIOR_CD_FACTOR']
                rec['originality_scope']='Four-cycle binary-factor obstruction is inherited; other examples are conditional boundary illustrations, not newly certified priority.'

            if collection=='nodes':
                rec['formal_contract']={
                  'declaration_role':role,
                  'complete_inline_domain':copy.deepcopy(node_contract(module,suffix)),
                  'quantifiers':'Definitions/model hypotheses are declared schemas. A theorem quantifies only over instances satisfying its full same-submodel assumptions; an open physical bridge is not discharged by declaration.',
                  'mathematical_and_actual_instances_are_distinct':True,
                  'instance_binding':'Use this exact declared model/paired comparison with its fixed target, time, ports, observer and units. Separate alternatives or observer instances are identified explicitly.',
                  'proof_or_evidence':rec['proof_review_rationale'],
                  'proof_source':{'path':str(NOTE[module]),'sha256':file_sha(NOTE[module]),'section':raw.get('section',raw.get('proof_locator'))},
                  'actual_application_obligations':copy.deepcopy(UI_ACTUAL if module=='UI20261009' else CM_ACTUAL),
                  'no_inference_to':['named_quality','phenomenal_intensity','unique_subject','subject_count','basal_experience_threshold','actual_source_occurrence_without_evidence'],
                  'machine_proof':False,'new_scientific_execution':False,
                }
                if id_ in OPEN_IDS:
                    rec['instance_obligation_status']='OPEN'
                    rec['registry_use']='Reference this open obligation by ID; do not treat it as an established mathematical or actual premise.'
                if id_=='CM20261009:PROBE_COUNTERCONTROL':
                    rec['formal_contract']['instance_binding']='This is the separate countercontract that permits current-probe access, explicitly violating the protected-information hypothesis. The protected setup and countercontract are compared, not conjoined as one instance.'
                if id_=='UI20261009:LIMITS':
                    rec['formal_contract']['instance_binding']='Each listed limit is a separate explicitly described model or a violation of a selected hypothesis. Do not conjoin the commuting counterexamples, order-label leak and coordinating-copy examples into one purported DOMAIN instance.'
                node_lookup[id_]=rec
            elif collection=='rules':
                rec['premise_semantics']='AND within this route for one explicitly typed comparison; separate rules are alternatives. Theorem schemas used as proof dependencies do not assert their hypotheses for a nominated actual token.'
                rec['instance_binding']=RULE_BINDINGS[id_]
                inline=[]
                for premise in rec['all_of']:
                    node=node_lookup.get(premise) or base_by_id[premise]
                    inline.append({
                      'id':premise,'statement':node.get('statement'),
                      'role':node.get('declaration_role','INHERITED_THEOREM_OR_DOMAIN_SCHEMA'),
                      'scope':node.get('scope'),
                      'node_presence_discharges_instance':False,
                      'instance_status':'OPEN' if premise in OPEN_IDS else 'SCHEMA_ONLY_NO_AUTOMATIC_INSTANCE_TRUTH',
                    })
                rec['inline_premise_contracts']=inline
                rec['formal_contract']={
                  'same_instance_required':True,'binding':RULE_BINDINGS[id_],
                  'proof_or_evidence':rec['proof_review_rationale'],
                  'proof_source':{'path':str(NOTE[module]),'sha256':file_sha(NOTE[module]),'locator':raw.get('proof_locator',defaults.get('proof_source'))},
                  'conclusion_mode':'Conditional schema only. Actual application requires every named physical premise independently discharged.',
                  'independent_rules_are_alternatives':True,'machine_proof':False,'new_scientific_execution':False,
                }
            else:
                rec['formal_contract']={'relation_semantics':'Non-deductive scope/analogy/limitation/lineage only; no premise truth and no scientific status change.','review':audit_by_id[id_]['rationale']}

            records.append(rec)
            normalized_records[id_]=rec
            log['record_operations'].append({
              'id':id_,'module':module,'collection':collection,
              'source_record_sha256':record_sha(raw),'normalized_record_sha256':record_sha(rec),
              'operation_refs':['N-GLOBAL-1','N-GLOBAL-2','N-GLOBAL-3']+(['N-UI-1','N-UI-2','N-UI-3','N-UI-4'] if module=='UI20261009' else ['N-CM-1','N-CM-2']),
              'field_changes':diff_fields(raw,rec),
              'registration_decision':'REVIEWED_NORMALIZED_OPEN_OBLIGATION_REFERENCE_ONLY' if id_ in OPEN_IDS else 'REVIEWED_NORMALIZED_NONDEDUCTIVE_CONTEXT' if collection=='context_links' else 'REVIEWED_NORMALIZED_CONDITIONAL_SCHEMA',
              'actual_premise_promotion':False,
            })
        result[collection]=records

    target=OUT/f'{module}.json'
    write_json(target,result)
    # Reparse the actual bytes and verify declaration/schema guards and exact ID preservation.
    parsed=json.loads(target.read_text())
    for collection in ['nodes','rules','context_links']:
        assert [x['id'] for x in parsed[collection]]==[x['id'] for x in source[collection]]
        for rec in parsed[collection]:
            assert rec['enabled_as_established_premises'] is False
            assert rec['automatic_premise_truth'] is False
            assert rec['actual_application_status']=='OPEN'
            assert rec['source_provenance']['source_record']==next(x for x in source[collection] if x['id']==rec['id'])
            if collection=='context_links':
                assert rec['deductive'] is False
    if module=='UI20261009':
        assert next(x for x in parsed['rules'] if x['id'].endswith(':r_delay'))['all_of']==['UI20261009:DOMAIN','UI20261009:DELAY_MODEL']
    metadata_before={k:v for k,v in source.items() if k not in ['nodes','rules','context_links']}
    metadata_after={k:v for k,v in parsed.items() if k not in ['nodes','rules','context_links']}
    log['modules'].append({
      'module':module,'source_path':str(source_path),'source_file_sha256':EXPECTED[module],
      'normalized_path':str(target),'normalized_file_sha256':file_sha(target),
      'source_status_preserved':parsed['status']==source['status'],
      'counts':{c:len(parsed[c]) for c in ['nodes','rules','context_links']},
      'metadata_field_changes':diff_fields(metadata_before,metadata_after),
      'scientific_status_promoted':False,'automatic_instantiation_hold_ids_after_normalization':[],
    })

assert len(normalized_records)==81
module_meta={m['module']:m for m in log['modules']}
for item in audit['items']:
    id_=item['id'];rec=normalized_records[id_]
    if item['source_file_sha256']!=EXPECTED[item['module']]:
        item['initial_materialized_source_file_sha256']=item['source_file_sha256']
        item['source_file_sha256']=EXPECTED[item['module']]
    item['original_review_verdict']=item.get('original_review_verdict',item['review_verdict'])
    item['normalized_record_sha256']=record_sha(rec)
    item['normalized_record_hash_scheme']=HASH_SCHEME
    item['normalized_module_path']=module_meta[item['module']]['normalized_path']
    item['normalized_module_sha256']=module_meta[item['module']]['normalized_file_sha256']
    item['normalized_registration_reviewed']=True
    item['normalized_review_rationale']=rec['proof_review_rationale']
    item['source_scientific_status_preserved']=True
    item['actual_application_status']='OPEN'
    if id_ in OPEN_IDS:
        item['review_verdict']='REVIEWED_NORMALIZED_OPEN_OBLIGATION_REGISTRATION_ONLY'
    elif item['record_type']=='context_link':
        item['review_verdict']='REVIEWED_NORMALIZED_NONDEDUCTIVE_CONTEXT_REGISTRATION'
    else:
        item['review_verdict']='REVIEWED_NORMALIZED_CONDITIONAL_SCHEMA_REGISTRATION'
    item['required_contract_updates_resolved_by_normalization']=item['required_contract_updates']
    item['remaining_contract_instantiation_holds']=[]
    if id_=='UI20261009:r_delay':
        item['normalization_resolution']='The effective all_of is now DOMAIN AND fully expanded DELAY_MODEL. The only BIT_MODEL import is an explicitly typed state/update source reference, excluding parity readout. Reviewed this concrete normalized binding; original hold resolved as a serialization correction, not an actual/phenomenal finding.'
    if id_ in {'UI20261009:DELAY_MODEL','UI20261009:DELAY_WITNESS'}:
        item['normalization_resolution']='The full separate r_y protocol is now inline and r_delay no longer imports the entire parity-readout model as a same-instance premise.'

for module in audit['modules']:
    meta=module_meta[module['module']]
    if module['source_sha256']!=EXPECTED[module['module']]:
        module['initial_materialized_source_sha256']=module['source_sha256']
        module['source_sha256']=EXPECTED[module['module']]
    module['full_note_sha256']=file_sha(NOTE[module['module']])
    module['original_registration_verdict']=module.get('original_registration_verdict',module['registration_verdict'])
    module['registration_verdict']='REVIEWED_NORMALIZED_CONDITIONAL_DECLARATION_REGISTRY_ADMISSION'
    module['automatic_instantiation_hold_ids']=[]
    module['normalized_path']=meta['normalized_path']
    module['normalized_file_sha256']=meta['normalized_file_sha256']
    module['source_status_and_open_premises_preserved']=True

audit['normalization']={
 'id':log['normalization_id'],'manifest_path':str(WORK/'NORMALIZATION_UI_CM.json'),
 'normalized_records_reviewed':81,'unreviewed_normalized_ids':[],
 'no_source_edits':True,'actual_or_phenomenal_promotion':False,
 'mechanical_validation':'Exact 81 IDs/counts preserved; all source records and hashes retained; every rule reference resolves; r_delay protocol binding explicit; all actual flags OPEN and all contexts nondeductive.',
 'scientific_proof_reexecution':False,
}
audit['source_materialization_reconciliation']=source_reconciliation
audit['coverage']['complete_notes_read']['CM']=NOTE['CM20261009'].read_bytes().count(b'\n')
audit['coverage']['CM_note_read_scope']='Full substantive note read from initial 104-line materialization; current byte-exact canonical copy has 103 newline-terminated lines after one added trailing newline was removed by parent. No substantive text changed.'
audit['conclusion']='All 81 normalized UI/CM records are reviewed for conditional-schema, open-obligation-reference or nondeductive-context registration. The raw r_delay serialization hold is resolved by its explicit separate protocol and state/update-only source import. No actual/phenomenal premise, QC issue or priority obligation is promoted or closed; source status and original records remain preserved.'
write_json(AUDIT,audit)
log['updated_review']={'path':str(AUDIT),'sha256':file_sha(AUDIT),'normalized_records_reviewed':81}

all_node_ids=set(base_by_id)|{r['id'] for r in normalized_records.values() if r['declaration_role'] not in {'CONDITIONAL_RULE_SCHEMA','NONDEDUCTIVE_CONTEXT'}}
missing=[]
for id_,rec in normalized_records.items():
    if rec['declaration_role']=='CONDITIONAL_RULE_SCHEMA':
        for ref in rec['all_of']+[rec['conclusion']]:
            if ref not in all_node_ids:
                missing.append({'rule':id_,'ref':ref})
assert not missing,missing
assert all(file_sha(SOURCE[m])==EXPECTED[m] for m in SOURCE)
log['validation']={'record_count':81,'missing_rule_references':missing,'source_file_hashes_unchanged':True,'source_status_preserved':True,'actual_or_qc_promotions':0,'scientific_programs_rerun':False,'descriptor_or_external_write':False}
write_json(WORK/'NORMALIZATION_UI_CM.json',log)
print(json.dumps({'files':[{'module':m['module'],'path':m['normalized_path'],'sha256':m['normalized_file_sha256'],'counts':m['counts']} for m in log['modules']],'manifest':str(WORK/'NORMALIZATION_UI_CM.json'),'manifest_sha256':file_sha(WORK/'NORMALIZATION_UI_CM.json'),'audit':str(AUDIT),'audit_sha256':file_sha(AUDIT),'records':81,'unreviewed':[]},ensure_ascii=False))
