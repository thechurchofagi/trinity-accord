"""Freeze review inputs and specify exact, non-promoting assembly; not the release builder."""
import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path('/workspace/scratch/328b6dbb55c2')
WORK=ROOT/'map_audit_work'
PROJ=ROOT/'uct/research/uct-agent-consciousness-workspace'
BASE=ROOT/'effective_v111'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def objsha(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def file_record(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def read(p):return json.loads(p.read_text())

# This metadata update states the completed delta review. Original per-ID findings stay intact.
p=WORK/'BASELINE_PER_ID_SEMANTIC_REVIEW.json'
d=read(p)
d['final_delta_review_status']='All six relevant modules fully reviewed: R185/HOM/R18770 items, UI/CM81 items, R18838 items; explicit effective normalizations complete. Two inherited effective corrections remain to be applied by the release builder. Final assembled-byte reconciliation is a separate gate.'
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
desc=WORK/'BASELINE_MODULE_DESCRIPTOR.json'
if not desc.exists():desc.write_bytes((PROJ/'UCT_FORMAL_GRAPH_MODULES.json').read_bytes())

baseline=read(BASE/'UCT_EFFECTIVE_GRAPH.json')
candidate=copy.deepcopy(baseline)
patch=read(WORK/'R173_EFFECTIVE_CORRECTION_PATCH.json')
assert sha(BASE/'UCT_EFFECTIVE_GRAPH.json')==patch['expected_baseline_file_sha256']
corrections=[]
for op in patch['operations']:
    n=next(x for x in candidate[op['collection']] if x['id']==op['id'])
    assert objsha(n)==op['expected_record_sha256']
    old=copy.deepcopy(n);n.update(op['set'])
    corrections.append({'id':n['id'],'collection':op['collection'],'before_sha256':objsha(old),'after_sha256_without_extra_release_metadata':objsha(n),'original_must_be_preserved':True})

order=['R185','HOM','UI20261009','CM20261009','R187','R188']
module_registry_ids={'R185':'R185','HOM':'R186-HOM-20261009','UI20261009':'UI20261009','CM20261009':'CM20261009','R187':'R187-CMA-20261009','R188':'R188-CER-20261009'}
modules=[]
for name in order:
    p=WORK/'normalized'/f'{name}.json';g=read(p)
    src=g.get('normalization_source',g.get('normalization',{}))
    srcpath=Path(src.get('path',src.get('source_file')))
    expected=src.get('sha256',src.get('source_file_sha256'))
    assert sha(srcpath)==expected,(name,'source hash')
    module={'module':name,'registry_id':module_registry_ids[name],'normalized':file_record(p),'original_source':file_record(srcpath),'counts':{k:len(g[k]) for k in ['nodes','rules','context_links']},'actual_or_phenomenal_premise_promotion':False,'preserve_normalized_record_objects_byte_semantically':True}
    modules.append(module)
    for key in ['nodes','rules','context_links']:candidate[key].extend(copy.deepcopy(g[key]))

expected_counts={key:len(candidate[key]) for key in ['nodes','rules','context_links']}
expected_counts.update(suspended_historical_rules=len(candidate['suspended_historical_rule_ids']),total=1608)
assert expected_counts=={'nodes':913,'rules':424,'context_links':261,'suspended_historical_rules':10,'total':1608}
arrays={k:[x['id'] for x in candidate[k]] for k in ['nodes','rules','context_links']}
allids=[i for xs in arrays.values() for i in xs]+candidate['suspended_historical_rule_ids']
assert len(allids)==1608 and len(set(allids))==1608
ns=set(arrays['nodes']);rs=set(arrays['rules'])
for name in order:
    for r in read(WORK/'normalized'/f'{name}.json')['rules']:
        assert all(x in ns for x in r['all_of']+[r['conclusion']]),r['id']

ledger_files=[
 ('baseline',WORK/'BASELINE_PER_ID_SEMANTIC_REVIEW.json','item_id','item_type',1419),
 ('R185_HOM_R187',WORK/'R185_HOM_R187_PER_ID_REVIEW.json','item_id','item_type',70),
 ('UI_CM',WORK/'UI_CM_REVIEW.json','id','record_type',81),
 ('R188',WORK/'R188_PER_ID_REVIEW.json','item_id','item_type',38),
]
ledger_specs=[];reviewids=[]
for label,p,idkey,typekey,count in ledger_files:
    d=read(p);assert len(d['items'])==count
    reviewids.extend(x[idkey] for x in d['items'])
    ledger_specs.append(dict(label=label,items_key='items',id_key=idkey,type_key=typekey,item_count=count,**file_record(p)))
assert len(reviewids)==1608 and set(reviewids)==set(allids)

read_notes=[
 PROJ/'records/R185_Cross_Scale_Relation_Membership_20261008/Cross_Scale_Relation_Membership_v0_1.md',
 PROJ/'records/R186_Higher_Order_Intervention_Masking_20261009/RESEARCH_NOTE.md',
 BASE/'pending_UI/RESEARCH_NOTE.md',
 PROJ/'records/CM20261009_Compensation_Observability/RESEARCH_CHECKPOINT.md',
 PROJ/'records/R187_Causal_Multiplicity_20261009/RESEARCH_NOTE.md',
 PROJ/'records/R188_Encoder_Access_and_Recovery_20261009/RESEARCH_NOTE.md',
]
records=PROJ/'records/R188_Encoder_Access_and_Recovery_20261009'
aux=[WORK/'R173_EFFECTIVE_CORRECTION_PATCH.json',WORK/'FAMILY_COMPATIBILITY_ASSESSMENTS.json',WORK/'NORMALIZATION_UI_CM.json',WORK/'UI_CM_REVIEW_REPORT.md',WORK/'WHOLE_MAP_SEMANTIC_REVIEW_REPORT.md',ROOT/'source_materialization_receipt.json']
spec={
 'schema':'uct-reviewed-effective-assembly-spec/1',
 'id':'R188-ASSEMBLY-UCT-MAP-v1.1.2',
 'created_utc':datetime.now(timezone.utc).isoformat(),
 'review_inputs_frozen':True,
 'release_target':'UCT-MAP-v1.1.2',
 'author_semantic_compatibility_review_completed':True,
 'actual_empirical_or_named_phenomenal_promotion':False,
 'independent_historical_proof_reexecution_claimed':False,
 'baseline':{'graph':file_record(BASE/'UCT_EFFECTIVE_GRAPH.json'),'old_ledger_archive_only':file_record(BASE/'REVIEW_LEDGER.json'),'canonical_descriptor_snapshot':file_record(desc)},
 'assembly_order':[
   {'step':0,'operation':'COPY_EXACT_BASELINE_GRAPH','instruction':'Preserve all inherited semantic objects and original source/proof annotations.'},
   {'step':1,'operation':'APPLY_TWO_SAME_ID_EFFECTIVE_CORRECTIONS','patch':file_record(WORK/'R173_EFFECTIVE_CORRECTION_PATCH.json'),'instruction':'Check per-record before hashes, preserve originals in correction history, apply set fields, keep BASE:CTX:169 unchanged. No suspended rule is activated.'},
   *[{'step':i+2,'operation':'APPEND_REVIEWED_CONDITIONAL_DECLARATIONS','module':m['module'],'path':m['normalized']['path'],'sha256':m['normalized']['sha256'],'counts':m['counts']} for i,m in enumerate(modules)],
   {'step':8,'operation':'UPDATE_RELEASE_METADATA_SEPARATELY','instruction':'Preserve source-era statuses and normalized objects; revision=v1.1.2. The old seven pending descriptor entries are retained in history; current unmerged list contains AC20261009 and IL20261009 only. Do not assert node presence is premise truth.'},
   {'step':9,'operation':'COMBINE_ALL_PER_ID_REVIEWS','instruction':'Use the four fresh review inputs below. Preserve original findings and record the two local R173 corrections as applied only after verification. Reclassify suspended IDs as historical nonexecutable rows, never active rules.'}
 ],
 'modules':modules,
 'ledger_inputs':ledger_specs,
 'correction_record_expectations':corrections,
 'expected_counts':expected_counts,
 'expected_id_inventories':dict(**arrays,suspended_historical_rules=candidate['suspended_historical_rule_ids']),
 'expected_record_hashes_without_added_release_metadata':{key:{n['id']:objsha(n) for n in candidate[key]} for key in ['nodes','rules','context_links']},
 'record_hash_scheme':'SHA256 of UTF-8 json.dumps(record,sort_keys=True,ensure_ascii=False,separators=(comma,colon)). Whole-file hashes refer to exact bytes. Do not confuse these hash schemes.',
 'typed_new_module_context_sources':[{'context_id':'R187:ctx_r186','source':'R186-HOM-20261009','source_type':'module','target':'R187:DURATION_LIMIT'},{'context_id':'R187:ctx_ol','source':'OL20261009','source_type':'module','target':'R187:NOISE_SEPARATION'}],
 'inherited_context_resolution':'Retain inherited EI source-import, TH/RB external and RU module reference typing. These are not missing node IDs and must not become deductive premise edges.',
 'remaining_pending_modules':[x for x in read(desc)['pending_checkpoints'] if x['id'] in ['AC20261009','IL20261009']],
 'unreviewed_effective_item_ids':[],
 'excluded_source_bodies_not_read':['AC20261009','IL20261009'],
 'open_status_invariants':['No reviewer-controlled finding closed.','QC10,IA-QC11,QC12,QC13 remain OPEN.','Actual tokenhood, physical access/ports/timing/signature and named experiential application remain OPEN.','C1/U1/P3 remain inherited commitments; finite communication or monitoring is not an experience gate.','Exact external priority remains UNVERIFIED; no publication action authorized.'],
 'full_available_notes_read':[file_record(p) for p in read_notes],
 'evidence_and_governance_read_scope':[file_record(p) for p in [PROJ/'AGENTS.md',PROJ/'RESEARCH_MASTER_GUIDE.md',PROJ/'FORMAL_MAP_REVIEW_POLICY.json',records/'INDEPENDENT_PROTOCOL_REVIEW.md',records/'EXACT_RESULTS.json',records/'PROCESS_RESULTS.json']],
 'auxiliary_audit_inputs':[file_record(p) for p in aux],
 'final_assembled_crosscheck_status':'PENDING_ROOT_BUILDER_OUTPUT; save an additional validation receipt without editing these frozen review inputs.'
}
out=WORK/'ASSEMBLY_SPEC.json';out.write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
(WORK/'ASSEMBLY_SPEC.sha256').write_text(sha(out)+'  ASSEMBLY_SPEC.json\n')
print(json.dumps({'assembly_spec':file_record(out),'counts':expected_counts,'modules':[{m['module']:m['normalized']['sha256']} for m in modules]},ensure_ascii=False))
