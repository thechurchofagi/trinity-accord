"""Serialize the semantic reading completed in the map_audit agent.

This script does not perform the review. It records the item contracts actually
read, and attaches the separately authored semantic assessments below. Review
means compatibility of statements and dependencies, not premise truth.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/328b6dbb55c2')
WORK = ROOT / 'map_audit_work'
BASE = ROOT / 'effective_v111/UCT_EFFECTIVE_GRAPH.json'
GRAPH = json.loads(BASE.read_text())
OLD_LEDGER = json.loads((BASE.parent / 'REVIEW_LEDGER.json').read_text())
OLD = {r['item_id']: r for r in OLD_LEDGER['items']}

def digest(x):
    return hashlib.sha256(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

# Written after reading all effective node/rule/context semantic packets.
# These assessments state the actual compatibility test for each subject family;
# each serialized row also retains that individual item's statement, scope,
# premises, proof/limit annotations and pending obligations.
FAMILY = {
 'A': 'The full tokenwise C1 signature and independently admitted actuality govern these claims. A restricted decoder, finite observation, fitted chart or common-encoder score cannot substitute for complete structural equivalence. Nonempty experience follows only through the inherited actual-token ontology and U1; neither a communication failure nor a graph coloring obstruction introduces a new experience gate. Product, symmetry, continuity and macro/local claims retain their own additional hypotheses.',
 'B': 'Finite typed translation describes the declared mechanism only after its vocabulary, bridge and target-faithfulness conditions. An encoder information restriction is an additional operational constraint, not a proof that any rival consciousness theory has been reduced. The nine rival-specific bridges remain separately conditional, and recurrence/dynamic stability calculations remain distinct from basal experience and empirical fidelity.',
 'C': 'The capability functional is fixed on one task, policy, resource, time and port contract. A change in maximum attainable recovery can enter P1 only after actual complete-type grounding. P2 fiber recovery, P7 common optimal actions, joint law versus marginal information, and scalar nonordering already cover much of the proposed motivation. Context-specific optimization cannot silently replace the single admissible policy required by these contracts.',
 'R126': 'A transported arbitrary projection is not an actual support selector. Deterministic closure requires successor and output constancy on the same fibers; metric diameter gives a necessary error bound, and refinement begins with the joint declared observation. Encoder-context constraints do not change this closure theorem or turn informational equivalence into actual token identity.',
 'R127': 'The exact task theorem uses one prequery encoder and all supported answer requirements. Its full Cartesian task setup differs from decoder side information that rules out source-context pairs. Mediation uses the joint cut including B, and Fano bounds require the same recovery law. These are direct inherited antecedents, so fresh challenge and min-entropy arguments are not new results. Neither observed recovery nor event-support definitions certify actual lineage.',
 'N128': 'Marginal stochastic closure need not give joint closure. The hidden coupling witness and the joint row-sum criterion retain their finite kernel and common operation assumptions. A common-encoder obstruction concerns feasible encoding across exclusive contexts; it is compatible with, but does not re-prove or replace, this joint-kernel obstruction.',
 'D': 'The declared continuation/task/payoff standard distinguishes bearer, actual control, estimates, reward and valence. Rank and payoff countermodels concern their stipulated logits and joint probability laws; finite grids require a separate regularity bound. New communication tasks supply no actual shutdown-control, fear, valence or named experience evidence.',
 'R131': 'Linear expected-probe completeness means full row rank including normalization. A deficient interface admits distinct laws, while decision sufficiency can require less than full law identification. The new finite encoder budget is a different resource restriction; it must not borrow actual-kernel closure or physiological fidelity from these algebraic probe results.',
 'R132': 'Shared scheduling, exact enabledness and joint next-summary/output laws are all part of the model. The Hall bottleneck already proves local feasibility need not imply simultaneous feasibility, and its higher-order witness is inherited. Exclusive decoder contexts are not simultaneous task requests, but both demand one legally implementable organization rather than pasted coordinate optima.',
 'R133': 'All decision cells require a common successful action, and persistent-model policies may not switch hidden models across time. MESSAGE_COVER already characterizes an ideal arbitrary encoder by a cover of good-action sets. Taking a to be a complete decoder table and m to be the source value makes zero-error confusability coloring an exact specialization of this existing theorem; it is not a new general characterization. Probe cost and surviving action opportunities remain part of the chosen model.',
 'R134': 'The profile recursion keeps one policy vector across all hidden states, and finite minimax/LP duality optimizes those attainable vectors. The false coordinatewise (1,1) profile is a direct predecessor of the encoder quantifier issue. Zero error permits purification; finite-error mixtures are already represented. Any new feedback formula must compare its actual policy class with this common-policy discipline.',
 'R135': 'A common target profile, not independent per-coordinate optima, defines directed guarantee loss. The common legal policy and payoff class are needed for coupling and transfer; hard enabledness may change discontinuously. Equal robust scalar scores, equal guarantee regions and equal exact profiles remain different claims. The new decoder task can instantiate fixed-J only under these same-contract safeguards.',
 'R136': 'Blackwell comparison assumes one common channel garbling, and causal simulation additionally enforces prefix nonanticipation. The late-query and delayed-read examples already separate offline information from executable timely access. A side-information-aware helper cannot be used as a source-only encoder without counting the missing context path. Feedback labels and their chronology must be explicit.',
 'R137': 'A legal randomized decoder is one common simplex vector on each visible fiber, including illegal-action zeros and the full joint next-state/output row. Helly and forbidden-action witnesses already address local-to-global compatibility. Shared versus fresh seeds change path laws despite equal marginals. These rules preclude hidden-state-aware or context-aware implementation being assumed merely from a pointwise optimum.',
 'R145': 'Logical feedback equivalence is restricted to descending operations; the diagnostic reset deliberately leaves that class. The affine rank witness and labeled/full primitive nonisomorphism are different statements. Decoder-context changes are operational changes, so they cannot be treated as passive recoding or as proof that equal outputs identify installed parts.',
 'R146': 'Equivariant centered reference is possible without an uncentered unique owner. Exact local prediction and external duplicate-label guessing separate under an independently sampled label. Self-target decoder sufficiency remains target-relative and does not establish source identity, anatomy or subjective mineness. Communication limits cannot count subjects.',
 'R147': 'The complete route map retains beta as well as sensorimotor permutations. Equal tau-inverse-sigma response laws do not identify attachment; synchronized commands can conceal swaps. Memory-only isolation leaves routing unchanged, whereas active consumer rewiring does not. New recovery contrasts must keep actual source occurrence and type equality separate.',
 'TA15': 'The frozen earlier source provides typed composition, factorization and observational nonidentification with declared domains and error hypotheses. These are inherited mathematics, not an originality increment. A new decoder-table application may cite the fiber result while retaining the same-target and same-observation contract.',
 'TA16': 'The finite cut/path, recoding and wrapper statements concern selected functional structure. Their historical RRH whole-target gate is not an allowed basal-experience necessity under current U1. Incompatible modes cannot jointly witness separate maxima; the new encoder-access issue reinforces rather than removes that restriction.',
 'TA17': 'Functional descendant sets, mutual information, source intervention and occurrence identity are distinct. Shared-upstream dependence does not prove current-process descent, and singleton summaries do not identify joint successor sets. Communication recovery therefore cannot infer event numerosity or membership conservation, and set-valued inheritance is not an additive amount of experience.',
 'TA18': 'The frozen selected-germ theory retains its explicit pair-separation, isomorphism and null-equivalence bridges. Its unrestricted type-valued bridge countermodel is not simultaneously a countermodel to current complete C1-OI. A restricted decoder target may factor through a coarser representation while complete experiential type does not.',
 'TA19': 'Local automorphism and monodromy obstructions concern equivariant singleton selectors or continuous sections, with their stated finite/topological hypotheses. They do not forbid centered reference, require exclusion of actual overlapping tokens, or determine their subject count. A coloring obstruction to one encoder is a different compatibility problem.',
 'R149': 'C1-OI makes complete experiential and complete structural type kernels coincide. A selected representation suffices for complete experience only if it reflects the complete type; weaker target sufficiency has weaker fibers. The new operational recovery result cannot erase the actual-bridge premise or claim new general fiber mathematics.',
 'R155': 'The finite Bayes updater separates installed attribution, external latent truth, threshold consumers and independently interpreted mineness. Its all-positive likelihoods allow mistaken attribution; unbounded exact posteriors cannot be held by a finite fixed-readout state. A better distributed decoder does not identify the named target left open here.',
 'R156': 'Matched snapshots omit the installation parameter that controls intervention-dependent use. The explicit two-entry response table identifies only functional R, not F_O. This supports declaring the new encoder access path but provides no semantic bridge from recovery accuracy to mineness.',
 'R157': 'Formula transport is valid for a grounded K-formula, correctly sorted actual carriers and every transported physical parameter. Definability is not autonomous substructure, a partial report measure has no values on nonreporters, and external phenomenal names remain undetermined. No new encoding witness discharges B_min.',
 'R158': 'A necessary-conjunct rejection requires an independently admitted target-positive witness; abstract bit assignment is insufficient. The definable-set counterexample separates formula preservation from closure under functions. Ownership and agency targets are separately fixed and may overlap, so the repaired R173 claim must retain distinction without Boolean independence.',
 'R159': 'Anchor, binding, internal frame and external referent are separately grounded. The same-instance structural relation transports even if the externally interpreted anatomical assignment is false, but no familiar ownership name follows. A shared decoder message is not by itself an actual body-frame relation.',
 'R160': 'The four-way intervention profile is defined only after independently grounded ports, metrics, error bounds and complete estimands. Cross-trial contrasts are not automatically a relation within one token or a common h across tokens. Missing/undefined effects cannot be treated as zeros; the new finite comparison supplies none of these trial bridges.',
 'R161': 'All six physical/measurement fidelity gates precede profile classification, and confirm/exclude/unresolved use one simultaneous interval family. A communication demonstration cannot serve as participant evidence or a substitute for those gates. These statistical decisions do not entail actual experiential interpretation.',
 'R162': 'Unpaired component datasets leave cross covariance unidentified. Independent pilot freezing preserves coverage only with the explicitly planwise conditional coverage premise and unchanged target. Decoder side-information geometry is unrelated to that sampling premise and must not be counted as its discharge.',
 'R163': 'Bounded finite-design outcomes, independent participant vectors and defined would-be outcomes determine the finite-sample/missingness claims. Clipped observations and randomized-order mixture targets remain distinct from latent or canonical targets. All formal probability conclusions remain conditional; no data or actual human application is provided by the increment.',
 'R164': 'Constant component bets preserve the unweighted mean target; predictable residuals and independent pilot selection remain explicit. Rare-spike and endpoint-missingness limits are unchanged by a coding model. Variance adaptation refines sampling uncertainty, not the identification region or tokenwise phenomenal evidence.',
 'R165': 'Finite-menu plan selection, residual transport and width-feasibility certification have different assumptions and error budgets. Invalid protocol, inconclusive pilot, menu infeasibility and confirmatory unresolved remain different states. A valid finite decoder construction has no bearing on physical apparatus feasibility or the named-experience bridge.',
 'R166': 'An actual installation requires one bearer/interval/signature, sorted occurrences, independent grounding and valid causal path discrimination. Population evidence and a finite trace cannot fill a missing token clause. The new mathematical encoder may be implementable in a model while no actual K-level experiential relation has been admitted.',
 'R167': 'Use must be assessed relative to declared backup contexts and compensation timing on one lineage. A single null cut can hide redundancy; later compensation is not evidence that an earlier path was absent. A common encoder/access contract can refine a concrete communication path but does not replace all R166 W1-W6 obligations.',
 'R168': 'Amplitude, context mass and observation-fiber coverage are distinct quantifiers. A lifted envelope requires actual hidden-context geometry and certified regularity; finite random no-hit evidence yields only a measure claim. Decoder-context restrictions do not justify universal physical coverage or a new experience threshold.',
 'R169': 'Local channel budgets compose on an independently inventoried actual route graph. Metric scale gauges, unknown fibers and held-out calibration are separately controlled. The new graph of source confusability is not this graph of physical routes and cannot supply its missing actual inventory or calibration.',
 'R170': 'A nonempty unresolved domain retains the global amplitude cap even at zero or tiny measure. Mean and exceedance bounds use a fixed independent measure; closure and mass certificates are different states. Finite coding completeness within its declared source-context class does not close a physical open-world remainder.',
 'R171': 'Direct and reachable proofs are alternative instance routes. The triage and four-domain synthesis only combine available schemas; effective application rules require the selected route actually discharged. The fitted-cover nonentailment retains its two admitted completion worlds; a proper observed subset alone is not enough. No new map audit self-certifies those external obligations.',
 'R172': 'Component certificates require actual interface compatibility and a separately grounded evidence-to-role bridge. Effective rules retain explicit frame/local/compatibility/certification/role/same-binding obligations and application OPEN. A local decoder existing in each context cannot be pasted into an actually installed common encoder; this is a related application, not proof of an old missing bridge.',
 'R173': 'The effective R175/R176 overrides govern: familiar targets are distinct, baseline admission yields AgencyLoop implies Avail, and a history twin needs its explicit admitted domain. Raw eight-way organizational independence is withdrawn; even all-six realizability remains open. Retentive formula transport requires the complete same-instance actual history/path package and does not identify F_F.',
 'TE20261008': 'Selected reduct isomorphism, complete type and actual token ancestry are different targets. Retiming must scale all relevant dynamics/delays, and relay subdivision preserves only the stated old-endpoint reachability and faithful values. Image-cardinality gain is selected capacity, not experience richness or a new current-history force.',
 'TO20261008': 'Reference rerouting can preserve reports while changing a separately specified nonreport consumer. Exact global clock coordinates require all cycle sums to vanish; a nonzero cycle does not always force a sign cycle. These established local/global constraints motivate but do not derive decoder coloring, and no temporal experience name is identified.',
 'R174': 'The S/C/H mediator-clamp signature separates only its declared rival class. An admitted untested context-gated bypass blocks unrestricted closure. Actual shared-coordinate transport excludes analyst evidence and retains the fixed temporal-order bridge and measurement obligations. New communication recovery does not close B_order.',
 'BR20261008': 'Added roles refine automorphism orbits but proper subgroup inclusion need not split every orbit. Joint anchor satisfaction requires one common map, not separately compatible maps. The actual grounded restriction and independently interpreted phenomenal anchors are essential; uniqueness in a bare graph supplies no named feeling. Exact role count is not a calibrated richness measure.',
 'R175': 'The effective repairs reject both eight semantic rows and an unsupported all-six realization. The explicit twin-domain premise is separate from the target definitions. Orientation anchors select a correspondence between supplied full chains; R176 forbids interpreting that completion as a newly identified held-out named content.',
 'R176': 'Partial endpoint data leave named order undetermined, and delayed causal use may reverse a selected use relation without reversing production. Effective orientation and present-slice replacements narrow historical statements. This correction must remain effective even when older descriptive node IDs contain held-out or twin language.',
 'IA20261008': 'Post-outcome rank matching fits every order and has no fixed-target predictive content. A genuine holdout must be independent of background closure and retain one predeclared identity map. Trace identity is causal ancestry with actual source parameters, not output rank or target decoding success; its phenomenal transport remains conditional.',
 'R177': 'Inverse-compensated stateless feature recoding preserves the displayed feature but not numerical source identity. The joint source/use/feature signature compares alternative circuits and does not require them to coexist in one installation. The new decoder result similarly must distinguish recovered value, current source and executing consumer.',
 'CORE20261008': 'Finite successful supports have minimal members; their common intersection need not succeed. A unique least support and hitting-set duality need their own finite/nonempty/monotone assumptions, while single-cut irreducibility is weaker under nonmonotonicity. Prior CG gluing already demands shared occurrence identity, actual interface compatibility and primitive coverage; none implies a common information-limited encoder is available.',
 'EI20261008': 'The arithmetic witnesses separate intact performance from the actual route supporting a target. Complete profile identification and one-query accuracy are distinct and already yield counting bounds. Support enumeration is protocol-specific; actual structural interpretation and a named-target bridge remain additional premises.',
 'R183': 'Individual unavoidable relevance is the intersection of minimal supports; redundant routes require a disjunctive condition. A deletion-only monotone criterion does not govern every intervention. The actual P/I/K/target/route package is not supplied by enumerating 167 finite families, and the named-feeling bridge stays open.',
 'OO20261008': 'Linear rowspace recoverability, nonlinear Walsh performance and noisy channel recoding use different admitted code classes. More unrestricted source access cannot hurt, but equal code dimension or entropy does not order every task. Query-return precision requires retained source, reverse communication and timing. Pending checkpoint flags and guarded actual C1 applications remain unchanged.',
 'RU20261008': 'Mean-optimal one-bit codes can have a reliability ceiling that matters under selection and loss. Calibration, coverage, abstention and wiring to the correct answer target are distinct. The common-encoder extension can add another admissibility axis without contradicting these posterior calculations or identifying subjective confidence. Pending source states remain pending.',
 'R184': 'Resumption uses the actually retained, target-discriminating carrier after obstruction. M/Q deletion supports and conflicting-content interventions are different protocols; intact matching hides priority. Reflex/deliberate labels do not identify named feelings. Both individual and disjunctive experiential routes retain separately grounded actual target/route premises.',
 'RC20261008': 'Point coherence fixes a global character table and therefore changes the attainable parity score/message budget. A posterior is normalized on possible worlds even if its separate hard modes conflict. Shared versus fresh candidate paths agree marginally but differ jointly; giving the full triple to the commitment rule changes context access. These are direct inherited boundaries for the new context-blind encoder example, with pending scientific premise flags retained.',
 'IE': 'A fixed actual complete organization cannot be assigned empty experience under C1/U1. Role and compensation examples are functional. Exact late-query answers require encoding the joint answer vector in its full task domain; early disclosure changes that domain. The new side-information graph is not a new general fiber theorem and does not establish a biological/silicon experience contrast.',
 'TH20261009': 'Information can migrate between registers while endpoint marginals match. Uniform linear recovery depends on the complete source/nuisance cut, and data processing needs fresh independent randomness. Stored recoverability, installed readout, duplicate XOR cancellation and source occurrence are distinct. These are inherited results, not a new random-challenge discovery; actual and named-target bridges remain open.',
 'RB20261009': 'The top-K bound already includes nonuniform sources, deadline transcript cardinality, keys, inverse limits and TV robustness. Its sharpness theorem explicitly enlarges the helper to observe both T and X. A source-only encoder remains subject to the upper bound but need not attain it. Silence, timing, identity and feedback are information paths and must be counted; the new contribution can quantify this implementation gap without correcting the valid bound.',
 'OL20261009': 'The finite LTI result fixes actual primitive write families, source kick, observability horizon and Q metric. Projection onto admitted write-image subspaces is not a source-message guessing problem. Passive coordinates must transport those primitive ports; physical compensation changes the question. A score gap alone is not fixed-J maximal capability or actual complete nonisomorphism, and local experience/agency boundaries remain open.',
}

SPECIAL = {
 'R173:THREE_TARGET_SEPARATION': 'CORRECTION REQUIRED: the raw effective statement still asserts realization of all eight organizational valuations. This conflicts with R175:BASELINE_ADMITTED_ACTION_DOMAIN and R175:SIX_ROW_EVENT_MODELS, which force G=>A and only an at-most-six bound. Preserve the historical eight-row Boolean enumeration, replace the effective reading with distinct partial semantic targets, and retain all-six realization OPEN. No active rule uses this node; CTX143 needs a scoped wording amendment and CTX169 must remain.',
 'BASE:CTX:143': 'CORRECTION REQUIRED: retain this as context about three separately fixed targets only. Its source node may not export the withdrawn eight-way independence to R158:TARGET_SPLIT. The repaired wording explicitly excludes both eight-way semantic independence and an all-six realizability claim.',
 'BASE:CTX:169': 'Retain the explicit review-corrected-by relation. It is the historical override link from the stale raw R173 node to the governing R175 target-separation correction; it is not a deductive rule or an independently closed reviewer finding.',
 'RB20261009:HELPER': 'Direct nonduplication anchor: the encoder is explicitly allowed to inspect BOTH T and X. Its achievability class is an enlarged hypothetical helper class. The proposed source-only model removes X from the encoder information set; it must not assert that the inherited theorem made an unqualified physical achievability claim.',
 'RB20261009:TIGHT': 'Keep this theorem unchanged. The top-K construction is sharp under HELPER, which has T and X, and not for every physical K-symbol channel. A gap for one source-only encoder is compatible and supplies a new quantified specialization, not a refutation of this sharpness theorem.',
 'RB20261009:r_tight': 'All six premises, especially HELPER, are conjunctive. The same P_TX and K must be used, and the optimization is only over the explicitly enlarged helper class. Dropping HELPER invalidates the intended application, not the existing conditional theorem.',
 'R133:MESSAGE_COVER': 'Strongest internal antecedent. Set m=T and let an action a be a complete decoder table X->T. Sources that can share one message are exactly those admitted in one action-cover set; for pair contexts these are independent sets of the confusability graph. Thus min-message graph coloring is already an exact specialization. Any paper must credit this route and locate its increment in a stronger finite-error/feedback formula or a distinct organizational comparison.',
 'r133_cover': 'The cover lower bound and matching encoder are valid with one arbitrary deterministic h(m) and ideal source access. Instantiating decoded actions as entire decoder tables derives the source-only zero-error graph result. Feedback and finite error require their own changed protocol/optimization proof; they do not establish a new general message-cover theorem.',
 'R127:TASK': 'The task f:H×Q->Y is required on the full declared product. In a side-information model, impossible (T,X) pairs remove constraints, so counting full Cartesian response profiles can overstate the needed code alphabet. Declare the support relation before deriving graph confusability.',
 'IE:QUERY_SPEC': 'The old query is independently chosen after encoding and has the full admitted task set. It must not be silently replaced by side information correlated with T; the support restriction is a substantive protocol change.',
 'C:P7': 'The equality condition already quantifies a common optimal action within each supported X cell. It is the decision-side predecessor of the proposed encoder quantifier obstruction, although it does not by itself supply the new feedback MaxCut formula.',
 'R136:TASK_ORDER': 'This already states that each pre-announced task can be perfectly solved while the delayed-query common resource cannot. The new side-information witness must acknowledge that generic local/global access lesson as inherited.',
 'R137:LOCAL_LP': 'The feasible decoder is one point in the intersection of all compatible-state constraint sets. The prospective source-only encoder is likewise one implementation across contexts; pointwise existence does not supply that intersection.',
 'R171:FITTED_COVER_NONENTAILMENT': 'The updated effective statement and explicit instance obligations require two admitted worlds agreeing on the sample. Read the retained shorter historical quantifier only under that full conjunction; proper F alone does not force the witness in a restricted hypothesis class.',
 'r171_four_domain_application': 'The two closure nodes are theorem schemas in this synthesis, not requirements that both direct and reachable certificates hold at one actual target. Actual inference uses the two separate effective replacement routes with typed discharge obligations.',
 'r171_range_certificate_triage': 'This collects available proof/countermodel schemas into seven status cases. It does not require both instance certificates, and its existence does not certify any chosen case. Preserve the later effective direct/reachable alternatives.',
 'R175:SIX_ROW_EVENT_MODELS': 'Retain at-most-six valuations under G=>A. Filtering two rows from a Boolean table is not construction of all six semantic event models; the explicit UPPER_BOUND_ONLY_SEMANTIC_REALIZATION_OPEN status is essential.',
 'R175:HELD_OUT_ORDER_PREDICTION': 'Use only the R176 effective reading: oriented anchors select the increasing correspondence between full supplied chains. This is not a new named-content prediction, and IA fixed-target/holdout obligations remain open.',
 'CORE20261008:PRIOR_CG_R': 'Joint realizability and complete primitive coverage are preconditions to coherent gluing. Merely matching each pair of source values or each local context response does not build a common actual encoder. This is overlap in the compatibility principle, not a derivation of the feedback value formula.',
 'OL20261009:ctx_capacity': 'Keep the explicit warning that a finite intervention residual is not automatically a difference of fixed-J maximal task capability. A later recovery task may define such a J only after its policy, resource and physical realization contracts are fixed.',
}

SUSPENDED = {
 'r171_range_application_boundary': 'Preserve suspension. The historical AND of both closure routes did not express one selected discharged instance certificate. The effective direct and reachable replacement rules are separate OR alternatives and each retains typed actual-application obligations.',
 'r172_witnessed_online_action_use': 'Preserve suspension. Frame installation plus a composition schema does not establish the actual evidence-to-role implication. The effective rule adds frame_instance, local_instance, compat_instance, cert_positive, role_bridge and same_binding; application remains OPEN.',
 'r172_experience_internal_action_coordinate': 'Preserve suspension. Formula transport requires the witnessed actual path, C1 instance, K grounding, sorted witnesses and parameter transport together. Use only its effective replacement; a certificate itself is not transported into experience.',
 'r172_bio_ai_application_boundary': 'Preserve suspension. Both bearers need their separately corrected actual applications and a common comparison signature. The effective replacement supplies these obligations and preserves semantic residual and application OPEN.',
 'r173_history_twin_witness': 'Preserve suspension. Definitions of Avail, AgencyLoop and RetBind do not construct an admitted pair of histories. R175:EXPLICIT_TWIN_DOMAIN and r175_r173_history_twin_effective are the conditional replacement.',
 'r173_familiar_mineness_boundary': 'Preserve suspension. This route used the raw eight-way target-separation node. The effective replacement uses R175:R173_EFFECTIVE_TARGET_SEPARATION and R157 semantic residual, without organizational Boolean independence.',
 'r175_orientation_forces_heldout': 'Preserve suspension. The endpoint/rank argument identifies a correspondence between already supplied full chains. r176_orientation_correspondence_completion retains this valid result while withdrawing an unearned new named-content holdout.',
 'r175_b_order_narrowed': 'Preserve suspension. Its purported positive held-out constraint did not establish a new named target. No actual B_order or semantic bridge is reinstated by the new coding analysis.',
 'r175_r173_six_row_effective': 'Preserve suspension. Baseline admission excludes G=1,A=0 but does not construct semantic realizations for all other rows. The retained node states only at most six valuations and explicitly leaves realization OPEN.',
 'r173_present_slice_nonidentification': 'Preserve suspension. The earlier premise referred to an unconstructed history twin. r176_present_slice_effective uses the explicitly admitted R175 pair and concludes only organizational RetBind nonrecovery, not a named phenomenal target.',
}

def contracts(n):
    return {k:v for k,v in n.items() if k.startswith('formal_contract')}

def obligations(n):
    found = set(n.get('instance_obligations', []))
    for c in contracts(n).values():
        if isinstance(c, dict):
            found.update(c.get('open_obligations', []))
    return sorted(found)

def semantic_snapshot(n):
    skip = {'origin_file', 'origin_module', 'source_record_sha256', 'source_sha256'}
    return {k:v for k,v in n.items() if k not in skip}

def endpoints(c):
    return (c.get('from', c.get('source', c.get('from_id'))), c.get('to', c.get('target', c.get('to_id'))))

def family_for(item, kind):
    if kind == 'node': return item['id'].split(':')[0]
    if kind == 'rule': return item['conclusion'].split(':')[0]
    a,b = endpoints(item)
    p = (b or '').split(':')[0]
    return p if p in FAMILY else (a or '').split(':')[0]

rows = []
for kind,key in [('node','nodes'),('rule','rules'),('context','context_links')]:
    for n in GRAPH[key]:
        nid=n['id']; f=family_for(n,kind)
        previous=OLD.get(nid,{})
        stmt=n.get('statement',n.get('relation', n.get('proof', '')))
        if not stmt and kind=='rule':
            stmt=next(x['statement'] for x in GRAPH['nodes'] if x['id']==n['conclusion'])
        review={
          'individual_semantic_content_read':stmt,
          'individual_scope_read':n.get('scope',n.get('binding',n.get('domain',previous.get('scope')))),
          'all_of_read':n.get('all_of',[]),
          'conclusion_read':n.get('conclusion'),
          'proof_or_argument_read':n.get('proof',n.get('proof_sketch',n.get('proof_location'))),
          'limits_read':{k:v for k,v in n.items() if k in ('limits','counterexamples_and_limits','caveats','excluded_inferences','boundary')},
          'family_compatibility_assessment':FAMILY.get(f,'This is an explicitly typed nondeductive source/module reference, not a proof premise.'),
          'targeted_item_assessment':SPECIAL.get(nid),
        }
        if kind=='context':
            a,b=endpoints(n)
            review['individual_link_assessment']={
              'source':a,'target':b,'declared_relation':n.get('relation',n.get('kind')),
              'allowed_use':'Attribution, scope, historical correction or motivation exactly as declared; no logical entailment or premise discharge.',
              'deductive_flag_checked':n.get('deductive') is False,
              'external_source_status':n.get('external_source',n.get('from_type') in ('source_reference','module_reference')),
            }
        if kind=='rule':
            review['individual_route_assessment']={
              'premise_semantics':'All displayed premises and external obligations must hold at one instance; alternatives remain separate rules.',
              'source_bindings':{k:v for k,v in n.items() if k in ('binding','semantic_binding','bindings_required','comparison_bindings','instance_obligations','premise_mode','may_infer')},
              'actual_application_status_preserved':n.get('actual_application_status'),
            }
        outcome='COMPATIBILITY_REVIEW_COMPLETED_WITH_STATED_LIMITS'
        if nid in ('R173:THREE_TARGET_SEPARATION','BASE:CTX:143'): outcome='EFFECTIVE_SCOPE_CORRECTION_REQUIRED'
        rows.append({
          'item_id':nid,'item_type':kind,'baseline_record_sha256':digest(n),
          'source_annotation_sha256_preserved':n.get('source_record_sha256',previous.get('source_record_sha256')),
          'source_status_preserved':{k:v for k,v in n.items() if k in ('status','effective_status','source_checkpoint_status','enabled_as_established_premise','actual_application_status')},
          'review_outcome':outcome,'review_scope':'Effective contract compatibility, read per item; not independent re-proof of every historical source argument.',
          'assessment':review,'open_obligations_preserved':obligations(n),
          'effective_record_read':semantic_snapshot(n),
          'historical_proofs_independently_reproved':False,
          'actual_or_named_phenomenal_premise_discharged':False,
          'reviewer_controlled_status_changed':False,
        })

for nid in GRAPH['suspended_historical_rule_ids']:
    old=OLD[nid]
    rows.append({
      'item_id':nid,'item_type':'suspended_historical_rule','review_outcome':'RETAIN_SUSPENDED_NONEXECUTABLE',
      'source_annotation_sha256_preserved':old.get('source_record_sha256'),
      'historical_statement_read':old.get('effective_statement'),
      'historical_premises_read':old.get('premise_ids'),
      'review_reason':SUSPENDED[nid],
      'active_inference_permitted':False,'historical_proofs_independently_reproved':False,
      'actual_or_named_phenomenal_premise_discharged':False,'reviewer_controlled_status_changed':False,
    })

descriptor=ROOT/'uct/research/uct-agent-consciousness-workspace/UCT_FORMAL_GRAPH_MODULES.json'
desc=json.loads(descriptor.read_text()) if descriptor.exists() else None
metadata={
 'schema':'UCT_SEMANTIC_COMPATIBILITY_REVIEW_V1',
 'audit_id':'R188_MAP_AUDIT_BASELINE_20261009',
 'baseline_path':str(BASE),'baseline_file_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),
 'baseline_version':GRAPH.get('version'),
 'coverage':{'nodes':804,'active_rules':377,'nondeductive_context_links':228,'suspended_historical_rules':10,'total':1419,'unread_effective_item_ids':[]},
 'review_method':'All effective statements, definitions/scopes, proof/limit annotations, rule all_of premises and bindings, context meanings and open-obligation annotations were read in model-visible packets. Serialization was programmatic only after that reading. Family assessments state shared substantive compatibility conditions; each row preserves its individual semantic object and targeted corrections. This is not a mechanical census or automatic theorem proving.',
 'reading_packets':sorted(p.name for p in WORK.glob('compact_nodes_*.jsonl'))+sorted(p.name for p in WORK.glob('rules_*.jsonl'))+sorted(p.name for p in WORK.glob('contexts_*.jsonl')),
 'historical_source_reproof_scope':'Not every archived source paper/proof/empirical dataset was independently re-read or rerun. Root source papers are separately handled by the main agent. Open external physical/semantic obligations remain open.',
 'final_delta_review_status':'R188 final extension awaited; five relevant pending modules under separate full-text/per-ID review.',
 'global_consistency_or_empirical_validation_claimed':False,'scientific_promotion_permitted_by_this_audit':False,
 'corrections_required':['R173:THREE_TARGET_SEPARATION','BASE:CTX:143'],
 'reporting_correction':'The prior ledger called suspended IDs ordinary rules with carry-forward compatibility. This ledger explicitly marks all ten as nonexecutable historical rules.',
 'pending_descriptor_preserved':desc,
 'pending_effective_graph_list_is_stale':GRAPH.get('pending_not_loaded'),
 'current_pending_checkpoint_ids':[p['id'] for p in (desc or {}).get('pending_checkpoints',[])],
 'reviewer_statuses_preserved':{'QC08':'RESOLVED_SCOPED_EFFECTIVE','QC09':'RESOLVED_SCOPED_EFFECTIVE','QC10':'ACKNOWLEDGED_OPEN','IA-QC11':'APPLICATION_OPEN','QC12':'MODEL_SCOPE_REPAIRED_APPLICATION_OPEN','QC13':'OPEN'},
 'items':rows,
}
assert len(rows)==1419 and len({r['item_id'] for r in rows})==1419
WORK.joinpath('BASELINE_PER_ID_SEMANTIC_REVIEW.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
WORK.joinpath('FAMILY_COMPATIBILITY_ASSESSMENTS.json').write_text(json.dumps(FAMILY,ensure_ascii=False,indent=2)+'\n')

node=next(n for n in GRAPH['nodes'] if n['id']=='R173:THREE_TARGET_SEPARATION')
ctx=next(n for n in GRAPH['context_links'] if n['id']=='BASE:CTX:143')
correction={
 'audit_id':'R188_R173_EFFECTIVE_SCOPE_REPAIR',
 'classification':'CORRECTION_OF_EFFECTIVE_READOUT_NOT_NEW_SCIENTIFIC_RESULT',
 'expected_baseline_file_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),
 'operations':[
  {'collection':'nodes','id':node['id'],'expected_record_sha256':digest(node),
   'preserve_original_record_in_correction_history':True,
   'set':{
    'statement':'F_O, F_A and F_F remain separately fixed partial semantic targets. The historical eight-row enumeration concerns unconstrained Boolean assignments only and does not establish organizational realizability. Under R175 baseline admission, AgencyLoop implies Avail, so at most six Boolean valuations remain; realizability of all six is OPEN.',
    'kind':'EFFECTIVE_TARGET_DISTINCTION_WITH_WITHDRAWN_INDEPENDENCE',
    'scope':'Same declared target domains and R175 baseline-admitted action family. Target distinction does not imply independence, exclusivity, totality, empirical prevalence or a named experiential dissociation. Historical raw Boolean rows are not actual organizational witnesses.',
    'status':'EFFECTIVE_SCOPE_CORRECTED_SEMANTIC_REALIZATION_OPEN',
    'proof':'Apply the existing R175 effective target-separation correction. Baseline membership gives AgencyLoop=>Avail and excludes the two G=1,A=0 rows; no construction of all six remaining semantic models is supplied.',
    'counterexamples_and_limits':'Neither eight-way organizational independence nor all-six semantic realizability is established. Actual grounding, B_min and independently fixed F_O/F_A/F_F interpretations remain OPEN.',
    'effective_reading_overrides_historical_status':True,
    'effective_override_source':'R188 map audit; enforces existing R175:BASELINE_ADMITTED_ACTION_DOMAIN, R175:SIX_ROW_EVENT_MODELS and R175:R173_EFFECTIVE_TARGET_SEPARATION.',
    'historical_statement_preserved':node['statement'],
    'scientific_promotion':False,
   }},
  {'collection':'context_links','id':ctx['id'],'expected_record_sha256':digest(ctx),
   'preserve_original_record_in_correction_history':True,
   'set':{'relation':'Context only: distinguishes the separately fixed ownership, agency and familiar-history targets under the R175 effective correction; does not assert eight-way organizational independence or all-six semantic realizability.','deductive':False}},
 ],
 'active_rule_descendants_of_raw_node':[],
 'outgoing_context_ids':['BASE:CTX:143','BASE:CTX:169'],
 'retain_context_id_unchanged':'BASE:CTX:169',
 'effective_routes_rederived':['r175_r173_target_boundary_effective','r175_r173_history_twin_effective','r176_present_slice_effective','r173_retentive_coordinate_transport'],
 'rederivation_reason':'The target-boundary route uses the existing R175 corrected target node, not raw R173 independence. The twin and present-slice routes require an explicit admitted twin. Retentive C1 transport uses the grounded history/path contract. All remain valid under their original conditions and no suspended historical route is reactivated.',
 'reviewer_statuses_changed':False,
}
WORK.joinpath('R173_EFFECTIVE_CORRECTION_PATCH.json').write_text(json.dumps(correction,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'ledger':str(WORK/'BASELINE_PER_ID_SEMANTIC_REVIEW.json'),'items':len(rows),'correction':str(WORK/'R173_EFFECTIVE_CORRECTION_PATCH.json'),'file_bytes':(WORK/'BASELINE_PER_ID_SEMANTIC_REVIEW.json').stat().st_size}))
