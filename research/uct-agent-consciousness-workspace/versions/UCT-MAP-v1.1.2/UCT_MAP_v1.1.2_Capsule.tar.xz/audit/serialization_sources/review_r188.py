"""Serialize the completed model-visible R188 semantic review, not automated proof."""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/328b6dbb55c2')
WORK = ROOT / 'map_audit_work'
REC = ROOT / 'uct/research/uct-agent-consciousness-workspace/records/R188_Encoder_Access_and_Recovery_20261009'

def digest_bytes(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def digest_obj(x):
    return hashlib.sha256(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

source = json.loads((REC / 'MAP_EXTENSION.json').read_text())
g = copy.deepcopy(source)
g['normalization_source'] = {'path': str(REC / 'MAP_EXTENSION.json'), 'sha256': digest_bytes(REC / 'MAP_EXTENSION.json'), 'source_status': source['integration_status']}
g['integration_status'] = 'REVIEWED_CONDITIONAL_DECLARATIONS'
g['enabled_as_established_premises'] = False
g['scientific_promotion'] = False
g['reviewer_controlled_status_changed'] = False
for key in ['nodes', 'rules', 'context_links']:
    for n in g[key]:
        n['original_source_record_sha256'] = digest_obj(n)
        n['source_status_preserved'] = n.get('status')
        n['registry_review_status'] = 'CONDITIONAL_CONTRACT_REVIEWED_NOT_PREMISE_TRUTH'
        if key != 'context_links':
            n['enabled_as_established_premise'] = False

nodes = {n['id']: n for n in g['nodes']}
rules = {r['id']: r for r in g['rules']}
nodes['R188:IDEAL_NOT_INSTALLED']['statement'] = nodes['R188:IDEAL_NOT_INSTALLED']['statement'].replace('RB top-K=1 is a valid upper bound.', 'On the matched six-state pair-context laws, the RB top-two quantity G_2=1 is a valid upper bound.')
rules['R188:r_gap']['instance_obligations'] = [
    'Specialize the common graph comparison to K=2 and L=1, with the uniform external (T,J) law in COMMON_STIMULUS.',
    'Use one common target/scoring/deadline contract; the internally routed context incidence is the explicitly changed mechanism.'
]
rules['R188:r_repair']['binding'] = 'One common target/context law per architecture and common scoring. Compare the explicitly distinct protocol instances (K,L)=(2,2) and (3,1); each construction satisfies all of its own timing and alphabet premises. No single trial is required simultaneously to use both alphabet contracts.'
rules['R188:r_repair']['instance_obligations'] = [
    'For (K,L)=(2,2), the binary feedback selector reaches the source before its one binary reply.',
    'For (K,L)=(3,1), use one three-symbol forward code and no current feedback; neither extra access is free in the (2,1) comparison.'
]
rules['R188:r_complete']['instance_obligations'] = [
    'Specialize G to the complete graph on an integer n>=2, with a uniform context edge and uniform candidate endpoint.',
    'K,L>=1; C=min(n,K^L); n=Cq+r with integers q>=1 and 0<=r<C.'
]
nodes['R188:LATE_FEEDBACK']['scope'] = rules['R188:r_late']['binding'] + ' For the six-state prism with K=2, the effective source-only reply value is the GAP value; later communication is outside the scored deadline.'
nodes['R188:ONE_SHOT']['scope'] = 'The main theorem is the one-shot pair-context protocol. The distinct countercontrol is a two-coordinate binary common-helper block with one reader role fixed across both coordinates; its mixed-role counterexample tests an explicitly broader block law. They are separate protocol instances, not joint same-instance premises.'
for r in g['rules']:
    r['same_instance_required'] = True
    r['alternative_route_semantics'] = 'AND within each complete typed instance, including external obligations; explicitly different protocol instances are comparisons, not contradictory premises of one trial.'
    r['premise_truth_discharged_by_review'] = False
for c in g['context_links']:
    c['deductive'] = False

REASONS = {
 'R188:PROTOCOL': 'The positive endpoint-context probability law, finite alphabets, direction and pre-reply timing define the admissible class. Independent tapes are harmless; correlated trial labels, time codes, omitted shared state or extra messages change that class. These are model assumptions, not actual access evidence.',
 'R188:RESPONSE_WORD': 'Fix a deterministic encoder and list its counterfactual reply to each of L possible feedback labels. Equal words are indistinguishable under every legal selector; a differing coordinate supplies an admissible selector. L entries describe alternatives, not L forward messages.',
 'R188:EXACT_SCORE': 'Each equal-word edge loses exactly its smaller joint endpoint mass; all differing-word edges can be recovered by a selected coordinate. Maximizing separated edge weight over at most K^L words proves both bounds. This is a finite-error application of established graph/response-table methods; external priority is unverified.',
 'R188:COINS': 'Conditioning on all independent tapes preserves P(T,X) and fixes each party\'s local strategy without making another party\'s tape observable. Each fixed strategy obeys the deterministic bound, so mixtures cannot exceed it. Input-correlated randomness is outside the premise.',
 'R188:ZERO_ERROR': 'Strictly positive supported edge weights make zero average error equivalent to separating every candidate edge. Proper coloring yields chi(G)<=K^L; feedback-label cardinality is not feedback-bit length, and K=1 must be treated separately.',
 'R188:COMMON_STIMULUS': 'Both graphs use exactly the same eighteen external (T,J) inputs and uniform law. The graph-dependent neighbor router is an explicitly changed internal mechanism. The source sees T, and the reader sees the routed edge; the full induced P(T,X) is not equal across graphs.',
 'R188:MATCHED_SUMMARIES': 'Three-regular six-vertex graphs give uniform targets and nine uniform edges, with two fair candidates in every context. Conditional entropy and separate context-aware one-bit recovery match, while graph incidence and a single globally admissible source code can differ.',
 'R188:GAP': 'For K=2,L=1 the bipartition separates all nine edges. The prism\'s disjoint triangles force at least two uncut edges, and labels(0,1,0,1,0,1) cut seven. Since each uncut context loses half its 1/9 mass, the exact average value is8/9, not7/9 or an experience fraction.',
 'R188:FEEDBACK_REPAIR': 'The prism coloring(0,1,2,1,2,0) is proper. Words00,01,10 and a timely binary coordinate selector give exact endpoint recovery with one binary reply; a three-symbol reply gives a separate no-feedback construction. Extra feedback is an accounted resource and a changed protocol.',
 'R188:LATE_FEEDBACK': 'The scored reply is irrevocably fixed before any current context reaches the encoder. Its effective pre-deadline feedback alphabet is L=1, so the source-only prism bound remains applicable. The effective node scope is specialized to this ordering, avoiding conflation with the general timely-feedback instance.',
 'R188:IDEAL_NOT_INSTALLED': 'The revised statement correctly treats RB:HELPER as a sufficient hypothesis for general achievability, not a necessary condition for every law. Bipartite laws attain G2=1 without context; the prism proves that unconditional transfer to the smaller access class is invalid. RB itself is not retracted.',
 'R188:COMPLETE_FAMILY': 'Uniform complete-graph contexts give error equal to monochromatic pairs divided by n(n-1). Balanced classes minimize this count; writing twice the pair count produces the stated denominator2n(n-1). The n>=2 and uniform-law specialization is explicit in the effective rule obligations.',
 'R188:EXECUTED_CHECKS': 'The final exact receipt reports51records and38013candidate tables, and its code hash matches the current checker. The added mixed-role negative witness is a separate51st record; the older50-record run is archived. This reviewer inspected receipts and arguments, did not independently rerun execution, and does not treat finite enumeration as the general proof.',
 'R188:PROCESS_REFERENCE': 'The executed receipt reports126cases/252workers with scores16/18 blind or late and18/18 timely on the prism. The independent reviewer inspected all126records and both code sources; this map reviewer read its complete report and receipt summaries. Function/pipe interfaces establish the stated reference, not OS isolation, complete actual organization or phenomenal evidence.',
 'R188:GROUNDING': 'Actual token admission, physical ports and timing, a justified exhaustive access boundary, common invariant J and supported policy class remain independent OPEN premises. A mathematical graph or executed reference does not discharge them.',
 'R188:UCT_TYPE': 'Only a genuinely established common-J difference for the same admitted actual comparison allows inherited C:P1 to infer different complete experiential structural types. This is conditional and does not identify named content, richness, intensity, subject count or a threshold for continuing local experience.',
 'R188:ONE_SHOT': 'The final text correctly specifies that the successful two-coordinate block keeps one side-information role across coordinates. Mixed role(A0,B1) has the supplied equal-message/equal-side-information collision. This is a separate countercontrol, not a proof that ordinary iid batching or the prism gap is generally repaired.',
 'R188:INFERENCE_CONTRACT': 'A reliable violation falsifies at least one conjunct of the declared prior/access/alphabet/timing/protocol/measurement model; it does not uniquely identify which one. Shared remote reads must also deliver fresh causal information, and neither performance nor feedback counts source occurrences or subjects.',
 'R188:r_word': 'Instantiate one fixed finite protocol and one deterministic strategy. The response table is a representation of its permitted behavior, not additional access. Independent random strategies are later handled by conditioning.',
 'R188:r_score': 'Within the same law, source/reader boundary and alphabets, the equal-word converse and explicit differing-coordinate construction coincide. The full referenced proof includes independent-tape conditioning, so the result does not rely on finite receipt counts or an unproved physical implementation.',
 'R188:r_coins': 'The source and reader tapes must be jointly independent of the current endpoint-context input. Conditional deterministic protocols have the same distribution and the established deterministic ceiling; averaging supplies the extension, without communicating private tapes.',
 'R188:r_zero': 'The positive-support premise in PROTOCOL is necessary for converting zero weighted error to a proper coloring of every declared edge. Zero-probability endpoint edges would have to be removed or the equivalence restated.',
 'R188:r_profile': 'Use the common eighteen-input router instance, count each oriented edge once and derive each listed marginal and posterior. This entails only the named summaries, not equality of complete joint information.',
 'R188:r_gap': 'Effective instance obligations materialize K=2,L=1 and the common uniform law already stated in the source proof. Applying an arbitrary-K,L exact-score schema alone would not identify the prism\'s8/9 specialization.',
 'R188:r_repair': 'The effective binding explicitly separates (2,2) timely feedback and(3,1) no-feedback constructions, each on the same relevant graph law. A comparison of resource contracts is not an AND requiring one physical trial simultaneously to have both alphabet sizes.',
 'R188:r_late': 'Its existing binding correctly uses effective pre-replyL=1; later context is outside the scored transcript and cannot modulate it. No unrestricted timely-feedback premise is silently transferred into this deadline result.',
 'R188:r_nonsuff': 'The same finite law is evaluated in two explicitly different hypothetical access classes. Unrestricted RB helper access is a referenced theorem hypothesis, not conjoined as an actual premise with source blindness. The source-only counterexample establishes only nonentailment of universal attainment.',
 'R188:r_complete': 'Effective obligations explicitly require a uniform complete graph and n>=2 before substituting the balanced-class count. The generic exact-score premise remains conditional and is not a license to use this closed form on arbitrary weighted graphs.',
 'R188:r_uct': 'GROUNDING, the finite contrast realized as the same actual invariantJ, C:FIXED_J and C:P1 must be jointly established. The route does not infer actual realization from the finite GAP or close any reviewer-controlled named-phenomenal question.',
 'R188:ctx_1': 'R133:MESSAGE_COVER is the inherited common-action compatibility antecedent. Taking each action as a whole context-indexed decoder table specializes it to zero-error source coding; the contextual attribution prevents falsely claiming this generic principle as new.',
 'R188:ctx_2': 'IE:QUERY_SPEC addresses delayed-query input access. Pair-support constraints and the weighted finite-error surface are different specializations; this relation supplies attribution and comparison rather than an inference premise.',
 'R188:ctx_3': 'RB20261009:HELPER records the larger(T,X)-aware access class. The graph link highlights the changed access premise; it does not assert both classes for one actual encoder or invalidate the inherited upper bound.',
 'R188:ctx_4': 'A:U1 constrains interpretation to preserve basal experience of admitted actual processes. This nondeductive link cannot turn feedback or successful decoding into a basal-experience gate.',
 'R188:ctx_5': 'A:P3 persistence under embedding remains conditional on an actual continuing local process. Feedback repair or compensator intervention alone does not erase it or prove that its content is unchanged.',
 'R188:ctx_6': 'The exact checker corroborates finite constructions and software arithmetic. Keeping this link nondeductive prevents enumerated sample counts from substituting for the all-instance proof.',
 'R188:ctx_7': 'The executed process reference informs the feasibility discussion while explicitly leaving physical causal closure and actual UCT grounding open. It cannot become a proof edge from code execution to complete organization.',
 'R188:ctx_8': 'The common-role block and mixed-role failure compare different fully declared protocols. They delimit the one-shot theorem rather than contradict it or assert an unqualified iid block theorem.',
 'R188:ctx_9': 'The synthesis with compensation and occurrence audits is a methodological relation. It does not conjoin separate example premises or deduce occurrence multiplicity from a decoding ceiling.'
}

items = []
for kind, key in [('node','nodes'), ('rule','rules'), ('context','context_links')]:
    for n in g[key]:
        assert n['id'] in REASONS, n['id']
        items.append({'item_id': n['id'], 'item_type': kind, 'source_module': 'R188', 'review_outcome': 'REVIEWED_CONDITIONAL_REGISTRATION_WITH_EXPLICIT_INSTANCE_SPECIALIZATIONS', 'review_reason': REASONS[n['id']], 'effective_record': n, 'normalized_record_sha256': digest_obj(n), 'actual_or_named_phenomenal_premise_discharged': False, 'reviewer_status_changed': False})
assert len(items) == 38 and len(REASONS) == 38

out = WORK / 'normalized/R188.json'
out.write_text(json.dumps(g, ensure_ascii=False, indent=2) + '\n')
evidence = {fn: digest_bytes(REC/fn) for fn in ['MAP_EXTENSION.json','RESEARCH_NOTE.md','EXACT_RESULTS.json','PROCESS_RESULTS.json','INDEPENDENT_PROTOCOL_REVIEW.md','check_encoder_access.py','run_process_reference.py']}
assert evidence['check_encoder_access.py'] == json.loads((REC/'EXACT_RESULTS.json').read_text())['code_sha256']
assert evidence['run_process_reference.py'] == json.loads((REC/'PROCESS_RESULTS.json').read_text())['code_sha256']
report = {
 'audit_id': 'R188_NEW_MODULE_PER_ID_SEMANTIC_REVIEW',
 'review_method': 'Every final module node, rule and nondeductive link read in full; complete5770-word manuscript and independent protocol review read. General weighted proof, concrete cut witness, timing and block countercontrols rederived analytically. Program serialization follows that reading; not an automatic proof or a second experimental rerun.',
 'source_file_hashes': evidence,
 'normalized_path': str(out), 'normalized_sha256': digest_bytes(out),
 'counts': {'nodes':18,'active_conditional_rules':11,'nondeductive_context_links':9,'total':38},
 'unread_item_ids': [],
 'normalization_changes': ['Materialize explicit K=2,L=1 instance obligations for r_gap.','Bind r_repair as a comparison of separate(2,2) and(3,1) protocols.','Materialize complete-graph/uniform/n>=2 obligations for r_complete.','Specialize LATE_FEEDBACK scope to effective pre-replyL=1 and ONE_SHOT scope to separate common-role block countercontrols.','Preserve all source statuses/hashes and actual/reviewer OPEN statuses; register conditional declarations only.'],
 'new_originality_scope': 'Exact weighted finite-error access-restricted application, matched six-state comparison, constructive directional repair, executed reference and synthesis. Witsenhausen coloring, response tables and general common-action compatibility are inherited. Exact external priority UNVERIFIED.',
 'overlap': [
   {'anchor':'R133:MESSAGE_COVER','finding':'Zero-error coloring is an exact specialization with action=full decoder table, not a newly discovered abstract compatibility theorem.'},
   {'anchor':'IE:QUERY_SPEC','finding':'Shares query-access issue; pair-supported target/context law and finite-error feedback surface distinguish this application from full Cartesian query recovery.'},
   {'anchor':'RB20261009:HELPER','finding':'Old sharpness assumes target-plus-context access. Restricted class can have smaller attainable value, preserving every old bound.'},
   {'anchor':'R137 common-decoder intersection','finding':'Generic simultaneous compatibility obstruction already inherited; R188 does not claim priority for quantifier order.'},
   {'anchor':'CM20261009:CHANNEL_BOUND','finding':'Real-valued monitor rank is not the finite alphabet K or K^L response-word count.'},
   {'anchor':'R187:ALL_POLICY_THEOREM','finding':'All-policy observed equivalence remains interface-relative. A new feedback/selective access protocol is a declared changed interface, not a contradiction.'}
 ],
 'evidence_limits': 'This reviewer did not independently rerun code, inspect every final source-code line, or verify OS isolation. The independent protocol report identifies the earlier50-record snapshot; the final51st mixed-role negative witness and final source/receipt hashes were checked here. Full actual-application and named-phenomenal premises remain OPEN.',
 'scientific_promotion': False,
 'items': items
}
(WORK/'R188_PER_ID_REVIEW.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'reviewed_items':len(items),'normalized_path':str(out),'normalized_sha256':digest_bytes(out),'source_sha256':evidence['MAP_EXTENSION.json']}, ensure_ascii=False))
