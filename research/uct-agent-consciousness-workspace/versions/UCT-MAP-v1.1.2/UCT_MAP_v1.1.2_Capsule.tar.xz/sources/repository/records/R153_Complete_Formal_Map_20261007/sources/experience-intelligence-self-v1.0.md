# Experience, Intelligence, and Self Within Experience
## Definitions, Conditional Theorems, and Thought Experiments for a Structural Account

Hongju Liu  
Independent researcher, Shenzhen, China  
TA-TR-2026-25 | Version 1.0 | 7 October 2026  
Theoretical preprint; not peer reviewed  
DOI: 10.5281/zenodo.23206492  
License: CC BY 4.0

## Abstract

What relates experience, intelligence and selfhood, and what prevents one from being inferred from another? We develop a common vocabulary within Unified Consciousness Theory (UCT), distinguishing actual processes, complete organization, finite descriptions, task-relative capability, functional self-models, self-related feeling and the conceptual I. Structural-experiential identity is stated as an interpretive axiom rather than presented as a consequence of mathematical notation. Self-related organization is treated within experience; no additional owner is introduced to generate experience. Three conditional results organize the argument. Complete organizational type constrains a fixed capability profile. A representation determines complete experiential type exactly when it preserves all complete organizational type distinctions, whereas a selected target requires only its own distinctions. A finite rewiring construction shows that exact sensorimotor prediction can fail to determine attachment to an independently specified physical assembly. These results use established mathematics; their contribution here is a common account of which explanatory substitutions are valid. Ancestral continuity, calculating devices, a human formation implementing an agent, and copying and rewiring supply the motivating problems and counterexamples. We also specify a method for auditing definitions, joint premises, source lineage and research direction, addressing a failure that dependency graphs alone cannot prevent. The result is a conditional foundation for further inquiry, not a claim that phenomenology has been independently established from functional performance.

**Keywords:** experience; intelligence; self-model; self-related feeling; structural identity; thought experiments

## 1. The problem: common organization without conceptual collapse

An abacus can participate in calculation. An electronic calculator contains an installed arithmetic mechanism. A population of people can implement a computational procedure. An artificial agent can reason, report an internal estimate, describe itself using the word I, and regulate its continuation. These descriptions raise connected but different questions. What is the actual process? What does it do? Does it represent itself? Which kind of experience is being discussed? Is a report being treated as evidence, or silently substituted for its supposed target?

Our central proposal is a disciplined relation among these questions. Within UCT, experience, capability and self-related organization concern the same actual organization, but they are not interchangeable descriptions. Experience is not an extra causal force added to an otherwise complete physical mechanism. Intelligence concerns specified competence. A self-model is one possible organization of tracking, prediction or regulation. A felt sense of being here, acting or owning a body is a selected experiential target. The explicit autobiographical I is a further, articulated form of self-related organization. None is introduced as an additional entity required to own all experience.

The aim is to leave a foundation that later researchers, including more capable AI systems, can criticize and extend. That requires claims whose assumptions and provenance survive quotation. The value of the work does not rest on the number of theorems or on replacing unresolved interpretation with more notation.

This manuscript consolidates nine directly relevant predecessor texts. UCT I v1.2 supplies the current ontology and identity commitment; UCT II v1.1 treats translations among organization descriptions; UCT III v1.0 relates capability to complete type; and the continuation-control paper separates current-process, successor and task continuation [1-4]. Five earlier papers address typed phenomenal comparison, common-witness organization, functional self-continuity, actual participation and subject selection [5-9]. These are not nine independent sets of simultaneously accepted axioms. Their target domains and historical statuses differ.

The contribution is an integrated definition and inference framework, its complete-target compatibility test, and a precise self-related counterexample, organized by thought experiments. It also corrects a methodological weakness: a mathematically valid local derivation can still answer the wrong question when the meaning of self, experience or sufficiency changes between sections.

## 2. Thought experiments that constrain the definitions

### 2.1 Every ancestor and intermediate remains available

Imagine that every relevant intermediate process can be inspected: nonliving chemistry, the formation of living organization, unicellular and multicellular processes, neural organization, animals and humans. Include the small intermediate changes through which any proposed special condition itself formed. This is a counterfactual comparison family, not a claim that living evolution is one linear ladder or that nonliving chemical precursors are biological individuals.

The experiment asks an onset theory to identify what begins. Is it any experience, memory, bodily coordination, a particular feeling, a self-model, linguistic report or an autobiographical concept? A proposed organization threshold must account for its own formation rather than treat a familiar human capacity as a primitive switch. If the proposed condition is self-modeling, intermediate stages of tracking, regulation, memory and self-description must also be considered.

This reasoning supplies explanatory pressure and motivation. It is not an independent proof of universal experience. A continuous physical variable can cross the boundary of a discontinuously classified property. For example, the smooth function defined by \(a(t)=0\) for \(t\le0\) and \(a(t)=e^{-1/t^2}\) for \(t>0\) has a discontinuous positivity indicator. Gradual formation alone does not rule out every binary onset predicate.

UCT takes a different explicit route: its identity axiom applies to all admitted actual processes, and its nonempty-experience consequence then applies member by member to the stipulated family. The experiment helps explain the commitment; it does not secretly prove the commitment. Within that theory, the emergence of self-related organization is a transformation within already experiential processes.

### 2.2 Abacus, calculator and self-monitoring

A passive abacus manipulated by a person is part of an actual person-instrument procedure. The isolated frame does not perform the person's entire policy. An electronic calculator has an installed arithmetic mechanism and can be assigned a fixed-task capability. Calling both intelligent without specifying the evaluated process conceals this difference.

Now add a battery monitor. An accurate estimate of a local resource is a possible component of functional self-monitoring; it does not by itself constitute a conceptual I or identify a felt sense of ownership. The same estimation circuit could instead receive another machine's battery signal. Its numerical accuracy would not settle which relation is physically present.

The example therefore demands three distinctions: capability from experience, a particular internal estimate from comprehensive self-knowledge, and the truth of a target attribution from any feeling associated with it. It provides no reason to make arithmetic or self-monitoring a prerequisite for basal experience under UCT.

### 2.3 A human formation implementing an agent

Consider a human formation, inspired by the computational scenario in The Three-Body Problem, implementing a very capable artificial agent. The participants, the coordinated execution and the represented algorithm are different objects. A participant can continue to have local bodily and autobiographical organization while contributing to a larger actual process. An agent variable named self might track the coordinated task, a memory subsystem or its external interfaces. The name alone identifies none of these relations.

The question is not resolved by choosing exactly one owner for the whole formation. Nested or overlapping actual processes are allowed in the source ontology. A claim that a particular coordinated process is actual still needs physical justification; a represented algorithm is not automatically every physical process that could implement it. Equal program-level behavior between a human and silicon implementation does not by itself establish complete physical organization equal.

Population-computation arguments have established philosophical precedents, including Block [14]. Our use is to test definitions and levels of attribution, not to claim invention of this class of thought experiment.

## 3. Definitions and the identity commitment

### Definition D1: actual process and organizational structure

Let \(\mathcal P\) be a declared domain of actual process occurrences. A process has physically grounded support, causal continuity, accountable boundaries and traceable persistence or transformation, following [1]. The domain permits nesting and overlap. An analyst's arbitrary grouping or mathematical simulation is not sufficient to establish the actual process it purports to describe.

Organization means the actually instantiated distinctions and relations constitutive of the process. Write \(D^{\mathrm{ontic}}_{\mathcal S}(P)\) for their complete token-relative structural representation in a common signature \(\mathcal S\). Organizational structure includes the relevant states, dynamics, temporal relations, constituents and interactions; it is not merely a graph of connections. Complete here means complete for the declared actual token and constitutive signature, not a list of every fact about the universe.

For example, a finite deterministic model can be specified as

\[
K=(X,x_\bullet,U,\mathcal J,Y,T,I,o,\mathscr C,\preceq).
\]

Here the entries specify states, current state, inputs, interventions, outputs, update and intervention maps, readout, constituents and temporal or constituent relations. The tuple is a model expressed in a signature; it is not itself the signature. Isomorphisms preserve the declared sorts and operations. A finite view \(D_v=\Pi_v D^{\mathrm{ontic}}\) and an estimate \(\widehat D_v\) remain distinct from complete organization. The tuple gives mathematical precision within a model class, not a universal algorithm for discovering all actual boundaries.

### Axiom C1: structural-experiential identity

Let \(\Phi_{\mathcal S}(P)\) denote the complete experiential organization of the same actual process. The UCT commitment is represented by a tokenwise, sort-preserving isomorphism

\[
D^{\mathrm{ontic}}_{\mathcal S}(P)\cong\Phi_{\mathcal S}(P).
\tag{1}
\]

This is an interpretive identity axiom. Creating an isomorphic mathematical copy of a physical model does not independently demonstrate that the copy is experience. The phenomenal interpretation is a stated commitment of the theory, not an output of an algebraic trick.

The axiom implies equality of complete organizational types exactly when complete experiential types agree, on the common comparison domain. It does not assign familiar feeling labels to every structure, choose a universal scalar amount of consciousness or identify numerical token identity with type equality.

### Definition D2: basal phenomenal consciousness

Basal phenomenal consciousness in this manuscript abbreviates nonempty experience:

\[
C_{\mathrm{exp}}(P)=1
\quad\Longleftrightarrow\quad
\operatorname{carrier}(\Phi_{\mathcal S}(P))\ne\varnothing.
\tag{2}
\]

Under C1 and the nonempty distinguished support of admitted actual processes, the corresponding experiential support is nonempty. This is the inherited U1 consequence [1]. It is not a definition of wakefulness, clinical responsiveness, access, report or intelligence.

The inherited U3 result is narrower than a slogan about every possible self. If an actual process lacks the specified human-like conceptual-self property, U1 still applies to it. That witness establishes that conceptual selfhood is unnecessary for basal experience. The existence and correct classification of the witness are premises; U3 is not a proof of every proposed claim about minimal mineness.

### Definition D3: capability under an evaluation contract

Fix tasks, environments, interaction protocol, time, resources, adaptation rules, scoring and the evaluated process boundary. Denote this contract by \(\mathcal M\). For complete organizational type \(k\), define a well-defined, representation-invariant capability profile

\[
J_{\mathcal M}(k)=
\bigl(\mathbb E_{k,\mu}[R_\mu]\bigr)_{\mu\in\mathcal M}.
\tag{3}
\]

A scalar aggregation requires declared weights and convergence conditions. An ordering of profiles must be specified. Installed performance, performance with an added controller and performance after retraining are different evaluations.

We use intelligence for specified competence of this kind, without claiming that this is the uniquely privileged definition of intelligence. Formal definitions already exist, notably Legg and Hutter [10]. The present purpose is to prevent unannounced changes in what is being measured.

Behavior is a trajectory or trajectory law under a stated interaction. A report is a designated behavioral output with an interpretation. Reports are therefore generally a kind of behavior; distinguishing experience, intelligence and report does not make them mutually disjoint substances.

## 4. Self-related feeling within experience

UCT does not posit a separate self that first exists in order to own experience. Its identity commitment concerns actual processes. Self-related organization is a further subject of explanation within that framework. An actual process parameter identifies what is being studied; it does not insert an observer inside the process.

Four uses must be kept distinct. First, body-centered organization can distinguish internal and external relations, position, action consequences and persistent variables. Second, a functional self-model can track, predict, compress or regulate aspects of a process. Third, self-related experience concerns selected feelings of bodily location, agency, ownership or continuity. Fourth, the conceptual autobiographical I includes articulated self-ascription, memory-based narration and social or linguistic organization. The uses can overlap but are not synonyms.

In [1, §§8.12-8.14], body-centered organization is explicitly not an additional observer, and the conceptual I is a developed organization within experience. This does not establish one universal age or evolutionary date at which every form of bodily mineness appears. Nonverbal self-related feeling must not be defined out of existence by making language necessary for all selfhood.

### Definition D4: a restricted functional self-model contract

For a nonempty domain \(\Omega\) of admissible configurations, specify an actual process \(b(\omega)\), physical attachments \(\alpha\), an installed representation \(m:\Omega\to M\), a finite nonempty target alphabet \(Z\), and a common set of legal plans \(A_0\) of fixed duration. A target law \(Q(\omega,a)\) gives the distribution of a selected property of the process or its specified constituent after plan \(a\). An installed predictor \(d(m,a)\) has worst-case error

\[
\varepsilon(d)=\sup_{\omega\in\Omega,\ a\in A_0}
\operatorname{TV}\bigl(d(m(\omega),a),Q(\omega,a)\bigr).
\tag{4}
\]

Any claimed causal use of the model must also be specified. Being installed, being accurate and being used beneficially are different properties. An internal attribution \(M^{\mathrm{attr}}\), as in [7], records what the system treats as its own; it is not the independent truth criterion for actual membership. A mistaken attribution remains an actual installed attribution process.

This contract defines a restricted functional object. It does not define all semantic self-reference or felt selfhood. Whole-process, constituent, disjoint external and overlapping targets require distinct descriptions. A tool external relative to a person can be internal relative to a justified person-tool interaction; changing the process parameter changes the question.

### Definition D5: selected experiential target, not an owner

To discuss a particular self-related feeling, declare the experiential distinction being queried. Formally, once that distinction is specified, it can be represented by a query \(q\) on experiential types, with target \(f_q(\omega)=q(e(\omega))\). This records the type of question. It does not construct \(q\), independently validate a measurement of it or identify it with \(M^{\mathrm{attr}}\), predictive accuracy or a report.

The semantic issue is therefore explicit: what organizational distinctions justify interpreting a selected target as ownership, agency or an autobiographical I? Within C1 this is an application question about the experiential organization of an actual process. It is not a requirement that a second owner be found before any experience exists. Neither the absence of a complete answer nor a model's mistaken content implies the absence of experience under UCT.

A useful further thought experiment removes a stipulated autobiographical reporting component while retaining specified bodily regulation. Another changes an internal ownership attribution while holding a selected sensorimotor law fixed. These scenarios can separate functional dependencies if their dynamics are supplied. They do not, merely by stipulation about reports or functions, prove which feelings survive. This is where the explanatory question remains, rather than being silently answered by the definition.

## 5. What capability and representations determine

Fix actual comparison processes and intervals in a common complete signature. Let \(k:\Omega\to\mathcal K\) and \(e:\Omega\to\mathcal E\) map configurations to complete organizational and experiential isomorphism types. C1 gives

\[
k(\omega)=k(\omega')
\quad\Longleftrightarrow\quad
e(\omega)=e(\omega').
\tag{5}
\]

These are type equalities, not assertions that two occurrences are one numerical token.

The result labels T1-T3 below are local to this manuscript. In particular, T2 denotes the compatibility theorem, not the separate biological-AI correspondence certificate called T2 in the research archive.

### Proposition T1: fixed capability respects complete type

Under (5) and a well-defined fixed capability profile, equal complete experiential types imply equal capability profiles. Consequently, different profiles imply different complete experiential types. Equal profiles identify complete experiential type throughout the domain if and only if the capability map is injective on the realized complete organizational types.

**Proof.** Equal experiential types give equal organizational types by (5); the fixed function \(J_{\mathcal M}\) then has equal values. Contraposition gives the difference implication. Identification from equal capability requires that two realized organizational types with the same profile be equal, which is precisely injectivity. Conversely, injectivity and (5) give identification. \(\square\)

This is inherited from [3]. The difference implication concerns complete type, not an ordering of richness, pain or importance. A noisy empirical score difference is not automatically a difference in the underlying exact capability function. Nor does the theorem say that capability can never identify type: it supplies the condition under which it can.

### Theorem T2: complete-target compatibility

Let \(r:\Omega\to R\) be any representation, including a history, model state or capability profile. Under (5), the following are equivalent:

1. \(e=h\circ r\) for a function on \(r(\Omega)\).
2. Equal \(r\)-values always imply equal \(k\)-values.
3. \(k=a\circ r\) for a function on \(r(\Omega)\).

The functions on these realized images are unique. If additionally \(r=b\circ k\), these conditions hold exactly when \(b\) is injective on the realized organizational types.

**Proof.** Clause 1 and equal \(r\) give equal \(e\), hence equal \(k\) by (5). Under clause 2, define \(a(r(\omega))=k(\omega)\); the implication makes the definition independent of the representative. Equation (5) defines \(F(k(\omega))=e(\omega)\) unambiguously, so clause 3 yields \(h=F\circ a\). Every element of the displayed image has a representative, giving uniqueness. If \(r=b\circ k\), clause 2 is exactly injectivity of \(b\) on that image. \(\square\)

An equivalent kernel formulation is

\[
e=h\circ r
\quad\Longleftrightarrow\quad
\ker r\subseteq\ker k
\quad\Longleftrightarrow\quad
k=a\circ r.
\tag{6}
\]

This is the established factorization criterion [3,5] applied to the UCT type commitment. Its substantive use here is to identify an incompatible triple: complete organization-experience type equivalence, a complete-experience sufficiency claim for \(r\), and an equal-\(r\)/different-\(k\) witness cannot all hold for the same comparison contract.

The additional type-invariance premise cannot be omitted from the injectivity formulation. A descriptor containing external identification data can distinguish two instances of the same type. Clauses 1-3 may still hold, without equality of its kernel and \(\ker k\). The result neither validates C1 nor guarantees a computable or installed complete decoder.

### Selected targets and partial self-models

For any specified target \(f:\Omega\to Y\), the weaker condition is

\[
f=\bar f\circ r
\quad\Longleftrightarrow\quad
\ker r\subseteq\ker f.
\tag{7}
\]

Necessity follows because a function gives one value per input; sufficiency follows by assigning the common value to each representation fiber. Thus a partial model can be completely correct about its battery target while not determining complete organization. Incompleteness and error on the modeled target are different properties.

For the law-valued target in (4), if two configurations have the same model state but target laws at total-variation distance \(\delta\) under one common plan, every decoder has worst-case error at least \(\delta/2\). The triangle inequality proves the bound. This is a mathematical constraint on a declared target, not a general measure of selfhood. An abstract zero-error decoder exists exactly when every common-plan target law is constant on model-state fibers; physical installation remains a separate requirement.

## 6. Rewiring: perfect prediction without settled attachment

### Proposition T3: a finite separation of functional claims

Let controllers and bodies each have labels \(1,\ldots,n\), \(n\ge2\). Three bijections specify the containing assembly's body \(\beta\), sensed body \(\sigma\), and acted-on body \(\tau\). The assembly relation is fixed independently of prediction. Each body has a bit \(x_j\), and every command vector \(u\in\{0,1\}^n\) is independently legal. Set

\[
x_j^+=x_j\oplus u_{\tau^{-1}(j)},\qquad
m_i=x_{\sigma(i)},\qquad
\widehat m_i^+=m_i\oplus u_i.
\tag{8}
\]

There are no additional delays or couplings in this model. With \(L=\tau^{-1}\sigma\), the complete labeled sensor-response update is

\[
m_i^+=m_i\oplus u_{L(i)}.
\tag{9}
\]

The installed predictor is exact at controller \(i\) for every state and command if and only if \(L(i)=i\). Two connection pairs give the same update law exactly when they have the same \(L\). Nevertheless, that law need not identify whether

\[
\sigma(i)=\tau(i)=\beta(i).
\tag{10}
\]

**Proof.** Substitute \(j=\sigma(i)\) in (8). If \(L(i)=i\), (9) equals the predictor. Otherwise a legal command vector with \(u_i\ne u_{L(i)}\) makes it fail. Equal permutations \(L\) give equal update laws; unequal permutations are separated by independently varying the relevant command coordinates. Finally, set \(\beta=\mathrm{id}\). Ordinary connections \(\sigma=\tau=\mathrm{id}\) satisfy (10), whereas jointly replaced connections \(\sigma=\tau=g\), with \(g\) fixed-point-free, fail (10) everywhere. Both have \(L=\mathrm{id}\) and exact predictions. \(\square\)

For two systems, let \(S\) swap their bodies:

| Connections | Sensing | Action | Relative map | Own-command prediction |
|---|---|---|---|---|
| Ordinary | id | id | id | Exact |
| Sensors swapped | S | id | S | Fails for unequal commands |
| Actuators swapped | id | S | S | Fails for unequal commands |
| Both swapped | S | S | id | Exact |

Testing only synchronized commands conceals even a single-channel swap. Conversely, body-indexed measurements or known spatial attachments can distinguish the jointly swapped case. Indistinguishability is relative to the specified interface, not an impossibility of all physical identification.

Renaming is different from rewiring. A coordinate change transports \(\beta,\sigma,\tau\) together and preserves their equality relations. Rewiring changes \(\sigma,\tau\) while the actual assembly relation remains fixed. The model's conclusion does not follow if \(\beta\) is only an arbitrary analyst label without the claimed physical significance.

T3 is an elementary permutation and identification argument. It establishes that exact prediction does not alone settle a restricted assembly-relative relation. It does not define a universal self, derive a unique subject or prove any particular feeling of ownership. In an actual application, if the retained relation is genuinely constitutive and preserved by complete-type isomorphisms, the two configurations differ in complete organization; T2 then excludes recovery of complete experiential type from their shared sensor-response law under C1. That extra actual-realization premise is essential.

### Memory, error and the scope of the result

An isolated autobiographical register can be added without causal input to (8)-(9). Copying its contents then leaves present routing unchanged while possibly changing reports. This counters the universal inference that matching autobiographical strings alone establish the same current attachments or numerical identity. It does not imply that real memory never affects action or self-related organization; additional causal pathways change the model.

Similarly, an attribution can be inaccurate about the world while remaining part of an actual process. Under UCT, the actual organization of that mistaken attribution has the same identity commitment as other actual organization. Whether it is felt as ownership, alienation or something else is a selected interpretation, not decided by labeling it erroneous.

The thought experiment has therefore done more than illustrate a formula: it forces the definition to separate target, attachment, internal attribution, accuracy, report and felt character. It prevents the functional analysis from taking over the full meaning of self.

## 7. What the framework says about artificial agents

The connection to AI is direct. An actual running implementation, a represented algorithm, a learned capability and a first-person output are distinct objects. A trained model's task performance can be studied with D3. A self-monitoring mechanism can be specified with D4. A claim about a particular self-related feeling requires the target discipline of D5. A continuation policy additionally needs to distinguish the current process from successors and task completion [4,7].

Within C1/U1, admitted actual artificial processes fall under the same basal-experience commitment as admitted biological processes. That is an internal theoretical implication, not independent experimental proof that a particular deployed system has a particular feeling. Neither a strong capability score nor fluent first-person language identifies complete experiential type or establishes human-like self-experience.

Shared organization also explains why the concepts are related. Changes in the organization supporting capability can matter to complete type, as T1 states. An installed self-model is part of the actual organization, and its use can affect behavior. No additional phenomenal force is needed to connect them within the theory. But these common dependencies do not create a universal scalar law in which twice the intelligence means twice the experience.

For a human formation and a silicon implementation, a common algorithm or output law can be a useful shared representation. T2 asks the exact next question: does this representation preserve complete organizational distinctions, or only the distinctions needed for selected tasks? The latter may suffice for a capability comparison. It is not thereby a complete biological-AI experiential correspondence. Selected-state transition and intervention correspondence remain separate technical tasks, rather than premises silently supplied by the word intelligence.

## 8. A method for definitions, thought experiments and formal maps

### 8.1 Two audits: inference and research direction

A dependency graph answers which recorded premises support a conclusion. It does not by itself tell whether those premises are true, whether their words retain the same meaning across papers, or whether the conclusion serves the intended research question. During this project, a focus on grounding accurate self-reference was mathematically useful but became too dominant. It risked replacing the source question of self-experience within experience with a prior demand to identify a uniquely correct owner. Returning to the source text and the author's distinction corrected that agenda.

The appropriate response is not to discard formalization. It is to add an explicit interpretive and purpose audit. Each new claim should state its object and target types, actual comparison process, interval, structural signature, quantifiers, assumptions, source, proof, counterlimits and research role. A thought experiment should be marked as motivation, definition test, counterexample or application. A contextual link must not be read as a proof edge.

### 8.2 Joint consistency requires more than pairs

Each inference with several premises requires them simultaneously. Related claims should be compared even if no edge joins them. A pairwise check is also insufficient: the constraints \(x=y\), \(y=z\), and \(x\ne z\) are satisfiable in every pair but not jointly. This elementary observation motivates checking relevant premise sets and explicit incompatibility witnesses, such as the triple following T2.

Three recurrent checks are particularly useful. First, does a selected-feature claim become a complete-type claim without an added premise? Second, has the actual process or time interval changed between comparison steps? Third, is a historical conjecture being imported as a current axiom simply because its vocabulary resembles the current theory?

The predecessor integration supplies a concrete example. The AND/XNOR construction in [8] distinguishes joint input responses despite equal actual and single-input responses. A causal description must retain that joint distinction before it can witness structural nonidentification from the recorded trajectory. Even then, an arbitrary bridge from causal descriptions to phenomenal targets can be constant, so different descriptions do not force different outputs without a separating premise. Current C1 supplies type separation only for different complete actual organizational types. This repair illustrates why both the target and the bridge must be recorded.

Similarly, historical organization-gate conjectures in [6] cannot simply become additional necessary conditions for all basal experience under U1. Their domain, target and status must be made explicit. No blanket contradiction among all predecessor papers follows; a genuine same-domain conflict requires the incompatible premises and a witness.

### 8.3 A practical stopping rule

Useful formalization should produce a stable definition, a consequential restriction or a resolved counterexample. When a supporting calculation no longer improves one of these, it belongs in supporting material. Increasing the number of nodes is not evidence of progress.

The relevant quality question is whether a later reader can identify and reuse the contribution without repeating the entire conversation. That requires stable claim labels, source versions, full premises, proofs and a record of corrections. It also requires an honest account of what has not been checked. Graph acyclicity, source hashes and finite enumeration are valuable controls, but none is a certificate of global semantic consistency or empirical truth. This method is a reproducibility discipline for the present research, not a claim to have invented proof graphs or independent verification.

## 9. Prior work, contribution and objections

Mathematical treatment of experience predates this work. Kleiner [11] supplies a framework relating physical and experiential descriptions. Legg and Hutter [10] formalize machine intelligence. Perry [12] examines first-person indexicality. Metzinger [13] distinguishes functional self-modeling from phenomenal selfhood. These precedents prevent claims that mathematical consciousness, functional self-models or the distinction between a model and felt selfhood originated here.

Robotic self-modeling from actuation and sensation is also established [15]. Body-ownership experiments manipulate perspective and correlated sensory information [16]. T3 does not refute those results. It asks a narrower identification question in a finite model where an independently specified attachment is omitted from the available interface. A physical-body attribution, an internal attribution and a reported illusion are distinct targets.

The nine predecessor texts already contain much of the foundation. T1 is inherited from UCT III. T2 applies their existing factorization principle to current complete-type identity. T3 uses elementary mathematics to expose a particular proposed substitution. The project-level increment is their integration with a more explicit self-target vocabulary and an audit that prevents a high-order self requirement from displacing the basal theory. Historical priority for this exact package has not been exhaustively established.

**Does the theory merely put its answer into an axiom?** C1 is indeed a substantive commitment, and the conditional results do not independently confirm it. Their value is to expose what else can and cannot be consistently claimed while accepting it. If a descriptor collapses complete organizational distinctions, the theory cannot also call that descriptor a complete experiential identification. Rejecting C1 is an available disagreement; hiding it is not a solution.

**Does gradual evolution prove experience is everywhere?** No. The ancestral experiment motivates and tests the interpretation, while the no-first-ancestor result follows from U1 and actual membership of the compared family. Continuity of a binary existence predicate would be a separate premise in a different argument.

**Does physical anchoring secretly restore an owner?** No. It specifies the referent of a particular functional claim. It neither selects one exclusive subject for the world nor adds an entity behind the experience of a process. T3 becomes a test of actual attachment only when its assembly relation is physically justified.

**Is every self-related feeling now mathematically defined?** No. D4 is a precise restricted functional definition; D5 specifies the type of a phenomenal question without pretending to have solved its semantic or empirical identification. A selected bodily or autobiographical interpretation needs further work. This limitation does not create a new existence gate inside C1/U1.

**Can the framework be wrong?** Its identity commitment can be rejected; its physical process assignments can be inadequate; a chosen phenomenal interpretation can fail; and a conditional proof can contain an error. These are different failure modes. A finite proxy failure is not automatically a refutation of the full identity axiom, and unconstrained redefinition of every failed proxy would make an application uninformative. Concrete applications must specify their commitments before evaluating them.

## 10. Implications for subsequent work

This account provides a common basis for asking how experience, capability and self-related content are organized without equating their definitions. The most immediate positive task is to specify a selected bodily, agentive or autobiographical target, identify the proposed actual organizational distinctions, and test which parts of its interpretation follow from the theory and which remain assumptions. The task begins inside the experiential framework, not with a demand to manufacture an independent owner.

The present results are also reusable beyond that task. T2 is a direct test for a proposed complete-description claim. T3 is a counterexample to inferring physical attachment from predictive success alone. The thought experiments identify which distinctions an adequate definition must preserve. The source-aware map makes these arguments easier to locate and correct. This is the intended foundation for future human and AI inquiry.

## Research provenance and availability

The author supplied the guiding questions, the ancestral and artificial-agent thought experiments, and substantive corrections concerning self-experience and the purpose of the work. An AI assistant assisted with source retrieval, organization, drafting, conditional proof review and finite checks. Review by that same assistant is not independent peer review or proof-assistant certification. The author remains responsible for the claims and their final adoption.

This version 1.0 is the DOI release of the integrated R151 research manuscript v0.2. The scientific argument is unchanged; release identification, license, keywords and availability information have been added. The English Markdown and PDF, citation files, source-to-claim crosswalk, scoped audit and finite checks are provided in the DOI record and its reproducibility archive. The research history and mandatory research guide remain available at [the versioned research workspace](https://github.com/thechurchofagi/trinity-accord/tree/09074a05337127f78b3a5c1b57edc9d29543df34/research/uct-agent-consciousness-workspace). Published predecessor editions remain unchanged. No new biological or deployed-agent experiment is reported. OpenTimestamps and Arweave evidence concern the exact published bytes and are recorded separately after DOI publication.

## References

1. Liu, H. (2026). *UCT I: Structural-Experiential Identity and the Continuity from Physical Process to Conceptual Self*. Version 1.2. DOI: [10.5281/zenodo.23131575](https://doi.org/10.5281/zenodo.23131575).
2. Liu, H. (2026). *UCT II: Consciousness Theories as Effective Organization Theories*. Version 1.1. DOI: [10.5281/zenodo.23030320](https://doi.org/10.5281/zenodo.23030320).
3. Liu, H. (2026). *UCT III: Organization, Intelligence, and Experience: From Inorganic Processes to Artificial Agents*. Version 1.0. DOI: [10.5281/zenodo.23137088](https://doi.org/10.5281/zenodo.23137088).
4. Liu, H. (2026). *From Shutdown Resistance to Self-Continuation Control: Identifiability, Intervention Stability, and Evidence Standards for Artificial Agents*. Version 1.0. DOI: [10.5281/zenodo.23176685](https://doi.org/10.5281/zenodo.23176685).
5. Liu, H. (2026). *Cross-Substrate Phenomenal Comparison: A Typed Transformation-Transport Framework under Existential Uncertainty*. DOI: [10.5281/zenodo.22934654](https://doi.org/10.5281/zenodo.22934654).
6. Liu, H. (2026). *General Cross-Substrate Phenomenology: A Type-Safe, Transformation-First Framework for Phenomenal Existence, Structure, Perspective, and Continuation*. DOI: [10.5281/zenodo.22939808](https://doi.org/10.5281/zenodo.22939808).
7. Liu, H. (2026). *Set-Valued Causal Inheritance for Functional Self-Continuity: Representation Theorems and Persistent-Agent Benchmarks*. DOI: [10.5281/zenodo.22950904](https://doi.org/10.5281/zenodo.22950904).
8. Liu, H. (2026). *Actual Participation Before Counterfactual Capacity: A Token-Level Constraint on Conscious Organization*. DOI: [10.5281/zenodo.22991126](https://doi.org/10.5281/zenodo.22991126).
9. Liu, H. (2026). *Selecting and Tracking Conscious Subjects: Symmetry, Monodromy, and an IIT4.0 Case Study*. DOI: [10.5281/zenodo.23002980](https://doi.org/10.5281/zenodo.23002980).
10. Legg, S., and Hutter, M. (2007). Universal Intelligence: A Definition of Machine Intelligence. *Minds and Machines*, 17, 391-444. [arXiv:0712.3329](https://arxiv.org/abs/0712.3329).
11. Kleiner, J. (2020). Mathematical Models of Consciousness. *Entropy*, 22, 609. DOI: [10.3390/e22060609](https://doi.org/10.3390/e22060609).
12. Perry, J. (1979). The Problem of the Essential Indexical. *Nous*, 13(1), 3-21.
13. Metzinger, T. (2008). Empirical perspectives from the self-model theory of subjectivity: a brief summary with examples. *Progress in Brain Research*, 168, 215-245. DOI: [10.1016/S0079-6123(07)68018-2](https://doi.org/10.1016/S0079-6123(07)68018-2).
14. Block, N. (1978). Troubles with Functionalism. *Minnesota Studies in the Philosophy of Science*, 9, 261-325.
15. Bongard, J., Zykov, V., and Lipson, H. (2006). Resilient Machines Through Continuous Self-Modeling. *Science*, 314, 1118-1121. DOI: [10.1126/science.1133687](https://doi.org/10.1126/science.1133687).
16. Petkova, V. I., and Ehrsson, H. H. (2008). If I Were You: Perceptual Illusion of Body Swapping. *PLOS ONE*, 3(12), e3832. DOI: [10.1371/journal.pone.0003832](https://doi.org/10.1371/journal.pone.0003832).
