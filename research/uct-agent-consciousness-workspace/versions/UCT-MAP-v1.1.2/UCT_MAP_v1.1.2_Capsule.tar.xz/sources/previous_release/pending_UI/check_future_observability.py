#!/usr/bin/env python3
"""Independent BFS check of future-readout congruence and witness-length bound."""
from collections import deque
from itertools import product
from pathlib import Path
import json,random

def witness(acts,obs,s,t):
    todo=deque([(s,t,())]);seen={(s,t)}
    while todo:
        a,b,w=todo.popleft()
        if obs[a]!=obs[b]:return w
        for i,f in enumerate(acts):
            q=(f[a],f[b])
            if q not in seen:seen.add(q);todo.append((*q,w+(i,)))
    return None

def partition(acts,obs):
    labels=tuple(obs)
    while True:
        keys=[(obs[i],tuple(labels[f[i]] for f in acts)) for i in range(len(obs))]
        d={k:j for j,k in enumerate(dict.fromkeys(keys))}
        new=tuple(d[k] for k in keys)
        if all((new[i]==new[j])==(labels[i]==labels[j]) for i in range(len(obs)) for j in range(len(obs))):return new
        labels=new

rng=random.Random(7321);pairs=0;models=0;maxlen=0;hits=[]
for n in range(1,5):
    maps=list(product(range(n),repeat=n))
    choices=list(product(maps,repeat=2)) if n<=3 else [(rng.choice(maps),rng.choice(maps)) for _ in range(128)]
    for acts in choices:
        for obs in product((0,1),repeat=n):
            c=partition(acts,obs);bound=n-len(set(obs));models+=1
            # induced actions preserve the computed quotient
            for i,j in product(range(n),repeat=2):
                if c[i]==c[j]:assert all(c[f[i]]==c[f[j]] for f in acts)
                w=witness(acts,obs,i,j);pairs+=1
                assert (w is None)==(c[i]==c[j])
                if w is not None:assert len(w)<=bound;maxlen=max(maxlen,len(w))
            # quotient commutation iff no future observer distinguishes either update order
            quotient_commutes=all(c[acts[1][acts[0][s]]]==c[acts[0][acts[1][s]]] for s in range(n))
            no_future_difference=all(witness(acts,obs,acts[1][acts[0][s]],acts[0][acts[1][s]]) is None for s in range(n))
            assert quotient_commutes==no_future_difference
res={'status':'PASS','automaton_readout_models':models,'state_pair_comparisons':pairs,
     'max_witness_length_found':maxlen,'checked_bound':'length <= n - number_of_initial_output_classes',
     'coverage':'all two-action systems of sizes 1-3 with all binary readouts; 128 seeded size-4 action pairs with all binary readouts',
     'not_claimed':'physical minimality, subject count, phenomenal equivalence or historical originality'}
path=Path(__file__).resolve().parents[1]/'results'/'FUTURE_READOUT_RESULTS.json'
path.write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
