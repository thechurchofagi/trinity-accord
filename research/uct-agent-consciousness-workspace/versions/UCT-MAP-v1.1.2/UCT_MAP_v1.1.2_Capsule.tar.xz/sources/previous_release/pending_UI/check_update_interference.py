#!/usr/bin/env python3
"""Exact finite operational checks; not an assay of phenomenal experience."""
from fractions import Fraction as F
from itertools import product, permutations
from pathlib import Path
import json, random

ST = tuple(product((0,1),repeat=2)); IDX={s:i for i,s in enumerate(ST)}
N=len(ST)
MAPS=list(product(range(N),repeat=N))

def compose(a,b): # a then b
    return tuple(b[a[x]] for x in range(len(a)))

def det(f):
    return tuple(tuple(F(int(f[i]==j)) for j in range(len(f))) for i in range(len(f)))

def mm(a,b):
    return tuple(tuple(sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b[0]))) for i in range(len(a)))

def mix(a,b,p):
    return tuple(tuple(p*x+(1-p)*y for x,y in zip(ra,rb)) for ra,rb in zip(a,b))

def tv(a,b):return sum(abs(x-y) for x,y in zip(a,b))/2

def norm(a,b):return max(tv(x,y) for x,y in zip(a,b))

def readmap(f):
    return tuple(tuple(F(int(j==f[i])) for j in range(max(f)+1)) for i in range(len(f)))

def observed(a,b,read,init=0):return mm(mm(a,b),read)[init]

def permmap(f,h):
    inv={v:i for i,v in enumerate(h)}
    return tuple(h[f[inv[i]]] for i in range(len(f)))

# Matched isolated probes, same state size and same endpoint readout.
a=tuple(IDX[(1-x,y)] for x,y in ST)
b_shared=tuple(IDX[(0,y)] for x,y in ST)
b_split=tuple(IDX[(x,0)] for x,y in ST)
read=tuple(x^y for x,y in ST)
A=det(a);BS=det(b_shared);BD=det(b_split);R=readmap(read)
summary={}
for label,b in [('shared_update',b_shared),('disjoint_update',b_split)]:
    out={}
    for name,w in [('none',()),('A',(a,)),('B',(b,)),('AB',(a,b)),('BA',(b,a))]:
        x=0
        for f in w:x=f[x]
        out[name]={'state':list(ST[x]),'readout':read[x]}
    summary[label]=out
assert all(summary['shared_update'][p]==summary['disjoint_update'][p] for p in ('none','A','B'))
assert summary['shared_update']['AB']['readout']==0
assert summary['shared_update']['BA']['readout']==1
assert summary['disjoint_update']['AB']['readout']==summary['disjoint_update']['BA']['readout']==1

# Enumerate all two-bit separately updating pairs, allowing arbitrary coordinate bijections.
local=list(product((0,1),repeat=2)); independent=set()
for h in permutations(range(N)):
    for f,g in product(local,repeat=2):
        af=tuple(IDX[(f[x],y)] for x,y in ST)
        bg=tuple(IDX[(x,g[y])] for x,y in ST)
        independent.add((permmap(af,h),permmap(bg,h)))
assert (a,b_split) in independent
assert (a,b_shared) not in independent
commuting=0; noncommuting=0
for f,g in product(MAPS,repeat=2):
    c=compose(f,g)==compose(g,f)
    commuting+=c;noncommuting+=not c
    assert (f,g) not in independent or c
# Absence of order effects does not imply factorization: a four-cycle with its square.
cyc=(1,2,3,0);sq=compose(cyc,cyc)
assert compose(cyc,sq)==compose(sq,cyc)
assert (cyc,sq) not in independent

# Relabeling invariance for every deterministic pair / preparation / endpoint readout
# Structural commutation is checked exhaustively; readout covariance uses the witness pair.
recoding=0
for h in permutations(range(N)):
    inv={v:i for i,v in enumerate(h)}
    nr=tuple(read[inv[i]] for i in range(N))
    for f,g in [(a,b_shared),(a,b_split),(cyc,sq)]:
        for x in range(N):
            pf,pg=permmap(f,h),permmap(g,h)
            assert nr[compose(pf,pg)[h[x]]]==read[compose(f,g)[x]]
            assert nr[compose(pg,pf)[h[x]]]==read[compose(g,f)[x]]
            recoding+=1

# Correlated initial conditions do not break exact disjoint commutation.
initial_checks=0
for cuts in product(range(5),repeat=4):
    if sum(cuts)!=4:continue
    mu=tuple(F(c,4) for c in cuts)
    assert mm((mu,),mm(A,BD))==mm((mu,),mm(BD,A))
    initial_checks+=1

# Graded change: route B to x with probability alpha, otherwise to y.
# Independent readout flipping probability eta attenuates the gap.
graded=[]
for alpha in [F(i,10) for i in range(11)]:
    B=mix(BS,BD,alpha)
    for eta in [F(0),F(1,10),F(1,4),F(1,2)]:
        noise=((1-eta,eta),(eta,1-eta));RN=mm(R,noise)
        ab=observed(A,B,RN);ba=observed(B,A,RN)
        gap=tv(ab,ba)
        assert gap==alpha*abs(1-2*eta)
        graded.append({'alpha':str(alpha),'readout_flip':str(eta),'order_gap':str(gap)})

# General robust bound for any nearby commuting pair, including stochastic kernels.
# ||A-A0||_TV<=ea, ||B-B0||_TV<=eb => D<=2(ea+eb).
rng=random.Random(20261009);robust_checks=0
for _ in range(600):
    f,g=rng.choice(tuple(sorted(independent)));a0,b0=det(f),det(g)
    aa=det(rng.choice(MAPS));bb=det(rng.choice(MAPS))
    x,y=F(rng.randrange(11),10),F(rng.randrange(11),10)
    ap,bp=mix(aa,a0,x),mix(bb,b0,y)
    ea,eb=norm(ap,a0),norm(bp,b0)
    rr=readmap(tuple(rng.randrange(2) for _ in range(N)))
    for state in range(N):
        D=tv(observed(ap,bp,rr,state),observed(bp,ap,rr,state))
        assert D<=2*(ea+eb)
        robust_checks+=1

# Delayed revelation: immediate readout can hide order effects.
# Same A,B_shared as above; observer initially reads y only; V copies x into y.
r_y=tuple(y for x,y in ST);V=tuple(IDX[(x,x)] for x,y in ST)
u,v=compose(a,b_shared)[0],compose(b_shared,a)[0]
assert r_y[u]==r_y[v]==0
assert r_y[V[u]]==0 and r_y[V[v]]==1

# Complete deterministic future-readout quotient (finite-state behavioral equivalence).
def quotient(actions,obs):
    labels=list(obs); rounds=0
    while True:
        keys=[(obs[s],tuple(labels[f[s]] for f in actions)) for s in range(len(obs))]
        uniq={key:i for i,key in enumerate(dict.fromkeys(keys))}
        new=[uniq[key] for key in keys]
        same=all((labels[s]==labels[t])==(new[s]==new[t]) for s in range(len(obs)) for t in range(len(obs)))
        rounds+=1
        if same:return new,rounds
        labels=new

# For shared vs split future observer, relational dependency can be revealed later.
classes,rounds=quotient((a,b_shared,V),r_y)
assert classes[u]!=classes[v]
# A fixed observer never distinguishes a hidden toggled bit when no copying action exists.
classes_hidden,_=quotient((a,b_shared),r_y)
assert classes_hidden[u]==classes_hidden[v]

# Why time/protocol leaks must be excluded: a readout handed the order can manufacture a gap.
assert int('AB'=='AB') != int('BA'=='AB')
# No claim that such an order indicator measures content-specific state dependence.

res={'status':'PASS','scope':'Finite classical models only; no phenomenal measurements',
 'matched_probe_witness':summary,'deterministic_pairs':len(MAPS)**2,
 'commuting_pairs':commuting,'noncommuting_pairs':noncommuting,
 'independent_binary_product_pairs':len(independent),
 'commuting_not_binary_product_pairs':commuting-len(independent),
 'covariant_readout_comparisons':recoding,'correlated_initial_checks':initial_checks,
 'robust_kernel_checks':robust_checks,'graded_cases':graded,
 'delayed_revelation':{'immediate_gap':0,'after_copy_gap':1,'future_partition_classes':len(set(classes))},
 'counterexamples':['commuting shared cycle','hidden difference masked by fixed readout','protocol-order leakage','physical copy/communication can emulate shared update; token identity not inferred'],
 'theorem_boundary':'Common time-homogeneous Markov state, order-independent same readout, same initial law, and complete retained noise/context are required.'}
if __name__=='__main__':
    path=Path(__file__).resolve().parents[1]/'results'/'EXACT_RESULTS.json'
    path.write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in res.items() if k!='graded_cases'},ensure_ascii=False,indent=2))
