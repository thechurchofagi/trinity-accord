# Memory Across Changing Support: Recoverability, Timely Access, and the Cost of Omitted Inputs

**Hongju Liu — UCT research program**  
**Research record:** TH20261009; result version **0.2.0**, 9 October 2026.  
**New submodule:** RB20261009 (recovery budget).  
**Manuscript status:** candidate theoretical/methods material, not submitted or DOI-published. Substantial AI assistance under the author's direction. No independent peer review or phenomenal validation is represented as completed.

## Abstract

A target can survive changes in the physical parts that store it, while becoming unavailable to a particular consumer or being read with an inappropriate decoder. Endpoint recovery therefore does not identify its intervening access history. Starting from a previously saved finite handoff construction, we distinguish target storage, permitted decoding, actual use and deadline-dependent performance. We prove a sharp finite-alphabet bound: if all newly arriving target-relevant input has at most K possible transcript values conditional on an earlier record X, any later recovery probability is bounded by the summed K largest posterior target masses. The bound is achievable in the unrestricted helper-encoding class, specializes to min(1,K/M) for a uniform residual ambiguity of M states, and gives a deadline-dependent necessary communication budget. A total-variation relaxation allows explicitly bounded violations of the mediation or prior model. Mask-reuse, timing-only signals, wrong decoders and coarser targets delimit the inference. These are applications of classical guessing/list-decoding and information-flow principles, not new foundations of information theory. Their proposed UCT role is to turn an otherwise vague missing-path explanation into a conditional quantitative constraint, while preserving experience in continuing local processes and distinguishing actual organization from a selected observer's information. New claims are integrated through a versioned compatibility review, without discharging physical or phenomenal bridge obligations.

## 1. Scope, foundations, and the actual question

The motivating question is not whether information above a threshold switches experience on. Under UCT I's C1/U1 commitments, an admitted actual process has experience; P3 distinguishes its termination from continuing membership in a larger process. Thus information inaccessible to a reader does not imply experiential nonexistence of the storing process. Nor does memory continuity prove an unchanged complete experiential type, a persisting numerical subject, or a particular familiar feeling [1,2].

UCT III already separates full structural type, fixed-contract capabilities and scalar experiential rankings [2]. TA25 and the released graph already separate finite views, actual physical support, available evidence, actual consumer use and target-specific interpretation [3,4]. The present record retains these distinctions. A register vector is a mathematical model. A realization involving a brain, a cell or a silicon device requires independent justification of the actual bearer, relevant boundary, time scale, mechanism, interventions and any omitted physical influences.

The immediate questions are: (i) what can successful later recovery establish about earlier storage or accessibility? (ii) when can an explanation appeal to omitted input, and how large must that input be? (iii) how can these results be compared without changing the target or deadline halfway through the argument?

No new human, animal or deployed-language-model experiment is performed. The analytic model and exact finite computations are tests of mathematical claims. All physical interpretation remains conditional.

## 2. Inherited handoff construction, now explicitly separated from new results

The full original TH20261009 v0.1.0 note and executable program are preserved in `prior/`. They are not relabeled as newly discovered material. Let T, eta and xi be independent fair bits. A pair of actual-model registers starts with

    A = T XOR eta,   B = eta.

Its joint relation determines T. Copy to C,D before clearing the old A,B registers. In a shared-flip handoff,

    C = A XOR xi,   D = B XOR xi,

so C XOR D = T. The endpoint minimal decoding supports migrate from {A,B} to {C,D}, with no shared storage register. This does not remove the clock, handoff circuit, boundary conditions or other potentially indispensable physical components.

A second handoff uses D = B XOR xi XOR 1. The unchanged XOR reader is always wrong, but a complemented reader is always correct. A third uses independent xi,zeta in the two branches. Once the earlier information and all relevant masks are genuinely outside the permitted future input, the final pair is independent of T and optimal recovery is 1/2.

The original construction matches the conditional time record of each individual register and the unconditional full endpoint distributions across these cases. It does not match their complete open mechanisms or all joint intermediate-time distributions. Their changed joint temporal relation is precisely the intended difference.

The previous affine formulation was X = H T + G eta + b0 over a finite field F_q, with independent uniform T in F_q^d and eta, fixed matrices, and known offset. Write

    rho = rank([G H]) - rank(G),    M = q^(d-rho).       (1)

Every attainable observation has exactly M equally probable target completions, so the optimal full-target recovery probability is 1/M. This is elementary quotient-space counting. Under a complete source-screening transition, no independent downstream randomization can increase optimal recovery. The full proof, exact loss expression, port restriction, coordinate/noise transport and failure conditions remain in the preserved prior note.

The current graph already has direct antecedents: `R127:PAIR_MODEL`, `R127:MEDIATION`, `R136:DELAY_GAP`, source-boundary and decoder-transport nodes. Therefore neither masked storage, the need for a complete causal cut, nor endpoint/access separation is a new UCT theorem here [4]. The new task is a sharper, computable recovery budget and its contract-sensitive application to this inherited family.

## 3. Endpoint success and timely access are different capabilities

Let T and E be independent uniform two-bit words, and let C = T XOR E. Consider a reader that sees C but cannot inspect E until time L=2. E remains stored in the larger assembly throughout. A fast comparison reader receives the key immediately. No output before its specified read time may use an unlisted side channel.

At deadlines D=0,1,2,3, the slow reader's optimal full-target accuracy is

    (1/4, 1/4, 1, 1),

whereas the fast reader's accuracy is (1,1,1,1). Under one common task that selects these four deadlines uniformly and independently of T, mean accuracies are 5/8 and 1. At the final deadline both perform perfectly.

This proves only that equal endpoint recovery does not establish equal deadline-dependent capability. It does not prove interrupted experience. The full assembly (C,E) retains T at all times, while a specified reader's accessible record changes. Calling C the entire system and later allowing E back in would silently change the boundary.

In a physically fixed implementation, achievable decoding may also be limited by computational time, energy or installed circuitry. Our Bayes-optimal scores are information-based upper bounds, with explicit decoders only for the constructions. They should not be substituted for unrestricted physical capability or measured cognition without an implementation argument.

## 4. Sharp finite-alphabet recovery budget

### 4.1 Definitions

Let T and X be finite random variables with an arbitrary known joint law. X is the declared earlier record. Z is the **entire additional target-relevant transcript** available to the later reader before the specified deadline. For each x of positive mass, assume at most K possible values of Z, with K a positive integer. Timing, source identity, silence, message length, relevant protocol state and recalled correlated randomness must be included whenever they can signal information. Fixed externally known protocol data may be included in X.

Define

    G_K(T|X) = sum_x sum of the K largest values among {P(T=t,X=x): t},
    p0 = G_1(T|X) = p_guess(T|X).                       (2)

Equivalently, G_K is the optimal probability that T appears in a size-K list selected after seeing X. Zero-mass entries pad shorter supports. It is not conditional Shannon entropy, a cell count, or an experience magnitude.

The output Y obeys a source-screening condition

    P(Y | T,X,Z) = W(Y|X,Z).                            (3)

Any further randomization must be covered by this condition. Marginal independence from T alone is insufficient. A randomized decoder whose random bits satisfy (3) does not improve upon an appropriate deterministic decision rule.

### 4.2 Theorem: upper bound

For every implementation in this declared probability class,

    Pr(Y=T) <= p_guess(T|X,Z) <= G_K(T|X)
             <= min(1, K p0).                         (4)

The first inequality also applies when Y is decoded from a downstream variable satisfying (3).

**Proof.** Optimal deterministic decoding from X,Z has score sum_(x,z) max_t P(t,x,z). For each x,z choose a maximizing target t_(x,z). Let S_x be the distinct targets selected for this x; it has at most K elements. Group each z contribution according to its selected target. For a fixed selected t, the sum over the associated z values is no larger than P(t,x). Consequently the cell score is at most sum_(t in S_x) P(t,x), no larger than the K largest joint masses in that cell. Summing over x proves the middle inequality. Each of those K masses is no larger than the maximum in its cell, proving the last bound. The source-screening condition makes any later decision a randomized decision from X,Z, proving the first inequality. QED.

### 4.3 Sharpness and its important qualifier

For a fixed P_TX, equality at G_K is attainable **in the unrestricted helper class where an encoder may inspect (T,X)**. For each x assign distinct messages to its K largest positive posterior targets. Assign any remaining targets to one of the already used messages. Each message is decoded as its designated high-mass target, so the total correct mass is exactly the top-K sum. When fewer than K targets are possible, all are identified.

This is an existence result for the stated class. It does not show that a particular late arriving physical pathway sees T,X, has the required target-dependent encoder, or can use its entire nominal alphabet. A target-independent and conditionally irrelevant input can achieve much less. No decoder circuit or biological realization is established by writing this proof.

### 4.4 Inverse constraint

Given a true recovery success s justified under the same contract, a necessary alphabet size is

    K >= min { k>=1 : G_k(T|X) >= s }.                  (5)

The coarser necessary condition K >= ceil(s/p0) follows but can be loose. For a single uninformative x and target prior (0.6,0.1,0.1,0.1,0.1),

    G_1,...,G_5 = 0.6,0.7,0.8,0.9,1.

To recover with success at least 0.9 requires K>=4, whereas the coarse multiplicative bound only requires K>=2. Posterior shape therefore matters, not just a single initial accuracy.

If observed success exceeds (4), it refutes the conjunction of the declared target law, transcript cap, mediation, deadline and measurement assumptions. It does not on its own uniquely identify a hidden biological mechanism. An empirical use needs a lower confidence bound on true success and independently justified upper constraints on G_K and model error.

## 5. Uniform residual ambiguity and deadlines

In the affine handoff model of (1), each attainable X leaves M=q^(d-rho) equally probable target values. Equation (4) becomes

    Pr(Y=T) <= min(1,K/M).                              (6)

Perfect full-target recovery requires K>=M. The logarithm log2 M is a necessary missing-transcript discrimination budget; it is not the storage size of the entire organism.

Suppose the additional input arrives through at most Delta fixed slots, each of b binary payload bits, with no uncounted variable timing, silences, source identities or variable length. Its full transcript then has at most 2^(b Delta) values, giving

    Pr(Y=T) <= min(1, 2^(b Delta)/M).                    (7)

For perfect recovery, b Delta >= log2 M is necessary. Existing independent processing time might impose a larger delay; (7) is not a sufficient real-time feasibility theorem.

A uniform d-bit masked word attains the binary integer points: send k bits of the retained key; the remaining target ambiguity is 2^(d-k), so success is 2^(k-d). For a two-bit target this gives 25%, 50%, 100% with zero, one and two key bits. The key alone is independent of T, yet jointly with the earlier ciphertext it removes the ambiguity. This is an ordinary correlation mechanism, not information created from nothing.

For a coarser requested target U=f(T), apply (2) to U, not T. For example one parity bit can be recovered perfectly while a two-bit full target remains only half recoverable. The complete-target bound cannot be presented as a universal bound on all possible intelligent tasks.

## 6. Approximate boundaries and prior uncertainty

Let P be the actual joint law of T,X,Z,Y. Suppose it is within total variation delta of

    Q(t,x,z,y) = P_TXZ(t,x,z) W(y|x,z),

a source-screened model with the same T,X,Z marginal and the stated K cap. Then

    Pr_P(Y=T) <= min(1, G_K(P_TX) + delta).              (8)

**Proof.** The difference in probabilities of the event {Y=T} is at most total variation. Apply (4) to Q. QED.

If the prior law used in the calculation is instead an estimate R_TX with TV(P_TX,R_TX)<=epsilon, add epsilon to (8). The functional G_K is 1-Lipschitz in total variation: it is the supremum of probabilities of events {T in L(X)}, where each L(X) has size at most K. Each such probability changes by at most total variation, hence so does the supremum.

The additive delta bound can be tight. Take an unbiased binary T and an independent unbiased reference output. Move delta/2 probability mass from each off-diagonal pair to its diagonal pair, for 0<=delta<=1/2. Total variation is delta and recovery rises from 1/2 to 1/2+delta.

These bounds are not empirical certificates for a brain. Delta and epsilon cannot be inferred from the desired conclusion or set to zero because a fitted graph omitted a path. Their independent justification is part of the application obligation.

## 7. Counterexamples that determine the interpretation

**A wrong reader is not absent information.** A fixed complemented reader can score zero while optimal recovery from the same record is one. Thus failure of a particular neural/AI decoder is a lower-achievability observation, not an upper bound on what the complete physical record could support. Applying (4) to its accuracy as p0 reverses the required inference.

**Marginal independence is not a complete cut.** For a fair target T and retained fair mask E, C=T XOR E and E individually conceal T but jointly determine it. Reusing E downstream violates a claimed Markov cut consisting of C alone. The fact E was initially independent of T does not repair that omitted joint dependence. This is inherited from R127 and the original TH reused-mask counterexample, not a fresh impossibility theorem.

**Timing is part of the transcript.** Send the same pulse in one of four slots chosen by a four-valued T. Payload content is constant, but full arrival-time observation recovers T exactly. Describing Z as the constant payload falsely sets K=1; the actual transcript has four distinct values. The fixed-slot assumption in (7) is substantive.

**Successful final restoration is not continuous accessibility.** In the delayed-key example, full source information persists in the larger assembly, yet earlier reader deadlines fail. With no key or any other target-correlated path admitted at any later time, successful restoration is impossible under the source-screening model. Neither case identifies subjective continuity.

**Model refutation is not mechanism localization.** Excess recovery may indicate omitted side information, a nonuniform target, a different task, a violated alphabet cap, a timing channel or estimation error. The bound diagnoses incompatibility of a package of assumptions. It does not prove that one favored hidden route exists.

## 8. Relation to published papers, internal map, and external precedents

The distinction between preserved local processes and changed full experiential structure is inherited from UCT I; fixed-contract capability/type consequences and the absence of a universal richness ranking are inherited from UCT III and TA25 [1–3]. Original R127 already has complete-cut mediation, XOR examples and information-theoretic lower bounds. R136 already distinguishes delay from discontinuity; R137 and R172 prevent omitted seed/joint-cause paths and certificate-to-mechanism substitutions. CORE/OO/RC/RU distinguish target-relative support, useful coding, coherence and actual readout. The new record does not turn these into a second set of original findings.

Mathematically, G_K is standard optimal posterior list success, and the K p0 consequence is a classical bounded-side-information guessing/min-entropy inequality. Dodis et al. [5, §2.4, Lemma 2.2(b)] explicitly give the corresponding average conditional min-entropy alphabet bound. The top-K expression supplies a sharp specialization for the specified helper class, not a priority claim against list decoding. Affine rank formulas and streaming communication constraints use established coding principles. An exact historical-priority claim for this combined handoff/recovery application remains unverified.

Wolff et al. [6] used an impulse-response approach to reveal memory-item-related signals when a conventional delay-activity readout was insufficient. Rose et al. [7] found transient reactivation of a previously unattended memory representation after stimulation. These original experiments motivate separating an observation failure from complete physical erasure. They do not establish the posterior of all relevant brain variables, an exhaustive bound on new target-related inputs, our masking mechanism, or experiential disappearance/reappearance. No raw data from either study have been reanalyzed here.

The proposed contribution is therefore an integrated theoretical constraint: moving target support can coexist with changing access; recovery beyond a known earlier record requires a quantitatively adequate additional discriminating transcript unless the mediation model itself fails. The work may be useful without naming a new quale. Its scientific value depends on making the target and input contract independently defensible, not on relabeling information as consciousness.

## 9. UCT inference map and a positive limit on interpretation

The new mathematical rules terminate in recovery-budget, deadline and counterexample nodes. They do not terminate directly in statements about human feelings. A conditional UCT application additionally requires (a) admitted actual processes, (b) a common complete relevant signature and time/boundary comparison, (c) an independently identified installed consumer and true fixed evaluation contract, and (d) a genuine inequality of the corresponding capabilities. Only then can inherited C:P1 be applied.

A new structural type difference need not change the particular target feeling being discussed, and preserving a task target need not preserve full experiential structure. Continuing local actual processes retain the U1 commitment; no reader, memory or delay threshold is imposed for basal experience. A named target interpretation would need its own noncircular bridge. QC10, IA-QC11, QC12 and QC13 are not closed by this work.

This respects the user's theoretical position: research need not wait for a unique exclusive subject selector. At the same time, target-information continuity must not be mislabeled numerical subject identity or familiar mineness. The mathematical variables are declared targets, not concealed definitions of the desired feeling.

## 10. Verification, review, and preservation

`code/check_recovery_budget.py` was actually run. It checks 5,095 finite joint laws (4,095 exhaustively enumerated binary-weight supports plus 1,000 fixed-seed rational cases), 60 helper-optimization cases across 38,568 candidate encoder evaluations, six total-variation saturation cases, streamed-key examples, timing/coarse-target controls and 1,221 prior-variation comparisons. All reported claims are computed with integer/Fraction arithmetic. Finite checks corroborate proofs within the stated domains; they do not prove universal statements by sampling.

The inherited TH v0.1.0 source note, map and code are retained by exact bytes. A fresh author-side compatibility review reads the 1,278 item statements, bindings and scopes of the completed v1.0.0 map, plus the TH additions. The newly appended rules do not rewrite old heads or activate the ten suspended historical rules. Unchanged old mathematical arguments are retained through their exact prior proof contracts; this is not a fresh independent proof of every source theorem or empirical claim. Pending R185 and AC work is preserved separately and is not used as established premises.

The release/audit files record the exact coverage and result version. A completed compatible additive map release may use v1.1.0 under the existing version policy; it must not overwrite v1.0.0. GitHub persistence and readback are recorded separately from the content of this candidate paper. No DOI, journal submission, Arweave transaction, website or scheduler action is authorized by this note.

## 11. Publication judgment and next decisive step

The combined TH/RB material is coherent enough for a working paper about temporal organization and recovery limits. It is not yet evidence for a new general theory of consciousness. The exact finite theorem is useful but mathematically closely related to established posterior-list and leakage results; the original handoff family also uses established correlated coding. A new publication should claim an explicit synthesis/application and contrast with the author's published III/TA25, not a first discovery of information preservation or an independent confirmation of C1.

A useful next step is one actually specified action-memory assembly with a predeclared consumer, deadline and exhaustive input budget, where a competing explanation predicts success above (4) or where two implemented handoffs preserve endpoint performance but differ on the same deadline task. A bounded implementation or a sufficiently documented existing experiment could establish the functional comparison. It still would not independently identify a named feeling. Immediate automatic DOI publication is withheld; this working draft and all proofs are preserved for assessment.

## References and access scope

[1] Liu, H. Unified Consciousness Theory I, v1.2. DOI 10.5281/zenodo.23131575. Frozen English source in the workspace R128 sources; C1/U1/P3 and actual-process/organization criteria used. First-party theory, not empirical ground truth.

[2] Liu, H. Unified Consciousness Theory III, v1.0. DOI 10.5281/zenodo.23137088. Fixed-contract capability and type statements and decision-theory limitations used.

[3] Liu, H. Experience, Intelligence, and Self Within Experience, v1.0. DOI 10.5281/zenodo.23206492. Frozen R153 source and corresponding map contracts used.

[4] Liu, H. UCT-MAP-v1.0.0 / FA20261008. Release commit f6445052acb1644fcdd7b2adcdda2307f7b98bc7; fixed source 48b131a3ae8f7ac003ff5a2ce9c8d36111b2ea3c. Current research head inspected separately at 11c1af83fa7e9eabca8351b67dfe162f59da7dd1. R127, R136, R137, CORE, OO, RC, RU, R171/R172 and pending AC/R185 distinguished.

[5] Dodis, Y., Ostrovsky, R., Reyzin, L., Smith, A. (2008). Fuzzy Extractors: How to Generate Strong Keys from Biometrics and Other Noisy Data. SIAM Journal on Computing 38(1), 97–139. DOI 10.1137/060651380. Author PDF https://www.cs.bu.edu/~reyzin/papers/fuzzy.pdf; §2.4 and Lemma 2.2(b) inspected including page images. Supports the established guessing/min-entropy alphabet bound, not novelty of this research.

[6] Wolff, M. J., Jochim, J., Akyürek, E. G., Stokes, M. G. (2017). Dynamic hidden states underlying working-memory-guided behavior. Nature Neuroscience 20, 864–871. DOI 10.1038/nn.4546. Publisher abstract and publicly available method description inspected, no raw-data reanalysis. https://www.nature.com/articles/nn.4546

[7] Rose, N. S., et al. (2016). Reactivation of latent working memories with transcranial magnetic stimulation. Science 354, 1136–1139. DOI 10.1126/science.aah7011. Original abstract and author repository record inspected, not a full independent replication. https://pubmed.ncbi.nlm.nih.gov/27934762/

[8] Liu, H. Map-Guided Theory Development, v1.0.1. DOI 10.5281/zenodo.23241982. Research protocol used for premises, counterexamples, full-census compatibility review and versioned preservation. Its publication does not validate the theory being developed.
