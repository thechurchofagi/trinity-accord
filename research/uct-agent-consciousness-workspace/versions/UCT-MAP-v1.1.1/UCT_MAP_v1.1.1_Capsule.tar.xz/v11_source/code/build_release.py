#!/usr/bin/env python3
"""Materialize the saved author-side compatibility decisions, NOT a new audit.
Rebuild requires exact baseline graph/ledger and the original TH v0.1 module.
"""
from __future__ import annotations
import copy, csv, hashlib, json, pathlib, shutil
from collections import Counter
ROOT=pathlib.Path(__file__).resolve().parents[1]
BASE=ROOT/'baseline'; PRIOR=ROOT/'prior'
VERSION='UCT-MAP-v1.1.0'; AUDIT='THRB20261009-COMPAT-v1'

def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def canon(o):return json.dumps(o,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()

def make_module():
    old=json.loads((PRIOR/'MAP_EXTENSION_v0.1.0.json').read_text())
    nodes=copy.deepcopy(old['nodes']);rules=copy.deepcopy(old['rules']);contexts=copy.deepcopy(old['context_links'])
    for obj in nodes+rules:
        obj['source_checkpoint_status']=obj.pop('status','PENDING_MAP')
        obj['review_status']='COMPATIBILITY_REVIEWED_WITH_LIMITS'
        obj['status']='APPLICATION_OPEN' if 'OPEN' in obj.get('kind','') else 'REVIEWED_CONDITIONAL_OR_DECLARED'
        obj['premise_truth_discharged_by_review']=False
        for field in ['proof_or_definition','proof']:
            if field in obj:obj[field]=obj[field].replace('RESEARCH_NOTE.md','prior/RESEARCH_NOTE_v0.1.0.md')
    # Do not turn pending checkpoint material into a deductive premise.
    for c in contexts:
        c['source_type']='external_reference' if c.get('external_source') else 'node'
        c['deductive']=False
    prefix='RB20261009:'
    def n(i,kind,s,scope,proof,limit):
        nodes.append({'id':prefix+i,'kind':kind,'statement':s,'scope':scope,'proof_or_definition':'RESEARCH_NOTE.md '+proof,'limits':limit,'review_status':'COMPATIBILITY_REVIEWED_WITH_LIMITS','status':'APPLICATION_OPEN' if 'OPEN' in kind else 'REVIEWED_CONDITIONAL_OR_DECLARED','premise_truth_discharged_by_review':False})
    common='One finite joint law, one full target T, one earlier accessible record X, one deadline and the entire newly admitted transcript. Conditional laws and decoder class remain fixed within each comparison.'
    n('CONTRACT','MODEL_ASSUMPTION','T,X,Z are finite; P_TX is specified. T is the full target. Z records all later source-relevant arrivals before the fixed deadline, not only payload bits.',common,'§4.1','Not an empirical declaration that a measured neural record is a complete physical cut.')
    n('ALPHABET','MODEL_ASSUMPTION','For every x with positive probability, the support of Z conditional on X=x has at most the positive integer K elements.',common,'§4.1','Timing, silence, sender identity, variable length and recalled correlated state must be counted when informative.')
    n('MEDIATION','MODEL_ASSUMPTION','For this same law P(Y|T,X,Z)=W(Y|X,Z); all additional randomness obeys the corresponding conditional source-screening relation.',common,'§4.1','Independence from T alone is not sufficient; no omitted shared key or source path.')
    n('TOPK','DEFINITION','G_K(T|X)=sum_x sum of the min(K,|T|) largest joint masses P(T=t,X=x). G_1=p_guess(T|X).',common,'§4.1 eq.2','An optimal list-success functional, not consciousness amount or mutual information.')
    n('BOUND','CONDITIONAL_THEOREM','Pr(Y=T)<=p_guess(T|X,Z)<=G_K(T|X)<=min(1,K*G_1(T|X)).',common,'§4.2','Requires CONTRACT, ALPHABET, MEDIATION jointly. Arbitrary one-reader failure is not an upper bound on G_1.')
    n('HELPER','MODEL_ASSUMPTION','For the achievability comparison, a hypothetical unrestricted helper encoder is allowed to inspect both T and X and send one of K labels.',common,'§4.3','No actual neural or silicon encoder with this access is established.')
    n('TIGHT','CONDITIONAL_THEOREM','With HELPER, the supremum recovery over allowed helper encoders and decoders equals G_K by labeling the top-K posterior candidates.',common,'§4.3','Tightness is relative to this unrestricted helper class; not every K-symbol physical pathway attains it.')
    n('CERTIFIED_SUCCESS','OPEN_APPLICATION_OBLIGATION','The true success s, posterior law or certified bounds on it, complete transcript cap, mediation and deadline have been independently justified for this same comparison.',common,'§4.4','A sample accuracy or a fitted model without confidence/realization evidence does not discharge the premise.')
    n('INVERSE','CONDITIONAL_THEOREM','A correctly specified comparison achieving success s requires K>=min{k:G_k>=s}, and hence K>=ceil(s/G_1).',common,'§4.4','Excess recovery rejects the joint contract, not uniquely one mechanism; target-specific bound.')
    n('NONUNIFORM','FINITE_CONSTRUCTION','For target prior (3/5,1/10,1/10,1/10,1/10) and constant X, G_1..G_5=(3/5,7/10,4/5,9/10,1). Success>=9/10 requires at least four transcript values.', 'The displayed five-state prior, constant X, K in {1,...,5}.','§4.4','The coarse ceil(s/p0) lower bound is only two; this example is not a human statistic.')
    n('UNIFORM_RESIDUAL','CONDITIONAL_THEOREM','Under TH FIELD_CONTRACT, every supported X leaves M=q^(d-rho) equiprobable T values; therefore G_K=min(1,K/M), and perfect full-target recovery requires K>=M.', 'One TH affine finite-field law instantiated jointly with the same RB target/view/transcript.','§5 eq.6','The original rho is a target discrimination dimension, not a substrate or experiential measure.')
    n('SLOTS','MODEL_ASSUMPTION','All newly informative input uses at most Delta fixed slots of b binary symbols each. There are no uncounted timing, silence, variable-length, identity or hidden-source channels.',common,'§5','Applies to the full incoming transcript. It is stronger than saying a packet has b payload bits.')
    n('DEADLINE_BOUND','CONDITIONAL_THEOREM','Under UNIFORM_RESIDUAL and SLOTS, success<=min(1,2^(b*Delta)/M). Perfect recovery requires b*Delta>=log2 M.',common,'§5 eq.7','Necessary information/deadline budget only; computational or physical implementation can require more.')
    n('KEY_MODEL','MODEL_ASSUMPTION','T and E are independent uniform d-bit words, C=T XOR E; E physically persists in the larger model. The selected reader sees C and only the declared k key bits by its deadline.', 'The fixed masked-word model, 0<=k<=d; key and reader availability are distinct.','§3 and §5','No recovery can be inferred for the brain from the mathematical model alone.')
    n('KEY_CURVE','FINITE_FAMILY_RESULT','In KEY_MODEL, optimal recovery is 2^(k-d). For d=2, no key/one key bit/full key gives 1/4,1/2,1.', 'Same uniform target and actual-toy decoder interface.','§5','Data-processing is not violated: the key is additional source-relevant information conditional on C.')
    n('DELAY_SETUP','MODEL_ASSUMPTION','Instantiate the two-bit KEY_MODEL in two allowed circuits: key available immediately versus first available at L=2; both face the same independent uniform deadline D in {0,1,2,3}, and no other target side input.',common,'§3','This is an explicit pair of physical-model architectures; equal eventual recall alone is not a fixed deadline-capacity comparison.')
    n('DELAY_WITNESS','FINITE_COUNTEREXAMPLE','For d=2, key arrival L=2 and common independent uniform deadline D in {0,1,2,3}, the delayed reader scores 5/8 and immediate reader 1, while both have perfect final recovery.', 'Same deadline distribution and target; routes are physically stipulated parts of the compared models.','§3','Endpoint equality does not identify continuous accessibility; does not imply a gap in experience.')
    n('APPROX_SETUP','MODEL_ASSUMPTION','The actual law P_TXZY is within total variation delta of Q=P_TXZ*W(Y|XZ), with the same TXZ marginal and the same K transcript cap.',common,'§6','Delta must be independently bounded; not set from the desired recovery score.')
    n('APPROX_BOUND','CONDITIONAL_THEOREM','Under APPROX_SETUP, success<=min(1,G_K(P_TX)+delta).',common,'§6 eq.8','A robustness envelope, not empirical identification of the violated mechanism.')
    n('PRIOR_SETUP','MODEL_ASSUMPTION','An estimated R_TX obeys TV(P_TX,R_TX)<=epsilon for the same target and observed alphabet.',common,'§6','A statistical certificate is not supplied by storing an estimate in the map.')
    n('PRIOR_LIPSCHITZ','CONDITIONAL_THEOREM','|G_K(P_TX)-G_K(R_TX)|<=TV(P_TX,R_TX); combining with APPROX_BOUND gives success<=min(1,G_K(R_TX)+delta+epsilon).',common,'§6','Same finite target/view labels and admissible lists on both laws.')
    n('WRONG_READER','FINITE_COUNTEREXAMPLE','For a uniform two-bit T and X=T XOR 3, the installed reader X scores zero but an inverted reader and Bayes optimum score one.', 'One uniform four-state target and invertible code.','§7','Observed poor decoding cannot establish complete representational absence.')
    n('TIMING_CONTROL','FINITE_COUNTEREXAMPLE','A constant pulse sent at one of four target-dependent times recovers a four-valued target; payload-only K=1 is false for the actual transcript, which has K=4.', 'Four distinguishable arrival slots, no noise.','§7','Controls the premise of the deadline theorem, not an alternative derivation bypassing it.')
    n('TARGET_CONTROL','FINITE_COUNTEREXAMPLE','With a uniform four-valued T and Z=T mod 2, full-target success is 1/2 while the parity target U=T mod 2 is known exactly.', 'Specific finite prior and coarsened target; the two tasks are explicitly distinct.','§5 and §7','Do not apply the full-T lower bound to a changed task U.')
    n('UCT_BOUNDARY','INFERENCE_GUARD','Applying these task relations to C1 needs the old actual-realization and fixed-real-J obligations; no new rule yields experiential absence, intensity, numerical subject continuity or a named quale.', 'All RB and TH applications.','§9','This does not retract U1/P3 or make a subject selector a prerequisite for research.')
    def r(i,ps,c,proof,binding):rules.append({'id':prefix+i,'all_of':[p if ':' in p else prefix+p for p in ps],'conclusion':prefix+c,'kind':'CONDITIONAL_DEDUCTION','binding':binding,'same_instance_required':True,'proof':'RESEARCH_NOTE.md '+proof,'review_status':'COMPATIBILITY_REVIEWED_WITH_LIMITS','status':'REVIEWED_CONDITIONAL','premise_truth_discharged_by_review':False})
    r('r_bound',['CONTRACT','ALPHABET','MEDIATION','TOPK'],'BOUND','§4.2','Same T,X,Z,Y,P and K; all input paths before the same deadline.')
    r('r_tight',['CONTRACT','ALPHABET','MEDIATION','TOPK','HELPER','BOUND'],'TIGHT','§4.3','Same P_TX,K; optimization only within the explicitly enlarged helper class.')
    r('r_inverse',['BOUND','CERTIFIED_SUCCESS'],'INVERSE','§4.4','The modeled/certified success and bound refer to the same contract.')
    r('r_uniform',['TH20261009:FIELD_CONTRACT','TH20261009:RECOVERY_RANK','TH20261009:BAYES_RECOVERY','TOPK','BOUND'],'UNIFORM_RESIDUAL','§5','RB T,X are exactly TH tau,X; no extra observation between the two definitions.')
    r('r_deadline',['UNIFORM_RESIDUAL','SLOTS'],'DEADLINE_BOUND','§5','Full deadline transcript alphabet, not just payload.')
    r('r_key',['KEY_MODEL','TOPK'],'KEY_CURVE','§5','The exactly stipulated independent full key and k revealed bits.')
    r('r_delay',['KEY_MODEL','KEY_CURVE','DELAY_SETUP'],'DELAY_WITNESS','§3','Instantiate d=2,L=2 and uniform D over 0..3, compared with immediate key arrival.')
    r('r_approx',['CONTRACT','ALPHABET','TOPK','APPROX_SETUP'],'APPROX_BOUND','§6','Same TXZ marginal; invoke the mathematical source-screened reference, not assume P itself is screened.')
    r('r_prior',['TOPK','PRIOR_SETUP','APPROX_BOUND'],'PRIOR_LIPSCHITZ','§6','Same alphabets; compare the same family of size-K target lists; additive delta and epsilon.')
    # Finite counterexamples are fully specified source constructions, not arbitrary routes.
    for i,s,t,rel in [
      ('ctx1','R127:MEDIATION','RB20261009:BOUND','Prior complete-cut contract; the coarse information bound is not new.'),
      ('ctx2','R136:DELAY_GAP','RB20261009:DELAY_WITNESS','Endpoint/timing distinction inherited; numerical witness specialized.'),
      ('ctx3','OO20261008:QUERY_RETURN','RB20261009:ALPHABET','Count returning target-dependent query/answer information; no silent change of architecture.'),
      ('ctx4','TH20261009:REUSED_MASK','RB20261009:MEDIATION','Joint conditional dependence survives marginal target independence.'),
      ('ctx5','C:P3','RB20261009:UCT_BOUNDARY','No scalar experiential ordering inferred.'),
      ('ctx6','TH20261009:LOCAL_EXPERIENCE','RB20261009:UCT_BOUNDARY','Continuing local experience is not revoked by access failure.'),
      ('ctx7','RB20261009:BOUND','TH20261009:ACTUAL_REALIZATION','Possible future application; neither node discharges the other.'),
      ('ctx8','EXTERNAL:Dodis2008Lemma2.2b','RB20261009:BOUND','Established conditional guessing/min-entropy alphabet bound; credit prior art.'),
      ('ctx9','EXTERNAL:Wolff2017','RB20261009:WRONG_READER','Original experiment motivates observational distinction, not an upper bound on all neural information.'),
      ('ctx10','PENDING:AC20261009','RB20261009:TARGET_CONTROL','Related task-specific binding record remains separately pending.')]:
        contexts.append({'id':prefix+i,'source':s,'target':t,'relation':rel,'deductive':False,'external_source':s.startswith(('EXTERNAL:','PENDING:')),'source_type':'external_reference' if s.startswith(('EXTERNAL:','PENDING:')) else 'node'})
    return {'schema':'uct-reviewed-additive-module/1.0','research_id':'TH20261009','result_version':'0.2.0','review_release':VERSION,'audit_id':AUDIT,'status':'REVIEWED_WITH_EXPLICIT_CONDITIONS','enabled_as_conditional_routes':True,'all_roots_automatically_accepted':False,'parent_completed_map':'UCT-MAP-v1.0.0','nodes':nodes,'rules':rules,'context_links':contexts,'physical_and_phenomenal_applications':'OPEN','publication':'WORKING_PAPER_ONLY_NO_DOI'}

# These families summarize judgments made after reading the complete item census and scope registry.
# Running this code reproduces recorded judgments; it cannot independently conduct that reading.
def compatibility_reason(item):
    ident=item['item_id']; st=item['effective_statement'];typ=item['item_type']
    prefix=ident.split(':')[0]
    if typ=='context':return 'Non-deductive linkage retained. New module does not execute analogy, citation, pending checkpoint or evidence relations as inference.'
    if item['decision'].startswith('SUSPEND') or ident in SUSP:return 'Historical route remains suspended and absent from active closure. The new module supplies no substitute that bypasses its amendment/instance obligations.'
    if prefix=='A' or ident.startswith('a0'):return 'C1/U1 and actual-token, P3 persistence, common-signature and scope commitments are unchanged. Finite target decodability is not admission or experiential existence; no new rule concludes an old ontic node.'
    if prefix=='B':return 'Cross-theory and target-translation claims retain their declared context. RB mathematical targets are not translated into a named phenomenal target without a separate bridge.'
    if prefix=='C' or ident in ('c01','c12'):return 'Fixed evaluation, optimal versus installed performance, type versus scalar richness and actual realization remain distinct. Added recovery bounds compare only their declared target, channel and deadline.'
    if prefix=='R127':return 'Source-screening cut, withheld correlated randomness and existing information bounds are inherited. Top-K sharpness narrows a finite helper class and does not contradict or claim priority over this contract.'
    if prefix in ('R136','R137'):return 'Deadline gaps and carried seeds are not experiential gaps. Delayed/reused keys are explicitly in the actual accessible/full-cut distinction; endpoint recovery does not erase these obligations.'
    if prefix in ('R168','R169','R170'):return 'Uncertainty/identification bounds remain conditional; RB delta and epsilon need independent justification. A decoder failure is not an exhaustive upper information certificate.'
    if prefix in ('R171','R172','R173','R174','R175','R176','R177','R178'):return 'Coverage alternatives, actual-use witnesses, joint contexts and effective corrections remain active. A probability model or saved certificate does not supply a missing actual occurrence or named self relation.'
    if prefix.startswith('CORE'):return 'Target-relative minimal support is compatible with support migration only under explicit timing/cut policies; nonmonotonic and alternative support limits remain retained.'
    if prefix in ('OO20261008','RC20261008','RU20261008','IE20261008','EI20261008','R183','R184'):return 'Functional use, coding, report, calibration and task relevance remain target- and architecture-relative. New information budgets neither replace their target nor turn control/recovery into named feeling.'
    return 'Statement, declared scope and recorded obligations remain compatible with the additive finite T/X/Z model. No old definition or head is rewritten; actual-token/finite-view, target/type, report/use and alternative/joint-premise distinctions are preserved. The prior proof/evidence decision is retained, not empirically upgraded.'

def main():
    global SUSP
    g=json.loads((BASE/'UCT_EFFECTIVE_GRAPH.json').read_text());oldledger=json.loads((BASE/'REVIEW_LEDGER.json').read_text())
    SUSP=set(g['suspended_historical_rule_ids']);m=make_module();dump(ROOT/'MAP_EXTENSION.json',m)
    # Make earlier-source proof locators explicit; the prior original is preserved, not overwritten.
    ids=[n['id'] for n in g['nodes']];newids=[n['id'] for n in m['nodes']]
    assert len(set(ids+newids))==len(ids)+len(newids)
    allids=set(ids+newids);allrules=g['rules']+m['rules'];assert len({r['id'] for r in allrules})==len(allrules)
    for r in m['rules']:
        assert r['all_of'] and set(r['all_of'])<=allids and r['conclusion'] in set(newids)
        assert r['same_instance_required'] and r['binding'] and not r.get('premise_truth_discharged_by_review')
    for c in m['context_links']:
        assert not c['deductive'];assert c['target'] in allids
        assert c.get('external_source') or c['source'] in allids, c
    # Check cycles on ordinary all_of routes; external obligations remain independent guards.
    edges={i:set() for i in allids};indeg=dict.fromkeys(allids,0)
    for r in allrules:
        for p in r['all_of']:
            if p in allids and r['conclusion'] not in edges[p]:edges[p].add(r['conclusion']);indeg[r['conclusion']]+=1
    q=[i for i,v in indeg.items() if v==0];nseen=0
    while q:
        x=q.pop();nseen+=1
        for y in edges[x]:
            indeg[y]-=1
            if not indeg[y]:q.append(y)
    assert nseen==len(allids)
    assert not SUSP & {r['id'] for r in allrules}
    # Record-specific compatibility rows preserve the complete old source record hash and substantive statement.
    reviewed=[]
    for it in oldledger['items']:
        row={'item_id':it['item_id'],'item_type':it['item_type'],'source':'baseline/REVIEW_LEDGER.json','parent_item_sha256':sha(canon(it)),'effective_statement':it['effective_statement'],'scope':it['scope'],'premise_ids':it.get('premise_ids',[]),'instance_obligations':it.get('instance_obligations',[]),'conclusion_id':it.get('conclusion_id'),'context_endpoints':it.get('context_endpoints'),'parent_decision':it['decision'],'this_review':'COMPATIBLE_WITH_ADDITIVE_TH_RB_CONTRACT','reason':compatibility_reason(it),'proof_handling':'Retain exact prior proof/evidence/status contract; not a new independent proof or empirical verification.','actual_premises_discharged':False}
        reviewed.append(row)
    for typ,records in [('node',m['nodes']),('rule',m['rules']),('context',m['context_links'])]:
        for it in records:
            reviewed.append({'item_id':it['id'],'item_type':typ,'source':'MAP_EXTENSION.json','source_record_sha256':sha(canon(it)),'effective_statement':it.get('statement',it.get('relation',f"{it.get('all_of')} => {it.get('conclusion')}")),'scope':it.get('scope',it.get('binding','Declared source/target contexts; non-deductive.')),'premise_ids':it.get('all_of',[]),'conclusion_id':it.get('conclusion'),'this_review':'REVIEWED_CONDITIONAL_OR_DECLARED' if typ!='context' else 'REVIEWED_NONDEDUCTIVE','reason':it.get('limits','Every all_of guard required in one appropriately bound model; no inference from a stored node to actual premise truth.') if typ!='context' else 'Source/analogy relation retained without becoming a proof path.','actual_premises_discharged':False})
    assert len({r['item_id'] for r in reviewed})==len(reviewed)
    effective=copy.deepcopy(g);effective.update(version=VERSION,audit_id=AUDIT)
    effective['nodes']+=m['nodes'];effective['rules']+=m['rules'];effective['context_links']+=m['context_links']
    effective['parent_release']='UCT-MAP-v1.0.0';effective['added_module']='TH20261009 v0.2.0';effective['pending_not_loaded']=['R185','AC20261009']
    dump(ROOT/'UCT_EFFECTIVE_GRAPH.json',effective)
    dump(ROOT/'REVIEW_LEDGER.json',{'release':VERSION,'audit':AUDIT,'review_kind':'Fresh author-side all-item compatibility review, deeper new and affected-chain argument review; no independent proof/empirical certification.','items':reviewed})
    with (ROOT/'REVIEW_LEDGER.csv').open('w',newline='') as f:
        fields=['item_id','item_type','source','this_review','reason','actual_premises_discharged'];w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(reviewed)
    counts={'nodes':len(effective['nodes']),'active_conditional_rules':len(effective['rules']),'suspended_historical_rules':len(SUSP),'reviewed_rule_records':len(effective['rules'])+len(SUSP),'context_links':len(effective['context_links']),'review_items':len(reviewed),'old_items':len(oldledger['items']),'new_nodes':len(m['nodes']),'new_rules':len(m['rules']),'new_contexts':len(m['context_links']),'unreviewed_in_active_defined_census':0}
    rr={'status':'PASS','counts':counts,'scope':'Mechanical checks reproduce the recorded structure; semantic reading is separately documented, not established by this program.','base_node_records_byte_semantics_unchanged':effective['nodes'][:len(g['nodes'])]==g['nodes'],'base_rule_records_unchanged':effective['rules'][:len(g['rules'])]==g['rules'],'suspended_routes_stay_inactive':True,'local_and_unguarded_reference_check':True,'all_new_rule_heads_in_new_namespace':True,'acyclic':True,'automatic_acceptance_of_roots':False}
    dump(ROOT/'results'/'MAP_CHECK_RESULTS.json',rr)
    dump(ROOT/'RELEASE.json',{'release_id':VERSION,'release_seq':2,'parent_release':'UCT-MAP-v1.0.0','audit_id':AUDIT,'research_id':'TH20261009','result_version':'0.2.0','date':'2026-10-09','status':'COMPATIBILITY_REVIEW_COMPLETE_WITH_CONDITIONS_AND_OPEN_APPLICATIONS','baseline_graph_sha256':sha((BASE/'UCT_EFFECTIVE_GRAPH.json').read_bytes()),'baseline_ledger_sha256':sha((BASE/'REVIEW_LEDGER.json').read_bytes()),'module_sha256':sha((ROOT/'MAP_EXTENSION.json').read_bytes()),'effective_graph_sha256':sha((ROOT/'UCT_EFFECTIVE_GRAPH.json').read_bytes()),'review_ledger_sha256':sha((ROOT/'REVIEW_LEDGER.json').read_bytes()),'counts':counts,'added_ids':[r['id'] for r in m['nodes']+m['rules']+m['context_links']],'changed_old_scientific_ids':[],'newly_suspended_ids':[],'pending_checkpoints_retained_not_promoted':['R185','AC20261009'],'qc_open':['QC-20261008-10','IA-QC11','QC-20261008-12','QC-20261008-13'],'physical_and_named_phenomenal_application':'OPEN','publication_status':'WORKING_MANUSCRIPT_NO_PUBLICATION_ACTION','review_is_not':['proof_assistant_verification','independent_peer_review','empirical_confirmation','complete_external_priority_clearance'],'remote_persistence':'SEPARATE_RECEIPT_REQUIRED'})
    print(json.dumps(rr,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
