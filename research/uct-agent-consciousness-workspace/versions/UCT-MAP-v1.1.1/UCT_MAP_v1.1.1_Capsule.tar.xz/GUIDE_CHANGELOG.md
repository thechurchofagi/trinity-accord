# Guide v2.0 -> v2.1

2026-10-09: Author directs obligatory persistent work logs and handoff after each substantive user-facing research output, precise version/release sequence and actual remote readback, failure retention, full audit. Adds §10 without changing UCT C1/U1/P3. Old v2.0 bytes separately preserved; no new consciousness axioms.
