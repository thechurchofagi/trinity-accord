This repository contains the behavioral data and analysis outputs for the manuscript
“Effects of prediction and attention on tactile precision in somatosensory gating” (D’Onofrio Pacheco & Zimmermann, Heinrich-Heine University Düsseldorf).

All data are organized in one main folder.

Data/ CSV Participant/

Contains the raw data for each participant.
Every subfolder Contains the raw data for each participant in each following conditions:

Active/ – trials recorded during self-generated movements. Attentional allocation Start & End 

Passive/ – trials recorded during externally driven movements. Attentional allocation Start & End 

Control/ – trials recorded at rest (no movement). Attentional allocation Start & End 



PSE_and_JND/

Contains the fitted psychometric results PSE and JND(based on cumulative Gaussian fits) for all participants in every condition and level.

VP,Gender,Age,PSE_Control_end,PSE_Control_start,PSE_Passive_end,PSE_Passive_start,PSE_Active_start,PSE_Active_end,JND_Control_end,JND_Control_start,JND_Passive_end,JND_Passive_start,JND_Active_start,JND_Active_end,Delta_Active_JND,Delta_Passive_JND

Notes

All CSV files are comma-separated and include participant ID, condition labels, trial number, and response variables.

Excel files contain the averaged and fitted psychometric parameters (PSE and JND) used for group-level analyses.

Naming conventions follow the terminology used in the manuscript Methods section.

Data can be analyzed using MATLAB, JASP, or any statistical software supporting CSV/XLSX formats.