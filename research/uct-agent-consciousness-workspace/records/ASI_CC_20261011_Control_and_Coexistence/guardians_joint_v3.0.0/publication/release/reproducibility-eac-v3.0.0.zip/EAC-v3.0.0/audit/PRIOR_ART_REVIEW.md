# Targeted primary-source and overlap review — EAC-v3.0.0

12 October2026. Not an exhaustive global novelty determination; searches returned some irrelevant quorum-sensing/religious results, which were discarded.

| Primary source | Reading scope during this revision | Attribution and boundary |
|---|---|---|
| Bailis et al., Coordination Avoidance in Database Systems, PVLDB8(3),185–196,2014 | Publisher full PDF; model and §4, including rendered pp4–5/printed188–189 | Individually valid snapshots do not imply valid merges; invariant confluence is established. Our elementary pair counterexample at one base does NOT refute their criterion over reachable states. |
| Kleppmann & Howard, Byzantine Eventual Consistency, arXiv2012.00472 | Primary full HTML, §§2.2–3.3 and Theorem3.1/proof | Byzantine invariant-preserving replication and nonconfluence limits are direct predecessors. Their arbitrary fault model differs from our bounded root exposure, and our scheme already coordinates through local journals. |
| Howard/Charapko/Mortier, Fast Flexible Paxos, arXiv2008.02671 | Primary full HTML, quorum intersection equations and proof scope | Higher-order intersections are already known. We index constraints by actual minimal application failures and qualified reviewers; no consensus lower-bound improvement or performance comparison. |
| Li/Chan/Lesani, Satrapy2026, DOI10.1007/s00446-026-00507-0 | Primary publisher HTML; definitions, weak-availability impossibility and authors/bibliography | Pairwise intersection plus weak availability need not establish full consensus. Our SOLO availability explicitly does not claim consensus or arbitrary contention termination. |
| Malkhi/Reiter, Byzantine Quorum Systems1998 | Author-affiliated bibliographic record and preceding v2 source context; full paper not independently reproduced here | Honest intersection and fail-prone-set separation are inherited. |
| Herzberg/Jarecki/Krawczyk/Yung1995 | Predecessor bibliography/abstract-level context; full cryptographic proof not reread | Proactive renewal already addresses cumulative exposure. No new cryptographic refreshing scheme or perpetual-security primitive claimed. |
| Castro/Liskov2002, DOI10.1145/571637.571640 | Primary ACM page and Microsoft author abstract/metadata | Bounded vulnerability windows with unbounded lifetime faults already known; no new proof of actual key erasure. |
| EAC-v2.0.0 user source | Full provided manuscript, code and audits; live GitHub index hashes match; both programs rerun | Single-proposal validity, temporal exposure count and witness coverage are inherited. Concurrency removes a serial-effect premise; not a contradiction of v2 under its own premises. |
| Published PR6 DOI23295776 and RAC13 DOI23299153 | Prior conversation/source metadata and publication scope; no new full proof rederivation | Resource-budget and persistent-consequence results are separate works. Applying residual state to signing commitments is not first discovery that new keys do not repair old effects. |

## Net increment
JPA-T1/T2: scoped exact joint-certificate and independent-refusal existence conditions; necessity uses full minimality and proper-subset signing. JPA-T3/C1: application interaction arity × qualified witness size × temporally usable exposure × solo refusal frontier. JPA-T4: exact residual constraint handoff with explicit fencing/actual-state hypotheses. JPA-E1: genuine signed worker journals and effect updates distinguish correct approaches, counterexamples and safe but non-live partial locks.

The core mathematical operations are elementary and inherited. This is a self-contained, executable, conditional application suitable for critical preprint review, not a claim that all these principles are new, that an optimal consensus protocol was invented, or that real superintelligences satisfy the premises.

## Outstanding scientific work
Independently validate actual effect conflict patterns and qualified root capabilities on a bounded real system. Establish effect fencing and accurate residual state. Broaden to order-sensitive effects or consistent distributed enrollment with an explicit stronger model, not by silently lifting these finite endorsement results. A complete global prior-art correspondence remains open.
