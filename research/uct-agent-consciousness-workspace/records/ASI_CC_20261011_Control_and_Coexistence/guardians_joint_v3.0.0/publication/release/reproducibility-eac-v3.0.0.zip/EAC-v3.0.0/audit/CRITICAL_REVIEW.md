# Internal critical review — EAC-v3.0.0

Review in the same assisted workflow; not external peer review.

**Definitions.** Proposals are individually valid; unsafe minimal combinations have arity>=2. The protected effect family is downward-closed and effects commute/persist within scope. A new singleton residual is rejected by unary validity, not promised solo availability. All refusal sets used in the general theorem are proper. Empty conflict catalogs impose no joint constraint; unrelated actions can still proceed.

**Quantifiers.** B is one jointly realizable effective exposure set. F_x are hypothetical solo refusal environments: the necessity argument combines certificates required by those promises, not a physically impossible simultaneous refusal event. The adversary may fragment/delay honest requests and act on completed certificates. A stronger global serialization or semantic revalidation changes the architecture and is not refuted.

**Proofs.** Sufficiency requires one common qualified nonexposed reviewer for every actual minimal bad set. Necessity requests only proper subsets at honest relevant roots; minimality guarantees no other smaller conflict is completed locally. The complement construction proves existence, not minimal signature cost. Cardinality lower bounds permit every subset up to the declared exposure/refusal sizes; nonuniform/physical restrictions can improve feasibility and must use the general set condition. Temporal exposure needs all relevant faulty signatures collectible during the same effective context.

**Renewal.** Journals need persist only until old possible effects are fenced/settled and actual committed effects represented in a sound successor. The residual theorem is set algebra, not automatic physical state recovery. Merely changing keys is insufficient. A complete authenticated current-state gate can substitute for journal history; this is explicitly allowed as a different verified architecture.

**Progress.** The proved availability is SOLO from a clean signing context. Local locks can split across proposals and strand every certificate. The explicit partial-lock case preserves safety but makes no progress; the manuscript does not call this a full solution to concurrent governance or consensus.

**Prior art.** Invariant confluence, BEC and higher-order Paxos intersections are direct predecessors. The result neither invalidates an established I-confluence criterion nor improves the3f+1 consensus bound. The new scope is a qualified-witness minimal-conflict authorization contract and exact temporal/residual specialization.

**Execution.** Seven true OS processes share one parent and host UID. Cryptographic signing/verification and SQLite effects really run. Root compromise is an explicit flag; semantic capability, root isolation, real human assent and timing are not independently measured. Low-level serial SQLite writes do not make stale-context approval a semantically serializable protocol. All final semantic outputs reproduce under two hash seeds; raw key/signature bytes vary. One initial scenario name was corrected, then all final programs rerun.

**UCT/coverage.** No new C1/U1 premise, no experiential existence threshold, no identification of keys with conscious subjects. Full broader UCT graph/corpus semantic audit remains incomplete. Candidate claims disabled. This does not change the completed state of the self-contained manuscript, but prevents representing it as an established UCT theorem family.

Decision: publication-prepared conditional research manuscript. The precise application can be disclosed and criticized; global originality, independent peer review, universal ASI coexistence and real deployment safety are not asserted.
