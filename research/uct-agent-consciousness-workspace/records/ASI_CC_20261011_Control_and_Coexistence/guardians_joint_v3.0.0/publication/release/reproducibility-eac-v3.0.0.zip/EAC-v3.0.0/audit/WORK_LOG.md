# EAC-v3.0.0 work log — 12 October 2026

## Request, source, and scope
The user requested further substantive research based on EAC-v2.0.0 and a prepared publication manuscript, not another automatic DOI. Read the full supplied v2 LaTeX, its claims/prior-art/audits, and relevant source. Read the connected Research Master Guide v2.3. Connected source verified on branch uct-agent-consciousness-workspace at1925a936e745ba8e4241db1f8f6b307f1173b674. All three supplied baseline paper/script SHA256 values match the live v2 index. The two already-published papers23295776 and23299153 remain separate works, not earlier versions to overwrite.

## Net question
The predecessor proves validity for one parent-state-bound change and assumes serial mediation. This revision explicitly changes the interface: independently certified, individually safe, commuting changes may jointly remove a retained protection. Study minimal unsafe combinations, their qualified witnesses, durable root-local journals, adversarial signature exposure and solo completion. Do not pretend a counterexample without serial revalidation refutes a proof that assumes serial revalidation.

## Derivations and executed evidence
1. Derived qualified common-intersection necessity/sufficiency for each minimal unsafe set. Necessity sends each honest root only a proper subset, while exposed roots can sign every member.
2. Derived exact existence with one counterfactual refusal set per proposal. Explicit complement construction attains safety plus SOLO availability. Arbitrary concurrent termination is not claimed.
3. Derived h>kappa+k*r and exact threshold interval; combined with inherited kappa=min(n,f+c*(w-1)). Demonstrated signature-window limits tightening with interaction arity. All set/counting ingredients are inherited methods.
4. Derived exact residualization of actual persistent effects after fencing unused approvals. Allows deletion of old journals only with sound state/context reconstruction. New residuals may be unary, which return to the individual-validity gate.
5. Implemented joint_certificates.py:10,800 full small acceptance-structure specifications;108,716 signing matrices;690 threshold profiles;132 mobile-exposure cases;4784 joint threshold checks;193 antichain catalogs/1439 handoffs/9980 residual-state comparisons.
6. Implemented independent journal_oracle.py:explicit BFS signing histories rather than theorem-function calls;786 models including392 overlapping-conflict configurations;214240 reachable states;862007 transitions;16782 heterogeneous threshold-vector checks.
7. Implemented concurrent_amendments.py:seven actual persistent worker processes with Ed25519 keys and separate SQLite approval journals;115 configurations;1021 signing attempts;993 generated signatures;963 verifications;127 actual effect/configuration commits. Genuine fault-free triple counterexample, mobile exposure, unanimous snapshot failure, retained vs cleared vs residualized renewal state, policy-update interaction, unrelated allowed operation and safe deadlock control included.
8. Reran both v2 scripts and compared archived semantic JSON. Then reran all3new scripts under PYTHONHASHSEED101/202, comparing final source hashes and normalized results. Counts do not include repetitions as independent samples. See RUN_RECEIPT.json.
9. Wrote complete12-page English publication manuscript, full proofs, primary-source comparison, claim ledger, Chinese handoff, DOI metadata draft, release checklist and manifest. PDF compiled and rendered for inspection, with readable equations/tables and no undefined reference or overfull box. Final bibliography formatting removed a short orphan reference page; no scientific content dropped.

## Important corrections and boundaries
A preliminary no-fault test label still called a helper with one corrupt root. Relabeled it as a one-corrupt-root control and added a distinct genuine zero-corruption case. All final outputs rerun; no mislabeled result survives. Raw root journals are no longer asserted necessary forever: residual conflict state can suffice after actual fencing and state transfer. General theorem assumes individually eligible candidates and minimal unsafe sets of arity>=2; unary-invalid actions require the preexisting validity gate. Allowed refusal sets for a nonempty signed operation are proper root subsets.

The implementation has one common parent controlling every key, qualification label, state and timing input. The work does not independently establish real human representation, consent, physical root independence, safe key recovery or Byzantine consensus. Local signatures and exact finite tests are not those endpoints.

## Review and preservation decision
Closest primary predecessors examined: Bailis et al. invariant confluence; Kleppmann/Howard BEC; Fast Flexible Paxos higher-order intersection; Satrapy2026 heterogeneous consensus; proactive recovery and classical Byzantine quorum work. Scope and reading depth are in PRIOR_ART_REVIEW.md. The mathematics is not a new general quorum or set-intersection theory. Net contribution is the exact conditional governance-composition specification and its integrated temporal/residual checks; exact global priority unverified.

Publication-prepared candidate, no DOI/OTS/Arweave action. Existing UCT formal mapv1.1.2 and913/424/261 are not promoted. Full historical semantic audit and complete publication-corpus reconciliation were not performed. Local claim/proof/evidence review and scope deltas are recorded. Actual remote paths, commit and read-back scope are supplied in PERSISTENCE_RECEIPT.json rather than inferred from local file creation.

## Final source preservation correction
A single space in the protocol output's human-readable limitation sentence was omitted during GitHub transcription. No executable decision changed. The final local source adopts that cosmetic spelling, its Git blob is09e0793c03fb5430ebd827f63ca8109e861bcb56, and the exact same final bytes were rerun under both recorded hash seeds. The final run receipt and source hashes were regenerated; earlier counts are unchanged.
