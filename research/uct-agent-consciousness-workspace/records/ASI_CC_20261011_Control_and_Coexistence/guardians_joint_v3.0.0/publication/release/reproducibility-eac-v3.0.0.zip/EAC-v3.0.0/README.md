# When the Guardians Can Be Acquired — EAC-v3.0.0

**Joint Protection Across Concurrent and Renewable Authorizations**

Hongju Liu · 12 October2026 · 12-page publication-prepared research manuscript, not peer reviewed or DOI-published.

The main source is `paper/manuscript.tex`; the rendered paper is `paper/manuscript.pdf`. The three new executed programs are `src/joint_certificates.py`, `src/journal_oracle.py` (independent explicit-state checker) and `src/concurrent_amendments.py` (actual signing workers and SQLite effects). `requirements.txt` pins the tested cryptography version. Mathematical checkers use only Python's standard library.

```sh
python -S src/joint_certificates.py --out data/joint_results_rerun.json
python -S src/journal_oracle.py --out data/journal_oracle_rerun.json
python src/concurrent_amendments.py --out data/concurrent_results_rerun.json
cd paper
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
```

The process protocol needs a Unix-like system, uses only temporary files and its own children, and requires no admin privileges, internet, provider keys or model calls. The parent controls every role; successful tests do not establish physical trust roots, real human representation or deployment security. Raw signatures/public keys vary; normalized outcomes reproduce. No private signing keys are stored in the package.

`baseline/` contains the previous executed programs and summaries, not newly claimed evidence. `RUN_RECEIPT.json`, `audit/`, `HANDOFF_ZH.md`, `INDEX.json`, and the manifest distinguish proofs, comparisons, original applications and open limits. `publication/` is local preparation only: no API write, DOI reservation, OTS or paid upload has occurred.

The exact combined result is for a declared finite endorsement-only interface, minimal unsafe proposal sets, honest root-local conflict journals, bounded jointly realizable exposure, and SOLO completion promises. Stronger global revalidation, a different exposure model or unknown physical conflicts require separate analysis. Core quorum/confluence mathematics is inherited. Old EAC drafts and published DOI23295776/23299153 are unchanged. Formal UCT graph admission stays disabled.
