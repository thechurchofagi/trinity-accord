# Author, assistance and proposed rights

Author: Hongju Liu (刘烘炬), Independent Researcher. Research directed by the author with substantial ChatGPT assistance in retrieval, formalization, implementation, execution, checking and writing. Checks in this workflow are not independent peer review.

For the owner's established preprint workflow, the local DOI draft proposes CC BY4.0 for newly authored materials to the extent rights are held. It does not claim ownership of cited work or relicense external text, tools or fonts. No external full paper or font files are bundled. No private signing keys, provider tokens or real account credentials are included in the data; test records contain generated signatures and public keys.

The present user request is to prepare the publication manuscript. It does not itself execute a public deposit, generate a DOI, make a paid preservation transaction, or warrant statements of independent publication acceptance.
