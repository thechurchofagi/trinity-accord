# Publication preparation / EAC-v3.0.0

**Decision:** complete self-contained publication-prepared theoretical manuscript for critical review. This checklist is not peer review, proof-assistant verification or a global originality certificate. No DOI, OTS or Arweave action has occurred.

## Completed
- Exact current problem and predecessor difference: signature-only concurrent effects, not an attack on the old serial-validation theorem.
- Textual necessity and sufficiency proofs, finite countermodels and positive codebook construction.
- Local-journal mechanisms distinguished from coordination-free protocols; SOLO availability distinguished from concurrent termination and consensus.
- Residual-journal renewal includes actual effects and a complete old-certificate fence; no lifetime-erasure shortcut.
- Primary comparison: I-confluence/BEC, high-order consensus quorums, proactive renewal; all scope and reading limits retained.
- Three actual executed scripts, independent journal search and explicit negative cases. Two replays match semantically. Baseline results not double counted.
- Full editable source, raw results, AI assistance disclosure, Chinese handoff and hash manifest in the research package.
- PDF compiled, all12pages rendered, title/proofs/tables/references checked; no unresolved references or overfull text.

## Before an actual DOI release
Re-read the owner's publication instruction and the then-current repository workflow. Freeze the exact PDF and ZIP, verify title/author/version/date/rights, and search owner deposits for an existing record of this Guardians work. v1/v2 are research drafts; a prior unreserved DOI must not be invented. If any metadata or paper bytes change, regenerate all hashes. Use the repository's idempotent release procedure and public exact-byte readback. DOI publication and OTS/Arweave stages are separately recorded, with no unverified success claims.

## Limits that remain part of the public manuscript
Physical conflict discovery and qualified witnesses are specified rather than independently learned. One trusted host owns all test roles. No AI motive, moral legitimacy, inter-agent economic equilibrium, physical actuator isolation or unconditional social consensus is established. Mathematically established underlying techniques are not presented as newly invented. Exact priority of this application remains open.
