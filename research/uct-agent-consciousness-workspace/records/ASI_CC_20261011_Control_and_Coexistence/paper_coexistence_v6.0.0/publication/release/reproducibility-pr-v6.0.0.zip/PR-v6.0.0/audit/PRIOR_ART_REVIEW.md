# Primary prior-art review and originality scope

Date2026-10-11. The following comparisons are limited to the material actually inspected. No universal priority certificate is claimed.

| Source | Material inspected | What is inherited / what differs |
|---|---|---|
| Tan et al., Safety of Linear Systems under Severe Sensor Attacks, arXiv2409.08413 | Full HTML, definitions and theorem context | Direct precedent for safety despite nonunique state reconstruction. Our exact combinatorial reserve is not their linear CBF problem. |
| Tan et al., Computationally Efficient Safe Control..., arXiv2502.20718 / ACC2025 | Full HTML and primary abstract | Explicitly avoids full secure state reconstruction. Broad novelty claim removed; no alleged contradiction with their conclusions. |
| Fawzi, Tabuada, Diggavi, IEEE TAC2014, doi10.1109/TAC.2014.2303233 | Full author PDF text, state estimation/control sections; rendered PDF page inspected | Coding, secure reconstruction, and separation under specified linear stabilization assumptions. Our different task does not refute their theorem. |
| Guruswami, Algorithmic Results in List Decoding, doi10.1561/0400000007 | Author-hosted monograph introductory and list-decoding sections; PDF page inspected | Returning several compatible messages is inherited; conditional union width and coupled remaining bank capacity are our scoped application. |
| Teixeira et al., Automatica2015, arXiv1212.0226 | Abstract plus accessible model material | Resource-limited adversary as a modeling device predates this work. We solve a specific common-budget role allocation. |
| Bertsimas & Sim, The Price of Robustness, doi10.1287/opre.1030.0065 | Primary publisher record/abstract and author-hosted discussion | Budgeted uncertainty and over-conservatism of simultaneous independent extremes are inherited. Exact f+1 ratio for the same role placement is the new scoped comparison. |
| Rober, Rose & How, GUARDIAN, arXiv2602.06026v2 | Primary record/abstract, revision and authors | Set-based uncertainty-aware safety filtering is a direct modern neighbor. We do not claim the generic idea. |
| Greenblatt et al., ICML2024 | Official PMLR abstract/metadata, pp16295–16336 | Useful control despite subversion motivates the problem; no measured improvement over their LLM benchmark. |
| Terekhov et al., arXiv2510.09462v2 | Full HTML and model/evaluation discussion | Adaptive attacks on monitors and authentication/truth distinction have known risk context; no reuse of their performance numbers. |
| Liu, PR-v5.0.0 | Supplied complete source, previous exact results and primary repo lineage; one suite rerun | Its four-channel threshold recovered exactly by CB-T3, not counted as new. |
| Liu, UCT I v1.2 | Actual repository lines on token/type/lineage, persistence and subject boundary | Process ontology motivates careful typing. No subjective feeling or machine moral status is inferred. |

Primary URLs: https://arxiv.org/html/2409.08413v1 ; https://arxiv.org/html/2502.20718v1 ; https://arxiv.org/pdf/1205.5073 ; https://www.cs.cmu.edu/~venkatg/pubs/papers/listdecoding-NOW.pdf ; https://arxiv.org/abs/1212.0226 ; https://pubsonline.informs.org/doi/10.1287/opre.1030.0065 ; https://arxiv.org/abs/2602.06026 ; https://proceedings.mlr.press/v235/greenblatt24a.html ; https://arxiv.org/html/2510.09462v2 .

The bounded exact-search queries for diagnosis/backup/common fault budget did not identify an equivalent closed form in the checked results. That is NOT evidence that none exists. A search result for https://www.mdpi.com/1424-8220/26/16/5098 mentioned a shared attack budget; direct retrieval returned HTTP429. It is an uninspected possible neighboring review, not a proved exact precedent or a dismissed source.

**Retained contribution:** closed-form minimum and attaining placements for arbitrary n,k,f,d,b under explicit role/timing/pooling constraints; a low-diagnostic fixed-placement optimum with nonunique diagnosis; exact factor-f+1 cost of ONE decoupled rule; arbitrary one-fault heterogeneous and arbitrary-fault repeated-class formulas; independent reproducibility.

**Not claimed:** first discovery of Byzantine faults, list decoding, robust control without state reconstruction, resource budgets, noninterference, authenticated sources, AI moral status, or universally safe ASI. The work is a theoretical result for a general but stated model, not a larger empirical dataset.
