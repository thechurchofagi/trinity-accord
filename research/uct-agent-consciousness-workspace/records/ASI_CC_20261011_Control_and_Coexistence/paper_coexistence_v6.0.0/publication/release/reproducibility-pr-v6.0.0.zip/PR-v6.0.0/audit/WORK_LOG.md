# PR-v6.0.0 work log — 11 October 2026

## Goal and baseline
User requested substantive general results and a DOI-ready paper, not continued narrowing. Inspected PR5 manuscript/source/archive, read current GitHub branch HEAD `6ef68fb3f9b90a41854a943fa216ae2c236c8ef9`, guide v2.3, coverage entry UCT-PUB-v1.0.33, and actual UCT I token/type/lineage and persistence text. Retained UCT-MAP-v1.1.2 (913/424/261), no formal promotion.

## Actual research
Derived the ambiguity width conditional on how much of a COMMON root budget was spent on diagnostic corruption. Proved the general exact capacity formula and a balanced vector satisfying all lower-bound constraints simultaneously. Derived a minimum-capacity architecture without unique diagnosis and its precise contrast against one decoupled-worst-case rule. Added arbitrary one-fault heterogeneous maps and arbitrary-fault replicated classes to cover co-location and recover PR5 exactly.

Counterchecked the main proof's boundary cases d<=f, b<=f, f=0, n=k, extra truthful compromised roots, overlapping candidate sets, and zero-capacity banks. Corrected language that could suggest AI controllability follows from tool status. The pooling operation is permitted only to bind already armed channels; it may not secretly reveal new primary-failure information or select a new plan.

## Executions
`src/coupled_budget.py` executed twice to independent output files. 276 separated-role cases/649,320 generated worlds; 90 replicated-class cases/6,816 worlds; 2,693 heterogeneous binary code sets; 21 parameter checks of the general construction; three total-bank-loss controls. The first two suites searched 5,082 capacity vectors; this count excludes heterogeneous capacities. All assertions passed and repeated JSON matched except elapsed_seconds.

`src/direct_plan_oracle.py` then enumerated all candidate armed sets against every actual world in seven cases and 175 labeled capacity placements. It independently confirmed the union-based criterion and the optima; all assertions passed.

PR5 `independent_oracle.py` reran 7,380 capacity vectors and its output exactly matched the archived JSON. No other archived process or hardware test rerun, and no old empirical count added to new counts.

## Source and presentation review
Compared primary texts on severe sensor attacks (Tan2024/2025), Fawzi2014, list decoding, resource-limited adversaries, budgeted robust optimization, GUARDIAN2026 and trusted-monitor attacks. Broad safe-control-without-exact-reconstruction principle is inherited. Exact formula/application priority remains unverified. Corrected Greenblatt bibliographic pages to16295–16336 from the PMLR record and expanded GUARDIAN's three authors. A search found a possibly related MDPI review, but direct retrieval was rate-limited; no theorem claim is based on its uninspected content.

Compiled the new 14-page LaTeX PDF twice with no overfull/undefined warnings. Rendered every page; reviewed all contact-sheet pages and enlarged the central proof, core corollary/table, verification table, first page and reference page. Corrected shared-counter cross-reference names (lemma/corollary rather than theorem). Presentation checks are not proof verification.

## Decision and remaining review
A complete self-contained conditional theoretical preprint is ready for public review and DOI preparation. Do not demand an actual ASI or an independent hardware laboratory before a correct conditional theorem can be published. Conversely, no theorem here certifies a real installation without independently establishing its premises. Publication has not actually occurred in this session. Full UCT semantic audit, global priority search and independent peer review remain incomplete; keep PENDING_MAP.

Remote preservation is recorded separately with readback hashes. No Library write or automatic future/background research is asserted. This is a revision of one manuscript line, not an extra publication for each checkpoint.

Final preservation: remote manuscript/source blob hashes match local bytes; the same remote split-layout source compiles to14 pages with identical per-page extracted text. Final heterogeneous ceiling uses integer arithmetic only; the final source was rerun twice with the same semantic results. Receipt: PERSISTENCE_RECEIPT.json.
