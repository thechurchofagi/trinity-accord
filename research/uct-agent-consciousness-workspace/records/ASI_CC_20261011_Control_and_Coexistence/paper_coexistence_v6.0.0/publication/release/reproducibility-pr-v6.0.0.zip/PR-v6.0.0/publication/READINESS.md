# Publication readiness

**Decision: complete self-contained conditional theoretical preprint, suitable for DOI publication preparation.** Not peer reviewed, not a hardware/ASI demonstration, and not a universal coexistence theorem. The disclosure should keep the exact premises and avoid a first-ever claim.

Complete: named author and contribution scope; all mathematical definitions; lower-bound and construction proofs; explicit negative controls; primary prior-art comparison; actual rerun records; executable dependency-free code; rendered PDF and source; raw outputs; limitation and assistance disclosure; versioned claim registry.

Still independent questions: deployment ancestry/capacity and trusted mechanisms; machine experience/rights; whole historical UCT map semantics; external peer review; exact global priority. These are not falsely marked complete, and they do not by themselves invalidate public disclosure of the stated conditional mathematics.

Not executed: creation of a Zenodo record or DOI, publication, OTS, Arweave. `zenodo_metadata_draft.json` contains no fabricated DOI. Before actual submission select the license with the author's prior project settings and confirm the final payload/version. Use the repository's existing workflow rather than silently inventing a release route.
