# Failures, corrections and excluded evidence

No new computation timeout or failed final assertion occurred in the recorded PR6 runs. The additional direct-action oracle and clean rerun both completed.

A direct HTML access to the older Fawzi preprint failed; the full author PDF was subsequently accessible and inspected. An exact-search neighboring MDPI review returned HTTP429 and remains uninspected. Neither failure was treated as evidence that a source or result does not exist.

Before finalizing, corrected a draft PMLR page range (16205–16236 to16295–16336), expanded GUARDIAN's exact author list, and corrected LaTeX shared-counter names so references identify lemmas/corollaries accurately. The first rendered contact sheets predated these cosmetic fixes; final individual pages were rendered again.

Scope corrections: removed language suggesting AI controllability follows from being a tool; qualified the minimum bank capacity by its fixed architecture; qualified the modular gap by its specific decoupled rule. Failure of independent budgets and hidden co-location are intentional mathematical negative controls, not defects suppressed from the output.

No old PR5 process counts or timeouts are presented as new runs. No LLM, new hardware, same-UID isolation, or physical independence experiment was conducted here.
