# Safe Revocation Without Complete Diagnosis — PR-v6.0.0

Author: **Hongju Liu**, 11 October 2026. A completed theoretical-preprint manuscript, not peer reviewed. It generalizes PR5 rather than presenting another four-channel toy.

## Main result
For n channels with k actual replacement needs, d independent full-set diagnostic roots, b separate backup bank roots, and at most f compromised roots across both roles, the exact reserve is:

`max_{a=0..f} [ w_a + (f-a) ceil(w_a/(b-f+a)) ]`, where `w_a=min(n,k(1+floor(a/(d-f))))`, for d>f,b>f.

There are complete formulas for d<=f and for co-located/heterogeneous families. The paper proves lower bounds and attaining allocations. In the d=b=f+1 architecture, capacity (f+1)k suffices without unique diagnosis. A particular independent-worst-case design can require an unbounded multiplicative overhead. Neither generic safety without state reconstruction nor budgeted uncertainty is claimed as an invention here.

## Reproduce
Python 3.10+ and standard library; no keys, network, models, or external services.

```sh
python src/coupled_budget.py --out data/new_results.json
python src/direct_plan_oracle.py --out data/new_direct_results.json
# Compare JSON semantically; only elapsed_seconds may differ in the first file.
(cd paper && pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex && pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex)
```

Two executions of the main suite matched excluding elapsed_seconds. The direct oracle enumerates actions against each actual possible world. PR5's 7,380-vector independent suite was rerun exactly; no previous process test is added to the new counts.

## Files and scope
`paper/` contains the complete manuscript and PDF; `src/` the two new scripts; `data/` the full outputs and regression receipts; `audit/` proof/priority/status review and logs; `publication/` DOI metadata draft and readiness decision. `INDEX.json` is the disabled machine-readable candidate entry.

The model is a single pre-commit service revocation, not all of civilization. Its common fault budget, separate roots, truthful honest reporters, full k-set reporting alphabet, faithful reference controller, universal surviving-capacity pool, and complete final veto cut are explicit assumptions. Randomness, AI consciousness, AI rights, and model goodwill are not needed. Independent hardware deployment validation remains future work; it is not represented as already achieved or required to publish a conditional theorem.

No DOI, OTS, or Arweave action is claimed. Full historical UCT semantic review is unfinished. The new candidate does not alter the established graph or prior public manuscript bytes. See the preservation receipt for exact remote/local scope.
