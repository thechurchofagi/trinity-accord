#!/usr/bin/env python3
"""Cross-check saved oracle outputs and regenerate separating examples.
This utility does not make the independent oracle import the analytical model.
Run the three main programs first, then this utility from any working directory.
"""
from pathlib import Path
from dataclasses import asdict
import argparse, hashlib, json
from commit_windows import Ticket,exact_margin,simulate,max_burst

ROOT=Path(__file__).resolve().parents[1]

def examples():
    gap=[]
    for p in range(1,33):
        separated=[Ticket(3*i,3*i+1,1) for i in range(p)]
        overlap=[Ticket(0,3*p,1)]*p
        a=exact_margin((),separated,1,1,2,1)['margin']
        b=exact_margin((),overlap,1,1,2,1)['margin']
        assert a==2 and b==p+1
        gap.append({'p':p,'separated_window_margin':a,'overlapping_window_margin':b,'count_only_robust_margin':p+1})
    ticket=[Ticket(3,3,1)]
    early=[2]+[0]*7;late=[0,0,0,2]+[0]*4
    te=simulate((),ticket,[3],early,1,1)
    tl=simulate((),ticket,[3],late,1,1)
    assert max(x['unrestored'] for x in te)==2
    assert max(x['unrestored'] for x in tl)==3
    windows=[Ticket(0,1,1),Ticket(3,4,1),Ticket(6,7,1)]
    broad=[Ticket(0,7,1)]*3
    # Contract-correlated alternative: the same broad individual windows, but
    # a scheduler enforces at most one pending commit per slot. Product bound
    # is not claimed necessary under this narrower allowed schedule family.
    cert=exact_margin((),broad,1,1,2,1)
    assert cert['margin']==4
    scheduled=simulate((),broad,[0,3,6],[1]*10,2,1)
    assert max(x['unrestored'] for x in scheduled)==2
    # Removing a canceled ticket only shrinks the permitted possibilities.
    cancel_checks=0
    for ps in (windows,broad):
        full=exact_margin((0,),ps,2,1,2,2)['margin']
        for j in range(len(ps)):
            reduced=exact_margin((0,),ps[:j]+ps[j+1:],2,1,2,2)['margin']
            assert reduced<=full;cancel_checks+=1
    return {'version':'ASI-CC-v1.3.0','linear_gap_family':gap,
            'deferred_burst_counterexample':{'ticket':asdict(ticket[0]),'early_burst_trace':te,'delayed_burst_trace':tl,'early_peak':2,'delayed_peak':3},
            'three_window_example':{'separated':exact_margin((),windows,1,1,2,1),'overlap':cert,'max_new_burst_at_H2_separated':max_burst((),windows,2,1,2,1),'max_new_burst_at_H2_overlap':max_burst((),broad,2,1,2,1)},
            'restricted_correlated_schedule_control':{'product_bound':4,'explicit_separated_trace_peak':2,'interpretation':'Narrower schedule family can reduce requirements; no counterexample to the product theorem'},
            'effective_cancellation_monotonicity_checks':cancel_checks,'assertions':'PASS'}

def main(data_dir):
    d=Path(data_dir)
    raw=json.loads((d/'oracle_window_results.json').read_text())
    for row in raw['profiles']:
        tickets=[Ticket(*x) for x in row['tickets']]
        actual=exact_margin(tuple(row['old_ready']),tickets,*row['params'])['margin']
        assert actual==row['maximum_observed_debt'],row
    exc=examples()
    (d/'separating_examples.json').write_text(json.dumps(exc,indent=2)+'\n')
    receipt={'version':'ASI-CC-v1.3.0','oracle_profiles_compared':len(raw['profiles']),'oracle_joint_schedules':raw['joint_schedules_checked'],'all_matches':True,
             'gap_family_sizes':32,'effective_cancel_checks':exc['effective_cancellation_monotonicity_checks'],'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'src').glob('*.py'))},'assertions':'PASS'}
    (d/'crosscheck_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data-dir',default=str(ROOT/'data'));main(p.parse_args().data_dir)
