# Publication preparation checklist — v1.3.0

## Completed within the declared scope
- Final self-contained12-page English manuscript, exact assumptions/proofs/constructive witnesses/limitations and AI assistance disclosure.
- Exact new source executed; independent job oracle computed first then cross-compared; complete reruns semantically match under two hash seeds.
- Previous v1.2 source and claims distinguished and rerun; separate published PR6 bytes untouched.
- Closest-prior-art correction included; shared budgets, escrow and generic minplus not claimed new.
- PDF rendered and checked; source/readiness notes, raw data, worklog, claim ledger, coverage delta and checksum manifest included.
- DOI metadata draft prepared but no record reserved or upload performed.

## Must be checked at an authorized publication action
- Resolve exact work/version identity; verify current repository publishing conventions and duplicate records.
- Confirm intended release license/author metadata; freeze exact public PDF and archive hashes.
- Publish one immutable preprint version and anonymously read back every public file byte hash.
- Record actual DOI/status and update scoped coverage. OTS and Arweave follow the actual authorized workflow; pending is not complete.

## Disclosed limitations, not disguised completed validations
No external peer review, complete global originality proof, hardware-root experiment or AI consciousness endpoint. Full formal-UCT historical semantic review remains pending; the current result is a self-contained technical manuscript, not an admitted UCT axiom. These limits must accompany publication, not be silently erased or used to promise a deployed safety result.

Decision: ready for fixed-version theoretical preprint release preparation and critical review. This checklist does not execute public release or guarantee future citation.
