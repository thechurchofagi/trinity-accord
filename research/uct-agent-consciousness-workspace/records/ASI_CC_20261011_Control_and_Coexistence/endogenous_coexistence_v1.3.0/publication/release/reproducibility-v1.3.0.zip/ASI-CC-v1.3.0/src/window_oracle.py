#!/usr/bin/env python3
"""Independent literal job simulator and exhaustive finite commit/arrival oracle.
Does not import the analytical certificate. Maxima are crosschecked externally.
"""
from pathlib import Path
import argparse,itertools,json


def run(out):
    old_states=[(),(0,),(2,)]
    options=[(0,0,1),(0,2,1),(1,2,2),(2,2,1)]
    tickets=[()]+[(x,) for x in options]+list(itertools.combinations_with_replacement(options,2))
    policies=[(1,0,1,1),(1,1,1,2),(2,1,2,2),(2,0,1,1)]
    horizon=6
    rows=[];trials=0
    for old,ps,(b,rho,mu,ell) in itertools.product(old_states,tickets,policies):
        arrivals=[]
        for a in itertools.product(range(b+1),repeat=horizon):
            if all(sum(a[i:j])<=b+rho*(j-i-1) for i in range(horizon) for j in range(i+1,horizon+1)):
                arrivals.append(a)
        best=len(old);witness=None;local=0
        for c in itertools.product(*(range(l,u+1) for l,u,k in ps)):
            for a in arrivals:
                jobs=list(old);peak=len(old)
                for t in range(horizon):
                    for _ in range(mu):
                        eligible=[(v,i) for i,v in enumerate(jobs) if v<=t]
                        if not eligible:break
                        jobs.pop(min(eligible)[1])
                    for i,(_,_,delay) in enumerate(ps):
                        if c[i]==t:jobs.append(t+delay)
                    jobs.extend([t+ell]*a[t]);peak=max(peak,len(jobs))
                trials+=1;local+=1
                if peak>best:best=peak;witness={'commits':c,'new_arrivals':a}
        rows.append({'old_ready':old,'tickets':ps,'params':[b,rho,mu,ell],'maximum_observed_debt':best,'joint_schedules_checked':local,'attaining_example':witness})
    r={'version':'ASI-CC-v1.3.0','method':'enumerate every six-slot conforming new-arrival stream and every independent pending-commit choice;literal per-job updates;no theorem-module import',
       'horizon':horizon,'profile_count':len(rows),'joint_schedules_checked':trials,'profiles':rows,'status':'MAXIMA_COMPUTED;SEPARATE_CERTIFICATE_COMPARISON_REQUIRED'}
    p=Path(out);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({k:v for k,v in r.items() if k!='profiles'},indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='oracle_window_results.json');run(p.parse_args().out)
