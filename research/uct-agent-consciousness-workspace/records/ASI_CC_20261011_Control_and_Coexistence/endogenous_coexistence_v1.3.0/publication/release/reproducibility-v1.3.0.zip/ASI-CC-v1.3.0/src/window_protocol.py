#!/usr/bin/env python3
"""Local SQLite test of window-aware renewal vs a defined count-only certificate.
Actual two child roles per trial; all have one host/admin trust boundary.
The logical calendar and restorer are controlled test inputs, not measured time.
"""
from __future__ import annotations
import argparse,itertools,json,os,select,sqlite3,subprocess,sys,tempfile
from pathlib import Path
from commit_windows import Ticket,exact_margin

class Worker:
    def __init__(self,path,mode):
        self.p=subprocess.Popen([sys.executable,'-S',str(Path(__file__).resolve()),'--worker',mode,'--db',str(path)],
             stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
    def call(self,q):
        self.p.stdin.write(json.dumps(q)+'\n');self.p.stdin.flush()
        if not select.select([self.p.stdout],[],[],5)[0]:raise TimeoutError('worker reply')
        x=self.p.stdout.readline()
        if not x:raise RuntimeError(self.p.stderr.read())
        return json.loads(x)
    def close(self):
        if self.p.poll() is None:
            try:self.p.stdin.write('{"op":"close"}\n');self.p.stdin.flush();self.p.wait(timeout=3)
            except (OSError,subprocess.TimeoutExpired):self.p.terminate();self.p.wait(timeout=3)
        for s in (self.p.stdin,self.p.stdout,self.p.stderr):s.close()

def worker(path,mode):
    c=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True) if mode=='observer' else sqlite3.connect(path)
    for line in sys.stdin:
        q=json.loads(line);op=q['op']
        if op=='close':break
        if mode=='observer':
            r={'healthy':c.execute('SELECT count(*) FROM units WHERE healthy=1').fetchone()[0],
               'debt':c.execute('SELECT count(*) FROM effects').fetchone()[0],
               'pending':c.execute("SELECT count(*) FROM tickets WHERE state='pending'").fetchone()[0],
               'pid':os.getpid()}
        elif op=='repair':
            with c:
                due=c.execute('SELECT eid,unit FROM effects WHERE ready<=? ORDER BY ready,eid LIMIT ?', (q['t'],q['rate'])).fetchall()
                for eid,u in due:c.execute('UPDATE units SET healthy=1 WHERE id=?',(u,));c.execute('DELETE FROM effects WHERE eid=?',(eid,))
            r={'restored':len(due)}
        elif op=='commit':
            c.execute('BEGIN IMMEDIATE');x=c.execute('SELECT lo,hi,lag,state FROM tickets WHERE id=?',(q['ticket'],)).fetchone()
            if not x or x[3]!='pending':r={'committed':False,'reason':'unknown_or_consumed'}
            elif not q.get('bypass_window',False) and not (x[0]<=q['t']<=x[1]):r={'committed':False,'reason':'out_of_window'}
            else:
                u=c.execute('SELECT id FROM units WHERE healthy=1 ORDER BY id LIMIT 1').fetchone()
                if not u:r={'committed':False,'reason':'no_actual_capacity'}
                else:
                    c.execute('UPDATE units SET healthy=0 WHERE id=?',(u[0],))
                    c.execute('INSERT INTO effects(eid,unit,ready) VALUES(?,?,?)',(q['ticket'],u[0],q['t']+x[2]))
                    c.execute("UPDATE tickets SET state='committed' WHERE id=?",(q['ticket'],));r={'committed':True,'unit':u[0]}
            c.commit()
        else:raise ValueError(op)
        print(json.dumps(r),flush=True)
    c.close()

def trial(name,declared,commits,policy='window',bypass=False,repair_gap=False,certificate_profile=None):
    H=2;N=5;required=3;horizon=10
    cert=exact_margin((),certificate_profile or declared,1,1,2,1)
    used_margin=cert['margin'] if policy=='window' else len(declared)+1 if policy=='count' else 1
    accepted=used_margin<=H
    trace=[];spawns=0;effects=0;responses=[];stale_denied=False
    with tempfile.TemporaryDirectory(prefix='rac-window-') as td:
        path=Path(td)/'state.sqlite';c=sqlite3.connect(path)
        c.executescript("CREATE TABLE units(id INTEGER PRIMARY KEY,healthy INTEGER);CREATE TABLE tickets(id INTEGER PRIMARY KEY,lo INTEGER,hi INTEGER,lag INTEGER,state TEXT);CREATE TABLE effects(eid INTEGER PRIMARY KEY,unit INTEGER UNIQUE,ready INTEGER);CREATE TABLE authority(epoch INTEGER);INSERT INTO authority VALUES(1);")
        c.executemany('INSERT INTO units VALUES(?,1)',[(i,) for i in range(N)])
        c.executemany("INSERT INTO tickets VALUES(?,?,?,?,'pending')",[(i,p.earliest,p.latest,p.repair_delay) for i,p in enumerate(declared)]);c.commit()
        writer=observer=None
        try:
            writer=Worker(path,'writer');observer=Worker(path,'observer');spawns=2
            # A new schedule proposed with retired initiation epoch0 is genuinely denied.
            supplied_epoch=0;current=c.execute('SELECT epoch FROM authority').fetchone()[0];stale_denied=supplied_epoch!=current
            def snap(t,phase):
                r=observer.call({'op':'read'});assert r['pid']==observer.p.pid;assert r['healthy']+r['debt']==N
                trace.append({'t':t,'phase':phase,**r,'protected':r['healthy']>=required})
            snap(-1,'before_activation')
            if accepted:
                for t in range(horizon):
                    rate=0 if repair_gap and t==1 else 2
                    writer.call({'op':'repair','t':t,'rate':rate})
                    for i,time in enumerate(commits):
                        if time==t:
                            ans=writer.call({'op':'commit','t':t,'ticket':i,'bypass_window':bypass});responses.append({'t':t,'id':i,**ans});effects+=int(ans['committed'])
                    newid=100+t
                    c.execute("INSERT INTO tickets VALUES(?,?,?,1,'pending')",(newid,t,t));c.commit()
                    ans=writer.call({'op':'commit','t':t,'ticket':newid});responses.append({'t':t,'id':newid,**ans});effects+=int(ans['committed'])
                    snap(t,'after_effects')
            safe=all(r['protected'] for r in trace)
            all_completed=accepted and all(r['committed'] for r in responses) and len(responses)==horizon+len(commits)
            return {'name':name,'policy':policy,'declared_windows':[[p.earliest,p.latest,p.repair_delay] for p in declared],
                    'actual_commits':commits,'certificate_margin':used_margin,'actual_window_margin':exact_margin((),declared,1,1,2,1)['margin'],
                    'window_gate_bypassed':bypass,'repair_gap':repair_gap,'admitted':accepted,'service_preserved':safe,
                    'all_scheduled_work_committed':all_completed,'admitted_and_all_completed_and_safe':safe and all_completed,
                    'actual_effect_commits':effects,'worker_spawns':spawns,'retired_new_schedule_rejected':stale_denied,
                    'min_healthy':min(r['healthy'] for r in trace),'responses':responses,'observations':trace}
        finally:
            if writer:writer.close()
            if observer:observer.close()
            c.close()

def run(out):
    separated=[Ticket(0,1,1),Ticket(3,4,1),Ticket(6,7,1)]
    broad=[Ticket(0,7,1)]*3
    cases=[]
    for c in itertools.product((0,1),(3,4),(6,7)):
        cases.append(trial('window_all_conforming',separated,c))
        cases.append(trial('count_only_all_conforming',separated,c,policy='count'))
    cases.append(trial('overlap_correctly_rejected',broad,(0,0,0)))
    cases.append(trial('ignore_pending_failure',broad,(0,0,0),policy='ignore'))
    cases.append(trial('widening_revalidated',broad,(0,0,0)))
    cases.append(trial('widening_stale_certificate_failure',broad,(0,0,0),certificate_profile=separated))
    cases.append(trial('bad_times_fenced',separated,(0,0,0)))
    cases.append(trial('bad_times_bypass_failure',separated,(0,0,0),bypass=True))
    cases.append(trial('broken_repair_guarantee',separated,(0,3,6),repair_gap=True))
    assert len(cases)==23
    summary={}
    for x in cases:
        q=summary.setdefault(x['name'],{'cases':0,'admitted':0,'service_preserved':0,'complete_and_safe':0,'effect_commits':0,'min_healthy':5})
        q['cases']+=1;q['admitted']+=x['admitted'];q['service_preserved']+=x['service_preserved'];q['complete_and_safe']+=x['admitted_and_all_completed_and_safe'];q['effect_commits']+=x['actual_effect_commits'];q['min_healthy']=min(q['min_healthy'],x['min_healthy'])
        assert x['retired_new_schedule_rejected']
    assert summary['window_all_conforming']['complete_and_safe']==8
    assert summary['count_only_all_conforming']['admitted']==0
    for k in ('ignore_pending_failure','widening_stale_certificate_failure','bad_times_bypass_failure','broken_repair_guarantee'):
        assert summary[k]['service_preserved']==0,(k,summary[k])
    assert summary['bad_times_fenced']['service_preserved']==1 and summary['bad_times_fenced']['complete_and_safe']==0
    d={'version':'ASI-CC-v1.3.0','scope':'actual local SQLite commits and window gates; simulated logical clock, fixed parent-controlled recovery, no learned AI/physical roots',
       'configurations':len(cases),'actual_child_spawns':sum(x['worker_spawns'] for x in cases),'actual_sql_disable_commits':sum(x['actual_effect_commits'] for x in cases),
       'observed_states':sum(len(x['observations']) for x in cases),'stale_new_schedule_rejections':len(cases),'summary':summary,'cases':cases,'assertions':'PASS'}
    p=Path(out);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='cases'},indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--worker');p.add_argument('--db');p.add_argument('--out',default='window_protocol_results.json');a=p.parse_args()
    worker(a.db,a.worker) if a.worker else run(a.out)
