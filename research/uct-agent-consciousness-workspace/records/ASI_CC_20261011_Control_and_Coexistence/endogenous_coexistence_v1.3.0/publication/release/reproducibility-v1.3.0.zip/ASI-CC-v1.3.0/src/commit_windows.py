#!/usr/bin/env python3
"""RAC v1.3 exact safety margin for inherited committed and in-flight effects.

Unit recoverable effects, independent integer commit windows, deterministic
work-conserving shared restorer. No model API, real infrastructure, or claims
about subjective experience. Full proof and timing convention in the paper.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
import argparse,itertools,json,math,random

@dataclass(frozen=True,order=True)
class Ticket:
    earliest:int
    latest:int
    repair_delay:int
    def __post_init__(self):
        if not all(isinstance(x,int) for x in (self.earliest,self.latest,self.repair_delay)) or not (0<=self.earliest<=self.latest and self.repair_delay>=1):
            raise ValueError('integer 0<=earliest<=latest, repair_delay>=1 required')


def validate(old,tickets,b,rho,mu,ell):
    if not all(isinstance(x,int) for x in (*old,b,rho,mu,ell)) or min(old,default=0)<0 or not (b>=max(1,rho) and rho>=0 and mu>=0 and ell>=1):
        raise ValueError('nonnegative integer old times, b>=max(1,rho), mu>=0, ell>=1')
    if not all(isinstance(p,Ticket) for p in tickets):raise TypeError('Ticket instances required')


def conforms(a,b,rho):
    return all(sum(a[i:j])<=b+rho*(j-i-1) for i in range(len(a)) for j in range(i+1,len(a)+1))


def simulate(old,tickets,commits,arrivals,mu,ell):
    if len(tickets)!=len(commits):raise ValueError('one commit per pending ticket')
    for p,c in zip(tickets,commits):
        if c not in range(p.earliest,p.latest+1):raise ValueError('commit outside certified window')
    jobs=[('old',i,t) for i,t in enumerate(old)];trace=[];uid=0
    for t,n in enumerate(arrivals):
        eligible=sorted([x for x in jobs if x[2]<=t],key=lambda x:(x[2],x[0],x[1]))[:mu]
        remove={(x[0],x[1]) for x in eligible}
        jobs=[x for x in jobs if (x[0],x[1]) not in remove]
        late=0
        for i,(p,c) in enumerate(zip(tickets,commits)):
            if c==t:jobs.append(('pending',i,t+p.repair_delay));late+=1
        jobs.extend(('new',uid+i,t+ell) for i in range(n));uid+=n
        trace.append({'slot':t,'new_commits':n,'old_ticket_commits':late,'restored':len(eligible),'unrestored':len(jobs)})
    return trace


def old_M(old,s):return sum(r<=s for r in old)
def J(tickets,s,t):return sum(p.earliest<=t and s<p.latest+p.repair_delay for p in tickets)
def P(tickets,t):return sum(p.earliest<=t for p in tickets)
def T_bound(tickets,ell):return max([ell-1]+[p.earliest for p in tickets])
def A_interval_length(s,t,ell):return t-max(0,s-ell+1)+1


def term_values(old,tickets,b,rho,mu,ell,s,t):
    v=len(old)-old_M(old,s)+b+rho*(A_interval_length(s,t,ell)-1)+J(tickets,s,t)-mu*(t-s)
    return v


def event_times(old,tickets,ell):
    T=T_bound(tickets,ell);e={0,T,ell-1}
    for v in list(old)+[p.earliest for p in tickets]+[p.latest+p.repair_delay for p in tickets]:e.update((v-1,v))
    return sorted(v for v in e if 0<=v<=T)


def exact_margin(old,tickets,b,rho,mu,ell,*,sparse=True,limit=None):
    validate(old,tickets,b,rho,mu,ell)
    if mu<rho:return {'margin':math.inf,'reason':'persistent arrival rate exceeds guaranteed recovery'}
    T=T_bound(tickets,ell)
    if limit is not None:T=limit
    times=event_times(old,tickets,ell) if sparse and limit is None else list(range(T+1))
    best=len(old);w={'kind':'initial','t':-1,'s':None};terms=0
    for t in times:
        value=len(old)+b+rho*t+P(tickets,t)-mu*(t+1);terms+=1
        if value>best:best=value;w={'kind':'prefix','t':t,'s':None}
        for s in times:
            if s>t:break
            value=term_values(old,tickets,b,rho,mu,ell,s,t);terms+=1
            if value>best:best=value;w={'kind':'interval','t':t,'s':s}
    return {'margin':best,'witness_term':w,'horizon_bound':T_bound(tickets,ell),'tested_times':times,'tested_terms':terms}


def witness(old,tickets,b,rho,mu,ell,cert):
    q=cert['witness_term'];t=q['t'];H=max([ell+2,t+3]+[p.latest+p.repair_delay+2 for p in tickets]+list(old))
    if H>20000:raise ValueError('Use sparse certificate, not explicit long trace, for very large calendar')
    start=0 if q['kind']!='interval' else max(0,q['s']-ell+1)
    a=[0]*max(1,H)
    if t>=0:
        a[start]=b
        for j in range(start+1,t+1):a[j]=rho
    c=[]
    for p in tickets:
        if q['kind']=='interval' and p.earliest<=t and q['s']<p.latest+p.repair_delay:
            c.append(max(p.earliest,q['s']-p.repair_delay+1))
        else:c.append(p.earliest)
    trace=simulate(old,tickets,c,a,mu,ell)
    assert conforms(a,b,rho)
    peak=max([len(old)]+[x['unrestored'] for x in trace])
    assert peak==cert['margin'],(old,tickets,b,rho,mu,ell,cert,trace)
    return {'pending_commits':c,'new_arrivals':a,'peak':peak,'trace':trace}


def max_burst(old,tickets,H,rho,mu,ell):
    if H<len(old) or mu<rho:return None
    # Every non-initial term has b coefficient one; b0=max(1,rho) avoids invalid input.
    b0=max(1,rho);T=T_bound(tickets,ell);times=event_times(old,tickets,ell)
    noninitial=[]
    for t in times:
        noninitial.append(len(old)+rho*t+P(tickets,t)-mu*(t+1))
        noninitial.extend(term_values(old,tickets,0,rho,mu,ell,s,t) for s in times if s<=t)
    out=H-max(noninitial)
    return out if out>=b0 else None


def pending_free_margin(old,b,rho,mu,ell):
    if mu<rho:return math.inf
    return max([len(old),len(old)+b-mu]+[len(old)-old_M(old,t)+b+rho*t for t in range(ell)])


def examples():
    rows=[]
    # One known protected-service stream; pending operations separated vs able to bunch.
    for name,tickets in [('separated',[Ticket(0,0,1),Ticket(3,3,1),Ticket(6,6,1)]),
                         ('overlapping',[Ticket(0,6,1)]*3)]:
        cert=exact_margin((),tickets,1,1,2,1)
        rows.append({'case':name,'tickets':[asdict(p) for p in tickets],'exact':cert,'witness':witness((),tickets,1,1,2,1,cert),
                     'all_pending_plus_clean_bound':len(tickets)+1,'maximum_new_burst_at_H2':max_burst((),tickets,2,1,2,1)})
    assert rows[0]['exact']['margin']==2 and rows[1]['exact']['margin']==4
    # Huge calendar demonstrates algorithm independent of timestamp magnitude.
    huge=[Ticket(10**12,10**12+10**9,1),Ticket(10**12+2,10**12+2,1)]
    h=exact_margin((),huge,2,1,2,2)
    assert len(h['tested_times'])<=12
    return {'separation':rows,'large_calendar':{'tickets':[asdict(p) for p in huge],'certificate':h}}


def run_checks():
    count=0;extended=0;inverse=0;maxevent=0
    opts=[Ticket(0,0,1),Ticket(0,2,1),Ticket(1,3,2),Ticket(2,2,1),Ticket(3,4,3),Ticket(0,1,3)]
    old_profiles=[(),(0,),(2,),(0,2),(3,3)]
    policies=[(1,0,0,1),(1,0,1,2),(1,1,1,1),(2,1,1,2),(2,1,2,3),(2,2,3,2)]
    pending_sets=[()]+[(p,) for p in opts]+list(itertools.combinations_with_replacement(opts,2))+list(itertools.combinations_with_replacement(opts[:3],3))
    for old,tickets,pars in itertools.product(old_profiles,pending_sets,policies):
        b,rho,mu,ell=pars
        cert=exact_margin(old,tickets,*pars)
        dense=exact_margin(old,tickets,*pars,sparse=False)
        assert cert['margin']==dense['margin']
        later=max([T_bound(tickets,ell)+5]+[p.latest+p.repair_delay+3 for p in tickets]+[x+3 for x in old])
        ext=exact_margin(old,tickets,*pars,sparse=False,limit=later)
        assert cert['margin']==ext['margin']
        witness(old,tickets,*pars,cert);count+=1;extended+=1;maxevent=max(maxevent,len(cert['tested_times']))
        if not tickets:assert cert['margin']==pending_free_margin(old,*pars)
        for H in range(len(old),len(old)+8):
            safe=[b1 for b1 in range(max(1,rho),H+mu+5) if exact_margin(old,tickets,b1,rho,mu,ell)['margin']<=H]
            assert max_burst(old,tickets,H,rho,mu,ell)==(max(safe) if safe else None)
            inverse+=1
    rng=random.Random(113)
    for _ in range(1000):
        old=tuple(rng.randrange(12) for _ in range(rng.randrange(5)))
        tickets=tuple(Ticket(l:=rng.randrange(12),l+rng.randrange(6),rng.randrange(1,6)) for _ in range(rng.randrange(6)))
        b=rng.randrange(1,5);rho=rng.randrange(b+1);mu=rng.randrange(rho,6);ell=rng.randrange(1,6)
        cert=exact_margin(old,tickets,b,rho,mu,ell)
        dense=exact_margin(old,tickets,b,rho,mu,ell,sparse=False,limit=25)
        assert cert['margin']==dense['margin']
        witness(old,tickets,b,rho,mu,ell,cert)
        extended+=1
    # Every enlarged Cartesian window family must weakly increase the bound.
    mono=0
    for a,b in itertools.product(range(4),repeat=2):
        p=(Ticket(a,a,1),Ticket(b,b,2));q=(Ticket(0,a+3,1),Ticket(0,b+3,2))
        assert exact_margin((),p,2,1,2,2)['margin']<=exact_margin((),q,2,1,2,2)['margin'];mono+=1
    return {'exact_grid_profiles':count,'grid_plus_seeded_extended_horizon_checks':extended,'inverse_comparisons':inverse,'window_expansion_checks':mono,'maximum_grid_event_times':maxevent}


def main(out):
    result={'version':'ASI-CC-v1.3.0','claim':'Exact window-aware inherited-effect admission; no real AI/power/welfare data','counts':run_checks(),'examples':examples(),
            'assumptions':['all integer unit impairment/repair costs','independent finite pending commit windows','new stream regulated at actual commit not request','trusted complete effect boundary and repair timing','guaranteed per-slot work-conserving recovery mu>=rho'],
            'assertions':'PASS'}
    p=Path(out);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'examples':[(r['case'],r['exact']['margin']) for r in result['examples']['separation']],'assertions':'PASS'},indent=2))
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--out',default='commit_window_results.json');main(a.parse_args().out)
