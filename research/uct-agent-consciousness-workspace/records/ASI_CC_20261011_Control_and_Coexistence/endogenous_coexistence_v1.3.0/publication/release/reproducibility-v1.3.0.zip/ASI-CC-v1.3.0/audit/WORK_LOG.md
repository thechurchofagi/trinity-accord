# Work log — ASI-CC-v1.3.0 —2026-10-11

## Request, baseline and selected gap
User requested a further substantive improvement and preparation for publication. Read supplied v1.2source/PDF/reproducibility package, connected guidev2.3 and actual branch/index. Current source baseline3ce6b328e53d6371cfe91896f04c96336160216b; predecessor source0173b9623b3f0741b472783df67a53114615fb27. Whole-map historical review not asserted. Selected the exact gap the old manuscript admitted: its all-stream sharp handoff result excluded uncommitted inherited tasks, while its escrow extension gave only safety for arbitrary asynchronous work.

## New actual research
Derived per-ticket contribution1{s-delay<c<=t} in the unrolled queue identity, maximized jointly over independent integer commit windows and a fresh actual-commit envelope, proved attaining shifted-burst schedules. Proved finite horizonT=max(ell-1,max earliest) under mu>=rho; proved boundary compression. Recovered old result with no pending tickets, derived inverse allowance and separated-count versus overlapping-window gap. Found a valid later fresh-burst example defeating reuse of the earlier universal frontloaded witness. This is not a refutation of the old no-pending theorem.

## Source and originality audit
Newly identified very close Irreversibility Budget paper, arXiv2609.00275. Shared cross-agent exposure and reservation concepts are now explicitly classified inherited, correcting an incomplete earlier comparison. Reviewed primary networkcalculus/RFC jitter and modern quiescence/semantic-transaction work. No claim of first ledger or generic minplus theory. The exact formula/specialization priority remains unverified.

## Actual computations
commit_windows.py:1140 systematic profiles;1000 seeded larger profiles; all sparse/dense/extended-horizon maxima and attaining traces agree;9120 inverse comparisons and16window-expansion controls. Separate window_oracle.py enumerated57120 joint schedules over180profiles without importing analytical module. verify_package.py separately compared all maxima, regenerated32separation-family sizes,6effective-cancellation monotonicity checks and a narrower-schedule negative boundary. Protocol:23cases/46spawns/153states/167realSQLdisablecommits/23stale-new-requestrejections. Eight conforming schedules with exact certificate all complete safely; count-only classifier declines all8, not falsely called unsafe. Added specific stale-window, out-of-window-gate, overlap and missing-repair controls.

All three v1.2 scripts rerun, archived semantic JSON equality after only process/runtime normalization. All three new scripts plus crosscheck utility fully rerun under hashseeds101 and202. Source hashes and actual commands/results in FINAL_RUN_RECEIPT.json. No previous count is added to new results and replays are not independent risk samples.

## Manuscript and packaging
Wrote focused self-contained12page manuscript with complete definitions, proofs, closest-prior-art comparison, scope, counterexamples and software result table. Rendered all pages and inspected all contact-sheet pages plus final reference page. Corrected appendix table floating above its section title by forcing local placement. Final build no overfull/undefined warnings. No mathematical assertion failure was suppressed. Removed an unused intermediate example variable; final code rerun after cleanup. Publication-preparation files created, no DOI/OTS/Arweave tools invoked.

## Status
Complete revised mathematical preprint for critical review and subsequent authorized publication. Not externally peer reviewed, not a proof of production safety, no hardware or learned-agent or subjective-experience data. Formal UCT-MAP-v1.1.2 and913/424/261 unchanged; coverage baselineUCT-PUB-v1.0.33 has a scoped candidate delta only. Whole historical semantic and worldwide priority audits remain open. Remote preservation claims are limited to PERSISTENCE_RECEIPT.json.

## Actual persistence outcome
GitHub baseline reads succeeded, but write-tool discovery surfaced only read functions in this runtime. Searched the installed plugin capability and checked local gh/credential availability; no executable authenticated write path was available. No repository or Library write is claimed. A complete repository-ready patch is packaged with all text source/data/metadata, and all deliverable files remain available via the conversation ZIP. This does not change the manuscript or research completion status.
