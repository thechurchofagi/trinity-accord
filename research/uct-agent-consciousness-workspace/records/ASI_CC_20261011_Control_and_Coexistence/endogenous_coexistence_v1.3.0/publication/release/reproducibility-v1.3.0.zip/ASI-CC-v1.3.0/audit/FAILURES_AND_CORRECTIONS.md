# Corrections and rejected overclaims — v1.3.0

- Closest-prior-art review improved materially: arXiv2609.00275 already gives cross-agent residual-risk budgets and reserved/committed accounting. The manuscript does not call a shared ledger its invention.
- The prior no-pending initial-burst witness is insufficient when an old ticket can execute later. A fixedslot3ticket and new2unitburst give peak2whenfrontloaded versus3whenaligned. The prior theorem was scoped correctly; extending its witness was rejected.
- An alternative smaller, correlated commit family can defeat necessity of the rectangular-window bound. This is explicitly retained as a boundary example; the positive result quantifies over the complete product.
- No failed numerical theorem assertion occurred in the final research sequence. Final scripts were rerun after removing unused exploratory code. Do not invent a failure or silently count a replay as new evidence.
- Initial PDF layout let the claim table float above its appendix heading. Table placement corrected and full PDF rerendered; scientific text unchanged.
- Tool-source outcomes and any later preservation errors, if any, belong in the persistence receipt. No unavailable Library destination is claimed.
