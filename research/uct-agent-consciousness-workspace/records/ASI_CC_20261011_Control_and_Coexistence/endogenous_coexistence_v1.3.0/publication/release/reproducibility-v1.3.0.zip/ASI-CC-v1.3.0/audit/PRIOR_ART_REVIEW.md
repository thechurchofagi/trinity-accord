# Targeted primary-source review — ASI-CC-v1.3.0

Checked11 October2026. This is not an exhaustive global priority search or independent peer review.

## Important new correction to the closest-prior-art comparison
Mohammadi & Bindschaedler, *The Irreversibility Budget: Fleet-Level Risk Accounting and Admission Control for Agent Operating Systems*, arXiv2609.00275v1, submitted31August2026, directly addresses cross-agent residual-risk budgets and reserve/confirm/cancel lifecycle accounting. Original abstract and full HTML, especially architecture, reserved+committed exposure and limitations, were read. Shared effect accounting must be inherited, not declared our general invention. Its values are heterogeneous residual loss; this paper studies recoverable unit-service impairment under a specified repair calendar. No empirical comparison against that system is performed.

## Source scopes
- Le Boudec & Thiran, *Network Calculus*, original author-hosted full PDF,2022online revision: §§1.4.1–1.4.2 backlog bounds/tightness/min-plus context read; relevant PDF pages39/44 rendered. Established mathematical method. No claim the general calculus is new.
- RFC9320, *Deterministic Networking Bounded Latency*: official full HTML, particularly source-versus-downstream arrival expansion by jitter and admission assumptions. The b+rho*Delta reshaping step is inherited. Not an assertion every real deployment has bounded delay.
- Zhu & Wang, root-scoped quiescence, arXiv2609.21284v1: original full HTML and stated fence/recovery scope. More complete old-root effect closure than our initiation-only gate; no claimed successful exploit of their implementation.
- Chen et al., Cordon, arXiv2606.17573v1: original abstract and HTML architecture/transaction boundaries. Task-level staging, validation, rollback/recovery are close established work. Not reproduced or outperformed here.
- Thiele/Chakraborty/Naedele, Real-Time Calculus, ISCAS2000: original institutional bibliographic record and abstract; full proof system not newly re-derived. Timed arrival/service analysis is inherited.
- Champati et al., Transient Delay Bounds, arXiv1806.03328: primary abstract/metadata. Initial-state-dependent transient analysis predates this work; their wireless/stochastic model is not the same theorem and is not refuted.
- O'Neil, Escrow1986: bibliographic/contextual source inherited; no new full original-paper access in this turn. Shared reservations are not a new method.
- Liu v1.2: supplied full LaTeX/PDF/archive and connected index. All three programs rerun, semantics matched. Old closed-form handoff is recovered as an exact pending-free case, not a new independent finding.
- UCT guidev2.3/current metadata and PR6 published-record context: connected reads. Entire UCT corpus and all published derivations were not reaudited; no consciousness claim is newly empirically validated.

## Precise candidate novelty
A sharp joint inherited-impairment/pending-window certificate, realizing schedules, horizon controlled by latest earliest commit rather than largest timestamp, an exact sparse event evaluation, and an explicit unbounded gap between a timing-aware contract and a count-only abstraction. The local experiment separates complete compliant operation from safe refusal and from gate or recovery violations. This is a proposed precise specialization/application. Worldwide priority remains unverified. A competing framework that preserves the same timing information might derive the same bounds; the paper does not deny that possibility.

Irrelevant search results were discarded. Reading an abstract or institutional record is not represented as reviewing the entire proof. Direct-source metadata and accessible HTML were used; no external text is reproduced in the artifact beyond ordinary short titles and bibliographic details.
