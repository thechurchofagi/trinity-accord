# When Revocation Does Not Restore Safety — ASI-CC-v1.3.0
## Exact Admission Across Asynchronous Policy Changes in Multi-Agent Systems

Hongju Liu · 11 October 2026 · 12-page publication-preparation manuscript, not peer reviewed and not DOI-published.

This revises the same unpublished v1.2 manuscript; it does not overwrite the separate PR-v6 DOI10.5281/zenodo.23295776. Read `paper/manuscript.pdf`. Full editable source: `paper/manuscript.tex`. The theorem extends a committed-only model to individually timed pending commitments, rather than simply reserving one unit forever for each pending task.

### Reproduce from this directory
```
python -S src/commit_windows.py --out data/commit_window_results.json
python -S src/window_oracle.py --out data/oracle_window_results.json
python -S src/window_protocol.py --out data/window_protocol_results.json
python -S src/verify_package.py --data-dir data
cd paper
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
```

Python3.10+ standard library. The protocol requires Unix-like pipe readiness, runs only its own child processes and temporary SQLite databases, and needs no model API, GPU or administrator privilege. `verify_package.py` compares oracle maxima after the independent module has computed them. The baseline folder includes the previously executed v1.2 programs; their reruns are inherited evidence, not added to new counts.

Seeded numerical profiles are test inputs, not a sampled threat distribution. Raw PIDs and run durations vary. No actual AI/hardware or experience is measured. The certificate assumes truthful and enforced commit windows, complete unit-effect accounting, a common logical time convention and work-conserving guaranteed recovery. No generic queue, escrow ledger or global priority is claimed as newly invented.

`audit/` includes exact source scope, critical review, version coverage, hashes and run receipts. `HANDOFF_ZH.md` explains the contribution in Chinese. `publication/` contains non-submitted DOI metadata and a release checklist. Preparing these files does not reserve or publish a DOI. Formal UCT-map admission remains disabled pending the uncompleted whole-map audit; the self-contained conditional manuscript is complete for public critical review.

The delivered ZIP contains PDF, full TeX, programs, raw JSON and audit records. `PERSISTENCE_RECEIPT.json` describes only actually verified remote preservation. No remote binary or Library backup is implied by creation of a local file.
