# Internal critical review — not external peer review

1. Recognition is not measured by agreeing with an ASI timeline; late or skeptical people retain equal standing. Representation can make access earlier.
2. Prefix-window dates are a restricted model. Reopening and lost access need sets of times; this is explicitly stated and a reopening negative control runs.
3. The sharp pairing bounds apply only if every pairing is genuinely possible. Constrained-linkage tests show why ignoring known identities exaggerates uncertainty.
4. The inverse extension theorem assumes an actual uniform extension of both procedural and material choice, holding access and admissible pairings fixed. It does not establish this capability exists, estimate its social cost, or recover an already destroyed option by decree.
5. The count guarantee is not a guarantee for a specified protected minority. It cannot ethically justify excluding everyone not counted toward k.
6. Uniform cost multiplier conversion assumes common exponential growth gap and nonbinding procedural dates; shared capacity or competing alternatives invalidate that simple conversion.
7. Speed comparison jointly changes access and closure. Fixed closure makes earlier access weakly beneficial. No claim education itself causes harm.
8. Both directions and tight witnesses are given for the finite bounds; independent permutation tests agree with assignment dynamic programming. Equality at the deadline is allowed consistently.
9. Human panel, natural experiment, approval by an ethics body, and preregistration are all proposed, not executed. No synthetic table is called survey evidence.
10. Review background clearly acknowledges anticipatory governance, irreversibility, political-power persistence and fixed-marginal mathematics. Exact synthesis priority is unverified.
11. Draft consolidation was performed now; no earlier delivered PDF or completed GitHub commit is invented. Baseline code reconstructed from supplied text is not falsely described as byte-identical recovery.
12. Formal UCT axioms, historical graph and published papers remain unchanged. This is a completed research manuscript, not an independent validation of a civilization-scale theory.
