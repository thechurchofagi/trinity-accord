#!/usr/bin/env python3
"""Reconstructed CD-v1.0.0 finite checks from the recorded prior source.
Synthetic cases only. Does not measure real AI adoption or recognition dates.
"""
from __future__ import annotations
import argparse,itertools,json
from fractions import Fraction
from functools import lru_cache
from pathlib import Path


def counts(a,d):
    n=len(a);support=set(a)|set(d)
    return max(0,max(sum(x<=t for x in a)-sum(y<t for y in d) for t in support)),n-max(0,max(sum(y<=t for y in d)-sum(x<=t for x in a) for t in support))


def assignment(a,d):
    n=len(a)
    @lru_cache(None)
    def dp(mask):
        i=mask.bit_count()
        if i==n:return 0,0
        opts=[]
        for j in range(n):
            if not mask>>j&1:
                l,u=dp(mask|(1<<j));v=int(a[i]<=d[j]);opts.append((l+v,u+v))
        return min(x[0] for x in opts),max(x[1] for x in opts)
    return dp(0)


def main(out):
    marginal=reviews=speeds=0;coupling=[]
    for n in range(1,6):
        arrays=list(itertools.combinations_with_replacement(range(4),n))
        for a in arrays:
            for d in arrays:
                assert counts(a,d)==assignment(a,d);marginal+=1
    for n in range(2,11):
        a=list(range(1,n+1));d=[n]+list(range(1,n))
        assert sum(x<=y for x,y in zip(a,d))==1
        coupling.append({'n':n,'aligned_successes':n,'shifted_successes':1})
    for ready,period,end,budget,g,h in itertools.product(range(13),range(1,5),[4,8,12],range(1,7),(Fraction(3,2),Fraction(2),Fraction(3)),(Fraction(1),Fraction(5,4))):
        t=((ready+period-1)//period)*period
        predicted=t<=end and g**t<=budget*h**t
        enumerated=any(t>=ready and t%period==0 and g**t<=budget*h**t for t in range(end+1))
        assert predicted==enumerated;reviews+=1
    change={-1:0,0:0,1:0}
    for a,d,alpha,beta,v1,v2 in itertools.product(range(1,9),range(1,9),range(1,4),range(1,4),[1,2,3],[2,3,4]):
        if v2<=v1:continue
        old=Fraction(a,v1**beta)<=Fraction(d,v1**alpha);new=Fraction(a,v2**beta)<=Fraction(d,v2**alpha)
        if alpha>beta:assert new<=old
        elif alpha==beta:assert new==old
        else:assert new>=old
        assert Fraction(a,v2**beta)<Fraction(a,v1**beta)
        speeds+=1;change[int(new)-int(old)]+=1
    demo=[]
    for v in (1,2,4):
        a=[Fraction(x,v) for x in (2,4,6,8)];d=Fraction(5,v*v)
        demo.append({'speed':v,'ready':[str(x) for x in a],'deadline':str(d),'timely':sum(x<=d for x in a)})
    assert [x['timely'] for x in demo]==[2,1,0]
    reopening=[t for t in range(7) if 2**t<=Fraction(1,4)*3**t]
    assert 0 not in reopening and reopening
    r={'version':'CD-v1.0.0-reconstructed','marginal_pairs':marginal,'rational_review_cases':reviews,'acceleration_configurations':speeds,'acceleration_change_counts':change,'coupling_witnesses':coupling,'acceleration_example':demo,'reopening_feasible_times':reopening,'assertions':'PASS','scope':'Same baseline mathematical cases; reconstructed delivery source, not claimed original byte identity'}
    p=Path(out);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='baseline_timing.json');main(p.parse_args().out)
