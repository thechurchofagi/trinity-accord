#!/usr/bin/env python3
"""Independent exhaustive permutation oracle; no imports of the design solver.
Constructed finite data, equal weights, equality at deadline admitted.
"""
import argparse,itertools,json
from pathlib import Path


def main(path):
    profiles=pairings=target_checks=0
    for n in range(1,7):
        arrays=tuple(itertools.combinations_with_replacement(range(3),n))
        cached={d:tuple(sorted(set(itertools.permutations(d)))) for d in arrays}
        for a in arrays:
            for d in arrays:
                scores=[]
                for s in range(max(0,max(a)-min(d))+1):
                    vals=[sum(x<=y+s for x,y in zip(a,p)) for p in cached[d]]
                    scores.append(min(vals));pairings+=len(vals)
                for k in range(n+1):
                    actual=next(s for s,x in enumerate(scores) if x>=k)
                    proposed=0 if k==0 else max(0,min(a[i]-d[i-k+1] for i in range(k-1,n)))
                    assert actual==proposed,(a,d,k,actual,proposed)
                    target_checks+=1
                profiles+=1
    report={'version':'CD-v1.1.0','profiles':profiles,'distinct_pairing_shift_evaluations':pairings,
            'target_checks':target_checks,'method':'Exhaustive complete permutations and extension scan; no imported formula implementation',
            'assertions':'PASS','empirical_human_data':False}
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='extension_oracle_results.json');main(p.parse_args().out)
