#!/usr/bin/env python3
"""CD-v1.1.0: exact effective-window extension with unknown date pairing.

All case arrays are constructed, not observations of people or actual policies.
Integer dates, equal weights, equality at closing time included. See manuscript.
"""
from __future__ import annotations
import argparse,itertools,json
from functools import lru_cache
from pathlib import Path


def validate(a,d):
    if not a or len(a)!=len(d):raise ValueError('Nonempty equal-length date lists required')
    if any(not isinstance(x,int) or isinstance(x,bool) for x in (*a,*d)):
        raise TypeError('Use exact integer dates in this verifier')


def bounds(a,d):
    validate(a,d);n=len(a);ts=set(a)|set(d)
    return (max(0,max(sum(x<=t for x in a)-sum(y<t for y in d) for t in ts)),
            n-max(0,max(sum(y<=t for y in d)-sum(x<=t for x in a) for t in ts)))


def minimum_uniform_extension(a,d,k):
    """Smallest integer s>=0 forcing >=k successes for every deadline pairing."""
    validate(a,d);n=len(a)
    if not isinstance(k,int) or isinstance(k,bool) or not 0<=k<=n:raise ValueError('0<=k<=n required')
    if k==0:return 0
    A=sorted(a);D=sorted(d)
    return max(0,min(A[i]-D[i-k+1] for i in range(k-1,n)))


def direct_assignment(a,d,allowed=None):
    """Independent exact cost DP with concrete witnesses, not CDF calculations."""
    validate(a,d);n=len(a)
    edges=allowed if allowed is not None else [set(range(n)) for _ in range(n)]
    if len(edges)!=n or any(j not in range(n) for row in edges for j in row):raise ValueError('Invalid graph')
    @lru_cache(None)
    def rec(mask):
        i=mask.bit_count()
        if i==n:return 0,(),0,()
        options=[]
        for j in sorted(edges[i]):
            if mask>>j&1:continue
            sub=rec(mask|(1<<j))
            if sub is None:continue
            lo,pmin,hi,pmax=sub;v=int(a[i]<=d[j])
            options.append((lo+v,(j,)+pmin,hi+v,(j,)+pmax))
        if not options:return None
        worst=min(options,key=lambda x:(x[0],x[1]));best=max(options,key=lambda x:(x[2],x[3]))
        return worst[0],worst[1],best[2],best[3]
    return rec(0)


def exact_extension_checks():
    tables=targets=shift_scores=0
    for n in range(1,6):
        arrays=tuple(itertools.combinations_with_replacement(range(4),n))
        for a in arrays:
            for d in arrays:
                maximum=max(0,max(a)-min(d));score=[]
                for s in range(maximum+1):
                    real=direct_assignment(a,tuple(x+s for x in d))
                    formula=bounds(a,tuple(x+s for x in d))
                    assert real is not None and (real[0],real[2])==formula
                    score.append(real[0]);shift_scores+=1
                assert score[-1]==n
                for k in range(n+1):
                    needed=minimum_uniform_extension(a,d,k)
                    brute=next(s for s,q in enumerate(score) if q>=k)
                    assert needed==brute,(a,d,k,needed,brute)
                    if needed>0:assert score[needed-1]<k
                    targets+=1
                tables+=1
    return {'marginal_pairs':tables,'target_coverage_checks':targets,'direct_shift_assignment_checks':shift_scores,
            'time_grid':[0,1,2,3],'population_sizes':[1,2,3,4,5],'all_minima_and_predecessor_failures':'PASS'}


def constrained_checks():
    graphs=0;profiles=0;strictly_tighter=0
    all_perms=tuple(itertools.permutations(range(3)))
    for mask in range(1<<9):
        edges=tuple({j for j in range(3) if mask>>(3*i+j)&1} for i in range(3))
        valid=[p for p in all_perms if all(p[i] in edges[i] for i in range(3))]
        if not valid:continue
        graphs+=1
        for a in itertools.product(range(2),repeat=3):
            for d in itertools.product(range(2),repeat=3):
                scores=[sum(a[i]<=d[p[i]] for i in range(3)) for p in valid]
                lo,hi=min(scores),max(scores);calc=direct_assignment(a,d,edges)
                assert calc is not None and (calc[0],calc[2])==(lo,hi)
                m,M=bounds(a,d);assert m<=lo<=hi<=M
                strictly_tighter+=int((m,M)!=(lo,hi));profiles+=1
    return {'admissible_linkage_graphs':graphs,'labeled_profile_checks':profiles,'strictly_narrower_than_anonymous':strictly_tighter,
            'scope':'Finite allowed-edge evidence; no causal mechanism inferred from edge labels'}


def robust_date_checks():
    profiles=states=0
    interval_options=((0,0),(0,1),(1,1),(1,2))
    for ai in itertools.product(interval_options,repeat=2):
        for di in itertools.product(interval_options,repeat=2):
            lowerA=[x[0] for x in ai];upperA=[x[1] for x in ai]
            lowerD=[x[0] for x in di];upperD=[x[1] for x in di]
            possible=[];req=[]
            for a in itertools.product(*(range(l,u+1) for l,u in ai)):
                for d in itertools.product(*(range(l,u+1) for l,u in di)):
                    result=direct_assignment(a,d);possible.extend((result[0],result[2]));states+=1
                    req.append(minimum_uniform_extension(a,d,1))
            lo=bounds(upperA,lowerD)[0];hi=bounds(lowerA,upperD)[1]
            assert (min(possible),max(possible))==(lo,hi)
            assert max(req)==minimum_uniform_extension(upperA,lowerD,1)
            profiles+=1
    return {'independent_interval_profiles':profiles,'actual_date_assignments':states,
        'robust_target_count':1,'scope':'Independent rectangular date uncertainty; correlated date constraints need a joint admissible set'}


def examples():
    a=d=[2,4,6,8];rows=[]
    for target in range(1,5):
        s=minimum_uniform_extension(a,d,target)
        v=direct_assignment(a,[x+s for x in d])
        prior=direct_assignment(a,[x+max(0,s-1) for x in d])
        rows.append({'target_cases':target,'uniform_real_extension':s,'min_successes':v[0],
           'max_successes':v[2],'one_slot_short_min':prior[0] if s>0 else None,
           'worst_deadline_indices':v[1],'best_deadline_indices':v[3]})
    assert [r['uniform_real_extension'] for r in rows]==[0,2,4,6]
    material=d[:];paper_extended=[x+4 for x in d]
    effective=[min(t,c) for t,c in zip(paper_extended,material)]
    assert bounds(a,effective)==bounds(a,d)==(1,4)
    assert bounds(a,[x+4 for x in d])==(3,4)
    identity=direct_assignment(a,d,[{i} for i in range(4)])
    assert identity[0]==identity[2]==4
    return {'dates':[2,4,6,8],'guarantee_table':rows,'legal_only_shift_lower_bound':1,
            'effective_shift_by4_lower_bound':3,'identity_linkage_lower_bound_without_shift':4,
            'notes':'Arbitrary person-decision-alternative cases; cardinality guarantee does not identify which people are protected'}


def main(path):
    result={'version':'CD-v1.1.0','kind':'Constructed mathematical verification, not human/social experiment',
            'uniform_extension':exact_extension_checks(),'restricted_pairing':constrained_checks(),
            'interval_censoring':robust_date_checks(),'examples':examples(),
            'assertions':'PASS','limitations':['All-pairings result applies only to its admissible pairing family',
                'Extending a meeting alone does not extend a material choice',
                'A coverage target is not a moral rule to discard the other cases',
                'Extension is prospective; changing a number does not recover lost options',
                'Capacity, feasibility and legitimacy are external premises, not measured by these scripts']}
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='examples'},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='window_design_results.json');main(p.parse_args().out)
