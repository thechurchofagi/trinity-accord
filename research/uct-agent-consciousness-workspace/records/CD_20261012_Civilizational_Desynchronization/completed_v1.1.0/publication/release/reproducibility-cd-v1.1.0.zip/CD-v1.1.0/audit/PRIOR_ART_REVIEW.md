# Scoped prior-art and source audit — CD-v1.1.0

Date:12 October2026. This is a targeted source check, not an exhaustive novelty audit or independent peer review.

- **Guston2014**, Understanding anticipatory governance, DOI10.1177/0306312713508669: publisher page retrieved. Prior programme of anticipatory social capacities and the Collingridge dilemma. Our operational timing bound is not first recognition that learning may come after lock-in.
- **Makarov1982**, DOI10.1137/1126086: direct DOI request failed; SIAM publisher metadata retrieved. Classical fixed-marginal bounds are inherited. The paper supplies a separate finite Hall-matching proof and an inverse for this application, not a claim of a new general probability method.
- **Hall1935**, DOI10.1112/jlms/s1-10.37.26: established mathematical attribution retained from the supplied manuscript; no new complete historical priority audit. The finite deficiency proof used here is explicit.
- **Granovetter1978**, DOI10.1086/226707: established predecessor retained from the supplied source for heterogeneous collective response. No diffusion mechanism is independently estimated or reproduced.
- **Arrow/Fisher1974**, DOI10.2307/1883074: irreversibility and preservation/learning reference retained. We do not claim first option-value analysis.
- **Acemoglu/Robinson2008**, DOI10.1257/aer.98.1.267: original AEA publisher abstract and author/NBER entries retrieved. De jure/de facto power persistence is prior work; our indicator is not their equilibrium or a validated proxy for political power.
- **Marchant2026**, The Pacing Problem and Soft Law: ASU author repository bibliographic record and abstract retrieved. Agility versus stakeholder participation is explicitly prior work.
- **Iseko2025**, DOI10.11648/j.ijsts.20251305.12: primary publisher text retrieved. Acknowledged for temporal-sovereignty/justice conceptual precedence. Interview claims were not independently verified and do not provide empirical evidence for our formulas. The text contains different case-count descriptions; we do not reproduce its claimed statistics.
- **Pew2025** official report retrieved:73%/23% expectation contrast concerns work over20years; fieldwork2024. The expert sample is unweighted and represents respondents. No inference to recognition timing, national expert population or political competence.
- **Federal Reserve2026** official2025household report retrieved:43%/10% prior-month workplace use by graduate/high-school-or-less workers. A usage statistic, not civilizational readiness evidence. No financial advice is given.
- **CIPSA TA-TR-2026-13** DOI10.5281/zenodo.22866775: first-party source already supplied in conversation. Its production/governance distinction is inherited. This run did not independently re-estimate its numerical illustrations or perform a full publication corpus reconciliation.

## Net claim
A case-specific opportunity model and exact, implementability-sensitive inverse guarantee under unknown date pairing, with separate constructed counterexamples and a prospective data-linkage protocol. Broader causality, welfare ranking, legitimate participation rules and inevitability of ASI remain unestablished. All standard mathematical and philosophical predecessors are acknowledged.
