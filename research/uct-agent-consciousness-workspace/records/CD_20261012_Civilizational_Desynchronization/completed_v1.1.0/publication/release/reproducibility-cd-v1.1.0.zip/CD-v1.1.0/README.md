# Awareness Can Catch Up After Choice Has Closed — CD-v1.1.0

Hongju Liu |12October2026|12-page completed English research manuscript. Not peer reviewed, no new DOI. This is the completed delivery of the previously interrupted awareness/desynchronization project.

Read `paper/manuscript.pdf`; edit `paper/manuscript.tex`. `HANDOFF_ZH.md` gives the Chinese explanation. `protocol/PROSPECTIVE_STUDY.md` proposes an unexecuted ethical empirical design. `audit/` records actual runs, scope, provenance, claims, prior art and quality.

## Reproduce (Python3.10+, standard library)

```sh
python -S baseline/timing_frontier.py --out data/baseline_timing.json
python -S baseline/pairing_oracle.py --out data/baseline_pairing.json
python -S src/window_design.py --out data/window_design_results.json
python -S src/extension_oracle.py --out data/extension_oracle_results.json
cd paper
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
```

No network, API keys, GPU or human data are needed for these finite verifications. Access dates and effective deadlines are stipulated model inputs. Classical matching methods are explicitly inherited. A genuine uniform extension of effective options is an external institutional/engineering premise, not automatically produced by the formula.

The SHA256 manifest lists the final delivered files. Prior source algorithms were reconstructed from conversation records; exact old byte identity is not asserted. Global novelty, real human power effects and physical implementability remain open. No old published bytes are overwritten.
