# Prospective empirical bridge — not executed or preregistered

## Research question
Does the timing of practical access, relative to the closing of a specific feasible institutional alternative, predict lost opportunity after accounting for representation and relevant institutional differences? A later causal question asks whether changes in such opportunity change enduring authority allocations. Neither is answered by synthetic arrays.

## Linked case schema
Each record should have a pseudonymous participant/represented-constituency ID, a decision ID, alternative ID, documented standing, representation route, neutral comprehension measures, forecast distributions for rapid/slow/stalled AI scenarios, practical access interval, scheduled procedural review dates, actual alternative feasibility intervals, source provenance, resources, implementation requirements, later reopening, and a separate institutional outcome. All dates should retain uncertainty and coding disagreement. Weighting must be declared before aggregating repeated cases.

## Identification
Practical access cannot be scored by agreement that superintelligence is imminent. Existing AI use, worry, enthusiasm, forecasts and comprehension are separate variables. Verify whether an effective representative already supplies participation. Link each person to the actual relevant decision window; do not randomly pair a national awareness distribution to unrelated institutional dates. The anonymous theorem is a sensitivity envelope when all pairings are genuinely possible, not permission to discard known links.

Confounders include economic resources, authority, occupation, organizational membership, education and local AI exposure. Institutions may strategically accelerate or delay commitments. Longitudinal association alone is not a causal timing effect. Record outcomes after the participation measure rather than define readiness retrospectively from policy success.

## Low-stakes randomized vignette proposal
Use identical balanced material, with disclosure of uncertainty and rapid/slow/stalled scenarios. Randomize timing within a session and whether the fictional review is merely nominal or genuinely permits implementable reconsideration. All participants eventually receive the same material. Test the interaction on mechanically available reconsideration; separately record the alternative selected and decision comprehension. Include an effective-reopening condition and a fixed-window control. Do not manipulate real civic rights, education access, livelihoods or actual political decisions.

Specify before recruitment the primary endpoint, exclusion rules, treatment comparison, attrition handling, sample-size justification and accessible procedures. Sample size has not been fixed here and no power calculation is claimed. Seek independent ethics review and informed consent. Avoid deceit about actual AI capability, consequential real-world losses and ideology-based grading. No ethics approval, recruitment, participant data or results exist for this proposal.

## Falsification and transfer
If delayed access is routinely offset by genuine representation, durable options or reopening, the alleged temporal exclusion mechanism may be absent. If lost opportunity does not causally affect the hypothesized persistent allocation, do not label the outcome a civilization-wide power fracture. A laboratory result would test a bounded mechanism, not date the arrival of ASI or establish historical inevitability.
