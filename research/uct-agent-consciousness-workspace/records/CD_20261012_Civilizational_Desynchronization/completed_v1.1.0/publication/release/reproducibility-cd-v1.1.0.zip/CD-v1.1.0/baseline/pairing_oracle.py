#!/usr/bin/env python3
"""CD-v1.0 reconstructed independent explicit complete-pairing oracle."""
import argparse,itertools,json
from pathlib import Path

def main(path):
    profiles=pairings=0
    for n in range(1,7):
        arrays=list(itertools.combinations_with_replacement(range(3),n))
        perms={d:tuple(sorted(set(itertools.permutations(d)))) for d in arrays}
        for a in arrays:
            for d in arrays:
                scores=[sum(x<=y for x,y in zip(a,pi)) for pi in perms[d]]
                points=set(a)|set(d)
                lo=max(0,*[sum(x<=t for x in a)-sum(x<t for x in d) for t in points])
                hi=n-max(0,*[sum(x<=t for x in d)-sum(x<=t for x in a) for t in points])
                assert (min(scores),max(scores))==(lo,hi)
                profiles+=1;pairings+=len(scores)
    r={'version':'CD-v1.0.0-reconstructed','profiles':profiles,'distinct_pairings_evaluated':pairings,'assertions':'PASS','empirical_human_data':False}
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='baseline_pairing.json');main(p.parse_args().out)
