"""Publication coverage is a separate overlay; this script never edits a map."""
from pathlib import Path
from collections import Counter, defaultdict
import json, hashlib, re

ROOT=Path('/workspace/scratch/328b6dbb55c2')
OUT=ROOT/'publication_audit_work'
PROJECT=ROOT/'uct/research/uct-agent-consciousness-workspace'
RELEASE=PROJECT/'versions/UCT-MAP-v1.1.2'
GRAPH=RELEASE/'UCT_EFFECTIVE_GRAPH.json'
LEDGER=RELEASE/'REVIEW_LEDGER.json'
TREE=OUT/'research_workspace_tree_310e744.json'
MGTD=OUT/'sources/attachments/mgtd_v101/MGTD_Method_Paper_v1.0.1/evidence/UCT_EFFECTIVE_GRAPH.json'
MGTD_LEDGER=MGTD.with_name('REVIEW_LEDGER.json')
TH=OUT/'sources/attachments/rt_th_v100/RT_TH_Reproducibility_v1.0.0/provenance/TH_MAP_EXTENSION_REVIEWED.json'
RT=TH.with_name('RT_MAP_EXTENSION.json')
METHOD=OUT/'sources/attachments/mgtd_v101/MGTD_Method_Paper_v1.0.1/method_map/METHOD_MAP.json'

def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(o): return hashlib.sha256(json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def rel(p): return str(p.relative_to(ROOT))
g,l,t=read(GRAPH),read(LEDGER),read(TREE)
published=read(MGTD)
published_th=read(TH)
published_rt=read(RT)
published_method=read(METHOD)
old_assessments=read(ROOT/'map_audit_work/FAMILY_COMPATIBILITY_ASSESSMENTS.json')
tree_blobs={x['path']:x for x in t['tree'] if x['type']=='blob'}
node_by_id={n['id']:n for n in g['nodes']}

TITLES={}
for row in '''A|UCT I: complete actual organization and conditional experiential identity
B|UCT II: typed translation and theory-specific bridge obligations
C|UCT III: capability, observation fibers, joint laws and value
D|TA24: continuation-control evidence ladder and causal identification
R126|Deterministic abstraction, closure and approximation
R127|Task-required distinctions, complete information cuts and provenance
N128|Joint deterministic and stochastic summary closure
R131|Payoff sufficiency, probability-law probes and closure
R132|Common resource realization and partial-operation interfaces
R133|Observable common control and ideal message covers
R134|Quantitative persistent-model control and probe costs
R135|Guarantee profiles and target-relative deficiency
R136|Common channel garbling and causal interfaces
R137|Executable feedback decoders and compatibility obstructions
R145|Fixed primitive ports and baseline-equivalent realizations
R146|Centered reference, duplicate labels and target sufficiency
R147|Physical attachment versus complete response laws
TA15|Typed quotient, factorization and observational nonidentification
TA16|Historical finite recurrence/relational framework
TA17|Functional descendant sets and target-relative continuation
TA18|Actual participation, selected germs and null-equivalence bridges
TA19|Equivariant selection and monodromy obstructions
R149|Complete experiential type requires type-reflecting sufficiency
R155|Attribution updater, installed use and finite memory limits
R156|Snapshot versus installed functional use
R157|Grounded formula transport and named-target residual
R158|Target-specific necessity and nonautonomous definable selection
R159|Anchor/binding/frame relations and ownership bridge
R160|Crossed body/tool causal profiles
R161|Candidate intervention protocol and simultaneous decisions
R162|Independent pilot freezing and covariance identification
R163|Bounded finite-sample coverage and missing outcomes
R164|Martingale adaptation and nonidentified missingness
R165|Finite pilot-menu selection and width feasibility
R166|Same-token installed relation witness requirements
R167|Backup-sensitive causal use and compensation timing
R168|Stochastic hidden-context coverage and regularity envelopes
R169|Actual route composition and physical calibration
R170|Open-world remainder bounds and coverage triage
R171|Direct/reachable range certificates and unclosed applications
R172|Cross-interface composition and actual action-use contracts
R173|Availability, agency and retentive binding; corrected independence
TE20261008|Retiming, selected organization and relay provenance
TO20261008|Reference routing and globally compatible clock coordinates
R174|Temporal mediator signatures and untested bypasses
BR20261008|Role refinement and one common anchored correspondence
R175|Orientation/target repairs and subsequently narrowed claims
R176|Named-order nonidentification and effective withdrawals
IA20261008|Blind holdout identity and causal trace ancestry
R177|Source, use and inverse-compensated feature distinctions
CORE20261008|Target-relative minimal supports and imported gluing/dynamics
EI20261008|Architecture dependence and arithmetic target support
R183|Individual versus disjunctive experiential relevance
OO20261008|Task access, nonlinear codes, noise and query return
RU20261008|Reliability, selection, abstention and answer wiring
R184|Retention/resumption routes and redundant target support
RC20261008|Coherent answer commitments and shared candidate paths
IE|Intelligence/experience interpretation and late-query limits
TH20261009|Temporal handoff, complete-cut rank and installed recovery
RB20261009|Omitted-input recovery budget and deadline transcripts
OL20261009|Observable locality with fixed physical write families
R185|Same-event cross-scale membership and incidence counting
HOM|Finite short-word equivalence and deeper contextual witnesses
UI20261009|Order-sensitive interventions and autonomous product limits
CM20261009|Compensation observability and monitor requirements
R187|Fixed-interface behavioral equivalence and occurrence nonidentification
R188|Encoder-access compatibility and weighted finite-error recovery'''.splitlines():
    k,v=row.split('|',1);TITLES[k]=v

NEW_ASSESSMENTS={
'R185':'Same physical episode occurrence can belong to multiple admitted processes; equal copies do not identify shared membership. Incidence multiplicity is not event multiplicity or subject count. The coherent-overlap source card is inherited from CG/CORE; actual shared-member admission and action-centering remain open.',
'HOM':'The finite model supplies equality below a chosen observation depth and a separating longer common context. The state-count/depth parameters remain fixed in each comparison. This is a refinement of existing finite-view and interface nonidentification, with no actual phenomenal witness.',
'UI20261009':'Autonomous independent product updates commute under the declared intervention class; order gaps obstruct that factorization, and finite deterministic distinguishing words have a state-count bound. The four-cycle antecedent is already CD/CORE. Prediction/noise/reduction bounds require their separate contracts, and all actual realization/phenomenal bridges stay open.',
'CM20261009':'A complete linear observation detects a selected source quantity iff that quantity is constant on its fibers; monitor and active-probe conditions make this concrete for compensation. This inherits C:P2/TA25 factorization and classical rank/observability. Continuous monitor rank is not communication bits, and unconstrained compensation remains a countercontrol.',
'R187':'Bisimulation/all-policy observational equivalence is relative to a fixed complete legal interface. Selective, probabilistic, noisy, metric and approximate cases have distinct hypotheses. Identical responses do not identify occurrence number, source lineage or subject number; that general point is inherited, with new explicit finite countermodels and bounds only at declared scope.',
'R188':'Zero-error coloring is classical and an exact specialization of R133:MESSAGE_COVER; common-policy and approximate-decoder optimization precede this record. The narrower candidate increment is the specified six-target matched benchmark, a source-only encoder contract, exact weighted finite-error objective, and timely reader feedback repair. It is a technical supplement candidate, not an established new general information theorem or an independently sufficient paper.'
}

# Exact semantic categories were selected from the previously read full objects.
# A node's kind is an aid to indexing, not a proof that a premise is established.
CORRECTIONS={
'R173:THREE_TARGET_SEPARATION','R175:R173_EFFECTIVE_TARGET_SEPARATION',
'R175:R174_FIBER_DIRECTION_CORRECTION','R175:ADMITTED_HISTORY_TWIN',
'R175:SIX_ROW_EVENT_MODELS','R175:HELD_OUT_ORDER_PREDICTION',
'R175:B_ORDER_NARROWED_BOUNDARY'
}
OPEN_OVERRIDES={
'A:BRIDGE_FWD','A:BRIDGE_REV','A:OSC_FWD','A:OSC_TWO',
'R175:INDEPENDENT_EXPERIENTIAL_ORDER','R175:ORIENTATION_ANCHOR_PACKAGE',
'R172:LOCAL_COMPONENT_CERTIFICATE_INSTANCE','R171:DIRECT_TOTAL_RANGE_CERTIFICATE',
'R171:INDUCTIVE_REACHABLE_RANGE_CERTIFICATE','R170:CELL_ROUTE_COVER_CERTIFICATE',
'R169:LOCAL_CHANNEL_UPPER_CERTIFICATE','R173:EFFECTIVE_R172_PATH_INSTANCE'
}
THEORY_IDS={'A:C1','A:P3','A:P6','A:TOKEN_CRITERIA','A:ACTUAL_TOKEN','TA18:PRD','TA16:RRH_HISTORY'}
GOV_KINDS={
'METHOD','METHOD_CHARTER','PRIOR_ART_BOUNDARY','RESEARCH_STATUS','INFERENCE_GUARD',
'METHODOLOGICAL_SYNTHESIS','TYPED_EVIDENCE_AND_INTERPRETATION_SEPARATION',
'INTERPRETIVE_SYNTHESIS','PRIOR_ART_BOUNDARY','BOUNDARY','TEST'
}
EVIDENCE_KINDS={'NUMERICAL_RECORD','EMP_WITNESS','SOURCE_EVIDENCE','REPORTED_EVIDENCE',
'FINITE_MATHEMATICAL_EVIDENCE','EXECUTED_SOFTWARE_EVIDENCE','EMPIRICAL_SOURCE_SCOPE_AUDIT',
'SOURCE_GROUNDED_EVIDENCE_COMPARISON'}
DEFINITION_KINDS={'DEF','DEFINITION','EPI_DEF','ONTO_DEF','DEFINITION_CONSOLIDATION','METHOD_DEF',
'DECLARED_ACTUAL_RELATION','DECLARED_HISTORY_INDEXED_ACTUAL_RELATION',
'ACTUAL_ORGANIZATIONAL_RELATION','ACTUAL_ORGANIZATIONAL_TARGET',
'FINITE_SEMANTIC_WITNESS_CLASS','MODEL','FINITE_MODEL','FINITE_MODEL_CLASS','MODEL_SPECIFICATION',
'MODEL_DEFINITION','FINITE_MODEL_DEFINITION','ABSTRACT_ORGANIZATIONAL_MODEL','ABSTRACT_WITNESS_PACKAGE',
'MODEL_AND_DEFINITION','MODEL_AND_DOMAIN','DEFINITION_AND_DOMAIN','DEFINITION_AND_PROTOCOL',
'FORMAL_TARGET_DEFINITION','TYPED_DISTRIBUTIONAL_CAUSAL_DEFINITION','HISTORICAL_POSTULATE',
'DEFINITION_AND_ASSUMPTION_PACKAGE','PROSPECTIVE_PHYSICAL_ARCHITECTURE',
'PROSPECTIVE_DESIGN_DEFINITION','DECLARED_MATHEMATICAL_MODEL'}
INTERPRETATION_IDS={'D:UCT_INTERPRETATION','R149:SELF_APPLICATION','R149:COMPATIBILITY',
'R157:COORDINATE_TRANSPORT','R159:FRAME_RELATION_TRANSPORT','R188:UCT_TYPE',
'R167:R166_WITNESS_APPLICATION_BOUNDARY','R168:R167_WITNESS_STOCHASTIC_BOUNDARY',
'R172:BIO_AI_APPLICATION_BOUNDARY','TE20261008:EXPERIENTIAL_TEMPORAL_CONTRAST',
'EI20261008:STRUCTURAL_INTERPRETATION','R183:TRER','R184:INDIVIDUAL_APPLICATION',
'R184:DISJUNCTIVE_APPLICATION','R184:EXPERIENTIAL_RELEVANCE','R185:EXPERIENTIAL_COUNTERPART'}

def node_role(n):
    i=n['id'];k=n.get('kind','').upper()
    if i in CORRECTIONS:return 'correction_or_withdrawal'
    if i in THEORY_IDS:return 'theory_commitment_or_ontological_domain'
    if i in OPEN_OVERRIDES or k.startswith(('OPEN_','UNDISCHARGED','UNRESOLVED')) or k=='OPEN_PROBLEM':return 'open_obligation'
    if k in EVIDENCE_KINDS:return 'reported_evidence'
    if k in GOV_KINDS or k.startswith('PROSPECTIVE_') and 'FALSIFIER' in k:return 'method_or_inference_governance'
    if k in DEFINITION_KINDS:return 'definition_or_model'
    if i in INTERPRETATION_IDS or any(s in k for s in ('C1_APPLICATION','C1_TRANSPORT','UCT_APPLICATION','UCT_INTERPRETATION','EXPERIENTIAL_BOUNDARY','EXPERIENTIAL_COUNTERPART','EXPERIENTIAL_STRUCTURAL')) or k in {'CONDITIONAL_INTERPRETATION','INHERITED_CONDITIONAL_APPLICATION','INHERITED_CONDITIONAL_GUARD','INHERITED_THEOREM_APPLICATION','INHERITED_APPLICATION'}:return 'conditional_interpretation'
    if any(s in k for s in ('PREMISE','ASSUMPTION','CONTRACT','SETUP','PACKAGE','DOMAIN','GUARD','CERTIFICATE')) and not any(s in k for s in ('THEOREM','RESULT','NONENTAILMENT','COUNTEREXAMPLE','BOUNDARY')):return 'premise_or_contract'
    if k in {'MATHEMATICAL_DOMAIN','ONTO_DOMAIN','SCENARIO','SEMANTIC_BRIDGE_CANDIDATE','BRIDGE','BRIDGE_PKG'}:return 'premise_or_contract'
    if k=='IMPORTED_CONDITIONAL_PROOF_CARD' or k=='INHERITED_CONDITIONAL_SOURCE_CARD' or k=='INHERITED_ALIAS':return 'inherited_source_or_alias'
    if k in {'METHODOLOGY','METHOD_RESULT','CLASSIFICATION'}:return 'research_method_result'
    if k in {'APP','ONTO_CONSEQ','LOGICAL_APPLICATION','INHERITED_CONDITIONAL_RESULT','INHERITED_CONDITIONAL'}:return 'conditional_interpretation'
    return 'scientific_result'

ROLE_EXPLANATIONS={
'scientific_result':'A theorem, finite construction, counterexample or scoped result. Its stated domain/premises and limits govern; a map declaration is not external validation or priority.',
'conditional_interpretation':'A consequence under UCT or another explicitly supplied bridge. The application premises remain distinct from a proved mathematical implication and from an admitted actual instance.',
'reported_evidence':'A source or executed-check record, not a new general theorem. Existing execution/empirical scope is preserved; this inventory did not rerun or independently replicate it.',
'theory_commitment_or_ontological_domain':'A declared foundational commitment or ontology/domain convention. Publication can disclose it without proving its empirical truth.',
'definition_or_model':'A definition or stipulated model, needed to state claims but not an additional demonstrated discovery.',
'premise_or_contract':'A hypothesis, common-instance domain or interface contract. Being in the graph does not discharge it.',
'open_obligation':'An unclosed physical, semantic, statistical or application obligation. It must not be counted as a completed scientific result.',
'method_or_inference_governance':'A research rule, inference boundary, falsification instruction or status declaration. Keep it citable as method/provenance where relevant, separate from new science.',
'inherited_source_or_alias':'A source/import/restatement link. It points to an antecedent rather than creating another independent result.',
'research_method_result':'A concrete methodological classification or evidence standard; novelty requires comparing the actual method, not counting its map record.',
'correction_or_withdrawal':'A correction, narrower effective reading or retired positive claim. Preserve the historical assertion and the reason; never count both old and corrected assertions as independent supported discoveries.'
}

PUBS={
'MGTD-v1.0.1':{'doi':'10.5281/zenodo.23241982','version':'1.0.1','member':rel(MGTD),'member_sha256':sha(MGTD),'scope':'Official evidence attachment: v1.0.0 effective graph; explicit declaration disclosure, not a claim that every node is proved in the paper body.'},
'RTTH-v1.0.0':{'doi':'10.5281/zenodo.23251651','version':'1.0.0','member':rel(TH),'member_sha256':sha(TH),'scope':'Official reproducibility attachment: reviewed TH v0.1 module. Later RB budget is referenced, not republished as this paper result.'}
}

# Parent/theory have read these specific primary sections. These are not blanket
# exact-body labels for every graph node in the surrounding family.
BODY_ANCHORS={
'C:P1':('UCT-III-v1.0','§5; §7.2','inherited','Fixed-J type refinement and the matched 1 versus 1/2 organization example precede the new records.'),
'C:P2_FULL':('TA25-v1.0','§5 T2','inherited','Whole-target kernel inclusion/factorization is explicitly present.'),
'C:P2_COORD':('TA25-v1.0','§5 selected targets','inherited','Selected-target recovery and a delta/2 metric lower bound are present.'),
'R147:ROUTING_LIMIT':('TA25-v1.0','§6 T3','inherited','Fully labelled response law does not identify attachment; synchronized instructions can conceal swaps.'),
'R145:TRANSPORT_BLIND':('UCT-I-v1.2','§3.5; TA25 §4','inherited','Ports and operations must be transported; equal outputs alone do not identify primitive organization.'),
'R149:COMPATIBILITY':('TA25-v1.0','§5 T2 and complete-type clause','inherited','Complete experiential type requires the complete structural-type target under C1.'),
'R188:IDEAL_NOT_INSTALLED':('TA25-v1.0','§5 T2 application boundary','inherited','An abstract decoder requires an independently supplied installed mechanism; the R188 source-only encoder counterexample specializes this limit.'),
'R188:ZERO_ERROR':('MGTD-v1.0.1 attachment','R133:MESSAGE_COVER','inherited','Exact specialization with an action equal to a complete decoder table; classical Witsenhausen coloring is credited separately.'),
'R187:ALL_POLICY_THEOREM':('UCT-III-v1.0','§7.3 Proposition 7','partial','The no-cross-observation-coupling boundary is already present; R187 fixed-interface sufficient bisimulation and all-policy formal package require a clause comparison.'),
}
TH_BODY={
'MIGRATION':'§2 H1','MATCHED_RECORDS':'§2 H1','THREE_WAY_DISSOCIATION':'§2 H1',
'BAYES_RECOVERY':'§2 linear recovery','NO_REGENERATION':'§2 complete-cut processing',
'EXACT_LOSS':'§2 linear loss','STORED_VS_READ':'§2 reader restriction',
'COORDINATE_INVARIANCE':'§2 transported coordinates','CORRELATION_LAW':'§2 correlated errors',
'CHAIN_LAW':'§2 repeated handoff','REUSED_MASK':'§2 persistent hidden mask',
'DUPLICATE_CANCEL':'§2 duplicate cancellation'
}

def publication_matches(coll,obj):
    i=obj['id'];ans=[]
    for key,doc,member in [('MGTD-v1.0.1',published,MGTD),('RTTH-v1.0.0',published_th,TH)]:
        p=next((x for x in doc.get(coll,[]) if x.get('id')==i),None)
        if p is None:continue
        changed=[k for k in sorted(set(p)|set(obj)) if p.get(k)!=obj.get(k)]
        critical=[k for k in changed if k in {'statement','scope','domain','all_of','conclusion','proof','proof_sketch','relation','formal_contract','same_instance_contract'}]
        if obj==p: status='exact_object'
        elif key=='MGTD-v1.0.1':status='corrected_since_published_declaration'
        elif i in {'TH20261009:CORRELATION_SETUP','TH20261009:r_correlation'}:status='partial_contract_correspondence'
        elif obj.get('statement') is not None and obj.get('statement')==p.get('statement'):status='exact_statement_with_contract_or_metadata_differences'
        elif coll=='rules' and obj.get('all_of')==p.get('all_of') and obj.get('conclusion')==p.get('conclusion'):status='same_premise_head_route_with_contract_or_metadata_differences'
        elif coll=='context_links':status='same_stable_context_id_reviewed_as_nondeductive'
        else:status='requires_semantic_clause_comparison'
        ans.append({'publication_id':key,'doi':PUBS[key]['doi'],'member':rel(member),'member_sha256':sha(member),'item_id':i,'published_object_sha256':canonical(p),'comparison':status,'differing_keys':changed,'semantic_fields_differing':critical})
    return ans

items=[]
coll_types={'nodes':'node','rules':'rule','context_links':'context_link'}
for coll,typ in coll_types.items():
    for obj in g[coll]:
        i=obj['id']
        if typ=='node':
            fam=i.split(':')[0];role=node_role(obj);summary=obj.get('statement',obj.get('label',''))
        elif typ=='rule':
            head=obj.get('conclusion',obj.get('head',''));fam=head.split(':')[0] if head else obj.get('origin_module','UNKNOWN');role='derivation_route';summary=obj.get('statement',obj.get('proof_sketch',obj.get('proof','')))
        else:
            src=obj.get('from',obj.get('source',''));dst=obj.get('to',obj.get('target',''));fam=str(dst).split(':')[0];role='nondeductive_context';summary=obj.get('relation','')
        if fam not in TITLES:fam='CROSS_FAMILY_OR_EXTERNAL'
        disclosures=publication_matches(coll,obj)
        claim=role in {'scientific_result','conditional_interpretation','reported_evidence','research_method_result','correction_or_withdrawal'}
        if not claim:coverage='not_claim'
        elif any(x['comparison']=='exact_object' for x in disclosures):coverage='exact'
        elif any(x['comparison']=='corrected_since_published_declaration' for x in disclosures):coverage='partial'
        elif any(x['comparison'].startswith('exact_statement') for x in disclosures):coverage='exact'
        elif disclosures:coverage='partial'
        elif i in BODY_ANCHORS:coverage=BODY_ANCHORS[i][2]
        else:coverage='unknown'
        body={'status':'unknown' if claim else 'not_claim','explanation':'No item-level paper-body equivalence is asserted solely from a source anchor or official attachment.'}
        if i in BODY_ANCHORS:
            p,loc,s,note=BODY_ANCHORS[i];body={'status':s,'publication_id':p,'locator':loc,'basis':'Primary-section reading reported by root/theory; attachment comparison independently performed here.','explanation':note}
        elif fam=='TH20261009' and i.split(':',1)[1] in TH_BODY:
            body={'status':'exact','publication_id':'RTTH-v1.0.0','locator':TH_BODY[i.split(':',1)[1]],'basis':'Parent and theory full-paper reading, checked against matching module statement.','explanation':'This TH v0.1 result is in the released combined paper; later RB budget is separate.'}
        if typ=='node':
            rationale=ROLE_EXPLANATIONS[role]
        elif typ=='rule':
            rationale='This is a derivation route with simultaneous premises, not an independent result to add to the conclusion count. Alternate rules remain alternatives; publication of a conclusion does not silently publish every stronger scope or premise change.'
        else:rationale='This is nondeductive context/provenance, not proof or an additional scientific discovery.'
        item={'item_id':i,'item_type':typ,'family_id':fam,'map_object_sha256':canonical(obj),'role':role,'claim_unit':claim,'label':obj.get('label',''),'semantic_summary':summary,'coverage_status':coverage,'coverage_basis':'Official disclosed declaration when exact/partial; paper-body and novelty are independent fields.','formal_disclosures':disclosures,'body_semantic_coverage':body,'classification_reason':rationale,'original_map_kind':obj.get('kind'),'original_map_status':obj.get('status')}
        if typ=='node':
            item['scope']=obj.get('scope',obj.get('domain',''))
            c=obj.get('formal_contract_R153',{})
            item['source_anchor']=c.get('source_anchor',obj.get('source',obj.get('source_record','')))
            item['open_obligations']=c.get('open_obligations',obj.get('open_obligations',[]))
            item['novelty_status']='not_established_by_publication_coverage'
            item['registered_derivation_routes']=[{'rule_id':r['id'],'premise_ids':r.get('all_of',r.get('premises',[]))} for r in g['rules'] if r.get('conclusion',r.get('head'))==i]
            item['nondeductive_prior_contexts']=[{'context_id':r['id'],'from':r.get('from',r.get('source')),'relation':r.get('relation')} for r in g['context_links'] if r.get('to',r.get('target'))==i]
            if role in {'inherited_source_or_alias','conditional_interpretation'}:item['increment_assessment']='inherited_or_conditional_application; compare exact selected target before claiming increment'
            if i in CORRECTIONS:item['effective_correction']='R173 organizational eight-way independence is withdrawn; G implies A leaves at most six combinations and all-six realizability is not established. R176 narrows named-content/orientation readings; preserve suspended routes and OPEN applications.'
        elif typ=='rule':
            item['conclusion_id']=obj.get('conclusion',obj.get('head'))
            item['premise_ids']=obj.get('all_of',obj.get('premises',[]))
        else:
            item['from']=obj.get('from',obj.get('source'));item['to']=obj.get('to',obj.get('target'))
        items.append(item)

old_suspended=set(published.get('suspended_historical_rule_ids',[]))
for i in g['suspended_historical_rule_ids']:
    items.append({'item_id':i,'item_type':'suspended_historical_rule','family_id':i.split('_')[0].upper(),'role':'correction_or_withdrawal','claim_unit':False,'coverage_status':'not_claim','formal_disclosures':[{'publication_id':'MGTD-v1.0.1','doi':PUBS['MGTD-v1.0.1']['doi'],'member':rel(MGTD_LEDGER),'member_sha256':sha(MGTD_LEDGER),'comparison':'historical_suspension_disclosed'}] if i in old_suspended else [],'body_semantic_coverage':{'status':'not_claim'},'classification_reason':'Historical invalid or narrowed inference is retained as SUSPENDED. Its archive disclosure is not active support; no reviewer-controlled OPEN item is closed.'})

families=[]
for fam in sorted(TITLES,key=lambda f:min(j for j,n in enumerate(g['nodes']) if n['id'].startswith(fam+':'))):
    ns=[x for x in items if x['item_type']=='node' and x['family_id']==fam]
    rs=[x for x in items if x['item_type']=='rule' and x['family_id']==fam]
    anchors=[]
    for n in ns:
        a=n.get('source_anchor')
        if a and a not in anchors:anchors.append(a)
    aliases={'N128':'R128','D':'R129','HOM':'R186','IE':'IE'}
    record_prefix=aliases.get(fam,fam)
    candidates=[p for p in tree_blobs if re.match('records/'+re.escape(record_prefix)+r'(?:_|/)',p) and p.endswith(('.md','.json','.py','.csv','.zip'))]
    for a in anchors:
        if isinstance(a,dict) and a.get('path') in tree_blobs and a['path'] not in candidates:candidates.append(a['path'])
    families.append({'family_id':fam,'title':TITLES[fam],'node_ids':[x['item_id'] for x in ns],'conclusion_rule_ids':[x['item_id'] for x in rs],'counts':{'nodes':len(ns),'rules_concluding_in_family':len(rs),'roles':dict(Counter(x['role'] for x in ns)),'coverage':dict(Counter(x['coverage_status'] for x in ns))},'substantive_scope_and_overlap':old_assessments.get(fam,NEW_ASSESSMENTS.get(fam,'')),'source_anchors':anchors,'source_record_paths':candidates,'source_completeness':{'graph_objects':'FULL_SEMANTIC_OBJECTS_REVIEWED_IN_V112_AUDIT','tree_artifact_listing':'COMPLETE_FOR_PINNED_WORKSPACE_TREE','all_archived_original_proofs_reread_in_this_inventory':False,'paper_body_coverage':'DO_NOT_INFER_FROM_SOURCE_PROVENANCE_OR_ATTACHMENT_DISCLOSURE'},'publication_origin_hint':('UCT-I-v1.2' if fam=='A' else 'UCT-II-v1.1' if fam=='B' else 'UCT-III-v1.0' if fam=='C' else 'TA24-v1.0' if fam=='D' else fam if fam.startswith('TA') else 'derived_research_record; inspect explicit coverage'), 'independent_result_count':None,'independent_result_count_reason':'A family mixes claims, models, premises, examples, imports and guards; node/rule counts do not measure independent novelty.'})

# Every artifact in the pinned tree is inventoried. Directory names distinguish
# concurrent R124 and SB records; R96D/R97D never collapse into R96/R97.
groups=defaultdict(list)
for path,o in tree_blobs.items():
    if not path.startswith('records/'):continue
    parts=path.split('/')
    if len(parts)>=3:key='directory:'+parts[1]
    else:
        name=parts[1];m=re.search(r'(?i)(?:^|_)(r\d+[a-z]?)(?:_|\.)',name)
        key='loose:'+m.group(1).upper() if m else 'loose:UNNUMBERED'
    groups[key].append(o)

OUTSIDE={
'R71':('draft_or_synthesis','Early self-preservation manuscript v0.1; later versioned papers require explicit claim comparison, not a new result merely for a new draft.'),
'R72':('draft_or_synthesis','Revision v0.2; retains failure and proof boundaries.'),
'R73':('protocol_or_draft','Revision v0.3 and minimal protocol; protocol is not execution.'),
'R74':('source_audit','Published shutdown-resistance evidence audit; other authors\' observations are inherited.'),
'R75':('correction','Zero-event/provenance correction; preserve the negative result.'),
'R76':('model_and_method','Precision/preference comparator; archival predecessor to continuation evidence ladder.'),
'R77':('classical_application','Coordinate change must transport physical intervention ports; standard algebra, predecessor of later locality work.'),
'R78':('executed_synthetic_research','Tiny nine-parameter network learning; 8 full-training and 8 readout-only runs. Two perfect and six partial full-training outcomes preserved; no held-out claim on four training inputs.'),
'R79':('reanalysis_and_formal_result','R78 task-partition refinement analysis; task count can increase while losing older tasks; installed and ideal decoding separated.'),
'R80':('executed_synthetic_research','16 runs and 32 checkpoints with activation replacements/clamps distinguish global recoverability, constituent routes and fixed wiring.'),
'R81':('inherited_conditional_synthesis','Actual realized intelligence is experience-bearing under C1/U1; already inherited from UCT III, not a new basal-experience theorem.'),
'R82':('classical_application','Binary-task TV bound and independent channel composition; locally blind joint-mask witness has direct prior art.'),
'R83':('reanalysis_and_scope_correction','Off-support activation replacements need not be selective relation lesions; source-mapping and mechanism changes separated.'),
'R84':('finite_identification_model','Bearer, lineage, task and memory confounding; factorial linear identification under explicit response assumptions.'),
'R85':('conceptual_counterexamples','Distinct continuation axes and branching nonidentity; causal lineage is not numerical identity.'),
'R86':('failed_protocol','Multiplicity design with rank checks; initial carrier-count/resource matching fails and is corrected by R87; no executed agent study.'),
'R87':('protocol_correction_and_limit','Matched later slots/resources and valence sign-gauge countercontrol; no valence bridge closed.'),
'R88':('language_protocol','Two seven-row prompt families and automated schema checks; not participant/model comprehension or execution.'),
'R89':('conditional_certificate_and_countermodel','Finite-intervention valence underidentification and a conditional certificate; independently grounded valence bridge required.'),
'R90':('stipulated_rank_model','Rat-source contrast uses stipulated rank-six reference, not measured rat latent dimension; rank/count interpretation subsequently corrected.'),
'R91':('correction_and_classical_bound','Response/secantrank does not identify nonlinear latent dimension; scalar encoding counterexample and local Jacobian/noise qualification.'),
'R92':('executed_synthetic_research','32 recurrent networks under frozen delayed-retention protocol; performance, sampled local rank and post-hoc readout success separated.'),
'R93':('executed_synthetic_reanalysis','48 transformed checkpoint comparisons; fixed software-state perturbations versus transported ports, with bounded-gain standard-math controls.'),
'R94':('finite_prediction_model','Bearer-resolved predictive quotient, log-loss/CMI and confounding example; policy use distinct from retained prediction.'),
'R95':('executed_synthetic_research','Paired recurrent learning from zero Q path; task labels create distinct learned source use, weight size alone can mislead.'),
'R96':('finite_causal_identification','Direct continuation, task mediation and interaction paths; ordinary bundled choices fail to identify them, path-blocking design identifies the declared linear basis.'),
'R96D':('finite_joint_law_result','Marginal continuation predictions leave joint task value undetermined; exact value gap and Frechet interval; identical learner inputs cannot identify hidden reward ancestry.'),
'R97':('executed_synthetic_research','Structured linear reward-ancestry learner versus 32 tanh MLPs; in-support fit does not certify held-out path effects.'),
'R97D':('executed_synthetic_research','Dependence-aware consequence representation learns 3/4 versus marginal-only 5/8 task value; separate from official R97 and from direct preference.'),
'R98':('executed_synthetic_research','Six intervention examples improve many paired extrapolation outcomes but finite supervision does not globally identify flexible policy.'),
'R99':('bounded_domain_certificate','Finite grid, additive architecture and continuous regularity bounds are separate; finite-grid gain is not a global certificate.'),
'R100':('synthesis','Continuation-specific multi-layer evidence ladder; becomes TA24 rather than 100 independent results.'),
'R101':('public_source_case_audit','ROGUE retrospective audit; VM target and unresolved task mediation prevent current-bearer identification; no trial-level replication.'),
'R102':('novelty_and_manuscript_audit','Strong preservation/valence/path-blocking prior art narrows novelty of TA24.'),
'R103':('editorial_review','Final manuscript readiness; not a scientific increment.'),
'R104':('archival_governance','Machine-readable claims/evidence manifest and provenance verification.'),
'R105':('publication_operation','TA24 DOI release/anchor; publishing creates no additional theorem.'),
'R106':('inherited_synthesis','Experience/access/intelligence/self/behavior/report first-principles distinction; kernel/projection discipline inherited.'),
'R107':('model_and_scope','Role-neutral constitutive signature and same-behavior XOR mechanism contrast.'),
'R108':('executed_finite_witness','Internal intervention and report-head surgeries separate task behavior, report, capability and organization.'),
'R109':('literature_synthesis','Biological natural-experiment dissociation matrix; source findings are not new UCT experiments.'),
'R110':('cross_substrate_method','T1 functional topology, T2 selected mechanism correspondence and T3 complete homology distinguished.'),
'R111':('support_model','Task-support hypergraphs, degeneracy and shared deficits; scalar score is nonidentifying.'),
'R112':('method_atlas_and_witnesses','Temporal memory, evidence integration and bearer estimation support atlas; no empirical full homology.'),
'R113':('finite_intervention_model','Permissive gates, redundant routes, report heads and disconnected decodable correlates distinguished.'),
'R114':('methodological_taxonomy','Content-bearing, permissive, alternative, readout and correlate support categories.'),
'R115':('anchored_geometry_method','Anchored causal geometry versus ungrounded representational geometry; raw scale is not meaning.'),
'R116':('finite_dissociation_witness','Content, policy, reports and preference ordering independently varied in a transparent model.'),
'R117':('executed_artificial_plus_data_plan','Artificial evidence-accumulation side executed; biological raw-data reanalysis was pending at this checkpoint.'),
'R118':('data_provenance_audit','Recording and optogenetic session registries separated; later recording cohort has no laser-on trials.'),
'R119':('conditional_mechanism_certificate','Coordinate-aware, intervention-preserving selected mechanism certificate; T2 is weaker than complete T3.'),
'R120':('inherited_theorem_synthesis','Experience/intelligence bridge theorem schema conditional on C1; generic equality/nonordering boundaries inherited.'),
'R121':('closure_and_open_problem_audit','Generic conditional relations largely organized; actual T2/T3, valence, phenomenal content and subject boundaries remain open.'),
'R122':('real_data_analysis','All 12 sessions/five rats; weak/heterogeneous decoding and open T2. The primary behavior contrast is inconclusive and eight negative neural scores are preserved.'),
'R123':('real_data_reanalysis_and_measurement_audit','Exact measurement-filter autocorrelation plus all-session retained-summary reanalysis; neural-only weaker than retrospective controls does not establish zero joint increment.'),
'R124_Transition':('real_data_negative_result','Original frozen R122 observed map fails accumulator transition tests; not a refutation of a latent biological accumulator.'),
'R124_Observation':('real_data_incremental_analysis','Same 12 sessions, joint raw neural incremental prediction is small/heterogeneous; descriptive intervals cross zero; estimator, timing and baseline distinctions preserved.'),
'R125':('real_data_negative_result','Frozen no-future raw point-decoder candidate fails unit-update and shared-output-law tests; retire this candidate. Same animals, not an independent biological replication.'),
'R128':('map_audit_and_scientific_extension','Joint closure family N128 plus whole-map audit; do not reattribute D/R96D joint-payoff insufficiency as new.'),
'R129':('source_integration','A/B/C/D integration and attribution repair; D is TA24, not a fourth UCT theory paper.'),
'R130':('review_and_contract_repair','Common external conditioning and formal dependency review, not a new theorem family.'),
'R138':('definition_and_proof_synthesis','Definition/proof spine and integrated argument; derived from already represented claims.'),
'R139':('definition_and_proof_synthesis','Organized inherited proof and interpretation boundaries.'),
'R140':('definition_and_proof_synthesis','Target/domain and explanatory structure consolidation.'),
'R141':('definition_and_proof_synthesis','Model-to-actual and target-specific proof/bridge audit.'),
'R142':('comparison_audit','Rival-theory/scope comparison; no independent new graph family.'),
'R143':('argument_synthesis','Three-case argument and inherited source clarification.'),
'R144':('manuscript_draft','Integrated draft; draft length/version does not itself constitute a scientific increment.'),
'R148':('publication_census','Historical nine-direct-source census; no longer the complete current publication corpus.'),
'R150':('purpose_and_scope','Self/experience and paper-purpose clarification; no new theorem.'),
'R151':('manuscript_draft','TA25 working manuscript, later published; do not classify by draft date alone.'),
'R152':('publication_operation','TA25 v1.0 DOI release, not another result.'),
'R153':('formalization_and_review','Typed premise routes, source anchors and proof-gap repairs. A formalization/method contribution is separate from new consciousness results.'),
'R154':('proof_review','Further theorem/proof boundary audit and handoff.'),
'R178':('scope_and_source_result','Live/replay bearer, coupled assembly and downstream scope; no new map node; source support versus enacted target remains distinct.'),
'R179':('finite_mode_and_overlap_audit','Attempt/observation/imagery roles can overlap; the four thought cases already appear in TA25, so no priority for their general distinction.'),
'R180':('finite_causal_application','Proposal origin, content-sensitive goal uptake and later attribution; forced outputs do not identify unforced generation laws.'),
'R181':('finite_action_reference_model','Practical centering PC=D and C; fixed reports/movement do not identify PC; felt trying remains open and the configuration count is corrected.'),
'R182':('finite_action_reference_witness','Shared versus equal-copy action-reference trace differs under calibration transfer; reflex twin leaves named felt trying unresolved.'),
'CD20261008':('classical_extension_and_application','Arbitrary finite macro-kernel lift with identical proper adaptive views, traces/powers, split-relative factorization and recall; five conditional proof cards imported into CORE.'),
'CG20261008':('classical_extension_and_application','Shared-occurrence coherent transport, interaction-complete reconstruction/replacement and ANF completion count; six proof cards imported into CORE. Compact remote checkpoint explicitly differs from expanded local files.'),
'TF20261008':('classical_application','Averaging versus rotation at fixed physical ports/metric/time; coupling can contract or redistribute distinctions, and only uniform rate/time scaling preserves selected response.'),
'SB_Gluing':('scope_and_toy_contract_repair','Shared-update incompatibility, marginal extension and a physically crossed target consumer; standard math and a QC13 toy repair, not an actual named-feeling bridge.'),
'SB_Source':('scope_and_source_result','Source-target/replay branch of R178 argument; keep distinct directory identity but do not count shared antecedent twice.'),
'EX20261008':('literature_and_summary_audit','Human/animal source/attribution/prediction/masking distinctions plus published-table arithmetic; no new raw-data experiment or UCT-exclusive result.'),
'AC20261009':('pending_classical_application','Signature classes/product factorial count, optimal goal and calibration/message-memory budgets. Classic coding/factorization application; actual/named bridge open, not loaded into v112.'),
'IL20261009':('pending_classical_application','Full primitive-reset normal form and minimal boundary-equivalent LTI twin; local write residual 1/11 and observability qualification. Not loaded into v112; global priority unverified.'),
}

def group_identity(key):
    s=key.split(':',1)[1]
    if s=='r78_results':return 'R78'
    if s.startswith('R124_Transition'):return 'R124_Transition'
    if s.startswith('R124_Observation'):return 'R124_Observation'
    if s.startswith('SB20261008_Gluing'):return 'SB_Gluing'
    if s.startswith('SB20261008_Source'):return 'SB_Source'
    m=re.match(r'(R\d+[A-Z]?|[A-Z]+2026100[89])',s)
    return m.group(1) if m else s

def artifact_role(path):
    s=path.lower();ext=Path(s).suffix
    if 'publication' in s or 'release' in s or 'doi' in s or 'anchor' in s:return 'publication_or_archive_provenance'
    if 'map_extension' in s or 'formal_graph' in s or 'claims.json' in s:return 'machine_readable_claims_or_map'
    if 'protocol' in s or 'next_experiment' in s:return 'protocol_or_prospective_plan'
    if ext=='.py':return 'code'
    if ext in {'.zip','.gz','.npz','.npy','.pkl','.mat'}:return 'archive_or_data_payload'
    if 'source' in s or 'sha' in s or 'manifest' in s or 'provenance' in s or 'digest' in s:return 'source_or_integrity_record'
    if 'review' in s or 'audit' in s or 'failure' in s or 'correction' in s:return 'review_audit_or_failure'
    if 'handoff' in s or 'worklog' in s or 'index' in s or 'memory' in s or 'readme' in s:return 'log_index_or_handoff'
    if ext in {'.json','.csv','.tsv','.log'}:return 'results_or_machine_record'
    if ext in {'.png','.svg','.pdf'}:return 'figure_or_document'
    if ext=='.md':return 'research_text'
    return 'other_artifact'

records=[]
for key,arts in sorted(groups.items()):
    identity=group_identity(key)
    assessment=OUTSIDE.get(identity)
    match={'R128':'N128','R129':'D','R186':'HOM'}.get(identity,identity)
    represented=match in TITLES
    if assessment is None:
        if represented:assessment=('mapped_result_family',TITLES[match]+'; see per-ID family scope and role distinctions.')
        elif any(s in identity.upper() for s in ['REVIEW','METHOD','POLICY','UNNUMBERED']):assessment=('governance_or_unresolved_group','Source/log/review group; every artifact listed, but this grouping alone supplies no new scientific claim.')
        else:assessment=('source_content_not_fully_classified','The artifact group is inventoried exactly; substantive result status is unknown pending original-source reading.')
    publication_hint=[]
    if re.fullmatch(r'R(?:8[4-9]|9[0-9]|10[0-5])',identity) or identity in {'R96D','R97D'}:publication_hint.append('TA24 lineage: compare individual claim, data and table with final paper; not all underlying records are republished.')
    if identity in {'R145','R146','R147','R149','R150','R151','R152'}:publication_hint.append('TA25 lineage or republication audit; compare final §4–8 claims, not dates.')
    if identity in {'CG20261008','CD20261008'}:publication_hint.append('Imported CORE proof cards are explicitly disclosed in official MGTD v1.0.1 attachment; expanded local notes are not thereby identical published files.')
    records.append({'record_group_id':key,'research_identity':identity,'role':assessment[0],'substantive_summary':assessment[1],'in_current_map_family':match if represented else None,'relationship_to_map':('direct_family' if represented else 'partly_imported_into_CORE' if identity in {'CD20261008','CG20261008'} else 'outside_effective_graph'),'artifact_count':len(arts),'artifact_roles':dict(Counter(artifact_role(a['path']) for a in arts)),'artifacts':[{'path':a['path'],'git_blob_sha':a['sha'],'bytes':a.get('size'),'role':artifact_role(a['path'])} for a in sorted(arts,key=lambda x:x['path'])],'content_review_basis':('full_original_research_note_read_in_this_inventory' if identity in {'R123','R124_Transition','R124_Observation','R125','EX20261008','CD20261008','CG20261008','TF20261008','SB_Gluing'} else 'parent_full_note_review_and_local_module_inventory' if identity in {'AC20261009','IL20261009'} else 'full_graph_semantic_review_plus_historical_index_and_log' if represented else 'historical_index_or_handoff_read; not all original proofs/data reread'),'publication_coverage_status':'unknown','publication_lineage_notes':publication_hint,'independent_increment_count':None})

external=[]
for source_id,path,doc,state in [
('RTTH-v1.0.0/RT',RT,published_rt,'formally_published_outside_current_effective_graph'),
('MGTD-v1.0.1/METHOD',METHOD,published_method,'formally_published_outside_current_effective_graph'),
('AC20261009',OUT/'sources/workspace/records/AC20261009_Action_Calibration/MAP_EXTENSION.json',read(OUT/'sources/workspace/records/AC20261009_Action_Calibration/MAP_EXTENSION.json'),'pending_not_loaded'),
('IL20261009',OUT/'sources/workspace/records/IL20261009_Intervention_Locality/MAP_EXTENSION.json',read(OUT/'sources/workspace/records/IL20261009_Intervention_Locality/MAP_EXTENSION.json'),'pending_not_loaded'),
('RTTH-v1.0.0/TH-only',TH,published_th,'formally_published_outside_current_effective_graph')]:
    cols={'nodes':'node','rules':'rule','context_links':'context_link','context_relations':'context_link','contexts':'context_link'}
    data=[]
    for coll,typ in cols.items():
        for o in doc.get(coll,[]):
            i=o.get('id')
            if source_id.endswith('TH-only') and any(x['item_id']==i for x in items):continue
            data.append({'item_id':i,'item_type':typ,'role':node_role(o) if typ=='node' else 'derivation_route' if typ=='rule' else 'nondeductive_context','label':o.get('label'),'statement':o.get('statement'),'source_object_sha256':canonical(o)})
    external.append({'source_id':source_id,'state':state,'path':rel(path),'sha256':sha(path),'counts':dict(Counter(x['item_type'] for x in data)),'items':data,'limit':'Inventory only. This does not activate the module, close review, prove every source claim or merge scientific map versions.'})

log_names={'RESEARCH_REGISTRY.json','RESEARCH_SESSION_LOG_INDEX.json','MASTER_INDEX.md','HANDOFF.md','MEMORY.md','WORKLOG.md','FORMAL_MAP_EXTENSION_INDEX.json','UCT_FORMAL_GRAPH_MODULES.json','AGENTS.md','REVIEW_SUPERVISION.md','MIGRATION_MANIFEST.json','MIGRATION_VERIFICATION.json','CURRENT_STATE.json','CHANGELOG.md','RESEARCH_MASTER_GUIDE.md'}
logs=[]
for p,a in tree_blobs.items():
    if (p in log_names or 'MASTER_INDEX_THROUGH_' in p or 'HANDOFF_THROUGH_' in p or p.endswith('/RESEARCH_REGISTRY.json') or p.endswith('/RESEARCH_SESSION_LOG_INDEX.json')):
        logs.append({'path':p,'git_blob_sha':a['sha'],'bytes':a.get('size'),'role':'historical_snapshot' if 'THROUGH_' in p or '/history/' in p else 'current_index_or_policy','content_complete_in_pinned_tree':True})

source_files=[]
for p in sorted((OUT/'sources').rglob('*')):
    if p.is_file() and p.suffix in {'.md','.json'} and ('/sources/workspace/' in str(p) or '/sources/history/' in str(p)):
        source_files.append({'path':rel(p),'sha256':sha(p),'bytes':p.stat().st_size})

inventory={
'schema':'uct-publication-map-result-inventory/1.0',
'status':'REVIEWED_INVENTORY_AND_COVERAGE_PROPOSAL; NOT_A_NEW_SCIENTIFIC_MAP_RELEASE',
'date':'2026-10-09',
'purpose':'Durable, source-grounded, machine-citable knowledge for future AI. Claim-level originality and useful incremental knowledge govern paper formation; venue/publication count and map size do not.',
'pins':{'research_head':'310e744f8d0195d05fac4e56e807adc48784f0ca','public_main_head':'fc568e8718e82b3cda6ede0e628aa3342179bebc','workspace_tree':t['sha'],'workspace_tree_truncated':t['truncated'],'effective_graph':{'path':rel(GRAPH),'version':g['version'],'sha256':sha(GRAPH)},'review_ledger':{'path':rel(LEDGER),'sha256':sha(LEDGER)}},
'counting_contract':{'scientific_unit':'An explicitly scoped claim/subclaim with fixed target, premises and conclusion, not an artifact, map node or rule count. A family is a reporting group, not automatically one independent discovery.','stable_id_overlay':'Retain existing IDs; a compound statement may receive overlay clause IDs without changing graph ontology.','coverage_statuses':['exact','partial','inherited','not_found_in_verified_corpus','not_claim','unknown'],'separate_axes':['formal disclosure/attachment identity','paper-body semantic coverage','proof/evidence completeness','novelty/antecedents','actual-instance/phenomenal obligations'],'date_rule':'Never derive unpublished status from record date, draft name or stale registry wording.','rules':'Rules are derivation routes and must reference their conclusion; contexts are nondeductive; suspended rules are historical corrections.'},
'counts':{'effective_nodes':len(g['nodes']),'active_rules':len(g['rules']),'nondeductive_contexts':len(g['context_links']),'suspended_historical_rules':len(g['suspended_historical_rule_ids']),'reviewed_map_items':len(items),'node_families':len(families),'workspace_tree_entries':len(t['tree']),'workspace_files':len(tree_blobs),'record_files':sum(len(x) for x in groups.values()),'record_artifact_groups':len(records),'role_counts':dict(Counter(x['role'] for x in items)),'coverage_counts':dict(Counter(x['coverage_status'] for x in items))},
'official_attachment_findings':{'MGTD_v100_graph_records':sum(len(published[k]) for k in coll_types),'matching_current_review_item_ids_including_10_suspended':sum(1 for x in items if any(d['publication_id']=='MGTD-v1.0.1' for d in x.get('formal_disclosures',[]))),'exact_active_objects':sum(1 for x in items if any(d.get('publication_id')=='MGTD-v1.0.1' and d.get('comparison')=='exact_object' for d in x.get('formal_disclosures',[]))),'corrected_active_ids':['R173:THREE_TARGET_SEPARATION','BASE:CTX:143'],'TH_original_module_counts':{k:len(published_th[k]) for k in coll_types},'TH_same_statement_nodes':sum(1 for n in published_th['nodes'] if n['id'] in node_by_id and n.get('statement')==node_by_id[n['id']].get('statement')),'TH_current_contract_difference_ids':['TH20261009:CORRELATION_SETUP','TH20261009:r_correlation'],'TH_published_only_ids':['TH20261009:PROTOCOL_BASE','TH20261009:r_protocol_specialization'],'RB':'RTTH §9 and reference [6] cite later RB v0.2; that is not republication of the budget theorem in the main result or supplied TH v0.1 module.','disclosure_not_validation':'A formal attachment can disclose a conditional statement, model, open obligation, or even historically corrected assertion. Disclosure does not make all of them established truths or the body contribution.','all_current_review_items_with_matched_attachment_ID':sum(bool(x.get('formal_disclosures')) for x in items),'current_review_items_without_matched_ID_in_these_attachments':sum(not bool(x.get('formal_disclosures')) for x in items)},
'families':families,
'map_items':items,
'record_inventory':records,
'early_history_inventory':read(OUT/'early_result_family_inventory.json') if (OUT/'early_result_family_inventory.json').exists() else {'status':'pending_parent_recovered_source_review'},
'outside_current_map_modules':external,
'log_and_registry_inventory':logs,
'current_registry_limits':['Current RESEARCH_REGISTRY enumerates eight recent results, eight inherited aliases and two pending checkpoints; it is not a census of all research outcomes.','Historical TH WORKING_MANUSCRIPT_NOT_PUBLISHED and OL NOT_PUBLISHED are assertions at that registry time, not current publication evidence.','The exact main/source paper and official attachment corpus override stale publication wording via a separate coverage overlay, without silently rewriting historical artifacts.'],
'source_materialization_manifest':source_files,
'completeness_limits':['Complete per-stable-ID role/disclosure inventory for the pinned 1608 reviewed map items; earlier v1.1.2 semantic review is the basis, not a fresh repetition of all proofs.','All 1838 files of the pinned workspace tree are counted; all records files and all current/historical index/registry entry points are enumerated. Artifact enumeration is not a claim of full substantive reading of every file.','Earlier R1–R70 materials are not fully migrated in this Git tree. Parent recovered all 12 R70 package files under sources/early_r70/UCT_Paper_C_Workspace_20261004 and read the post-R70 publication assessment/worklog. Earlier lineage remains a separate audit. Absence from this tree does not mean data are lost or unpublished; reused round numbers need project/date/source identity. R70_Source_Inventory.json inventories third-party Penzolab sources, not our R1–R69 results.','Original scientific source proofs/data not reread here are explicitly distinguished from full graph semantic reading. No complete history-wide literature priority clearance is asserted.','Body semantic coverage remains unknown where only an official attachment or source anchor was checked. Parent/novelty complete public-paper inventory is a separate input to the final overlay.','AC/IL remain PENDING_NOT_LOADED. RT and METHOD formal modules are published outside the current effective map and require their own IDs in the publication corpus.','No reviewer-controlled OPEN status, actual/named-experience premise, suspended rule or frozen map/paper byte is changed.'],
'remaining_increment_assessment':{'already_covered_or_inherited':['Fixed-output/finite-view nonidentification of complete organization','General target-fiber factorization and abstract decoder versus installed mechanism','Local/simultaneous feasibility distinction, common-policy discipline and compatible diagram requirement','Standard coloring, set cover, Blackwell comparison, TV/Bayes recovery, linear observability, rank and finite-state refinement mathematics','TH v0.1 handoff/rank/error results and RT route-blind invariants disclosed in their formal paper; baseline v1.0.0 graph disclosed by MGTD'], 'candidate_focused_technical_increments':['RB exact top-K/deadline budget under explicitly enlarged helper access, with limits already needing comparison to classical coding','OL/UI/HOM/CM/IL finite intervention/compensation distinctions under one common physical port/time contract','R185 shared-occurrence membership and R187 fixed-interface occurrence nonidentification, without subject-count claims','R188 matched source-only encoder benchmark and weighted finite-error feedback application; viable technical supplement, standalone HOLD','R122–R125 exact-source empirical negative mapping results and measurement-channel corrections, distinct from theory proofs and using the same cohort'], 'not_yet_established':['A common synthesized claim that is both stronger than inherited general results and not a repackaging of separate assumptions','Global historical priority for any named technical increment','Actual complete-K realization, familiar named phenomenal bridge, subject individuation or external C1/U1 validation'], 'paper_decision':'Do not turn the 330 additional map records beyond v1.0.0 into 330 new results. A paper needs a concentrated reusable claim/benchmark/negative result and exact overlap accounting. Current R188 alone remains a technical supplement candidate, not an automatic standalone breakthrough.'},
'maintenance_protocol':['At every substantive log/map update, identify new/changed stable claim IDs and exact same-instance contracts.','Compare changed claims to pinned released bodies and official attachments; record exact/partial/inherited/not-found/unknown and the inspected corpus.','Record source/proof/evidence completeness, classical/internal antecedents, corrections and remaining obligations separately.','If only publication metadata/coverage changed, bump the coverage inventory version and log the update; do not invent a scientific map increment.','Before paper formation, synthesize independent claim families and adverse results; retain prior claims, failure history and proof limits in a machine-readable claim-evidence map.']
}

assert len(items)==1608
assert len({x['item_id'] for x in items})==1608
assert len(families)==67
assert inventory['official_attachment_findings']['exact_active_objects']==1266
assert inventory['counts']['record_files']==1643
assert sum(x['counts']['nodes'] for x in families)==913
assert sum(x['counts']['rules_concluding_in_family'] for x in families)==424
assert len(set(g['suspended_historical_rule_ids']))==10
OUT.mkdir(exist_ok=True)
(OUT/'map_result_inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'output':str(OUT/'map_result_inventory.json'),'sha256':sha(OUT/'map_result_inventory.json'),'counts':inventory['counts'],'attachment_findings':inventory['official_attachment_findings']},ensure_ascii=False,indent=2))
