# R70 source and reading-scope ledger

Access/research date: 2026-10-05. This ledger distinguishes source retrieval, text search, close reading, and execution. No private credentials used.

## 1. Direct prior art

1. Rubenstein, P. K., et al. (2017), *Causal Consistency of Structural Equation Models*. https://arxiv.org/abs/1707.00819 ; submitted 2017-07-04, UAI 2017. Read official abstract and bibliographic metadata. Supports attribution of intervention-consistent exact transformation as prior art. Full paper proofs were not audited. R70's elementary conjugacy proof is provided independently.
2. Beckers, S., and Halpern, J. Y. (2019), *Abstracting Causal Models*. AAAI 33, 2678–2685. https://ojs.aaai.org/index.php/AAAI/article/view/4117 ; DOI https://doi.org/10.1609/aaai.v33i01.33012678 ; published 2019-07-17. Read official abstract and metadata. Supports prior existence of a hierarchy sensitive to intervention families; no claim that we reproduced its full definitions or proofs.

Novelty verdict: causal coordinate invariance and intervention-dependent abstraction are established topics. The present exact example and R69 correction are local research progress, not a newly discovered general principle. This was a targeted precedent audit, not an exhaustive literature review.

## 2. Biological source and actual code retrieval

3. Macdonald et al. (2026), *A synaptic mechanism for encoding the learned value of action-derived safety*. Nature Communications 17:4916, 2026-06-04. https://doi.org/10.1038/s41467-026-73906-3 . Article reading scope is inherited explicitly from R69: abstract, opening results, and publisher-indexed methods; not full supplementary-material review. In R70 we followed its code references. The biological paper already provides a direct precedent for learned safety value; this project does not claim that concept as original.
4. Penzolab repository: https://github.com/Penzolab/Data-analysis-of-Two-way-active-avoidance-task . Read-only checkout at commit `41e4ef6a53c8cce2a4f82639d365654027c50e5f`, repository commit date 2021-07-09. 38 tracked files inventoried and hashed. Complete uncompressed text searched, not wholly semantically audited. Read both `AA_behavior/readme.txt` and `AA_wSignal/readme.txt` fully; `Codes/AA_behavior/Rscripts/GetSummary_S5.R` fully; first 105 lines of `Codes/AA_wSignal/Rscripts/GetSummary_wSig_ZS_S5.R`. `Codes.rar` was not extracted and remains out of scope. No repository code executed on animal data or altered.
5. Zenodo code record: requesting https://zenodo.org/api/records/12707790 returned metadata with resolved record ID `12707791`. Title: `laxace33/Penzo-Lab-files-for-Ma-OMalley-et-al-2024: Penzo Lab - Ma OMalley et al Code`. Artifact: `laxace33/Penzo-Lab-files-for-Ma-OMalley-et-al-2024-Publication.zip`, 170237 bytes. Download endpoint: https://zenodo.org/api/records/12707791/files/laxace33/Penzo-Lab-files-for-Ma-OMalley-et-al-2024-Publication.zip/content . SHA256 `69be3c897b748d56141b8780c7b764b236b934c2024191e5b0c7f1073cce63c2`. Extracted 38 files inventoried and hashed. It is a code artifact labeled 2024, not established as the 2026 paper's complete fitted-model source.

Search pattern in both snapshots: `rescorla|wagner|cmdstan|softmax|learning.?rate|bootstrap|bayesian|safety.?value|\balpha\b|\bbeta\b` (case-insensitive). Notebook code cells included; notebook outputs excluded. Both snapshots had zero files matching this pattern. This negative search is not proof of absence of all learning-related calculations, of files hidden in the opaque archive, or of code elsewhere. All actual paths, sizes, hashes and scope labels are in `R70_Source_Inventory.json`.

Read all code cells of `Codes/Whole_Trial_Photometry/Whole Trial GCaMP.ipynb` in the Zenodo snapshot. It separately fits auto-channel coefficients (a,b) and GCaMP coefficients (c,d). An initial plot uses c,d. A later reconstruction uses `a*x + d`. This is inconsistent with independent GCaMP detrending unless an additional shared-slope rationale is supplied. R70 tests only that algebraic consequence using ideal synthetic linear traces. It does not determine intended analysis, trace figure provenance, or change any empirical paper conclusion.

The distinct data record https://zenodo.org/records/20031828 was located in R69 (472.6 MB package). It was not downloaded or analyzed in R70. Supplementary fitting code and parameter recovery remain unchecked. No model reproduction claim is warranted.

## 3. Access failures and recovery

Browser-style web retrieval of the GitHub and Zenodo code pages failed. Read-only command-line git and public API/archive retrieval succeeded without authentication. No login, CAPTCHA, or agreement was operated. A secondary OSCR search result was used only to locate references; its no-README claim was contradicted by the actual subdirectory readmes and is not used as evidence. No source archive or repository is represented as wholly reviewed.

## 4. UCT interface and continuity sources

- Canonical master `UCT_Agent_Consciousness_Research_Master_20261004.md`, ID `libfile_f43117ce64388191af6439c0d719fc50`, version 38, read fully before the round. Latest identified records were R69 note, worklog, source ledger, results. No later completed round was identified at start.
- UCT I v1.2, DOI https://doi.org/10.5281/zenodo.23131575 : reviewed source copy, §3.5 reread closely this round. Its port-aware signature is an existing requirement, not introduced by R70. C1/completeness and §§5.5–5.6 audit carried forward from R69.
- UCT II v1.1, DOI https://doi.org/10.5281/zenodo.23030320 : reviewed source copy, BAC-1 through BAC-7 reread this round; BAC-5 directly governs the covariance issue.
- UCT III v1.0, DOI https://doi.org/10.5281/zenodo.23137088 , ID `libfile_d77b37ead30c81919b03538d3373009b`: §2 check inherited from R69; no claim of a fresh whole-paper read this round.

No published text was modified. Research-note labels, exact toy arithmetic, and keyword matches are not independent empirical support for C1 or a fear bridge.
