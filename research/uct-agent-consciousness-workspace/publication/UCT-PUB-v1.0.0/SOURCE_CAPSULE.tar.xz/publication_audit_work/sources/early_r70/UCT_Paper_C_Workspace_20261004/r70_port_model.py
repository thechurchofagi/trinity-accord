"""Executable register/port audit, not a trained model or experience measure."""
from dataclasses import dataclass, asdict
from fractions import Fraction as Q
from pathlib import Path
import json

@dataclass
class VG:
    v: Q
    g: Q
    def step(self, r=Q(1), alpha=Q(1,2)):
        rho=1-alpha
        nv=rho*self.v+alpha*r
        if nv<=0: raise ValueError('positive-state comparison domain required')
        self.g=1-rho*(1-self.g)*self.v/nv
        self.v=nv
    def write_v(self, value):
        if value<=0: raise ValueError('v must be positive')
        self.v=value
    def write_g(self, value): self.g=value
    def score(self,d=Q(1,2),c=Q(1,4)): return self.g*self.v*d-c
    def transform(self): return US(self.g*self.v,self.v)

@dataclass
class US:
    u: Q
    s: Q
    def step(self,r=Q(1),alpha=Q(1,2)):
        rho=1-alpha
        self.u=rho*self.u+alpha*r
        self.s=rho*self.s+alpha*r
    def physical_write_v(self,value):
        if self.s<=0 or value<=0: raise ValueError('positive-state domain required')
        self.u=self.u*value/self.s
        self.s=value
    def physical_write_g(self,value): self.u=value*self.s
    def score(self,d=Q(1,2),c=Q(1,4)): return self.u*d-c

def row(a,b):
    assert a.transform()==b
    assert a.score()==b.score()
    return dict(vg=asdict(a),us=asdict(b),score=a.score())

traces=[]
operations=[('step',None),('write_v',Q(2,3)),('step',None),
            ('write_g',Q(1)),('step',None)]
a=VG(Q(3,4),Q(1,3));b=a.transform()
traces.append(dict(operation='initial',**row(a,b)))
for op,x in operations:
    if op=='step': a.step();b.step()
    elif op=='write_v': a.write_v(x);b.physical_write_v(x)
    else: a.write_g(x);b.physical_write_g(x)
    traces.append(dict(operation=op,argument=x,**row(a,b)))

# The same physical operation, not the same variable name, must be translated.
actual=US(Q(1,4),Q(3,4));actual.physical_write_v(Q(3,4))
naive=US(Q(3,4),Q(3,4)) # INCORRECT substitution u <- control v
assert actual.score()==Q(-1,8) and naive.score()==Q(1,8)

# Collapsing to u preserves nominal dynamics but loses the g-write operation.
p=VG(Q(3,4),Q(1,3));q=VG(Q(1,4),Q(1))
assert p.score()==q.score()
p.write_g(Q(1));q.write_g(Q(1))
assert p.score()!=q.score()
hidden_witness=dict(after_g_write=[p.score(),q.score()])

# Independent constant writes commute in either correct coordinate system.
a=VG(Q(3,4),Q(1,3));a.write_v(Q(2,3));a.write_g(Q(1,2))
b=VG(Q(3,4),Q(1,3));b.write_g(Q(1,2));b.write_v(Q(2,3))
assert a==b
c=US(Q(1,4),Q(3,4));c.physical_write_v(Q(2,3));c.physical_write_g(Q(1,2))
e=US(Q(1,4),Q(3,4));e.physical_write_g(Q(1,2));e.physical_write_v(Q(2,3))
assert c==e==a.transform()

# Writing only a register at a given instant is not dynamic independence.
p=VG(Q(3,4),Q(1,3));q=VG(Q(3,4),Q(1,3));q.write_v(Q(1,2))
assert p.g==q.g
p.step();q.step()
assert p.g!=q.g
dynamic_coupling=dict(g_without_v_write=p.g,g_with_v_write=q.g)

# Independent check of a code inconsistency in the inspected photometry file.
# Separately fitted trends: auto=a*x+b0; GCaMP=c*x+d0. File reuses a for GCaMP.
aa,cc,dd=Q(1),Q(2),Q(10)
artifact=[dict(x=x,as_written_dff=100*(cc-aa)*x/dd,
               separately_detrended_dff=Q(0)) for x in range(1,4)]
assert [r['as_written_dff'] for r in artifact]==[Q(10),Q(20),Q(30)]

checks={
 'correct_coordinate_and_port_translation_preserves_all_trace_outputs':True,
 'naive_value_name_substitution_creates_false_rescue':True,
 'nominal_one_state_reduction_fails_with_gain_write_port':True,
 'independent_constant_writes_commute_under_correct_translation':True,
 'instantaneous_write_selectivity_does_not_imply_dynamic_autonomy':True,
 'inspected_trend_formula_can_create_a_ramp_in_a_no_event_input':True,
}
out=dict(scope='exact formal implementation checks and synthetic code diagnostic only',
         checks=checks,trace=traces,false_rescue=dict(correct=actual.score(),naive=naive.score()),
         hidden_state_witness=hidden_witness,dynamic_coupling=dynamic_coupling,
         photometry_diagnostic=artifact,
         limitations=['no trained model, subjective or neural measurements',
         'no claim that the inspected notebook produced published figures',
         'port meanings require independent implementation grounding'])
Path(__file__).with_name('R70_Results.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
for k in checks: print('PASS',k)
print('6 summary checks; 5-operation state trace; no empirical consciousness experiment.')
