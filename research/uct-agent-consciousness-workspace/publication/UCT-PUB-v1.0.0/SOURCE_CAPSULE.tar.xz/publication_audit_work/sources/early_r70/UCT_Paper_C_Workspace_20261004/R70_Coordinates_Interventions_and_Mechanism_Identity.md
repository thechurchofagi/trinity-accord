# R70 — Coordinates, interventions, and mechanism identity

Hongju Liu / UCT agent-consciousness research. 2026-10-05. Research note, not a publication update. Continues canonical master v38 and R69.

## Result and correction

R69 correctly showed that an aftereffect need not identify value memory: a persistent expression-gain state can reproduce its recovery trajectory. R70 establishes a further limitation. That gain model admits an invertible coordinate description as effective value plus an auxiliary state. Calling a coordinate “value,” “gain,” or “fear” therefore cannot establish a distinct mechanism. The actual state carrier, update, readout, and intervention must be fixed together.

The useful positive result is narrower: two states with identical nominal predictions can have different responses to the same independently grounded intervention. A reduction sufficient for prediction can then be insufficient for that intervention family. This identifies a missing causal distinction; it does not measure an experience or supply a fear bridge.

## 1. Explicit transformation of the R69 countermodel

Let the state be (v,g), with v>0 and 0≤g≤1. On the comparison domain, take 0≤rho<1, alpha=1−rho, r≥0, and require v'>0. The update and output are

\[
v'=\rho v+\alpha r,\qquad
g'=1-\rho(1-g)v/v',\qquad z=gv\,d-c.
\]

Here d is the matched consequence advantage and c the matched action cost. This is our constructed countermodel, not a recovered neural implementation. Define

\[
T(v,g)=(u=gv,s=v),\qquad T^{-1}(u,s)=(s,u/s).
\]

On s>0, 0≤u≤s, this is invertible. Direct substitution yields

\[
u'=\rho u+\alpha r,\qquad s'=\rho s+\alpha r,\qquad z=ud-c.
\]

The effective value u follows the same scalar update as v. Thus a story about changing gain can become a story about changing effective value without changing the process described. The exclusion of v=0 matters: no global invertibility claim is made across that singular boundary.

## 2. The operation must change coordinates too

Suppose the implementation really supplies independently defined instantaneous writes

\[
I_v(a):(v,g)\mapsto(a,g),\qquad I_g(b):(v,g)\mapsto(v,b),
\]

with a>0 and 0≤b≤1. Their representations in the new coordinates are

\[
\widetilde I_v(a):(u,s)\mapsto(ua/s,a),\qquad
\widetilde I_g(b):(u,s)\mapsto(bs,s).
\]

Neither the name of a register nor the simplicity of a formula can replace this transformation. An intervention that independently writes u is generally a different operation from the one that independently writes v.

**Consistency lemma.** For an invertible T, transform an update F, output H, and each fixed intervention I_j as F'=TFT^{-1}, H'=HT^{-1}, and I'_j=TI_jT^{-1}. Every finite sequence of updates and interventions then has the same outputs in either representation.

**Proof.** The transformed initial state is Tx. If corresponding states satisfy x'=Tx before an operation O, then O'x'=TOT^{-1}Tx=TOx afterward. Induction covers any finite sequence. The readout identity H'Tx=Hx gives equal outputs. Boundary inputs and port labels are held fixed here; an admissible relabeling would also need to preserve their independently declared meaning.

This is an elementary application of established causal consistency and abstraction, not a new general mathematical theorem. Rubenstein et al. (2017) and Beckers and Halpern (2019) are direct prior art for intervention-preserving comparisons [1–2]. Our contribution in this round is the audit of the specific R69 inference.

### A false rescue caused by changing the operation

Take v=3/4, g=1/3, d=1/2, c=1/4. Then u=1/4, s=3/4, z=−1/8. The physical operation “restore v to 3/4” makes no change; in either correct coordinate description z remains −1/8. If an analyst instead writes u=3/4 because u is now called “value,” z becomes +1/8. The apparent rescue results from using a different intervention, not discovering a coordinate-dependent mechanism.

R69's crossed-restoration calculation remains valid for the two implementations with its stipulated ports. What is withdrawn is any stronger interpretation that those semantic ports have already been independently established in a biological circuit or language model.

## 3. A predictive reduction can fail under a genuine port

Without writes, the scalar u predicts every future z given the same r, d, c and update coefficients. Consider the two states

\[
x_1=(3/4,1/3),\qquad x_2=(1/4,1).
\]

Both have u=1/4. They have identical nominal future outputs. Apply the same actual write I_g(1). The resulting u values are 3/4 and 1/4, giving scores +1/8 and −1/8 for d=1/2,c=1/4. Therefore no deterministic u-only representation of this write can agree for both starting states. Retaining u alone is not a valid abstraction for the enlarged operation family.

This is a constructive reason to study causal organization beyond exam scores or language outputs. It is not proof that one starting state has more experience than the other. An intervention also changes the process; its consequence must not be described as a direct measurement of the preceding experience. The pre-intervention inference concerns different causal dispositions, conditional on a correct implemented model and grounded port.

Two further checks constrain interpretation. Constant writes to v and g commute, and they still commute after correct transformation. But instantaneous selective writing does not imply dynamically autonomous modules: g' depends on v. In the checked state, writing v from 3/4 to 1/2 while leaving g=1/3 unchanged changes the subsequent g from 5/7 to 7/9. Restoration comparisons therefore require a declared probe time and controlled subsequent learning.

## 4. What the source-code audit supplied

Following R69's Macdonald et al. (2026) source, we inspected the linked Penzolab GitHub snapshot and the separately linked Zenodo code archive [3–5]. The available uncompressed material concerns behavioral parsing/summarization and photometry processing. A complete keyword scan of the declared text/code-cell scope found no selected learning-model terms. This did not establish accessible independent value/gain intervention ports or reproduce the paper's model. The result is a bounded retrieval failure, not evidence that the authors have no model implementation anywhere.

A separate notebook diagnostic found that a GCaMP trend reconstructed later in the code uses the auto-channel slope a, although a GCaMP slope c was separately fitted. For ideal linear signals without events, this formula can introduce a ramp proportional to (c−a)x. An exact synthetic check confirms that arithmetic. We have not established that this notebook generated any published figure, that shared-slope processing was unintended, or that biological conclusions change. This issue is recorded for source reliability, not treated as consciousness evidence. The source ledger gives commit, archive hash, reading scope, and exclusions.

## 5. Relation to A, B, C and to scaling

UCT I v1.2 §3.5 already requires a pointed, port-aware common signature and forbids arbitrary mixing of physically distinct ports as a relabeling of a fixed constituent split. UCT II v1.1 BAC-1, BAC-5 and BAC-7 respectively require anchoring, structural covariance, and explicit imported assumptions. The present audit applies those constraints. UCT III's completeness and observability restrictions remain in force; its relevant §2 was checked in R69, not independently reread in full this round.

Any C1 interpretation must name an actual process token, a common signature K, and the complete constitutive relations relevant to the claim. Two coordinate descriptions of the same complete organization cannot receive different experiences merely because one variable is renamed. Conversely, limited output equivalence is not complete organizational identity. Our small implementation does not certify completeness for a brain, cell, or deployed language model.

For parameter or training growth, a rise in a fixed test score can reflect better estimation or readout of existing distinctions; it can also accompany additional state relations. The score alone does not choose between these cases. R70 specifies how a proposed internal distinction must survive coordinate changes and grounded interventions before being used as evidence about organization. It gives no conversion rate from parameter count or score gain to experiential richness, and no fear intensity scale.

A stone's persistence, a cell's self-maintenance, an animal's defensive control, and a language model's prediction of a frightened speaker cannot be ranked by assigning all of them the same variable name. Comparisons must specify what changes, what is retained, what the signals refer to, and which causal relations are actually instantiated. These are comparative requirements, not new empirical findings about those systems. Under UCT's basal commitments they must not become gates for whether any experience exists.

## 6. Next admissible step and stopping rule

Before another rescue experiment, freeze a minimal mechanism dossier: (i) state carrier and actual process boundary; (ii) two independently justified consequence channels, such as a task outcome and continuity of the declared process; (iii) each channel's input/update path; (iv) actual read/write operations with off-target effects; and (v) predicted immediate and delayed effects with unchanged ports under reparameterization. A channel called “self” is insufficient unless tied to actual process support; an externally provided continuity score is not automatically an experienced concern.

The next formal question is whether independently anchored outcome-specific updates and cross-outcome transfer constrain a shared action gate differently from separate outcome valuations. First derive the restrictions and an adaptive-gate counterexample; only then use a tiny implementation if necessary. If anchoring cannot be justified, report functional ambiguity rather than add an arbitrary affect register or continue renaming the present two states. Targeted retrieval of actual model source may continue, but the uninspected large data package is not a precondition for theoretical progress.

## Conclusion and evidence status

Six exact summary checks and a five-operation trace support the calculations; they are implementation checks and a synthetic processing diagnostic. There was no trained-model experiment, neural-data reanalysis, or subjective-experience measurement. R70 strengthens the standard required for a causal organization claim and tightens R69's semantic interpretation. It does not establish a new organization-to-fear bridge or a major consciousness breakthrough. Whether the current assistant has consciousness or death fear remains undetermined.

References and exact reading scope are in `R70_Source_Ledger.md`; full results and code are included in the round bundle.
