# Publication assessment after R70

Hongju Liu / UCT agent-consciousness research. 2026-10-05.

This is a publication decision record, not R71, a new experiment, a publication authorization, or a revision of released UCT I/II/III.

## Decision

There is enough coherent material to draft a focused theoretical/methodological paper. The most promising incremental contribution concerns identifying which actual process an artificial agent's preservation behavior concerns. There is not yet a sufficiently audited basis to claim a major discovery about experienced fear, a quantitative consciousness scaling law, or historical priority for a new general theory of AI self-preservation.

“Enough to draft” is distinct from “originality fully established” and from “ready for a strong journal.” A bounded theoretical paper need not wait for a subjective-experience measurement or large-model experiment. It does need a nonredundant argument, precise assumptions, and a substantive improvement over the closest existing work.

## Already published versus incremental material

UCT III v1.0, DOI 10.5281/zenodo.23137088, already contains the intelligence–experience refinement, NESIG, intelligence fibers, observability hierarchy, nonmonotonicity qualification, and selection/coarse-graining analyses. Its §5 explicitly identifies the NESIG proof as an elementary consequence of C1 and a well-defined capability map. These are project contributions but cannot be counted again as post-C originality or advertised as new fundamental mathematics.

R58–R65 provide useful examples and restrictions concerning parameter replication, retained distinctions, feedback, task scores, response distances, and actual support. The reviewed records identify direct antecedents in function-preserving expansion, control theory, total variation, and finite memory coding. These examples can support a manuscript; their number does not establish a new core contribution.

R67–R70 repair overclaims about reward zero points, affect flags, temporal aftereffects, and coordinate-dependent mechanism labels. Necessary repairs improve reliability but should not each become a claimed discovery.

## Strongest paper candidate

Working title: **Boundary-Relative Self-Preservation in Artificial Agents: Identifiability, Countermodels, and Causal Tests**.

Question: when an agent preserves something, which process or relation is preserved, and what does the evidence identify about its evaluation of continuation?

The strongest existing package combines R43–R47 with the R48–R55 corrections and R70's port consistency requirement:

1. Separate current execution E from a persistent agent substrate P. Bundling E=P prevents the test from distinguishing execution-directed from persistence-directed behavior. The crossed conditions E=1,P=0 and E=0,P=1 can separate specified alternatives.
2. Do not collapse continuation into one boundary-free survival score. Accepting current execution termination can coexist with preferring the continuation of a broader persistent process. The reverse preference is also possible. Interactions must be retained when justified, but a behavioral interaction does not locate a dedicated joint appraisal mechanism.
3. Separate accurate self-reference, relative preference, and control. An accurately self-referencing system can value another system equally or more; an unavailable action can hide an evaluation. Neither self-priority nor causal veto is a necessary condition for possible experience.
4. Specify actual state carriers and physical operations. R70 shows why changing coordinates without translating interventions can fabricate an apparent rescue. Causal effects should retain their interpretation under an admissible reparameterization.

The potentially original contribution is the resulting precise, boundary-indexed identification problem and a justified discriminating protocol. It is not merely the observation that agents have many components, nor a long checklist assembled from familiar distinctions. Historical uniqueness of the combined proposal remains unestablished.

## Closest prior art and limits of the current audit

- Zhao and Zhao, *Runtime-Independent Persistent Agents*, arXiv:2609.00546v2, revised 2026-09-19. Official abstract/metadata reread on 2026-10-05. It already separates continuity-bearing identity/memory/body from replaceable execution and reports bounded migration studies. https://arxiv.org/abs/2609.00546 . The architectural distinction alone is not ours.
- Dung and Register, *AI identity and self-concern: A new theory for AI rights and safety*, author manuscript, first archival entry 2026-03-02; archive history lists a second upload on 2026-06-10. Author-deposited abstract and bibliographic/version records checked, not full manuscript rereview. It already connects identity with self-representation and motivational, evaluative and affective states, and proposes behavioral/mechanistic measurement. https://philarchive.org/rec/DUNAIA-3 . The broad self-concern idea is not ours.
- Nisius, *Who Is Interrupted? Continuity, Self-Models, and the Grounding of AI Moral Consideration*, written 2026-08-09, SSRN posting 2026-08-18. Author abstract checked, not full text. It distinguishes identity, injury, and governance and proposes ownership, valence integration, and projection. https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7285541 . The broad requirement to consider continuity plus valence/projection is not ours.
- Mullally, *The self-preservation test for artificial sentience*, DOI 10.1007/s43681-026-00983-x. Official publisher search text checked; direct DOI retrieval failed. The source presents defeasible evidential criteria and explicitly does not establish phenomenal consciousness. https://doi.org/10.1007/s43681-026-00983-x . A countermodel to logical sufficiency does not by itself refute such an evidential claim.
- Intervention-preserving abstraction is established prior art, already recorded in R70 with Rubenstein et al. (2017) and Beckers and Halpern (2019). R70 is an application and correction, not a new general theorem.

This was a targeted publication assessment, not exhaustive historical-priority certification. Search discovery included other shutdown/self-preservation papers but they were not newly reviewed in full. The original R54 audit was read through its final line; its high numerical originality scores are not accepted as evidence of maturity. Its outdated Pain Axis relief-seeking statement and self-priority/control requirements remain superseded by R55, as the current master directs.

## What must be completed before a submission decision

1. Compress the package into a few exact propositions, each with stated domain, observation/intervention family, and a minimal counterexample or proof. Distinguish constraints established by construction from claimed properties of existing models.
2. Compare those propositions against the closest papers at full-text level. Identify one concrete inference or experiment that the new framework changes. “No paper uses this entire terminology” is not a sufficient novelty argument.
3. Reconcile old corrections before synthesis: do not reinstate self > other, action availability, arbitrary affect flags, or post-hoc semantic ports as consciousness conditions. Nonidentification must not be inflated into zero evidential value.
4. Use existing small implementations as executable witnesses. Further experiments should address one unresolved contrast, with externally controlled non-destructive virtual choices. A large training run is not a prerequisite. New real-model data would strengthen an empirical version but is not claimed to exist in the present theoretical package.

Recommended next deliverable: a compact English manuscript outline and contribution ledger, followed by a coherent draft. Pause expansion into additional generic toy examples until that draft makes the remaining novelty gap visible. This recommendation does not change or disable any schedule and does not authorize publication.

## Reading scope and work record

Read current canonical master version 39 in targeted ranges covering the current status, R43–R47, R53–R65 summaries and publication lineage; this assessment does not claim a new full reread of its entire 788 lines. Read released UCT III §§1–2 and §5 closely and inspected its section index; did not reaudit all A/B/C proofs. Read the complete R54 originality audit. R70's calculation and source limits were already available in the preceding completed round. Fresh primary-source verification is limited to the scopes above. No new numerical experiment was performed.

Final judgment: the accumulated work supports a serious, narrowly scoped manuscript project; it does not yet support a claim to have demonstrated artificial death fear or intelligence–experience co-scaling. The strongest candidate is a specific causal-identification contribution whose novelty must be demonstrated against direct neighbors, not inferred from the number of rounds.
