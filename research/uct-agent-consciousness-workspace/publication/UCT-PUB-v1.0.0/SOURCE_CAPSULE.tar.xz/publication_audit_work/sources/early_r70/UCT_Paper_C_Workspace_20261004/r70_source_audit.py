"""Read-only inventory of the retrieved primary source code snapshots."""
import sys,json,hashlib,re,subprocess
from pathlib import Path
repo,archive=map(Path,sys.argv[1:3])
terms=re.compile(r'rescorla|wagner|cmdstan|softmax|learning.?rate|bootstrap|bayesian|safety.?value|\balpha\b|\bbeta\b',re.I)
def scan(root,paths):
 out=[]
 for p in paths:
  if not p.is_file(): continue
  b=p.read_bytes();kind=p.suffix.lower()
  item=dict(path=str(p.relative_to(root)),size=len(b),sha256=hashlib.sha256(b).hexdigest())
  if kind=='.rar': item['scope']='opaque archive not extracted'
  else:
   text=b.decode('utf-8',errors='replace')
   if kind=='.ipynb':
    nb=json.loads(text)
    text='\n'.join(''.join(c['source']) for c in nb['cells'] if c.get('cell_type')=='code')
    item['scope']='all code cells searched; outputs excluded'
   else:item['scope']='entire text searched, not a full semantic audit'
   item['model_term_matches']=[dict(line=i,text=t[:180]) for i,t in enumerate(text.splitlines(),1) if terms.search(t)]
  out.append(item)
 return out
files=subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines()
root=next(p for p in archive.iterdir() if p.is_dir())
data=dict(access_date='2026-10-05',github=dict(url='https://github.com/Penzolab/Data-analysis-of-Two-way-active-avoidance-task',
 commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
 files=scan(repo,[repo/p for p in files])),
 zenodo=dict(requested_record='12707790',resolved_record='12707791',
 archive_sha256=hashlib.sha256((archive/'source.zip').read_bytes()).hexdigest(),
 archive_bytes=(archive/'source.zip').stat().st_size,
 files=scan(root,sorted(root.rglob('*')))),
 manually_read=['both repository readme.txt files','AA_behavior/Rscripts/GetSummary_S5.R full',
 'AA_wSignal/Rscripts/GetSummary_wSig_ZS_S5.R first105 lines',
 'Whole_Trial_Photometry/Whole Trial GCaMP.ipynb all code cells'],
 conclusion='No advertised RW/Stan fit implementation located in the searched text. This is not proof that no fitting code exists elsewhere.',
 execution='Source code inspected, not executed. RAR and 472.6MB data archive not inspected.')
Path(__file__).with_name('R70_Source_Inventory.json').write_text(json.dumps(data,indent=2)+'\n')
for key in ['github','zenodo']:
 f=data[key]['files'];print(key,len(f),'files;',sum(bool(x.get('model_term_matches')) for x in f),'files with model-term hits')
