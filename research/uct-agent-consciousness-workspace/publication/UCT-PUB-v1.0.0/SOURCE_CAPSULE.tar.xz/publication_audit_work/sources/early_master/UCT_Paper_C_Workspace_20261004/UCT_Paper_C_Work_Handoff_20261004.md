# UCT Paper C / UCT III — Complete Work Handoff

**Date:** 2026-10-04  
**Status:** active research handoff for continuation in ChatGPT Work mode  
**Publication status of Paper C:** **NOT PUBLISHED / NO DOI / DO NOT RELEASE YET**  
**Primary next action:** obtain the authorized COGITATE Experiment 2 fMRI **BIDS Sample (~12 GB)** and run the preregistered Residual Structure Test pipeline.

---

# 0. One-paragraph mission

The current project asks how **experiential organization**, **intelligence**, and **evolutionary change** relate under Unified Consciousness Theory (UCT). The broad idea that “evolution makes consciousness more complex” is not original enough and is also scientifically too crude. The strongest current direction is instead:

> **Experience is identified by UCT I with complete token-relative physical organization, whereas intelligence is a task/environment-relative functional or observation of that organization. Therefore intelligence generally underidentifies experiential organization. Evolutionary changes in intelligence necessarily imply some experiential structural change under C1, but do not imply monotonic increase on a scalar consciousness-complexity axis.**

The empirical program now tests whether organization features not exhausted by task competence and GNWT-inspired access proxies still improve prediction of a finite psychophysical target (Seen/Unseen) in COGITATE Experiment 2.

---

# 1. Published UCT foundation that MUST remain fixed

## 1.1 UCT I / Paper A — published v1.2

**Title:** *Unified Consciousness Theory I: Structural–Experiential Identity and the Continuity from Physical Process to Conceptual Self*  
**Report:** TA-TR-2026-20  
**Version:** 1.2  
**DOI:** **10.5281/zenodo.23131575**  
**Concept DOI:** **10.5281/zenodo.23005587**  
**Previous v1.1 DOI:** **10.5281/zenodo.23030207**  
**Previous v1.0 DOI:** **10.5281/zenodo.23005588**

Publication verification already completed:
- 13 public files;
- exact-byte public readback PASS;
- DOI resolution PASS;
- v1.1 public inventory unchanged;
- do not overwrite prior versions.

### UCT I v1.2 core

Domain:
\[
P\in\mathcal P
\]
where \(\mathcal P\) is the domain of actual valid physical process tokens.

Core consciousness-specific commitment:
\[
\boxed{
C1:\quad
D^{ontic}_{\mathcal K}(P)
\cong
\Phi_{\mathcal K}(P)
}
\]

Interpretation:
- the complete token-relative physical organization and intrinsic experiential organization are the same structure under the declared common signature;
- the isomorphism is the formal expression;
- metaphysical identity is a substantive commitment and is not empirically proven by finite experiments.

Derived results:
- **U1 Universal Nonempty Experience**
- **U2 Structural Continuity transfer**
- **U3 Selfhood Non-Prerequisite**
- **E1 No First Conscious Ancestor**
- **E2 Fine-Grained Structural Chains**
- **E3 Connected Existence Constancy** — independent conditional mathematics

Process ontology:
- **P3** persistence / cessation / embedding
- **P6** token / type / lineage

Critical distinction:
\[
\boxed{
\text{experience existence}
\neq
\text{experience organization}
\neq
\text{report/access/self-model}
}
\]

No universal subject selector or scalar consciousness ladder is assumed.

---

# 2. UCT II / Paper B — published v1.1

**Title:** *Unified Consciousness Theory II: Consciousness Theories as Effective Organization Theories*  
**Report:** TA-TR-2026-21  
**Version:** 1.1  
**DOI:** **10.5281/zenodo.23030320**

Paper B does NOT define the ontology. It supplies the **organization-mechanism translation layer**.

Finite physical view:
\[
D^{PA}_v(P)=\Pi_v[D^{ontic}(P)]
\]

Theory-specific translator:
\[
O_T=\mathcal T_T(D^{PA}_v(P),B_T)
\]

Main conceptual role:
- reconstruct/embed/reinterpret/conflict-test mechanisms from IIT, RPT, GNWT, HOT, predictive processing/active inference, DIT, memory theories, AST, TTC;
- separate mechanistic recovery from ontological endorsement and empirical confirmation;
- preserve Bridge Admissibility Conditions (BAC), Translation Fidelity Requirement (TFR), formal F0–F4 classes, empirical V0–V4 classes.

## 2.1 Required dependency migration before future Paper-B v1.2 release

Paper B v1.1 terminology should eventually migrate:

| Paper B v1.1 dependency | UCT I v1.2 replacement |
|---|---|
| A1 Universal Experience | U1 Universal Nonempty Experience |
| A3 Persistence Under Embedding | P3 |
| A5-SI | C1 |
| A5-OI | C1-OI |
| A5-W | C1-W |

Important:
- this is a dependency/interface update;
- do **not** recompute B's toy-model numerical results merely because labels migrate;
- do not add Paper-C theory into B;
- B v1.2 can be a narrow linked revision later.

---

# 3. Paper C research history and why the focus changed

## R1 — Evolutionary experiential complexity
Initial candidate themes:
- selection transfer;
- intelligence vs experience;
- experiential evolvability;
- multidimensional complexity frontier;
- sensory differentiation.

Problem: major parts were already close to prior art.

## R2 — Intelligence fibers / identifiability
Formalized:
- intelligence as a lossy task-relative functional;
- Intelligence Separation Criterion;
- constant-rank local fibers;
- no monotonic intelligence→experiential-complexity theorem;
- modal-evolvability slippage correction.

## R3 — Observability architecture
Added:
- full observation family \(O=(J,M,R_{\mathcal I},\ldots)\);
- nested fibers;
- observability gain;
- intelligence-mediated selection-null directions.

## R4 — Competitor discrimination
Strongest current formal signature discovered:

\[
\boxed{
\Delta I\neq0
\Rightarrow
\Delta\Phi_{\text{type}}\neq0
}
\]

under a fixed intelligence evaluation and comparable actual valid tokens.

This was named:

## NESIG — No Experientially Silent Intelligence Gain

It means:
> if the actual token's intelligence genuinely changes under the same declared evaluation, the complete experiential structural type cannot remain identical.

It does **not** mean:
- more intelligent = more conscious;
- higher intelligence = greater scalar phenomenal richness;
- reportability must increase;
- global access must increase;
- self-awareness must increase.

---

# 4. Current strongest theorem package

## 4.1 IC-1 — Intelligence–Experience Refinement Asymmetry

Let:
\[
J:\mathfrak S_{\mathcal K}\to\mathcal Y
\]
be a fixed intelligence profile on structural-type space.

Under C1:
\[
s\sim_\Phi s'
\iff
s=s'
\]

while:
\[
s\sim_J s'
\iff
J(s)=J(s')
\]

Therefore:
\[
\boxed{
\sim_\Phi\subseteq\sim_J
}
\]

and:
\[
\boxed{
J(s)\neq J(s')
\Rightarrow
\Phi(s)\not\cong\Phi(s')
}
\]

but generally:
\[
J(s)=J(s')
\not\Rightarrow
\Phi(s)\cong\Phi(s')
\]

unless \(J\) is injective.

---

## 4.2 O1 — Experiential Identifiability Criterion

A declared observation family \(A\) identifies complete experiential type on a domain iff:
\[
\boxed{
A
\text{ is injective on that domain.}
}
\]

This is standard identifiability mathematics with a UCT-specific interpretation.

Do not claim invention of injectivity/observability theory.

---

## 4.3 O2 — Coordinate Factorization Criterion

For an experiential structural coordinate:
\[
C:\mathfrak S\to Z
\]

\(C\) is fully determined by observations \(A\) iff \(C\) is constant on every \(A\)-fiber, equivalently:
\[
\boxed{
C=\bar C\circ A.
}
\]

This allows different consciousness dimensions to have different relations to intelligence.

---

## 4.4 O3 — Local Intelligence-Fiber Dimension

For a smooth local structural chart \(U\) of dimension \(n\):
\[
J:U\to\mathbb R^m
\]

with constant rank \(r<n\):
\[
\boxed{
\dim J^{-1}(J(s))=n-r>0.
}
\]

Interpretation:
there are locally distinct structural/experiential directions invisible to the declared intelligence profile.

Again: standard constant-rank theorem, UCT-specific interpretation.

---

## 4.5 O4/O5 — Observation refinement

Add Paper-B mechanism coordinates \(M\) and intervention-response coordinates \(R\):

\[
\boxed{
\mathcal F_{J,M,R}
\subseteq
\mathcal F_{J,M}
\subseteq
\mathcal F_J.
}
\]

Local rank gains:
\[
G_M=
\operatorname{rank}D(J,M)
-
\operatorname{rank}DJ
\]

\[
G_R=
\operatorname{rank}D(J,M,R)
-
\operatorname{rank}D(J,M)
\]

These are **observability gains**, not consciousness amounts.

---

## 4.6 E1 — Intelligence-Mediated Selection-Null Theorem

If a fitness component depends only on intelligence:
\[
w_I(x)=F(J(x))
\]

and:
\[
v\in\ker DJ_x,
\]

then:
\[
\boxed{
D_vw_I=0.
}
\]

Interpretation:
selection acting solely through the declared intelligence profile cannot, to first order, distinguish structural/experiential changes along intelligence-null directions.

These directions can still be selected by:
- energetic cost;
- sensory ecology;
- robustness;
- mating;
- developmental constraints;
- pleiotropy;
- drift;
- other organismal functions.

This is the cleanest explanation of why intelligence and experiential organization can co-evolve without being identical.

---

## 4.7 Negative theorem — no monotonic intelligence→phenomenal-complexity law from C1 alone

UCT does NOT entail:
\[
I_1>I_0
\Rightarrow
C_\Phi(s_1)>C_\Phi(s_0)
\]

for any scalar \(C_\Phi\) unless an additional monotonicity/alignment bridge is supplied.

Likewise:
\[
C_\Phi\uparrow
\not\Rightarrow
I\uparrow.
\]

---

## 4.8 Modal evolvability correction

Do NOT claim that UCT I v1.2 alone maps every merely possible descendant physical organization to a possible experiential organization.

C1 in v1.2 quantifies over **actual valid tokens**.

Safe theorem:
\[
\boxed{
\mathcal R_D^{act}(A,H)
=
\mathcal R_\Phi^{act}(A,H)
}
\]

for actually realized descendant repertoire.

Potential/modal evolvability requires an explicit extra premise:
\[
C1^\Diamond
\]
which is stronger than published v1.2 and must not be smuggled in.

---

# 5. Current originality boundary

## Do NOT claim originality for:
- consciousness becoming richer through evolution;
- multidimensional consciousness;
- "intelligence is not consciousness";
- same behavior / same input-output with different causal structure;
- output-null neural dimensions;
- fibers/null spaces/rank/observability;
- Price-equation selection transfer;
- right-tail/left-wall complexity reasoning;
- architecture changing cognitive evolvability;
- new sensory discrimination giving richer phenomenal discernment.

## Important prior-art pressure already identified:
- IIT 4.0 — "Being is not doing";
- Doerig et al. unfolding argument;
- Usher responses / unfolding limitations;
- Kleiner & Hoel substitution arguments;
- Kaufman et al. output-null neural subspaces;
- Birch/Schnell/Clayton multidimensional animal consciousness;
- Dung/Newen multidimensional consciousness framework;
- Barron/Halina/Klein cognitive transitions;
- Phenomenal Interface Theory — conscious-experience evolvability;
- Edelman — evolutionary phenomenal discernment;
- Williams — Price-equation qualia selection;
- Gignac — access consciousness as intelligence-like capacity;
- Fleming/Shea — intelligence/consciousness may be more interwoven than sharp separations suggest.

## Current defensible contribution

The strongest candidate package is the integration:

\[
\boxed{
\text{UCT-I complete structural/experiential type}
+
\text{UCT-II mechanism observation layer}
+
\text{Paper-C intelligence/intervention observation hierarchy}
+
\text{NESIG}
+
\text{selection-null directions}
+
\text{competitor residual-structure tests}
}
\]

Estimated publication potential before real-data analysis:
**about 8/10**, but direct empirical discrimination is still the weakest point.

---

# 6. Competitor discrimination logic

## 6.1 IIT
IIT already allows same input-output behavior with different internal causal/phenomenal structure.

UCT-specific contrast:
- IIT applies maximality/exclusion/irreducibility;
- UCT assigns nonempty experience to every actual valid process token;
- overlapping/reducible/nonselected processes can remain experiential in UCT.

Do not caricature IIT.

## 6.2 GNWT
GNWT can treat local processing as nonconscious until global ignition/access.

UCT predicts:
- local actual process already has nonempty experience;
- if local task intelligence changes, that local token's experiential structural type changes even if global access does not.

## 6.3 HOT
HOT can leave first-order processing unconscious without an appropriate higher-order relation.

UCT:
- first-order actual process already experiential;
- first-order intelligence change changes first-order experiential organization.

## 6.4 PIT
PIT already treats a phenomenal interface as evolutionarily expandable.

UCT difference:
- PIT-like interface is a higher-order organization phenotype, not the basal existence condition for experience.

## 6.5 SRT
Broad evolutionary experiential-complexity story is close.

Do not assert a stronger contradiction unless SRT's sufficient descriptor is explicitly reconstructed from source.

## 6.6 Williams
Treat as adjacent formal prior art, not primary competitor.

## 6.7 Gignac
Access-consciousness capacity can be included in \(J\) or Paper-B \(M\).

UCT only rejects the stronger inference:
\[
\text{access/intelligence profile}
\Rightarrow
\text{complete experiential type}
\]
unless the map is injective.

---

# 7. CT-1 — General sufficient-descriptor contrast

If competitor \(T\) claims complete phenomenal type is determined by:
\[
C_T:\mathfrak S\to Z_T
\]

with:
\[
\Phi_T=H_T\circ C_T,
\]

and \(C_T\) is non-injective, then there can exist:
\[
s\neq s',
\qquad
C_T(s)=C_T(s').
\]

Competitor:
\[
\Phi_T(s)=\Phi_T(s')
\]

while UCT C1-OI:
\[
\boxed{
\Phi_{\rm UCT}(s)\not\cong\Phi_{\rm UCT}(s').
}
\]

Boundary:
\(C_T\) must faithfully include everything the competitor actually treats as phenomenal-content determining. Follow Paper B's TFR.

---

# 8. R5 empirical program — PRIMARY NEXT WORK

## 8.1 Dataset

### COGITATE Experiment 2 fMRI BIDS

Official public analysis repository:
`Cogitate-consortium/cogitate-msp2`

Official repository states the fMRI pipeline includes:
- behavioral/event extraction;
- fMRIPrep preprocessing;
- activation;
- gPPI;
- FIR;
- decoding;
- RSA;
- seen/unseen searchlight;
- category/location decoding.

Official demo documentation identifies a **four-subject sample**:
- CC102
- CC202
- CD101
- CD199

The data bundle page has listed:
- Exp 2 fMRI BIDS Sample: approximately **12 GB**
- full Exp 2 fMRI BIDS: approximately **292 GB**
- access via COGITATE Data User agreement/account.

Important:
the GitHub repository contains **analysis code**, not the actual BIDS sample data.

---

# 9. Work-mode instructions for data acquisition

## Goal

Download the **COGITATE Experiment 2 fMRI BIDS Sample (~12 GB)**.

## Required workflow

1. Use ChatGPT Work / Cloud Browser.
2. Open the COGITATE official site:
   `https://www.arc-cogitate.com/`
3. Navigate to the Data User / data bundle page.
4. Select **Experiment 2 fMRI BIDS Sample**, not the full ~292 GB dataset.
5. When the website requests:
   - username;
   - password;
   - one-time code;
   - consent/account authorization;

   **STOP browser automation and hand the login form to the user.**

6. The user must enter credentials directly in the browser.
7. Do **not** ask the user to paste the password into chat.
8. Do **not** copy, record, summarize, or expose credentials.
9. After login/authorization succeeds, resume and download the sample.
10. Save the downloaded archive and record:
    - filename;
    - size;
    - any official checksum if supplied;
    - download timestamp;
    - extraction directory.
11. Extract the bundle.
12. Confirm expected BIDS structure and the four sample subjects if they are still the sample release:
    - `participants.tsv`
    - `sub-CC102/`
    - `sub-CC202/`
    - `sub-CD101/`
    - `sub-CD199/`
13. Do not start the full ~292 GB download unless explicitly instructed.

## If the login/download flow changes

Do not improvise credentials.
If authentication fails:
- capture the non-secret error message;
- stop before repeated destructive/redundant attempts;
- report the exact blocker.

---

# 10. Primary Paper-C Residual Structure Test

The current empirical question is:

> After conditioning on task competence and a preregistered GNWT-inspired access feature family, does residual neural organization still improve held-out prediction of a finite visibility/awareness target?

## 10.1 Bridge target

\[
\Psi=\text{Seen / Unseen report}
\]

Use only physically present face/object stimulus trials for the primary test.

This is a **finite psychophysical bridge target**, not "experience itself."

---

## 10.2 Task-competence family

Call it:
\[
J_{\rm task}
\]

Do **not** call one trial-level score "general intelligence."

Primary behavioral features:
- `performance`
- `difficulty`
- preregistered rolling performance history if available

Controls:
- category
- location
- run
- site
- subject grouping
- trial order/world if required

---

## 10.3 GNWT-inspired access family

\[
A_{\rm GNW}
\]

Use only preregistered features derived from official GNW-oriented ROIs / access-related summaries.

Official COGITATE code contains GNW ROI lists including:
- anterior/mid cingulate;
- inferior frontal;
- middle frontal;
- superior frontal;
- related frontal regions.

Important wording:
call them **GNWT-inspired finite proxies**, not "the full GNWT state."

---

## 10.4 Residual organization family

\[
R
\]

Predeclare a small feature set outside \(J\) and the chosen GNW/access family.

Candidates:
- posterior/IIT-oriented category decodability;
- posterior location decodability;
- FFA/LOC representation strength;
- EVC V1/V2 response;
- FFA/LOC ↔ EVC gPPI;
- posterior representational geometry.

Do not choose features post hoc after seeing the target result.

---

# 11. Nested models

Primary:

\[
M_0:
\quad
\Psi\sim J+\text{controls}
\]

\[
M_1:
\quad
\Psi\sim J+A_{\rm GNW}+\text{controls}
\]

\[
M_2:
\quad
\Psi\sim J+A_{\rm GNW}+R+\text{controls}
\]

Primary held-out statistic:
\[
\Delta LL_R
=
LL(M_1)-LL(M_2)
\]

positive means adding residual organization improves prediction.

Secondary:
- ROC-AUC
- balanced accuracy
- calibration

Primary operational null:
\[
H_0:
I(\Psi;R\mid J,A_{\rm GNW})=0
\]

Alternative:
\[
H_1:
I(\Psi;R\mid J,A_{\rm GNW})>0
\]

Permutation:
shuffle residual-feature rows **jointly within subject**.

---

# 12. Required sensitivity analyses

1. **Physical-input restriction**  
   Prefer physically matched face/object conditions.

2. **Seen/unseen balancing**  
   Match/subsample within subject, category, location.

3. **Performance/difficulty matching**  
   Use stratification or nearest-neighbor matching.

4. **Replay sensitivity**  
   Do not pool VG/Replay blindly.

5. **Residual-family freeze**  
   Freeze primary feature family before full-cohort analysis.

6. **Site generalization**  
   If sample size allows, train on one site and test another.

7. **Negative results must be preserved.**

---

# 13. Interpretation rules

A positive \(M_2>M_1\) result supports:

> the chosen residual physical organization contains held-out information about the finite seen/unseen bridge target beyond task competence and the chosen GNWT/access proxies.

It does **NOT** by itself:
- prove C1;
- prove UCT true;
- refute full GNWT;
- refute full HOT;
- prove historical priority.

To claim a direct competitor failure, the competitor descriptor must first be shown under TFR to be fidelity-complete for the tested claim.

---

# 14. Synthetic software validation already completed

The residual-test pipeline was coded and tested end to end on synthetic grouped data.

Synthetic validation:
- subjects: 12
- trials: 1440

Held-out results:

### J only
- log loss ≈ **0.67564**
- AUC ≈ **0.60299**

### J + GNW
- log loss ≈ **0.63357**
- AUC ≈ **0.69478**

### J + GNW + residual
- log loss ≈ **0.61485**
- AUC ≈ **0.71672**

Residual log-loss improvement:
\[
\approx 0.01872
\]

This is **software validation only**, not scientific evidence.

---

# 15. Script contract

Current analysis script:

`uctiii_cogitate_exp2_residual_structure_test.py`

Expected trial-level CSV columns:

Required:
- `subject`
- `seen`
- `performance`
- `difficulty`

Optional controls by prefix:
- `category_*`
- `location_*`
- `site_*`
- `run_*`

GNW/access features:
- prefix `gnw_`

Residual organization:
- prefix `resid_`

Example execution:

```bash
python uctiii_cogitate_exp2_residual_structure_test.py \
  --input trial_features.csv \
  --output results.json \
  --n-permutations 1000
```

The script performs:
- grouped cross-validation by subject;
- logistic regression with scaling;
- nested J / J+GNW / J+GNW+R models;
- held-out log loss;
- balanced accuracy;
- AUC;
- within-subject residual-feature permutation.

---

# 16. IMPORTANT sample/full-cohort distinction

The ~12 GB sample has only about four subjects according to the current official demo documentation.

Therefore sample analysis can establish:
- data plumbing;
- variable correctness;
- trial extraction;
- feature construction;
- leakage checks;
- software behavior;
- rough effect direction.

It is **not** sufficient for strong publication-level population inference.

Do not overclaim a four-subject sample result.

Full-cohort analysis should occur only after:
- sample pipeline is stable;
- feature family is frozen;
- no obvious leakage;
- analysis plan is locked.

---

# 17. Useful fallback dataset

If COGITATE access becomes impossible, a secondary option is the Stein et al. 2021 visibility/fMRI dataset described during the R5 research.

Why useful:
- objective face/house discrimination;
- subjective visible/invisible report;
- fMRI category representation;
- trial-level dissociation of objective performance and visibility.

Use as fallback / secondary validation, not silently substitute it for COGITATE without documenting the change.

---

# 18. Current research artifact inventory

The following files were generated in this project.

## Research architecture
- `UCT_Paper_C_Research_Architecture_R1_20261004.md`

## Formal R2
- `UCT_Paper_C_Formal_Research_R2_20261004.md`
- `UCT_Paper_C_R2_Countermodels_20261004.json`

## Observability / originality R3
- `UCT_Paper_C_Originality_and_Observability_R3_20261004.md`
- `UCT_Paper_C_R3_Theorem_Ledger_20261004.json`

## Competitor discrimination R4
- `UCT_Paper_C_R4_Competitor_Discrimination_20261004.md`
- `UCT_Paper_C_R4_Competitor_Discrimination_Audit.json`

## Empirical R5
- `UCT_Paper_C_R5_COGITATE_Exp2_Preregistered_Analysis_Plan_20261004.md`
- `uctiii_cogitate_exp2_residual_structure_test.py`
- `UCT_Paper_C_R5_synthetic_trial_features.csv`
- `UCT_Paper_C_R5_pipeline_synthetic_test.json`

This handoff is intended to be the single starting file for Work mode.

---

# 19. Work-mode execution checklist after download

Once the 12 GB bundle is downloaded:

## Phase 1 — inventory only
1. record archive filename and size;
2. extract;
3. save full top-level tree;
4. read `participants.tsv`;
5. count BOLD files;
6. locate events TSVs;
7. locate fMRIPrep derivatives if included;
8. locate any ready-made beta-series/ROI outputs;
9. do not launch multi-day preprocessing before confirming what is already included.

## Phase 2 — check whether preprocessing is necessary
The official MSP2 repo says downstream FEAT/decoding assumes fMRIPrep.

Before rerunning:
- verify whether sample bundle already contains `derivatives/fmriprep`;
- verify existing derivatives;
- use existing prepared data if valid.

Avoid unnecessary 1–2-day/subject recomputation.

## Phase 3 — construct trial table
Build one row per valid stimulus/probe trial with:
- subject;
- stimulus identity/category/location;
- seen/unseen response;
- task performance;
- difficulty;
- run/world/trial;
- site;
- GNW proxy features;
- residual posterior features.

Write:
`trial_features_v1.csv`

Also write a data dictionary:
`trial_features_v1_dictionary.md`

## Phase 4 — freeze primary feature families
Before looking at the main residual-test outcome, save:
`UCTIII_R5_FEATURE_FREEZE.json`

It must list:
- exact J features;
- exact GNW features;
- exact residual features;
- transformations;
- exclusions;
- primary metric;
- permutation scheme.

## Phase 5 — run pipeline
Run:
```bash
python uctiii_cogitate_exp2_residual_structure_test.py \
  --input trial_features_v1.csv \
  --output UCTIII_R5_sample_results.json \
  --n-permutations 1000
```

## Phase 6 — audit
Check:
- no subject leakage;
- no target leakage;
- no same-trial label encoded in a feature;
- fold-by-fold performance;
- stability under matching;
- stability to one-subject-out sensitivity;
- class balance.

## Phase 7 — interpret conservatively
Classify result as one of:
- **pipeline only**
- **weak exploratory support**
- **sample-level stable signal**
- **negative/null**
- **inconclusive**

Do not use "validated UCT" wording.

---

# 20. No-publication boundary

Paper C is **not ready for DOI publication yet**.

Do not:
- publish Zenodo;
- generate a Paper-C DOI;
- submit OTS;
- archive to Arweave;
- create a formal release;
- claim empirical validation.

The next publication decision should occur only after:
1. real sample analysis;
2. theorem re-audit;
3. competitor-discrimination review;
4. final originality search;
5. author review.

---

# 21. Recommended next decision after sample result

If residual organization adds stable held-out predictive information:
- proceed to full-cohort preregistered analysis;
- freeze all primary features first;
- strengthen competitor-specific interpretation only after TFR audit.

If no residual signal:
- preserve the negative result;
- do not tune until success;
- examine whether the feature family failed observability or whether the theory prediction was too strong;
- Paper C may still remain a formal theory paper.

If results reverse across sites/subjects:
- treat as instability, not as success.

---

# 22. Short instruction to the next Work-mode agent

> Continue UCT Paper C from this handoff. First obtain the authorized COGITATE Experiment 2 fMRI BIDS Sample (~12 GB) using the official COGITATE Data User workflow. Pause whenever login credentials or verification codes are required and let the user enter them directly; never request or record passwords in chat. After download, inventory the sample before launching preprocessing. Use the existing preregistered R5 plan and `uctiii_cogitate_exp2_residual_structure_test.py`. Build a trial-level table with task competence \(J\), GNWT-inspired access proxies, residual posterior/sensory organization features, and Seen/Unseen as a finite psychophysical target. Freeze the primary feature family before examining the main outcome. Run subject-grouped held-out models M0/M1/M2 and within-subject residual permutation. Preserve null results. Do not publish Paper C or claim C1 validation.

---

# 23. One-sentence scientific checkpoint

\[
\boxed{
\textbf{Paper C now asks not "does intelligence equal consciousness?" but "which dimensions of complete experiential organization are identifiable and evolutionarily selected through intelligence, and which remain outside the intelligence observation fiber?"}
}
\]

That is the current research frontier.
