# UCT Paper C Workspace Manifest

**Workspace:** `/UCT_Paper_C_Workspace_20261004`  
**Start here:** `UCT_Paper_C_Work_Handoff_20261004.md`  
**Paper C status:** research in progress; no DOI/public release authorized.

| File | Bytes | SHA256 | Role |
|---|---:|---|---|
| `UCT_Paper_C_Formal_Research_R2_20261004.md` | 21787 | `c2fb056ec6548c7eed4fe7584f8bf2d657647ec253a4f8be302a24b5b7a5b7a4` | R2 theorem and countermodel audit |
| `UCT_Paper_C_Originality_and_Observability_R3_20261004.md` | 21872 | `d3c32e743f4c39ba0e080a24f8f642a48e030a118f289ad8d7568dde5e3c7c31` | R3 observability/originality audit |
| `UCT_Paper_C_R2_Countermodels_20261004.json` | 1972 | `4ccb6ca2a1f501c9e71ccbafb508d451b1cc6d2a4f53ae4c7596ddd91b2c63b6` | R2 executable countermodel results |
| `UCT_Paper_C_R3_Theorem_Ledger_20261004.json` | 2180 | `56cb6dd68f5edbb72506d0f5664af57372c9bdbb8cee71bc1c35c76776b17241` | R3 theorem ledger / numeric audit |
| `UCT_Paper_C_R4_Competitor_Discrimination_20261004.md` | 20580 | `0349120c7532a7d9c2606d55156a88b667efcb4502f7ba5a4f54dcee363837fe` | R4 competitor discrimination audit |
| `UCT_Paper_C_R4_Competitor_Discrimination_Audit.json` | 669 | `3958d830c0bea5f22a4bcf762f16cb57f682ab402bd52abadac3344d8b53bc99` | R4 formal discriminator audit |
| `UCT_Paper_C_R5_COGITATE_Exp2_Preregistered_Analysis_Plan_20261004.md` | 7755 | `e7265baa3a7d60d35b4d6e6e619eafb90f97fc4704fbebc2c3218e9cea00def2` | R5 preregistered COGITATE analysis plan |
| `UCT_Paper_C_R5_pipeline_synthetic_test.json` | 398 | `94d416bf748057387732a9812723f41e9926e7c3de079e24cbccabfa473bea67` | R5 synthetic pipeline validation result |
| `UCT_Paper_C_R5_synthetic_trial_features.csv` | 130484 | `630db1f2fbedb247dfb960a89542c34fa93603ca8ec12f8ba91669e47f03849c` | R5 synthetic pipeline input |
| `UCT_Paper_C_Research_Architecture_R1_20261004.md` | 13149 | `04988e2b88cc5b959eef53135237c7b8707d702c67c975ce4f3e65c71ba163bc` | R1 research architecture / originality framing |
| `UCT_Paper_C_Work_Handoff_20261004.md` | 27270 | `33503e86694a1a6bf48d87552201e00f55f81356720b4d0878bc6f384fd723fa` | complete Work-mode handoff / start here |
| `uctiii_cogitate_exp2_residual_structure_test.py` | 7097 | `4a9c7ece9cf90c9a8ff68b2000c90983fef8700fedb1aee522838bb0f7f316fa` | R5 residual structure test analysis code |

## Work-mode rule

Read the handoff first, then continue with authorized COGITATE Experiment 2 fMRI BIDS sample acquisition. Pause for user-entered login/password/verification. Do not request or record credentials. Inventory the downloaded sample before starting long preprocessing. Preserve null/negative results and do not publish Paper C without a new explicit author release decision.
