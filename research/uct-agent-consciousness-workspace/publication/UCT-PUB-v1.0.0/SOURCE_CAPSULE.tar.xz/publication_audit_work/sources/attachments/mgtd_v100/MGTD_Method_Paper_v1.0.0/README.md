# Map-Guided Theory Development — supplementary package

**Research ID:** METHOD20261008. **Manuscript:** MGTD-PAPER-v1.0.0.
**Author:** Hongju Liu. **Status:** complete manuscript prepared for author review, not peer reviewed or DOI-registered.

Read `MGTD_Method_Paper_v1.0.0.pdf` or the editable `manuscript.md`. `manuscript.tex` is the generated mathematical typesetting source. See `README_ZH.md` for a Chinese introduction.

## Reproduce the checks

Requires Python 3.10 or newer; standard library only. From this directory:

```sh
python code/reference_checks.py --output rerun_results --backup evidence
```

The exact archived ledger and effective graph in `evidence/` support a retrospective count/field check only. The original UCT semantic audit is not independently rerun or certified here. `results/fixtures.json` records every authored fixture. `results/results.json` contains the execution outcomes and limits. No network calls or API credentials are required.

The small checker trusts declared source contracts and compares string bindings. It is not a natural-language semantic verifier or an automatic discovery system. The finite frontier function requires positive, acyclic rules and a fixed environment. Cycles, uncertain physical bridges, and empirical truth are outside the guarantee. Twelve deliberately designed invalid fixtures and twelve benign controls are not a held-out benchmark.

## Build the PDF

Run `bash build_pdf.sh` with Pandoc, XeLaTeX and standard TeX packages installed. The PDF uses Latin Modern Roman and Latin Modern Mono when available. No font binaries are distributed.

## Identity and preservation

`CURRENT_STATE.json` selects the completed manuscript. `RELEASE.json` lists exact method IDs, results, open obligations and version limits. `method_map/` contains an explicitly bounded index and per-item author-side review of the method paper. `LITERATURE_REVIEW.json` records comparison scope and source access. `MANIFEST.json` records package-file hashes except itself and separate operational receipts. The external ZIP SHA-256 is stored outside the ZIP.

Do not advance or overwrite UCT-MAP-v1.0.0 because this paper is completed. It is only the case-study version. Create MGTD-PAPER-v1.0.1 or another explicitly incremented method-paper version for the next substantive completion. No publication automation is implied by this package.
