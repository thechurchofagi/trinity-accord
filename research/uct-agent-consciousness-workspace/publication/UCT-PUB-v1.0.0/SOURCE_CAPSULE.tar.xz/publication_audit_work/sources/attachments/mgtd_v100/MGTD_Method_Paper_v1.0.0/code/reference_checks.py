#!/usr/bin/env python3
"""MGTD 1.0.0 reference checks. Python standard library only.

Executable contract tests for a deliberately restricted research-map model.
NOT a natural-language semantic judge, general theorem prover, or efficacy study.
Run from any directory: python code/reference_checks.py --output results
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path
from typing import Any


def digest(value: Any) -> str:
    data = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
    return hashlib.sha256(data).hexdigest()


def fixture() -> dict[str, Any]:
    nodes = [
        {"id": "A", "status": "assumed", "binding": "system-A:t0:micro:S1", "definition": "D1", "definition_version": "1"},
        {"id": "B", "status": "assumed", "binding": "system-A:t0:micro:S1", "definition": "D1", "definition_version": "1"},
        {"id": "Q", "status": "conditional", "binding": "system-A:t0:micro:S1", "definition": "D1", "definition_version": "1"},
    ]
    contract = {"premises": ["A", "B"], "conclusion": "Q", "binding": "system-A:t0:micro:S1", "mode": "all"}
    return {
        "nodes": nodes, "rules": [{"id": "R1", "premises": ["A", "B"], "conclusion": "Q", "binding": contract["binding"],
            "mode": "all", "relation": "deduction", "execution": True, "active": True,
            "contract_id": "C1", "source_hash": digest(contract)}],
        "contracts": {"C1": contract}, "definitions": {"D1": "1"},
        "required_ids": ["A", "B", "Q", "R1"], "reviewed_ids": ["A", "B", "Q", "R1"],
        "version": "1.0.1", "parent_version": "1.0.0", "content_changed": True,
        "validated_applications": [], "context_exports": [], "joint_constraints": [],
    }


def structural_errors(g: dict[str, Any]) -> list[str]:
    errs: list[str] = []
    ids = [n["id"] for n in g["nodes"]] + [r["id"] for r in g["rules"]]
    if len(ids) != len(set(ids)):
        errs.append("duplicate-id")
    ns = {n["id"] for n in g["nodes"]}
    for r in g["rules"]:
        if not set(r["premises"] + [r["conclusion"]]) <= ns:
            errs.append("unresolved-reference")
    return sorted(set(errs))


def finite_satisfiable(constraints: list[dict[str, Any]]) -> bool:
    """Tiny propositional fragment: positive literal, negative literal, NAND."""
    variables = sorted({x for c in constraints for x in c["args"]})
    if len(variables) > 16:
        raise ValueError("Finite checker supports at most 16 variables; no guess is returned.")
    for bits in itertools.product((False, True), repeat=len(variables)):
        a = dict(zip(variables, bits))
        ok = True
        for c in constraints:
            vals = [a[x] for x in c["args"]]
            if c["op"] == "pos": result = vals[0]
            elif c["op"] == "neg": result = not vals[0]
            elif c["op"] == "nand": result = not all(vals)
            else: raise ValueError("Unsupported finite constraint")
            ok = ok and result
        if ok:
            return True
    return False


def full_errors(g: dict[str, Any]) -> list[str]:
    errs = structural_errors(g)
    if errs: return errs
    ns = {n["id"]: n for n in g["nodes"]}
    for n in ns.values():
        if g["definitions"].get(n["definition"]) != n["definition_version"]:
            errs.append("stale-definition-use")
        if n["status"] == "empirically_validated" and n["id"] not in g["validated_applications"]:
            errs.append("unsupported-empirical-promotion")
    for r in g["rules"]:
        c = g["contracts"].get(r["contract_id"])
        if c is None:
            errs.append("missing-source-contract"); continue
        if r["source_hash"] != digest(c): errs.append("source-hash-mismatch")
        if r["premises"] != c["premises"]: errs.append("premise-contract-mismatch")
        if r["conclusion"] != c["conclusion"]: errs.append("direction-contract-mismatch")
        if r["mode"] != c["mode"]: errs.append("and-or-contract-mismatch")
        if r["binding"] != c["binding"]: errs.append("binding-contract-mismatch")
        if r["execution"]:
            if r["relation"] != "deduction": errs.append("nondeductive-edge-executed")
            if not r["active"]: errs.append("suspended-rule-executed")
            bind = [ns[x]["binding"] for x in r["premises"] + [r["conclusion"]]]
            if any(x != r["binding"] for x in bind): errs.append("binding-mismatch")
    expected_ids = {n["id"] for n in g["nodes"]} | {r["id"] for r in g["rules"]}
    if set(g["required_ids"]) != expected_ids: errs.append("declared-census-mismatch")
    if set(g["reviewed_ids"]) != set(g["required_ids"]): errs.append("coverage-mismatch")
    if len(g["reviewed_ids"]) != len(set(g["reviewed_ids"])): errs.append("duplicate-review")
    try:
        current = tuple(int(x) for x in g["version"].split("."))
        parent = tuple(int(x) for x in g["parent_version"].split("."))
        if len(current) != 3 or len(parent) != 3 or min(current + parent) < 0:
            errs.append("unsupported-version-format")
        elif g["content_changed"] and current <= parent:
            errs.append("version-not-advanced")
    except (ValueError, TypeError, AttributeError):
        errs.append("unsupported-version-format")
    for record in g["context_exports"]:
        if record["from"] != record["to"] and not record.get("transport_witness"):
            errs.append("unlicensed-context-export")
    if not finite_satisfiable(g["joint_constraints"]): errs.append("joint-inconsistency")
    return sorted(set(errs))


def mutations() -> list[tuple[str, str, dict[str, Any]]]:
    out: list[tuple[str, str, dict[str, Any]]] = []
    def case(name: str, error: str, mutate: Any) -> None:
        g = fixture(); mutate(g); out.append((name, error, g))
    case("M01_cross_instance", "binding-mismatch", lambda g: g["nodes"][1].update(binding="system-B:t0:micro:S1"))
    case("M02_dropped_premise", "premise-contract-mismatch", lambda g: g["rules"][0].update(premises=["A"]))
    case("M03_and_to_or", "and-or-contract-mismatch", lambda g: g["rules"][0].update(mode="any"))
    case("M04_analogy_as_proof", "nondeductive-edge-executed", lambda g: g["rules"][0].update(relation="analogy"))
    case("M05_empirical_promotion", "unsupported-empirical-promotion", lambda g: g["nodes"][2].update(status="empirically_validated"))
    case("M06_stale_definition", "stale-definition-use", lambda g: g["definitions"].update(D1="2"))
    case("M07_source_tamper", "source-hash-mismatch", lambda g: g["contracts"]["C1"].update(note="changed after review"))
    case("M08_suspended_rule", "suspended-rule-executed", lambda g: g["rules"][0].update(active=False))
    case("M09_partial_audit", "coverage-mismatch", lambda g: g.update(reviewed_ids=["A", "B", "Q"]))
    case("M10_same_version_overwrite", "version-not-advanced", lambda g: g.update(version="1.0.0"))
    case("M11_context_leak", "unlicensed-context-export", lambda g: g.update(context_exports=[{"from":"Gamma1","to":"Gamma2"}]))
    case("M12_joint_conflict", "joint-inconsistency", lambda g: g.update(joint_constraints=[{"op":"pos","args":["p"]},{"op":"pos","args":["q"]},{"op":"nand","args":["p","q"]}]))
    return out


def controls() -> list[tuple[str, dict[str, Any]]]:
    out: list[tuple[str, dict[str, Any]]] = []
    for i in range(12):
        g = fixture()
        g["version"] = "1.0." + str(i+1)
        g["nodes"][0]["note"] = "benign annotation " + str(i)
        if i % 3 == 0:
            g["context_exports"] = [{"from":"Gamma1","to":"Gamma2","transport_witness":"explicit-fixture-transport"}]
        if i % 3 == 1:
            g["rules"][0].update(relation="analogy", execution=False)
        if i % 3 == 2:
            g["rules"][0].update(active=False, execution=False)
        out.append(("C%02d" % (i+1), g))
    return out


def minimal(sets: set[frozenset[str]]) -> set[frozenset[str]]:
    return {s for s in sets if not any(t < s for t in sets)}


def frontiers(target: str, accepted: set[str], opened: set[str], rules: dict[str, list[list[str]]], trail: frozenset[str] = frozenset()) -> set[frozenset[str]]:
    """Exact for finite acyclic positive AND/OR graphs, one fixed environment.
    Every proposed rule is an approved conditional schema; an open root is NOT true.
    """
    if target in trail: raise ValueError("Cyclic proof route")
    if target in accepted: return {frozenset()}
    if target in opened: return {frozenset({target})}
    result: set[frozenset[str]] = set()
    for premises in rules.get(target, []):
        products: set[frozenset[str]] = {frozenset()}
        for p in premises:
            fs = frontiers(p, accepted, opened, rules, trail | {target})
            products = {x | y for x in products for y in fs}
        result |= products
    return minimal(result)


def closure(accepted: set[str], rules: dict[str, list[list[str]]]) -> set[str]:
    result = set(accepted)
    while True:
        nxt = result | {q for q, rs in rules.items() if any(set(p) <= result for p in rs)}
        if nxt == result: return result
        result = nxt


def check_frontiers() -> dict[str, Any]:
    # All subsets of the 10 nonempty positive rules on four topologically ordered nodes.
    # a is accepted; b is open; c can depend on subsets of {a,b}; d on subsets of {a,b,c}.
    candidates: list[tuple[str, list[str]]] = []
    for q, prior in [("c", ["a","b"]), ("d", ["a","b","c"])]:
        for n in range(1, len(prior)+1):
            candidates.extend((q, list(s)) for s in itertools.combinations(prior,n))
    assert len(candidates) == 10
    comparisons = 0
    for mask in range(1 << len(candidates)):
        rules: dict[str, list[list[str]]] = {}
        for i, (q, ps) in enumerate(candidates):
            if mask >> i & 1: rules.setdefault(q, []).append(ps)
        for target in ("c", "d"):
            f = frontiers(target, {"a"}, {"b"}, rules)
            for s in (set(), {"b"}):
                computed = any(set(x) <= s for x in f)
                brute = target in closure({"a"} | s, rules)
                assert computed == brute
                comparisons += 1
    example = frontiers("T", {"A"}, {"B","C","D"}, {"T":[["A","B"],["C","D"]]})
    return {"graphs": 1 << len(candidates), "closure_comparisons": comparisons,
            "mismatches": 0, "example_frontiers": sorted([sorted(s) for s in example]),
            "scope": "Finite enumerated positive acyclic rule graphs; not a discovery-performance estimate."}


def check_factorization() -> dict[str, Any]:
    checked = 0; successful = 0
    for n in range(1,6):
        maps = list(itertools.product((0,1), repeat=n))
        for r in maps:
            for f in maps:
                fibers = all(r[i] != r[j] or f[i] == f[j] for i in range(n) for j in range(n))
                decoder = any(all(h[r[i]] == f[i] for i in range(n)) for h in itertools.product((0,1), repeat=2))
                assert fibers == decoder
                checked += 1; successful += decoder
    omega = list(itertools.product((0,1), repeat=2))
    r = [a ^ b for a,b in omega]; f = [a for a,b in omega]
    witnesses = [[omega[i],omega[j]] for i in range(4) for j in range(i+1,4) if r[i] == r[j] and f[i] != f[j]]
    assert all(((a ^ b) ^ b) == a for a,b in omega)
    return {"map_pairs": checked, "factorizing_pairs": successful, "mismatches": 0,
            "example_domain": omega, "descriptor": r, "target": f, "counterexample_pairs": witnesses,
            "repaired_descriptor": "(a XOR b, b)", "repair_verified_on_states": len(omega),
            "novelty": "Elementary inherited factorization; used as a transparent discovery-cycle demonstration."}


def audit_source(backup: Path | None) -> dict[str, Any]:
    if backup is None: return {"status":"NOT_REQUESTED"}
    ledger = json.loads((backup/"REVIEW_LEDGER.json").read_text())["items"]
    graph = json.loads((backup/"UCT_EFFECTIVE_GRAPH.json").read_text())
    ids = [x["item_id"] for x in ledger]
    assert len(ids) == len(set(ids)) == 1278
    types = dict(Counter(x["item_type"] for x in ledger))
    assert types == {"node":722,"rule":353,"context":203}
    assert len(graph["rules"]) == 343
    assert len(graph["suspended_historical_rule_ids"]) == 10
    required = {"item_id","effective_statement","scope","source_record_sha256","semantic_reason","review_state"}
    assert all(required <= set(x) for x in ledger)
    return {"status":"COUNTS_AND_FIELDS_RECHECKED", "item_counts":types,"unique_ids":len(ids),
        "review_states":dict(Counter(x["review_state"] for x in ledger)),
        "decision_counts":dict(Counter(x["decision"] for x in ledger)),
        "active_rules":len(graph["rules"]), "suspended_rules":len(graph["suspended_historical_rule_ids"]),
        "ledger_sha256":hashlib.sha256((backup/"REVIEW_LEDGER.json").read_bytes()).hexdigest(),
        "effective_graph_sha256":hashlib.sha256((backup/"UCT_EFFECTIVE_GRAPH.json").read_bytes()).hexdigest(),
        "limit":"Descriptive re-analysis of saved author-side judgments; not independent semantic recertification."}


def run(output: Path, backup: Path | None) -> None:
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    fixture_records = []
    for name, expected, g in mutations():
        se, fe = structural_errors(g), full_errors(g)
        assert expected in fe, (name,expected,fe)
        assert not se, (name,se)
        rows.append({"fixture":name,"expected_error":expected,"structural_errors":se,"contract_errors":fe})
        fixture_records.append({"id":name,"expected_error":expected,"graph":g})
    valid_rows = []
    for name, g in controls():
        assert not full_errors(g), (name,full_errors(g))
        valid_rows.append({"fixture":name,"contract_errors":[]})
        fixture_records.append({"id":name,"expected_error":None,"graph":g})
    triple = [{"op":"pos","args":["p"]},{"op":"pos","args":["q"]},{"op":"nand","args":["p","q"]}]
    pairwise = all(finite_satisfiable(list(p)) for p in itertools.combinations(triple,2))
    assert pairwise and not finite_satisfiable(triple)
    results = {"version":"MGTD-PAPER-v1.0.0","test_type":"author-constructed deterministic conformance suite",
        "mutants":rows,"controls":valid_rows,
        "summary":{"mutants":len(rows),"structural_rejections":sum(bool(x["structural_errors"]) for x in rows),
             "contract_rejections":sum(bool(x["contract_errors"]) for x in rows),"valid_controls":len(valid_rows),"control_rejections":0},
        "joint_consistency":{"pairs_satisfiable":pairwise,"triple_satisfiable":False},
        "frontier_check":check_frontiers(),"factorization_check":check_factorization(),
        "source_case":audit_source(backup),
        "limits":["Fixtures were designed with the checker: no blind or held-out evaluation.",
                  "The structural checker is intentionally weak, not a comparison to existing research systems.",
                  "String binding and contract comparison cannot resolve undisclosed natural-language ambiguity.",
                  "Conformance does not imply scientific validity, originality, or discovery efficiency."]}
    (output/"results.json").write_text(json.dumps(results,indent=2)+"\n")
    (output/"fixtures.json").write_text(json.dumps(fixture_records,indent=2)+"\n")
    print(json.dumps({k:results[k] for k in ("summary","frontier_check","factorization_check","source_case")},indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=Path("results"))
    parser.add_argument("--backup",type=Path,default=None,help="Directory containing frozen REVIEW_LEDGER.json and UCT_EFFECTIVE_GRAPH.json")
    opts = parser.parse_args()
    run(opts.output,opts.backup)
