#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for tool in pandoc xelatex; do
  command -v "$tool" >/dev/null || { echo "Missing dependency: $tool" >&2; exit 1; }
done
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
pandoc manuscript.md --standalone --number-sections --top-level-division=section \
  --include-in-header=latex_header.tex --pdf-engine=xelatex \
  -V papersize=a4 -V link-citations=true -o manuscript.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory="$build" manuscript.tex > "$build/pass1.txt" || { cat "$build/pass1.txt" >&2; exit 1; }
xelatex -interaction=nonstopmode -halt-on-error -output-directory="$build" manuscript.tex > "$build/pass2.txt" || { cat "$build/pass2.txt" >&2; exit 1; }
cp "$build/manuscript.pdf" MGTD_Method_Paper_v1.0.0.pdf
# Keep a short build diagnostic, not temporary TeX output files.
grep -E 'Overfull|Missing character|LaTeX Warning' "$build/manuscript.log" > results/typesetting_warnings.txt || true
printf 'Created %s\n' MGTD_Method_Paper_v1.0.0.pdf
