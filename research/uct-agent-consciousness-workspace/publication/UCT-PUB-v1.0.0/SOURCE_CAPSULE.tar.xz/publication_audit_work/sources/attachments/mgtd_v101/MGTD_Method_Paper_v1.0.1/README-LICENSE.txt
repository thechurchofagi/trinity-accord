Map-Guided Theory Development (MGTD) v1.0.1
Author: Hongju Liu
Version DOI: 10.5281/zenodo.23241982
Original v1.0.0 DOI: 10.5281/zenodo.23241205
Status: public methods preprint, not peer-reviewed.

The scientific propositions and case data are unchanged from v1.0.0. Corrections update the title page, AI-assisted authorship disclosure wording, and publication status, all of which became obsolete when v1.0.0 was assigned its Zenodo DOI.

Substantial AI assistance was used under human guidance. CC BY 4.0 applies only to newly authored material to the extent rights are held. All third-party sources retain their rights. DOI/OTS/Arweave attest archival identifiers/bytes/timestamps, not scientific truth or originality.

Only v1.0.1 is eligible for new OTS and Arweave processing. The v1.0.0 OTS proof is retained historically, but no additional old-version AR upload is authorized.
