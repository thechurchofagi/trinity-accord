# Work log — UCT-RC v1.1.0

12 October 2026. Request: re-examine the supplied paper deeply, optimize it where necessary, and finish the final manuscript. No instruction in this turn to publish a DOI.

Read the supplied full source, critical review, verification package and 19-page PDF; render and inspect original pages. Retrieve the current project policy/state and pinned UCT I combination scope. Conduct targeted original-source checks, including exact parity prior art, IIT conditional independence, current phenomenal-structure work, Markov projections and common-drive precedents.

Re-derive RC1–RC6 and inspect both original verification programs. Re-run them; reproduce the original primary JSON bytes. Identify the exact-intersection premise needed to exclude unintended overlap identifications. Derive a lag-wise compatibility result and a fixed positivity-floor qualification. Construct and prove the positive 16-state hidden-mediator witness. Check its stationary law, matching apparent one-step table, preserved complete local laws, different multistep correlations and fresh-input response. Add a common lower bound on the apparent tables, while distinguishing them from a closed transition kernel. Keep observational equivalence separate from equality under interventions.

Extend the readout calculation to the main overlap model. Derive matched-local preparations and an innovation-coupling replacement with fixed marginals. Add these as a coherent revision of the same paper; preserve all prior user thought experiments and the non-erasure/structural-sameness distinction. Execute the new exact verifier, inspect outputs, revise interpretation and declarations, and build the English final manuscript. Render and check the final PDF; bind final sources, results and review in a new versioned package.

The full historical UCT-map semantic audit is not completed. Candidate nodes remain disabled, and no experience endpoint or IIT score is invented. Source/claim coverage is local and targeted, not an exhaustive global originality audit. DOI/OTS/AR statuses remain not submitted. Persistence coverage is recorded separately and must not be overstated.

## Final persistence and clean rerun

All three verifiers were rerun in a separate output directory and the primary JSON bytes matched. Final PDF: 25 pages; no overfull boxes; all fonts embedded; all pages rendered and reviewed. Proposed deposit metadata were corrected to nested v1.1.0 fields. GitHub handoff-only commit: `58f673a9fdb00911b5bd4e62d4de87f5669488d0`; full manuscript/PDF/code are in the attached local package, not in that commit. See `metadata/PERSISTENCE_RECEIPT.json`. No DOI/OTS/Arweave action occurred.
