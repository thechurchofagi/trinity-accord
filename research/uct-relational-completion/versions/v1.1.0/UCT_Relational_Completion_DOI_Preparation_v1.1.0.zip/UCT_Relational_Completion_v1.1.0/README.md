# What the Whole Adds Without Erasing Its Parts — v1.1.0

Hongju Liu. UCT-RC-2026-01. Final revised English theoretical/computational preprint, 12 October 2026. Same work as the supplied v1.0.0; the old version is not overwritten.

## Main files

`What_the_Whole_Adds_v1.1.0.pdf` is the final typeset manuscript. `manuscript.md` and `manuscript.tex` are editable sources. `review/FINAL_SCIENTIFIC_REVIEW.md` records the proof and interpretation audit. `review/CLAIM_LEDGER.json` identifies every claim and its dependencies. `sources/SOURCE_LEDGER.json` records source-access limits. Publication metadata are proposed, not submitted.

## Reproduce the mathematics

Use Python 3.10+ without `-O`; no third-party Python packages or network access are required. From this directory:

```sh
python code/verify_relational_completion.py --out fresh-results
python code/verify_overlapping_memory.py --out fresh-results
python code/verify_revision.py --out fresh-results
```

Compare the three primary JSON files with `results/`. The first two scripts are unchanged from v1.0.0. The new script checks exact-overlap scope, lag-wise compatibility, a uniform transition floor, a full-support hidden-memory witness, and a matched-marginal preparation/intervention protocol. Examples are stipulated mathematical systems, not physical devices or measurements of consciousness.

## Rebuild the PDF

Pandoc plus XeLaTeX, with Liberation Serif, Liberation Sans and DejaVu Sans Mono installed locally:

```sh
pandoc manuscript.md --from=markdown+tex_math_single_backslash --standalone --to=latex -o manuscript.tex
xelatex -interaction=nonstopmode -halt-on-error manuscript.tex
xelatex -interaction=nonstopmode -halt-on-error manuscript.tex
```

Font files are not distributed. PDF bytes may change with build time/toolchain; the delivered PDF is bound by the manifest. Mathematical result JSONs are deterministic.

## Boundaries

No DOI has been reserved or published, and no OTS/Arweave submission occurred in this revision. No published source manuscript or authoritative UCT map was overwritten. The full historical semantic map remains unaudited in this run, so new candidate nodes remain disabled. Publication/preservation receipts, if later obtained, must be separate from scientific-validity claims. See the final persistence receipt for exact GitHub versus local coverage.
