#!/usr/bin/env python3
"""Exact finite checks for Local Persistence and Relational Completion.

Standard library only. These are stipulated mathematical models, not measurements
of consciousness or implementations of IIT. Run without network access:
    python code/verify_relational_completion.py --out results
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import itertools as it
import json
import math
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path


def subsets(n: int, include_empty: bool = False):
    return range(0 if include_empty else 1, 1 << n)


def chi(x: int) -> int:
    return -1 if x.bit_count() % 2 else 1


def kernel(n: int, theta: F):
    if n < 2 or not -1 <= theta <= 1:
        raise ValueError('n >= 2 and -1 <= theta <= 1 required')
    d = 1 << n
    return [[(1 + theta * chi(x) * chi(y)) / d for y in range(d)] for x in range(d)]


def multiply(a, b):
    d = len(a)
    # Independent ordinary matrix multiplication, not the claimed spectral formula.
    return [[sum((a[i][k] * b[k][j] for k in range(d)), F(0))
             for j in range(d)] for i in range(d)]


def generator_row(n: int, theta: F, x: int):
    row = [F(0) for _ in range(1 << n)]
    flip = (1 - theta) / 2
    for random_low in range(1 << (n-1)):
        for noise, prob in [(0, 1-flip), (1, flip)]:
            last = (x.bit_count() + random_low.bit_count() + noise) % 2
            y = random_low | (last << (n-1))
            row[y] += prob / (1 << (n-1))
    return row


def covers(n: int, max_size: int):
    whole = (1 << n) - 1
    for size in range(1, max_size+1):
        for c in it.combinations(subsets(n), size):
            union = 0
            for patch in c:
                union |= patch
            if union == whole:
                yield c


def check_relational_completion():
    report = []
    for n, max_size in [(3, 7), (4, 3)]:
        atoms = [m for m in subsets(n) if m.bit_count() in (2, 3)]
        m = len(atoms)
        count = fibers_checked = globals_checked = 0
        for cover in covers(n, max_size):
            covered_ids = [i for i, atom in enumerate(atoms)
                           if any((atom & patch) == atom for patch in cover)]
            hist = defaultdict(int)
            for whole in range(1 << m):
                # The observed signature consists of ALL induced patch atom-values.
                signature = tuple(tuple((whole >> i) & 1 for i, atom in enumerate(atoms)
                                         if (atom & patch) == atom) for patch in cover)
                hist[signature] += 1
            missing = m - len(covered_ids)
            expected_fiber = 1 << missing
            assert len(hist) == 1 << len(covered_ids)
            assert set(hist.values()) == {expected_fiber}
            count += 1
            fibers_checked += len(hist)
            globals_checked += 1 << m
        report.append({'events': n, 'candidate_relational_atoms': m,
                       'cover_size_at_most': max_size, 'covers_checked': count,
                       'local_data_fibers_checked': fibers_checked,
                       'whole_cover_pairs_checked': globals_checked})
    # Explicit incompatible local descriptions: one shared atom both true and false.
    shared_atom = (0, 1)
    patch1 = {shared_atom: True}
    patch2 = {shared_atom: False}
    assert any(patch1[k] != patch2[k] for k in patch1.keys() & patch2.keys())
    return report


def check_overlap_transport():
    # Shared actual event carrier; independently relabeled local and whole structures.
    u = (0, 1, 2, 3)
    patches = ((0, 1, 2), (1, 2, 3))
    count = 0
    for hw_values in it.permutations(u):
        hw = dict(zip(u, hw_values))
        for hp_values in it.permutations(range(3)):
            hp = dict(zip(patches[0], hp_values))
            for hq_values in it.permutations(range(3)):
                hq = dict(zip(patches[1], hq_values))
                jp = {hp[e]: hw[e] for e in patches[0]}
                jq = {hq[e]: hw[e] for e in patches[1]}
                for e in (1, 2):
                    assert jp[hp[e]] == jq[hq[e]] == hw[e]
                assert len(set(jp.values()) | set(jq.values())) == 4
                assert len(set(jp.values()) & set(jq.values())) == 2
                count += 1
    return {'whole_local_relabelings_checked': count,
            'shared_events': 2, 'union_events': 4, 'disjoint_copy_events': 6}


def check_dynamic_family():
    parameters = [F(-1), F(-3,4), F(-1,2), F(0), F(1,2), F(3,4), F(1)]
    records = []
    for n in range(2, 6):
        d = 1 << n
        marginal_distributions = generator_rows = eigen_rows = powers = 0
        for theta in parameters:
            p = kernel(n, theta)
            assert all(sum(row) == 1 and all(v >= 0 for v in row) for row in p)
            assert all(sum(p[x][y] for x in range(d)) == 1 for y in range(d))
            for x in range(d):
                assert generator_row(n, theta, x) == p[x]
                generator_rows += 1
                assert sum(p[x][y] * chi(y) for y in range(d)) == theta * chi(x)
                eigen_rows += 1
                for patch in range(1, d-1):
                    distribution = defaultdict(F)
                    for y in range(d):
                        distribution[y & patch] += p[x][y]
                    assert len(distribution) == 1 << patch.bit_count()
                    assert set(distribution.values()) == {F(1, 1 << patch.bit_count())}
                    marginal_distributions += 1
            # A model obeying independent output mechanisms and these singleton
            # distributions has only the uniform kernel, unlike every theta != 0.
            uniform = kernel(n, F(0))
            assert (p == uniform) == (theta == 0)
            current = p
            for lag in range(1, 5):
                if lag > 1:
                    current = multiply(current, p)
                assert current == kernel(n, theta ** lag)
                powers += 1
        records.append({'units': n, 'states': d, 'parameters': len(parameters),
                        'proper_output_marginal_distributions': marginal_distributions,
                        'circuit_rows': generator_rows, 'parity_eigenvector_rows': eigen_rows,
                        'matrix_power_checks': powers})
    # Proper local TRAJECTORIES, not merely static marginals: explicit 3-time check.
    n, theta, patch = 3, F(3,4), 0b011
    p, d = kernel(n, theta), 1 << n
    trajectories = defaultdict(F)
    for x0, x1, x2 in it.product(range(d), repeat=3):
        trajectories[(x0 & patch, x1 & patch, x2 & patch)] += F(1,d)*p[x0][x1]*p[x1][x2]
    assert len(trajectories) == 64
    assert set(trajectories.values()) == {F(1,64)}
    # On synchronized raw views no ambiguity remains: patch overlaps share episode IDs.
    stitched = 0
    for n in range(2,7):
        whole = (1 << n)-1
        leave_one_out = [whole ^ (1 << j) for j in range(n)]
        for x in range(1 << n):
            reconstructed = 0
            for patch in leave_one_out:
                reconstructed |= x & patch
            assert reconstructed == x
            stitched += 1
    return {'parameter_grid': [str(t) for t in parameters], 'rows': records,
            'three_time_proper_patch_paths': {'micro_paths': 512, 'observed_paths':64,
                                            'each_probability':'1/64'},
            'synchronized_vectors_reconstructed': stitched}


def check_output_channels():
    records = []
    for n in range(2,5):
        d = 1 << n
        invisible = visible = 0
        for channel in range(1 << d):
            imbalance = sum(chi(y) for y in range(d) if channel & (1 << y))
            if imbalance:
                visible += 1
            else:
                invisible += 1
        assert invisible == math.comb(d, d//2)
        assert visible + invisible == 1 << d
        # Sum/count and parity do retain the n-way mode; a proper-coordinate reader does not.
        for j in range(n):
            assert sum(chi(y)*((y >> j)&1) for y in range(d)) == 0
        assert sum(chi(y)*chi(y) for y in range(d)) == d
        records.append({'units':n,'binary_readout_channels':1 << d,
                        'invisible':invisible,'visible':visible})
    # Noise formula from direct enumeration of independent bit flips.
    noise_cases = 0
    for n in range(2,5):
        for rates in it.product([F(0), F(1,4), F(1,2)], repeat=n):
            direct = F(0)
            for noise in range(1 << n):
                prob = F(1)
                for j, rate in enumerate(rates):
                    prob *= rate if (noise >> j)&1 else 1-rate
                direct += prob * chi(noise)
            product = math.prod(1-2*r for r in rates)
            assert direct == product
            noise_cases += 1
    # Temporal aliasing: equal even-step kernels do not imply equal one-step organization.
    assert kernel(3,F(3,4)) != kernel(3,F(-3,4))
    assert multiply(kernel(3,F(3,4)),kernel(3,F(3,4))) == multiply(kernel(3,F(-3,4)),kernel(3,F(-3,4)))
    return {'readout_classification':records, 'independent_noise_cases':noise_cases,
            'opposite_sign_even_lag_aliasing':True}


def check_persistent_local_factors():
    # Local binary memory s_i is copied exactly; r_i are the coupled registers.
    n, d = 3, 8
    checks = 0
    for theta in (F(0), F(1,2), F(1)):
        p = kernel(n,theta)
        for s, r in it.product(range(d),repeat=2):
            for patch in range(1,d-1):
                output = defaultdict(F)
                for rp in range(d):
                    output[(s & patch, rp & patch)] += p[r][rp]
                assert set(output.values()) == {F(1,1 << patch.bit_count())}
                assert all(sp == s & patch for sp, _ in output)
                checks += 1
    return {'units':n,'persistent_local_state':'s_i(t+1)=s_i(t)',
            'coupling_parameters': ['0','1/2','1'], 'proper_patch_checks':checks,
            'warning':'Equal stochastic views do not certify unchanged complete local experience.'}



def transitive_closure(n, relation):
    out = set(relation)
    for k in range(n):
        for i in range(n):
            for j in range(n):
                if (i,k) in out and (k,j) in out:
                    out.add((i,j))
    return out


def partial_orders(n):
    pairs = list(it.combinations(range(n),2))
    out = []
    for choices in it.product((0,1,-1),repeat=len(pairs)):
        relation = set()
        for (i,j), choice in zip(pairs,choices):
            if choice == 1: relation.add((i,j))
            elif choice == -1: relation.add((j,i))
        closed = transitive_closure(n,relation)
        if closed == relation and all(i != j for i,j in closed):
            out.append(frozenset(relation))
    return out


def check_order_completion():
    # Local temporal orders are strict partial orders. Shared event IDs are fixed.
    classifications = []
    for n in (3,4):
        global_orders = partial_orders(n)
        pairs = list(it.combinations(range(n),2))
        accepted = rejected = 0
        for choices in it.product((0,1,-1),repeat=len(pairs)):
            positive, negative = set(), set()
            for (i,j), choice in zip(pairs,choices):
                if choice == 1:
                    positive.add((i,j)); negative.add((j,i))
                elif choice == -1:
                    positive.add((j,i)); negative.add((i,j))
                else: negative.update(((i,j),(j,i)))
            closure = transitive_closure(n,positive)
            criterion = all(i != j for i,j in closure) and not closure.intersection(negative)
            # All pair patches reveal every ordered pair, so the candidate is fixed.
            direct = frozenset(positive) in global_orders
            assert criterion == direct
            if criterion: accepted += 1
            else: rejected += 1
        classifications.append({'events':n,'pair_patch_families':3**len(pairs),
                                 'accepted':accepted,'rejected':rejected})
    n = 4
    globals_ = partial_orders(n)
    p, q = (0,1,2), (1,2,3)
    def relabel(order,carrier):
        return frozenset((carrier[i],carrier[j]) for i,j in order)
    local_orders = partial_orders(3)
    histogram = defaultdict(int)
    tested = 0
    for pp0, qq0 in it.product(local_orders,repeat=2):
        pp, qq = relabel(pp0,p), relabel(qq0,q)
        overlap = {(1,2),(2,1)}
        if pp.intersection(overlap) != qq.intersection(overlap):
            continue
        known = {(a,b) for patch in (p,q) for a in patch for b in patch if a != b}
        positive = set(pp)|set(qq)
        negative = known-positive
        closure = transitive_closure(n,positive)
        criterion = all(i != j for i,j in closure) and not closure.intersection(negative)
        completions = [g for g in globals_ if positive <= g and not g.intersection(negative)]
        assert criterion == bool(completions)
        if criterion:
            assert frozenset(closure) in completions
            augmentable = False
            for i in range(n):
                for j in range(n):
                    if i == j or (i,j) in closure or (i,j) in negative: continue
                    augmented = transitive_closure(n,closure|{(i,j)})
                    if all(a != b for a,b in augmented) and not augmented.intersection(negative):
                        augmentable = True
            assert (not augmentable) == (len(completions) == 1)
        tested += 1
        histogram[len(completions)] += 1
    return {'complete_pair_cover':classifications,
            'overlap_cover_abc_bcd':{'compatible_local_pairs':tested,
                                  'completion_count_histogram':dict(sorted(histogram.items()))}}


def hb(p):
    p = float(p)
    if p in (0,1): return 0.0
    return -p*math.log2(p)-(1-p)*math.log2(1-p)


def run(out: Path):
    out.mkdir(parents=True,exist_ok=True)
    results = {'schema':'uct-relational-completion-checks/1.0.0',
               'scope':'Finite synthetic mathematical verification; no human, AI-consciousness, or IIT experiment.',
               'relational_completion':check_relational_completion(),
               'overlap_transport':check_overlap_transport(),
               'temporal_order_completion':check_order_completion(),
               'collective_memory':check_dynamic_family(),
               'measurement':check_output_channels(),
               'persistence':check_persistent_local_factors(),
               'failures':0}
    data = (json.dumps(results,indent=2,sort_keys=True)+'\n').encode()
    (out/'EXACT_RESULTS.json').write_bytes(data)
    with (out/'memory_readout.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['theta','lag','true_parity_correlation','memory_bits','three_bit_noise_rate','measured_signed_mean'])
        for theta in (F(-3,4),F(0),F(1,2),F(3,4),F(1)):
            for lag in (1,2,4,8):
                corr=theta**lag
                w.writerow([str(theta),lag,str(corr),format(1-hb((1-corr)/2),'.12f'),'1/10',str(corr*F(4,5)**3)])
    print(json.dumps(results,indent=2,sort_keys=True))
    print('SHA256 EXACT_RESULTS.json:',hashlib.sha256(data).hexdigest())

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=Path('results'))
    run(parser.parse_args().out)
