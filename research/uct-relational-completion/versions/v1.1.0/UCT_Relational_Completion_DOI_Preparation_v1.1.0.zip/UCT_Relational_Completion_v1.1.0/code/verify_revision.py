#!/usr/bin/env python3
"""Exact checks for the v1.1.0 scope repair and matched-marginal protocol.

Python standard library only. Finite model verification, not hardware or
consciousness evidence. Assertions are deliberately kept active.
"""
from __future__ import annotations
import argparse
import itertools as it
import json
import math
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path


def sign(x: int, mask: int) -> int:
    return 1 - 2 * ((x & mask).bit_count() % 2)


def kernel(a: F, b: F, g: F) -> list[list[F]]:
    return [[(1 + a*sign(x,3)*sign(y,3) + b*sign(x,6)*sign(y,6)
                + g*sign(x,5)*sign(y,5))/8 for y in range(8)] for x in range(8)]


def mm(a: list[list[F]], b: list[list[F]]) -> list[list[F]]:
    n=len(a)
    return [[sum((a[i][j]*b[j][k] for j in range(n)),F(0))
             for k in range(n)] for i in range(n)]


def apply(k: list[list[F]], v: list[F]) -> list[F]:
    return [sum((p*z for p,z in zip(row,v)),F(0)) for row in k]


def row_apply(p: list[F], k: list[list[F]]) -> list[F]:
    return [sum((p[x]*k[x][y] for x in range(len(p))),F(0))
            for y in range(len(p))]


def two_time_probability_bounds() -> dict:
    checked=0
    signs=list(it.product((1,-1),repeat=2))
    for n0 in range(13):
        for n1 in range(13-n0):
            for n2 in range(13-n0-n1):
                ns=(n0,n1,n2,12-n0-n1-n2)
                ps=[F(n,12) for n in ns]
                a=sum(p*u for p,(u,v) in zip(ps,signs))
                b=sum(p*v for p,(u,v) in zip(ps,signs))
                c=sum(p*u*v for p,(u,v) in zip(ps,signs))
                assert -1+abs(a+b)<=c<=1-abs(a-b)
                assert [(1+a*u+b*v+c*u*v)/4 for u,v in signs]==ps
                checked+=1
    return {'probability_tables_denominator_12':checked,
            'claim':'RC7 pointwise lag bound; joint feasibility across multiple lags is not asserted'}


def positivity_floor() -> dict:
    checked=feasible=0
    grid=[F(i,4) for i in range(-4,5)]
    floors=[F(0),F(1,8),F(1,4),F(1,2),F(3,4)]
    for rho,a,b,g in it.product(floors,grid,grid,grid):
        z=1-rho
        actual=min((1+a*u+b*v+g*u*v)/8
                   for u,v in it.product((1,-1),repeat=2))>=rho/8
        interval=-z+abs(a+b)<=g<=z-abs(a-b)
        assert actual==interval
        if actual:
            feasible+=1
            if a>=0 and b>=0:
                assert abs(g)<=z-abs(a-b)
        checked+=1
    return {'parameter_floor_quadruples':checked,'feasible_cases':feasible,
            'claim':'RC8 uniform minorization, not merely entrywise positivity'}


def projection_pathlaw(k: list[list[F]], pi: list[F], mask: int) -> dict:
    n=len(k); out=defaultdict(F)
    for x,y,z in it.product(range(n),repeat=3):
        out[(x&mask,y&mask,z&mask)]+=pi[x]*k[x][y]*k[y][z]
    return dict(out)


def hidden_matrix(lam: F) -> tuple[list[list[F]],list[F],F]:
    a,b,g,d=F(3,4),F(1,4),F(1,4),F(1,5)
    mu=d*lam/(1-g*lam)
    mat=[]
    for i in range(16):
        x=i&7; h=1-2*(i>>3); c=g+d*h*sign(x,5)
        reg=kernel(a,b,c)[x]
        mat.append([reg[j&7]*(1+lam*h*(1-2*(j>>3)))/2 for j in range(16)])
    pi=[(1+mu*sign(i&7,5)*(1-2*(i>>3)))/16 for i in range(16)]
    return mat,pi,mu


def hidden_memory() -> dict:
    a,b,g,d=F(3,4),F(1,4),F(1,4),F(1,5)
    examples=[]; marginal_checks=lag_checks=path_checks=one_step_checks=fresh_preparation_checks=0
    for lam in (F(1,2),F(3,4),F(9,10),F(99,100),F(999,1000)):
        k,pi,mu=hidden_matrix(lam)
        assert min(v for row in k for v in row)>0
        assert all(sum(row)==1 for row in k)
        assert sum(pi)==1 and min(pi)>0 and row_apply(pi,k)==pi
        # Every observed register state has stationary probability 1/8.
        assert all(pi[x]+pi[x+8]==F(1,8) for x in range(8))
        for i in range(16):
            x=i&7
            for mask,rate in ((3,a),(6,b)):
                for obs in range(8):
                    if obs & ~mask: continue
                    got=sum(k[i][j] for j in range(16) if (j&mask)==obs)
                    assert got==(1+rate*sign(x,mask)*sign(obs,mask))/4
                    marginal_checks+=1
        geff=g+d*mu
        observed=kernel(a,b,geff)
        assert min(v for row in observed for v in row)>=F(59,2400)
        for x,y in it.product(range(8),repeat=2):
            p=sum(8*pi[x+8*h]*sum(k[x+8*h][y+8*hp] for hp in range(2))
                  for h in range(2))
            assert p==observed[x][y]
            one_step_checks+=1
        rv=[F(sign(i&7,5)) for i in range(16)]
        sv=[F(sign(i&7,3)) for i in range(16)]
        tv=[F(sign(i&7,6)) for i in range(16)]
        rfuture=rv[:]; sfuture=sv[:]; tfuture=tv[:]
        weight=d*mu/(lam-g)
        assert 0<weight<1
        cs=[]
        for lag in range(1,13):
            rfuture=apply(k,rfuture); sfuture=apply(k,sfuture); tfuture=apply(k,tfuture)
            ck=sum(pi[i]*rv[i]*rfuture[i] for i in range(16))
            expected=weight*lam**lag+(1-weight)*g**lag
            assert ck==expected
            assert all(sfuture[i]==a**lag*sv[i] and tfuture[i]==b**lag*tv[i] for i in range(16))
            assert -1+abs(a**lag+b**lag)<=ck<=1-abs(a**lag-b**lag)
            cs.append(ck); lag_checks+=1
        assert cs[0]==geff
        assert cs[1]-geff**2==d*mu*(lam-geff)>0
        for mask in (3,6):
            assert projection_pathlaw(k,pi,mask)==projection_pathlaw(observed,[F(1,8)]*8,mask)
            path_checks+=1
        # Test the complete two-step matrix independently of the moment recurrence.
        k2=mm(k,k)
        c2=sum(pi[i]*rv[i]*sum(k2[i][j]*rv[j] for j in range(16)) for i in range(16))
        assert c2==cs[1]
        for r in (1,-1):
            fresh=[F(1,8) if sign(i&7,5)==r else F(0) for i in range(16)]
            for lag in range(1,13):
                fresh=row_apply(fresh,k)
                assert sum(fresh[i]*rv[i] for i in range(16))==r*g**lag
                fresh_preparation_checks+=1
        iat=1+2*((1-weight)*g/(1-g)+weight*lam/(1-lam))
        if lam>=F(9,10):
            assert cs[7]>F(1,2)**8
        examples.append({'lambda':str(lam),'min_transition':str(min(v for row in k for v in row)),
                         'stationary_RH':str(mu),'observed_gamma_eff':str(geff),
                         'min_apparent_transition':str(min(v for row in observed for v in row)),
                         'C1':str(cs[0]),'C2':str(cs[1]),'gamma_eff_squared':str(geff**2),
                         'semigroup_defect_lag2':str(cs[1]-geff**2),
                         'C8':str(cs[7]),'C8_decimal':float(cs[7]),
                         'naive_asymmetry_envelope_lag8':str(F(1,2)**8),
                         'slow_mode_weight':str(weight),'slow_tail_time':-1/math.log(float(lam)),
                         'integrated_autocorrelation_time':str(iat),'iat_decimal':float(iat)})
    return {'models_checked':len(examples),'local_marginal_equalities':marginal_checks,
            'observed_one_step_kernel_equalities':one_step_checks,'lag_moment_checks':lag_checks,
            'three_time_patch_law_comparisons':path_checks,'fresh_preparation_checks':fresh_preparation_checks,'examples':examples,
            'claim':'RC9: same observed one-step law and local path laws do not imply Markov closure or the exponential lifetime frontier'}


def matched_preparation_readout() -> dict:
    cases=[(F(1,2),F(1,2),F(1,4)),(F(1,2),F(1,2),F(9,10)),
           (F(3,4),F(1,4),F(2,5)),(F(0),F(0),F(-3,4))]
    prep_checks=reader_checks=innovation_checks=0
    for a,b,g in cases:
        k=kernel(a,b,g); dec=kernel(a,b,a*b)
        # A fresh independent replacement of V retains its original marginal.
        for u,v in it.product((1,-1),repeat=2):
            pu=sum((1+a*u+b*z+g*u*z)/4 for z in (1,-1))
            pv=sum((1+a*z+b*v+g*z*v)/4 for z in (1,-1))
            assert pu*pv==(1+a*u+b*v+a*b*u*v)/4
            innovation_checks+=1
        preps={r:[F(1,4) if sign(x,5)==r else F(0) for x in range(8)] for r in (1,-1)}
        for mask in (3,6):
            for obs in range(8):
                if obs & ~mask: continue
                assert all(sum(p[x] for x in range(8) if x&mask==obs)==F(1,4)
                           for p in preps.values())
                prep_checks+=1
        current={r:p[:] for r,p in preps.items()}
        for lag in range(1,5):
            for r in (1,-1):
                current[r]=row_apply(current[r],k)
                for reader in range(256):
                    obsset=[y for y in range(8) if reader>>y&1]
                    aa=F(len(obsset),8)
                    br=sum(F(sign(y,5),8) for y in obsset)
                    actual=sum(current[r][y] for y in obsset)
                    assert actual==aa+r*g**lag*br
                    reader_checks+=1
            contrast=sum((current[1][x]-current[-1][x])*sign(x,5) for x in range(8))
            assert contrast==2*g**lag
        # Equality of patch laws before and after coupling-only replacement.
        for mask in (3,6):
            assert projection_pathlaw(k,[F(1,8)]*8,mask)==projection_pathlaw(dec,[F(1,8)]*8,mask)
    invisible=sum(sum(sign(y,5) for y in range(8) if reader>>y&1)==0 for reader in range(256))
    assert invisible==70
    return {'model_cases':len(cases),'matched_local_preparation_checks':prep_checks,
            'exact_readout_distribution_checks':reader_checks,
            'innovation_decoupling_checks':innovation_checks,
            'deterministic_binary_readers':256,'invisible_to_R':invisible,
            'claim':'RC10: relation preparation and marginal-preserving coupling intervention'}


def overlap_exactness() -> dict:
    # Commutation on the declared overlap alone permits accidental identifications.
    p={'a':0,'b':1}; q={'b':1,'c':0}; declared={'b'}
    assert all(p[x]==q[x] for x in declared)
    assert set(p.values()) & set(q.values()) != {p[x] for x in declared}
    q_grounded={'b':1,'c':2}
    assert set(p.values()) & set(q_grounded.values()) == {p[x] for x in declared}
    return {'counterexample_checked':True,'grounded_repair_checked':True,
            'claim':'RC3 exact intersections require an exact physical overlap premise, not just commuting arrows'}


def main() -> None:
    if not __debug__:
        raise RuntimeError('Run without -O: verification requires assertions.')
    ap=argparse.ArgumentParser(); ap.add_argument('--out',type=Path,default=Path('results'))
    args=ap.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    report={'schema':'uct-rc-v1.1.0-revision-verification','status':'PASS',
            'overlap_exactness':overlap_exactness(),
            'two_time_bounds':two_time_probability_bounds(),
            'uniform_positivity':positivity_floor(),
            'hidden_memory':hidden_memory(),
            'matched_preparation_readout':matched_preparation_readout(),
            'assertion_failures':0,
            'scope':'Exact finite stipulated models; self-contained proofs are in manuscript. No independent peer review, hardware test, clinical evidence, or consciousness measurement.'}
    text=json.dumps(report,indent=2,sort_keys=True)+'\n'
    (args.out/'REVISION_RESULTS.json').write_text(text,encoding='utf-8')
    print(text)

if __name__=='__main__':
    main()
