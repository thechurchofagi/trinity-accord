#!/usr/bin/env python3
"""Exact overlapping-memory completion and lifetime-frontier checks.

Uses only Python's standard library. All checks are finite mathematical fixtures.
No consciousness measurements, hardware execution, or IIT calculations occur.
"""
from __future__ import annotations
import argparse
import itertools as it
import json
import math
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path


def sign(x: int, mask: int) -> int:
    return 1 - 2*((x & mask).bit_count() % 2)


def transition(a: F, b: F, g: F):
    return [[(1 + a*sign(x,3)*sign(y,3) + b*sign(x,6)*sign(y,6)
              + g*sign(x,5)*sign(y,5))/8 for y in range(8)] for x in range(8)]


def circuit_row(a: F, b: F, g: F, x: int):
    row = [F(0) for _ in range(8)]
    for u,v in it.product((1,-1), repeat=2):
        p = (1+a*u+b*v+g*u*v)/4
        for shared in (0,1):
            s_next = sign(x,3)*u
            t_next = sign(x,6)*v
            y1 = shared ^ int(s_next == -1)
            y3 = shared ^ int(t_next == -1)
            y = y1 | (shared << 1) | (y3 << 2)
            row[y] += p/2
    return row


def mul(a, b):
    n=len(a)
    return [[sum((a[i][k]*b[k][j] for k in range(n)), F(0))
             for j in range(n)] for i in range(n)]


def pathlaw(k, mask):
    result=defaultdict(F)
    for x,y,z in it.product(range(8),repeat=3):
        result[(x&mask,y&mask,z&mask)] += F(1,8)*k[x][y]*k[y][z]
    return dict(result)


def entropy_memory(r):
    p=(1-float(r))/2
    if p in (0.,1.): return 1.
    return 1+p*math.log2(p)+(1-p)*math.log2(1-p)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',type=Path,default=Path('results'))
    args=ap.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    ab=[F(k,4) for k in range(-4,5)]; gs=[F(k,8) for k in range(-8,9)]
    candidates=valid=invalid=marginals=generator=eigen=powers=0
    for a,b,g in it.product(ab,ab,gs):
        candidates+=1
        lo=-1+abs(a+b); hi=1-abs(a-b)
        k=transition(a,b,g)
        nonnegative=all(v>=0 for row in k for v in row)
        assert nonnegative == (lo<=g<=hi)
        if not nonnegative:
            invalid+=1; continue
        valid+=1
        assert all(sum(row)==1 for row in k)
        assert all(sum(k[x][y] for x in range(8))==1 for y in range(8))
        for x in range(8):
            assert circuit_row(a,b,g,x)==k[x]; generator+=1
            for mask,r in ((3,a),(6,b)):
                for obs in range(8):
                    if obs & ~mask: continue
                    got=sum(k[x][y] for y in range(8) if y&mask==obs)
                    expected=(1+r*sign(x,mask)*sign(obs,mask))/4
                    assert got==expected; marginals+=1
            for mask,r in ((3,a),(6,b),(5,g)):
                assert sum(k[x][y]*sign(y,mask) for y in range(8))==r*sign(x,mask)
                eigen+=1
        product=k
        for lag in range(2,5):
            product=mul(product,k)
            assert product==transition(a**lag,b**lag,g**lag); powers+=1
    # Pair process laws remain unchanged with nonzero local memories.
    choices=[F(0),F(1,4),F(1,2),F(3,4),F(1)]
    reference=transition(F(1,2),F(1,2),F(1,4))
    path_checks=0
    for g in choices:
        k=transition(F(1,2),F(1,2),g)
        for mask in (3,6):
            assert pathlaw(k,mask)==pathlaw(reference,mask); path_checks+=1
    # For nonnegative local retentions, the maximal absolute global eigenvalue
    # is exactly 1-|a-b|. The attainable extremal kernel is included.
    bounds=0
    for a,b in it.product([F(k,16) for k in range(17)],repeat=2):
        lo=-1+abs(a+b); hi=1-abs(a-b)
        assert max(abs(lo),abs(hi))==hi
        assert all(v>=0 for row in transition(a,b,hi) for v in row)
        bounds+=1
    # Full support and arbitrarily long relational memory for equal local r=1/2.
    fullsupport=[]
    for denominator in (10,100,1000,10000):
        g=1-F(1,denominator)
        assert all(v>0 for row in transition(F(1,2),F(1,2),g) for v in row)
        fullsupport.append({'gamma':str(g),'local_correlation_time':-1/math.log(.5),
                            'relational_correlation_time':-1/math.log(float(g))})
    report={'schema':'uct-overlapping-memory-v1','status':'PASS','assertion_failures':0,
      'grid':{'alpha_beta':'-1 to 1 step 1/4','gamma':'-1 to 1 step 1/8',
              'candidates':candidates,'valid_kernels':valid,'invalid_kernels':invalid},
      'generator_rows_checked':generator,'local_marginal_checks':marginals,
      'eigenfunction_checks':eigen,'matrix_power_checks':powers,
      'three_time_local_process_law_comparisons':path_checks,
      'sharp_nonnegative_retention_bounds_checked':bounds,
      'fullsupport_equal_local_memory_sequence':fullsupport,
      'illustrative_global_one_step_information_bits':[
        {'alpha':'1/2','beta':'1/2','gamma':str(g),'bits':entropy_memory(g)} for g in choices],
      'scope':'Exact stipulated kernels and explicitly enumerated stochastic circuit; not empirical consciousness evidence.'}
    (args.out/'OVERLAPPING_MEMORY_RESULTS.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,indent=2,sort_keys=True))

if __name__=='__main__': main()
