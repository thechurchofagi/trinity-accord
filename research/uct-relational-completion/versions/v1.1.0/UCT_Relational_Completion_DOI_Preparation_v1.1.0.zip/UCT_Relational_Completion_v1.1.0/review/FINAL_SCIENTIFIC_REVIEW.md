# Final scientific review — UCT-RC v1.1.0

Date: 12 October 2026. Internal, author-directed, substantially AI-assisted review; not independent peer review.

## Decision

Complete this research increment as the revised manuscript of the same work, not a new paper. The supplied v1.0.0 remains unchanged. v1.1.0 retains the bounded positive overlap result and adds a scope counterexample and a usable intervention protocol. The manuscript is ready for a separately authorized DOI preparation/deposit step. This assessment is not a guarantee of correctness, global priority, journal acceptance, or future citation.

## Substantive changes

**Exact overlap.** The original commuting-diagram premise preserves agreement on a declared shared part but does not alone exclude additional unintended identifications. The revision states the exact-intersection condition and transports it under C1. A three-label counterexample demonstrates why it is needed. C1/U1 are not applied to an arbitrary interface as though it were an admitted actual process token.

**Robustness versus positivity.** RC6 is mathematically valid within its closed, fresh-innovation, character-diagonal Markov family. RC8 adds a fixed transition-floor frontier: with L(y|x) >= rho/8 and z=1-rho, gamma lies in [-z+|alpha+beta|, z-|alpha-beta|]. The equal-local-law unbounded limit requires the uniform margin to vanish. Process-transition noise and sensor noise are explicitly different.

**What is genuinely model robust.** RC7 proves the lag-wise raw-sign-moment interval without Markov, stationarity, or fresh-noise assumptions. It does not claim that every independent selection of lag-wise feasible moments extends to a single process. It does not turn a one-step bound into an exponential envelope. Raw sign moments are not called centered correlations unless their signs are unbiased.

**Hidden-mediator witness.** RC9 supplies an explicit full-support 16-state process. The local retentions are fixed at alpha=3/4, beta=1/4; a hidden sign H has retention lambda in [1/2,1), and the innovation coupling is c=q+dHR with q=1/4, d=1/5. Its stationary law pi(x,h)=(1+mu R(x)h)/16, mu=d lambda/(1-q lambda), is proved and checked. Its entire stationary observational one-step register table equals the closed-family table at gamma_eff=q+d mu. Both complete local patch trajectory laws also agree. Nonetheless C_k=w lambda^k+(1-w)q^k, w=d mu/(lambda-q), not gamma_eff^k. The defect C_2-C_1^2=d mu(lambda-gamma_eff)>0 distinguishes the witness from its memoryless twin. The visible one-step tables have a common positive floor 59/2400, but are not closed kernels of the hidden process. Tail and integrated correlation times diverge as lambda tends to one; the weight tends to 16/225 rather than vanishing.

**Do not overstate the twin.** Its equality is observational and stationary, NOT equality of all interventional one-step responses. Freshly preparing R independently of H produces q^k input retention and can distinguish the models. This clarification was added during the final adversarial pass. Tail time, integrated autocorrelation time, and first 1/e crossing are not interchangeable.

**Matched-local test.** RC10 extends the observation contract to the main overlapping model, rather than borrowing the all-proper-patches-invisible statement from the inherited n-bit control. M_r is uniform over the four register states with outer parity r. The two local patch laws remain identical while the global readout contrast is 2 gamma^k. Replacing one innovation by an independent sign with its original marginal sends gamma to alpha beta without changing local path laws. The protocol separates physical intervention from post-hoc data shuffling and a generator-side effect from a readout-side change.

## Originality and theory interpretation

The single-parity kernel and collective-versus-local memory example remain explicitly attributed to Rosas et al. (2020). Binary coupling, marginal projection, transport of structure, temporal closure, and common-drive organization are not claimed as new mathematical ideas. The application increment is the combined fixed-law overlap frontier, explicit positive latent-state counterlimit, and preparation/intervention contract. An exact earlier treatment of the complete integration was not established in the targeted primary-source search; this is NOT a proof of global novelty.

C1/P3/U1 remain conditional UCT premises. A continuing local process need not retain unchanged experiential content. A cross-patch relation relative to P={1,2}, Q={2,3} is not an irreducible three-body quantity: R can be read from the outer pair. Neither coherent transport, long memory, a decoded bit, nor a successful mathematical fit establishes subjective unity, subject count, or a named feeling. No IIT score was calculated and no IIT-refutation claim is made. Existing user thought experiments about continuing parts, copied versus shared relays, slow systems, and coarse instruments remain, with a new hidden-relay box experiment.

## Verification and limits

The two original verifiers were re-executed; their main exact-result JSONs reproduce the original bytes. The third verifier checks the new results using exact rational arithmetic, matrix operations, probability enumeration, stationary measures, and complete three-time local path distributions. General results rest on the proofs, not on parameter-grid counts. All three scripts require Python's standard library only and are run without optimization.

The revision verifier checks 455 lag-wise probability tables; 3,645 floor/parameter combinations; five positive latent-state examples with 640 local marginal equalities, 320 apparent one-step equalities, 60 lag-moment identities, 10 three-time patch-law comparisons, and 120 fresh-preparation checks; and 8,192 exact binary-readout distributions. No human, animal, neural, clinical, large-model, or hardware experiment was performed.

The current guide and state, and the pinned UCT I combination and subject-selection passages, were re-read. The full historical semantic map was NOT re-audited. Candidate nodes remain disabled; no authoritative map version is promoted. Published-claim coverage is assessed against the supplied predecessor and retrieved relevant sources, not claimed exhaustive over every publication in the repository.

## Production and execution incidents

An initial request for an interactive execution session failed because streaming sessions are not enabled. It was replaced by an ordinary synchronous call; all executions described above then actually ran. The draft transformation script emitted Python invalid-escape warnings in one replacement expression; the final manuscript was checked for control characters and the intended k>=1 qualifier was applied directly. These were workflow issues, not falsified scientific outputs. The final adversarial pass strengthened the observational-versus-interventional distinction and documented the fixed apparent-table floor. No failed mathematical claim was concealed or used as a premise.

## Final production check

The PDF is 25 pages. All pages were rendered and inspected at contact-sheet scale, with the overlap conditions, hidden-mediator theorem/table, and matched-preparation formulas additionally inspected at full resolution. Two overlong bibliography paths were replaced by source-ledger references; the final build has no overfull boxes and all fonts are embedded. A packaging audit found inherited v1.0.0 fields inside the nested proposed deposition metadata; these were corrected to a single v1.1.0 metadata object matching the final abstract. No deposit was made. All three exact verifiers were run again in a clean directory, and every primary result JSON matched the first run byte for byte.
