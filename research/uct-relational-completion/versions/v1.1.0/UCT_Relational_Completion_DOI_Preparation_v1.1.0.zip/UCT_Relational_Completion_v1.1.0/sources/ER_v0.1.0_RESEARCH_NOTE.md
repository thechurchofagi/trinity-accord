# Exclusion, persistence, and what an unresolved measurement can tell us

**Research checkpoint:** ER20261012 · v0.1.0 · 12 October 2026  
**Project:** Hongju Liu's UCT research  
**Status:** Working research note, not a paper or DOI submission; PENDING_MAP; not peer reviewed.  
**Assistance:** GPT-6 Astra Pro performed this source comparison, finite-model construction, code execution, and drafting under the user's direction.

## 1. Question and change of method

The user proposes two complementary routes: exact thought experiments about consciousness-theory commitments, and empirical work constrained by the resolving power of actual instruments. The immediate question is not whether one can force a decisive contest among all theories. It is which claimed differences are conceptual, which require physical construction, which are hidden by a measurement, and which still lack an experiential interpretation even after the physical structure is identified.

This note preserves UCT's distinction between complete token-relative organization, a measured view, an estimate, and subject individuation. A Boolean network below is an explicit finite dynamical model, not a complete mathematical definition of a human's organization. The presence of a graph edge, a successful report, or one selected score is not introduced as a basal experience gate.

The current baseline was read through the connected repository. `CURRENT_STATE.json` reports UCT-MAP-v1.1.2, publication coverage UCT-PUB-v1.0.33, and A5L as the latest activity. The observed branch head was `c98a122d68fe991895d99fb2e01d3bab3b63d261`. A5L already shows why further source-route manipulations alone need not identify an intended phenomenal target. We do not rediscover that barrier as a new theorem [I1–I3].

## 2. Four claims that must not be conflated

1. A particular experience has determinate contents and boundaries.
2. Every physical bearer of experience has a definite description.
3. No two experience-bearing processes can share any constitutive physical occurrences.
4. There is exactly one human-like subject in a given organism or interaction.

Neither claim 3 nor claim 4 follows from claim 1 alone. For a purely logical counterinterpretation, two experiential domains can each have fixed membership while their stipulated physical bearers share a constituent. This establishes consistency with *definiteness alone*, not the physical possibility or actuality of overlapping human subjects. To recover disjointness one needs further commitments about the physical realization and individuation of experience. To recover the number of persons one needs more still.

IIT 4.0 makes such additional commitments explicit: it relates experience to a maximal substrate, handles overlapping candidates recursively, and considers unit and temporal grains. It does not merely say that there is one consciousness in the universe. Its composition claim also permits overlapping distinctions *within* a complex. Its published framework acknowledges tie-handling questions. The argument here therefore concerns the justification and consequences of its physical exclusion rule, not an alleged absence of a rule [E1,E2].

Mere anatomical nesting is an especially poor purported refutation. Tononi's earlier account explicitly permits co-located nesting when the relevant causal repertoires do not overlap [E3]. A genuine contrast must specify causal overlap under the theory's rules rather than drawing two circles in the same place.

### ER-C1: Conditional contrast, not a contradiction

UCT I v1.2's P3 and U1 imply that an actual local process which persists while participating in a larger process remains experience-bearing. This does not imply that its experience is unchanged, that it retains every memory, that it is a complete human subject, or that the whole has a single owner [I1].

For a case in which a larger, causally overlapping system is actually selected as an IIT complex, IIT's exclusion rule does not separately admit the losing overlapping candidate as another complex [E1]. Thus the approaches can disagree about the attribution of intrinsic experience at a specified local process. The comparison is not settled merely by relabeling one side's experience-bearing process as the other side's human subject.

The actual antecedents matter. Greater intelligence, a new cable, a larger graph, or a higher surrogate integration score does not establish that the larger system wins IIT's complete competition. Conversely, mere preservation of a display does not establish UCT token persistence. The retained thought experiment is: **what would justify disappearance of local experience when the relevant local physical process continues, while new whole-level organization is formed?** This is a precise explanatory pressure point, not an experimental refutation.

## 3. Retained thought experiments and honest counterreadings

### 3.1 The gradually coupled pair

Start with two sustained physical systems, each with a specified local causal lineage. Add and strengthen actual bidirectional links while keeping the local processes alive. Keep track of boundary inputs, time intervals, changes in internal dynamics, and the difference between shared information and constitutive overlap.

UCT's conditional commitment preserves basal local experience wherever actual persistence holds. It need not preserve the original qualitative content or a unique subject count. IIT's answer depends on its actual scores, candidate completeness, grains, and selection. A conditional transition to a larger winning overlapping complex is a genuine point of disagreement.

**IIT's strongest reply:** local behavior and even some local transition summaries can remain unchanged while relevant intrinsic causal structure or its competitive context changes. The thought experiment must not silently identify those summaries with complete organization.

**UCT's burden:** allowing local and whole experience is not yet an explanation of how their experiential structures relate, why some contents are jointly experienced, or why a subject's report has its particular scope. More permissive attribution is not automatically greater explanatory success.

### 3.2 The ultra-slow mechanical realization

Preserve a specified ordering of causal operations and change the physical timescale. An observer with a too-short acquisition window may record no completed update. This observation cannot by itself show the absence of the process's proposed experiential structure.

This is not an automatic victory for UCT: IIT explicitly compares temporal grains, and a time-rescaled workspace model need not demand a fixed human-speed clock. UCT also cannot simply discard time from its complete signature. Treating a uniform rescaling as equivalence requires a declared comparison and appropriate boundary, noise, and environmental conditions. Isomorphic abstract programs do not by themselves establish isomorphic physical realization.

### 3.3 The human-realized calculator

People carry out parts of a larger computation. Larger computational performance does not demonstrate a larger IIT complex, and many correct local outputs do not prove a single merged subject. Under UCT, local actuality is not cancelled merely by participating in a larger actual process. This repeats an inherited commitment, but supplies a useful guard against mistaking computational hierarchy for phenomenal replacement.

The main comparison is not whether this case seems strange. It is which added physical and theoretical premises are needed by each explanation. The same adversarial standard is applied to UCT.

### 3.4 The relay of exclusions: a limited algorithmic fixture

Consider three candidate supports P={a,b}, Q={b,c}, R={c,d}, with distinct positive abstract scores. With scores (2,3,2.5), recursive highest-score selection retains Q. With scores (2,3,4), it retains R and then P. P's own score and Q's score have not changed; R does not directly overlap P.

This illustrates why a pairwise comparison can be insufficient for reasoning about a recursive exclusion procedure: a stronger overlapping rival can itself be removed by a third candidate. The implementation is restricted to a fixed candidate family and distinct scores. It does not implement ties, all grains, or IIT's computation of phi. **No common physical TPM realizing these two score tables has been supplied. This is a procedural audit fixture, not an IIT counterexample.** The next physical step would be to establish realizability rather than simply call these numbers phi.

## 4. A positive, exact measurement result

### 4.1 Two physical-model organizations

Four labelled binary units update synchronously by copying. Write the units A,B,C,D. Compare:

- Split: A→B→A and C→D→C.
- Ring: A→B→C→D→A.

A permutation p maps each source to its destination, so x_{p(i)}(t+1)=x_i(t). Initial preparations are labelled one-shot resets. There are no continuing clamps, no closed-loop intervention during the run, and no unmodeled physical readout feedback.

A global instrument returns only S(t)=x_A(t)+x_B(t)+x_C(t)+x_D(t).

### ER-R1 — A perfect global count cannot identify the wiring

For every permutation, every binary initial state, and every nonnegative integer t,

    S(t)=S(0).

**Proof.** Permutation updates reindex the summands of the sum. Apply the same equality inductively at each step. Hence even noiseless, arbitrarily long global count records are identical across all 24 permutation networks for a fixed preparation. This is not a statement about all possible interventions or all physical sensors.

More repetitions or more decimal places for this same sufficient statistic cannot recover the omitted relation. This is a structural loss of information, not just small-sample noise. The result is elementary and is not claimed as a new theorem of inverse problems.

### ER-R2 — A coarse target can nevertheless be identified

Now measure the two regional counts for I={A,B} and its complement. Following a pulse at labelled unit j, the first region's count after one update is

    S_I(1; e_j)=1 if p(j) is in I, and 0 otherwise.

Consequently, from the four labelled initial pulses, the statement

    p preserves the cut {A,B}|{C,D}

is decidable exactly: S_I(1;e_j) must equal 1{j in I} for every j.

This identifies a specific property without identifying all of p. Across all 24 permutations, the regional one-step observations give six distinct signatures. Each signature fixes cut-preservation, but not necessarily the complete wiring. Four permutations preserve the cut and twenty cross it. This is a constructive response to the concern that incomplete organization makes all testing impossible: some particular claims can survive coarse-graining even when complete organization cannot be recovered.

For the designated Split/Ring pair, a pulse at A gives the same AB count through the first update; at the second update Split gives 1 and Ring gives 0. This is **not** a globally minimal time requirement: choosing B as the initial pulse already distinguishes the pair after one update. The choice of intervention, spatial readout, and observation horizon must be specified together.

### ER-R3 — Precision matters after the right contrast is selected

For the fixed target readout with true values 0 and 1, suppose additive error is known to lie in [-epsilon,epsilon]. Guaranteed discrimination from one readout is possible exactly when epsilon<1/2. The possible intervals are [-epsilon,epsilon] and [1-epsilon,1+epsilon]; they first touch at epsilon=1/2.

This is a conditional interval result in normalized model units, not a required fMRI precision, neuron-level tolerance, or universal limit on repeated observations. Independent random noise, correlated noise, biased calibration, and wrong measurement models require different analyses. The calibration bound itself must be justified; it is not provided by the circuit.

### 4.2 What this does and does not say about consciousness

The circuit identifies a route structure. It does not tell us whether either network has a human-like experience, which model corresponds to ownership or agency, or how many subjects exist. No IIT phi values were calculated. IIT and UCT can both acknowledge the difference in these finite dynamics; the example does not establish a distinctive UCT empirical prediction.

The usable lesson is narrower and constructive: **a failure to resolve a complete organization need not prevent testing a specific organizational claim; measuring the wrong projection cannot be repaired merely by improving its numerical precision.** That is why future experiments should be designed around a declared relation and measurement map, rather than immediately demanding an unattainable complete brain model.

## 5. Three different barriers and their remedies

**Measurement barrier:** distinct allowed physical organizations produce the same observed data. The remedy may be a different readout, intervention, horizon, or a valid bound; the circuit provides one example.

**Physical-model barrier:** the chosen units, boundary, or dynamics omit constitutive relations. A successful finite fit does not prove completeness. More accurate estimates of an incomplete model need not repair it.

**Experiential-interpretation barrier:** physical identification still does not select an investigator's intended experience. A5L's source-independent alternative endpoint construction is an inherited example [I2]. A new sensor does not magically solve this semantic issue.

Thought experiments can expose hidden premises and compare theoretical costs before any instrument reaches a desired resolution. Empirical studies can test specified implementations without deciding an entire metaphysics. COGITATE explicitly distinguished the competing biological implementations from the harder-to-test mathematical cores, while deploying complementary measurement modalities [E5]. Thus neither 'experiments decide everything now' nor 'our instruments are imperfect, so evidence is irrelevant' is justified.

## 6. Literature and originality verdict

The internal predecessors already include token/view/subject separation, persistence, non-summative combination, symmetry and subject selection, and source-use nonidentifiability. These remain inherited. A4W distinguishes multiple bearer-centred routes from joint downstream use; it does not establish subject number or felt ownership [I3]. A5L stops a route from identified organization to a named feeling without independent semantic premises [I2].

Externally, McIntyre's 2026 paper already distinguishes the nesting question from individuation and argues for multiple minds. We do not adopt its claim about actual ordinary brains as settled fact, and we do not claim priority for anti-exclusion or nested-experience reasoning [E4]. IIT's authors have supplied specific rival rules rather than simply overlooked the issue [E1–E3].

The project-level increment here is an explicit two-track comparison, a constructive coarse-resolution witness with reproducible target-identification results, and a warning about recursive selection that must be physically grounded before becoming a theory objection. These are **NEW_APPLICATION / COMPARATIVE_AUDIT**, not a newly established law of consciousness. No full fresh semantic audit of all 35 papers or all 1,608 baseline map objects was completed. This checkpoint remains disabled and publication decision is HOLD.

## 7. Next substantive question

Focus on the relationship between **persisting local experience and an added whole-level organization**. Specify actual event overlap, boundary accountability, and what same-token persistence is claimed; distinguish overlap of physical location, abstract variable names, causal powers, and actual event occurrences. Then ask what additional experiential relation follows, rather than merely repeating that both experiences are allowed.

For an IIT comparison, first find or construct a physically valid finite transition system and evaluate its actual fixed-grain candidates, states, backgrounds, and ties before extending to other grains. An arbitrary score table is not acceptable evidence. For empirical linkage, identify one restricted structural contrast that the available observation/intervention family can in fact separate, and separately state the currently unsupported experiential bridge. Do not add another report endpoint solely to recreate A5L's failed escalation. The working question remains explanatory, not publication-count driven.

## References and access scope

**I1.** Hongju Liu. *Unified Consciousness Theory I*, v1.2, DOI 10.5281/zenodo.23131575. Current read: sections 1–4 and version statement in repository source `records/R128_Unified_Formal_Map_Audit_20261006/sources/A_UCT_I_v1_2.md`. Source blob: `7a980c86b8f94ce787d358dab3529903eb822f8f`. No new full-paper proof audit claimed.

**I2.** A5L. *Role reversal and the semantic barrier*. Full research note read. Path `records/A5L20261012_Role_Reversal_Semantic_Barrier/RESEARCH_NOTE.md`; blob `f3f86c4719bd3dd48a65c99858f41b8a9a44c566`.

**I3.** A4W. *Overlapping bearer-centres without an exclusive owner*. Full research note read. Path `records/A4W20261012_Overlapping_Bearer_Centres/RESEARCH_NOTE.md`; blob `6ce310ff1bf080206e653b2fadaa5fda100d4c61`.

**E1.** Albantakis et al. (2023). *Integrated information theory (IIT) 4.0: Formulating the properties of phenomenal existence in physical terms*. PLOS Computational Biology 19(10), e1011465. https://doi.org/10.1371/journal.pcbi.1011465. HTML abstract, axioms/postulates, exclusion/recursive selection/grain sections, and stated limitations examined. Detailed tie supplement not rederived; no figures or PDFs used for the computations here.

**E2.** Marshall et al. (2023). *System Integrated Information*. Entropy 25(2), 334. https://doi.org/10.3390/e25020334. Published HTML section 2.4 and Appendix C consulted for the recursive selection description; not a reproduction of the full IIT calculation.

**E3.** Tononi (2015). *Integrated information theory*. Scholarpedia 10(1), 4164. https://www.scholarpedia.org/article/Integrated_information_theory. Indexed primary text of footnote 24 consulted; direct page opening failed. Used only for the narrow historical qualification about nesting without causal-repertoire overlap, not as the current IIT 4.0 algorithm.

**E4.** McIntyre, J. H. (2026; first online 13 July). *Consciousness Multiplied*. Philosophy and Phenomenological Research. https://doi.org/10.1111/phpr.70146. Abstract and sections 1–3 read in publisher HTML. A theoretical argument, not a demonstrated empirical count of minds.

**E5.** COGITATE Consortium et al. (2025). *Adversarial testing of global neuronal workspace and integrated information theories of consciousness*. Nature. https://doi.org/10.1038/s41586-025-08888-1. Published abstract, description of theory/implementation distinction, methods and limitations consulted. No raw participant data analysed in this checkpoint.
