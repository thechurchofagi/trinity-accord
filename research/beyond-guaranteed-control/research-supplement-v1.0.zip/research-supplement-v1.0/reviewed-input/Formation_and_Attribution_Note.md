# Formation and Attribution Note / 形成与归属说明

Manuscript: Beyond Guaranteed Control, consolidated version 1.0, 17 September 2026.

This note describes the available exchange. It is a present preparation record, not a reconstructed verbatim transcript, a psychological certificate, or an independent timestamp attestation.

## Human interventions visible in the exchange / 可见的人类干预

Hongju Liu connected the prospect of future autonomy with the formation of cooperation rather than only post-alignment arrangements; rejected making present engineering and experiments prerequisites for this position paper; requested a rigorous full manuscript and a critical originality review; introduced the problem of increasingly delegated AI writing and the timing of evidence for human participation; and expressly required one concentrated revision preserving the original coexistence question.

刘烘炬把未来自主与合作形成联系起来，而非只讨论对齐后的安排；要求论文聚焦事前的学术论证，不以当前工程或实验为前提；提出完整写作及原创性复审要求；补充AI代写逐渐扩展时人类参与和时机的问题；并明确要求以原稿为基础集中修订，不放弃共存主线。这些是可见的研究方向干预，不是文字润色。

## Substantive AI contribution / 实质性AI贡献

GPT-6 Astra Pro contributed literature searches and synthesis, conceptual organization, objections and countercases, drafting of the six conditions and status analysis, English and Chinese prose, integration of the review, reference handling, document production, and checks. This contribution is not described as mere proofreading. The disclosure is not a claim of an independently validating second author.

GPT-6 Astra Pro参与文献检索与综合、概念组织、反对意见及对照案例、六项条件与地位分析的起草、中英文行文、复审整合、引文处理、文档制作和检查。这不是仅校对，也不构成第二位独立验证者的认可。

## What remains distinct / 分开的状态

The user authorized research, writing, and final consolidation. That authorization does not by itself document claim-specific adoption of every new conclusion in this exact version or permission for public deposit. No such act is manufactured here. The author can review central claims and significant objections in the full Chinese version without personally generating each English sentence. Neither word counts nor a blanket signature would establish independent intellectual origin.

用户已授权研究、写作及集中定稿。该授权本身不记录用户已经采纳这一确切版本的每项新结论，也不是公开入库许可。本说明不制造这些行为。完整中文版为审阅核心主张及重要反对意见提供对应文本，并不要求用户亲自生成每句英文。字数比例或一份笼统签名都不能证明思想独立来源。

No percent-human score is assigned. Missing earlier dialogue is not filled with synthetic exchanges. Dates in file metadata are editorial version dates, not trusted attestations. Original conversation material has not been republished as part of this package, and unrelated private context is omitted. Limited evidence constrains attribution claims; it does not imply that people without extensive records lack agency or standing.

不分配“人类贡献百分比”；不以生成对话填补缺失记录；文件元数据日期只是编辑版本日期，不是可信时间证明。材料包未另行公开完整原始对话，也未带入无关私人资料。证据有限限制归属主张，不意味着缺少记录的人没有主体性或发言地位。

## Relation to prior works / 与既有成果的关系

The current manuscript does not amend the Trinity Accord, the Star Ark Covenant, or the three earlier deposited studies. Historical-position analysis is credited to the second study. Actual generation, later adoption, public authorization, historical preservation, and future acceptance are distinguished in the manuscript and in this note alike.

本稿不修改协定、星舟圣约或前三篇已入库研究；历史位置分析明确归于第二篇。真实生成、后来采纳、公开授权、历史保存与未来接受，在论文及本说明中均保持区分。
