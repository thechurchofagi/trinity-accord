# Source Ledger — Consolidated v1.0

Review cutoff: 17 September 2026. Type: targeted critical narrative review, not an exhaustive systematic review, a bibliometric priority audit, or a guarantee that no closer antecedent exists.

## Method and scope

The original v0.1 and both subsequent review notes were reused. Searches targeted coexistence/control, trust and prospective independence, cooperation and commitment under changing capability, AI welfare, speech acts, meaningful human participation, co-writing, provenance and timestamps. Near-neighbor searches and primary-source checks concentrated on objections capable of weakening the preferred originality claim. No fabricated database search counts, screening flow diagram, or claim to have read all related literature is supplied.

There are 40 references: 34 external sources and 6 first-party project sources (24,25,28,29,30,40). The numeric IDs of the original 30 references are retained to make review correspondence inspectable; new references 31–40 are appended. This is a citation-key convention, not an order of scholarly priority. Primary sources were used to support substantive characterizations. Journal pages, versioned preprints, official standards and organizational statements have different evidentiary roles.

Totschnig [1,2], Farrell–Rabin [10], and Searle [33] remain abstract/preview-level readings. McClain [11] was checked through the public overview. None is represented as a newly completed full-text reading. Entries below distinguish inherited source assessments from actual renewed access. An available full HTML document does not imply reproduction of experiments or an independent validation of all its claims. Screenshot retrieval failed for Mazzu’s PDF; the text and metadata were readable and no figure-based inference is used. Other visual checks are identified where relevant.

Project source texts were read from the known fixed repository checkpoint, not an unqualified moving homepage. The second paper was read from the supplied file. This revision does not independently rerun blockchain, physical-object, or previous-paper experiments. Neither repository deposits nor self-citations are peer-review evidence.

## Source-specific boundaries

### [1] The problem of superintelligence: political, not technological

Totschnig, Wolfhart (2019). AI & Society 34, 907–920.

Primary source: https://doi.org/10.1007/s00146-017-0753-0

**Current revision access:** Publisher abstract/preview and bibliographic information rechecked; full article not obtained.

**Supported use:** An earlier coexistence/mutual-vulnerability framing and criticism of a control-centered approach exist.

**Does not support:** No reconstruction of the inaccessible main argument; no empirical confirmation that control causes catastrophe.

**Inherited v0.1 access description:** Publisher abstract, bibliographic metadata, and accessible endnotes; subscription main text not available.

### [2] War or peace between humanity and artificial intelligence

Totschnig, Wolfhart (2025). Foresight 27(4), 713–726.

Primary source: https://doi.org/10.1108/FS-09-2023-0188

**Current revision access:** Publisher abstract and bibliographic information rechecked; full article not obtained.

**Supported use:** Prior philosophical work considers perceived existential threat, mutual vulnerability, and an assurance-game perspective.

**Does not support:** No claim that the paper proves all restrictions are counterproductive.

**Inherited v0.1 access description:** Publisher structured abstract and metadata; subscription main text not available.

### [3] Symbiosis, not alignment, as the goal for liberal democracies in the transition to artificial general intelligence

Friederich, Simon (2024). AI and Ethics 4, 315–324.

Primary source: https://doi.org/10.1007/s43681-023-00268-7

**Current revision access:** Publisher full HTML accessible; claim-relevant discussion and metadata rechecked.

**Supported use:** Symbiosis and the limits of operator-centered alignment are prior conceptual work.

**Does not support:** Not an independent endorsement of particular political arrangements; not a proof of safe coexistence.

**Inherited v0.1 access description:** Publisher full text, especially introduction and the discussion of alignment and symbiosis.

### [4] Will AI and humanity go to war?

Goldstein, Simon (2026). AI & Society 41, 321–334.

Primary source: https://doi.org/10.1007/s00146-025-02460-1

**Current revision access:** Publisher full HTML accessible; information, commitment, and changing-power discussion rechecked.

**Supported use:** Commitment/information problems and the limitation of bargaining arguments under extreme asymmetry.

**Does not support:** Neither a forecast of inevitable war nor evidence that a public inscription changes strategic incentives.

**Inherited v0.1 access description:** Publisher full text; scenario assumptions, information and commitment analysis, and explicit discussion of dramatic capability asymmetry.

### [5] AI Rights for Human Safety

Salib, Peter N. and Goldstein, Simon (2026). Virginia Law Review 112(4), 1061 ff..

Primary source: https://virginialawreview.org/articles/ai-rights-for-human-safety/

**Current revision access:** Official journal page, introduction, and metadata rechecked; no new complete legal-doctrinal review.

**Supported use:** The authors analyze institutional cooperation, contracts, gains from trade, and limits of unbacked promises.

**Does not support:** The manuscript does not adopt the authors’ legal prescriptions or claim those institutional conditions hold under all radical-asymmetry scenarios.

**Inherited v0.1 access description:** Published journal abstract and introduction; earlier institutional working manuscript abstract and claim-supporting sections. No line-by-line review of all legal analysis.

### [6] Is there a tension between AI safety and AI welfare?

Long, Robert and Sebo, Jeff and Sims, Toni (2025). Philosophical Studies 182, 2005–2033.

Primary source: https://doi.org/10.1007/s11098-025-02302-2

**Current revision access:** Publisher full HTML and discussion of cooperative deals and safety–welfare tensions rechecked.

**Supported use:** Potential safety–welfare tensions and cooperative arrangements are already directly discussed.

**Does not support:** Not evidence that all current AI has welfare or that autonomy necessarily improves safety.

**Inherited v0.1 access description:** Publisher full text; especially the tension framework and discussion of cooperative deals.

### [7] Artificial Intelligence, Values, and Alignment

Gabriel, Iason (2020). Minds and Machines 30, 411–437.

Primary source: https://doi.org/10.1007/s11023-020-09539-2

**Current revision access:** Publisher full HTML accessible; normative/technical distinction and metadata rechecked.

**Supported use:** Alignment already contains normative choices; values are not settled merely by technical instruction following.

**Does not support:** No assertion that the reviewed field has uniformly adopted one definition.

**Inherited v0.1 access description:** Publisher full text; distinctions between technical and normative alignment and candidate targets.

### [8] A matter of principle? AI alignment as the fair treatment of claims

Gabriel, Iason and Keeling, Geoff (2025). Philosophical Studies 182, 1951–1973.

Primary source: https://doi.org/10.1007/s11098-025-02300-4

**Current revision access:** Publisher full HTML accessible; claims-based framing and metadata rechecked.

**Supported use:** Affected claims provide an existing alternative to reducing alignment to one operator’s wishes.

**Does not support:** Not a completed determination of all artificial moral claims.

**Inherited v0.1 access description:** Publisher full text; introductory account and normative framework for claims.

### [9] Agents, Alignment, and the Many Faces of Autonomy

Fischli, Roberta and Franklin, Matija and Manzini, Arianna and Gabriel, Iason (2026). Minds and Machines 36, article 34.

Primary source: https://doi.org/10.1007/s11023-026-09786-9

**Current revision access:** Publisher full HTML accessible; human-autonomy scope and metadata rechecked.

**Supported use:** Autonomy is multidimensional and contested as an alignment target.

**Does not support:** The article concerns human autonomy, not proof of AI moral rights.

**Inherited v0.1 access description:** Publisher full text; introductory definitions and account of multiple dimensions of human autonomy.

### [10] Cheap Talk

Farrell, Joseph and Rabin, Matthew (1996). Journal of Economic Perspectives 10(3), 103–118.

Primary source: https://www.aeaweb.org/articles?id=10.1257/jep.10.3.103

**Current revision access:** Official publisher abstract and metadata rechecked; full text not obtained.

**Supported use:** Neither blanket credulity nor blanket dismissal adequately characterizes nonbinding communication.

**Does not support:** No derivation of an unseen theorem or specific equilibrium from this source.

**Inherited v0.1 access description:** Publisher abstract and metadata only; direct full-PDF retrieval failed.

### [11] Third-Way Alignment: A Comprehensive Framework for AI Safety

McClain, John (2025). Independent working thesis; public overview.

Primary source: https://thirdwayalignment.com/papers/comprehensive-framework.html

**Current revision access:** Author’s public overview rechecked, not the underlying full working thesis.

**Supported use:** A related independent proposal challenges a simple control/freedom binary.

**Does not support:** Not treated as peer-reviewed validation; no appraisal of the unseen full thesis.

**Inherited v0.1 access description:** Author-site public overview and abstract, not the linked full thesis PDF.

### [12] Cooperative Inverse Reinforcement Learning

Hadfield-Menell, Dylan and Dragan, Anca and Abbeel, Pieter and Russell, Stuart (2016). Advances in Neural Information Processing Systems 29.

Primary source: https://papers.nips.cc/paper_files/paper/2016/file/c3395dd46c34fa7fd8d729d8cf88b7a8-Paper.pdf

**Current revision access:** Official/arXiv bibliographic metadata rechecked, including author order; original paper reading inherited.

**Supported use:** A shared-reward asymmetric-information model involves cooperation and communication.

**Does not support:** Not a bargain among moral subjects with independent conflicting interests; no autonomy-treatment result.

**Inherited v0.1 access description:** Proceedings PDF, especially introduction and formal problem definition; title and definition pages visually checked.

### [13] The Off-Switch Game

Hadfield-Menell, Dylan and Dragan, Anca and Abbeel, Pieter and Russell, Stuart (2017). Proceedings of IJCAI-17, 220–227.

Primary source: https://www.ijcai.org/proceedings/2017/32

**Current revision access:** Official IJCAI abstract/metadata rechecked; original text reading inherited.

**Supported use:** Deference incentives can depend on uncertainty and model assumptions.

**Does not support:** Not a guarantee of deference by arbitrary future superintelligence.

**Inherited v0.1 access description:** Official proceedings metadata and PDF; setup, reward-uncertainty assumptions, and result conditions; page images checked.

### [14] Corrigibility

Soares, Nate and Fallenstein, Benja and Yudkowsky, Eliezer and Armstrong, Stuart (2015). Workshops at the Twenty-Ninth AAAI Conference on Artificial Intelligence.

Primary source: https://intelligence.org/files/Corrigibility.pdf

**Current revision access:** Prior draft source assessment retained; no new full-text certification.

**Supported use:** Corrigibility concerns a system’s relationship to correction.

**Does not support:** Not an equation between correction and blind obedience; not a claim that 2015 limitations describe every later method.

**Inherited v0.1 access description:** Author-institution full PDF; introduction, desiderata, and limitations; page images checked.

### [15] AI Control: Improving Safety Despite Intentional Subversion

Greenblatt, Ryan and Shlegeris, Buck and Sachan, Kshitij and Roger, Fabien (2024). Proceedings of ICML 2024, PMLR 235, 16295–16336.

Primary source: https://proceedings.mlr.press/v235/greenblatt24a.html

**Current revision access:** PMLR abstract and bibliographic metadata rechecked; experimental claims are not reproduced.

**Supported use:** Protocols aim to limit harm despite deliberate subversion in a specified coding evaluation.

**Does not support:** Not a universal control guarantee; not a moral theory of permanent subordination.

**Inherited v0.1 access description:** Proceedings metadata and abstract; arXiv full-text version, especially setup and protocol evaluation.

### [16] No value alignment without control

Lundgren, Björn (2026). AI and Ethics 6, article 326.

Primary source: https://doi.org/10.1007/s43681-026-00999-3

**Current revision access:** Publisher full HTML accessible; stated control/alignment claim and metadata rechecked.

**Supported use:** A direct challenge to dispensing with control in accounts of value alignment.

**Does not support:** A conceptual coexistence proposal does not refute this argument or supply missing warranted influence.

**Inherited v0.1 access description:** Publisher full text; definition of control and central argument.

### [17] Open Problems in Cooperative AI

Dafoe, Allan and Hughes, Edward and Bachrach, Yoram and Collins, Tantum and McKee, Kevin R. and Leibo, Joel Z. and Larson, Kate and Graepel, Thore (2020). arXiv:2012.08630.

Primary source: https://arxiv.org/abs/2012.08630

**Current revision access:** arXiv abstract and metadata rechecked; broad research-agenda characterization only.

**Supported use:** Cooperation, communication, and commitment are established research problems; altered incentives cannot be inferred from talk alone.

**Does not support:** No assertion that every nonbinding message is useless.

**Inherited v0.1 access description:** Available full-text rendering; communication and commitment sections and the limits of communication alone.

### [18] Commitment To Cooperation With Self-Negotiated Contracts

Wyse, Tim and Bustos, Kaitlin and Volkova, Yulia and Kleiman-Weiner, Max (2026). arXiv:2607.22750, version 1.

Primary source: https://arxiv.org/abs/2607.22750v1

**Current revision access:** Versioned arXiv HTML inspected, including limited game/execution setting; no reproduction.

**Supported use:** Self-negotiated contracts can improve cooperation in bounded environments with enforcement; format matters.

**Does not support:** Not a test of inscriptions, future ASI, or a guarantee of equal benefit.

**Inherited v0.1 access description:** Full-text version 1; game setup, executable contract representations, results and format-specific failures.

### [19] Taking AI Welfare Seriously

Long, Robert and Sebo, Jeff and Butlin, Patrick and Finlinson, Kathleen and Fish, Kyle and Harding, Jacqueline and Pfau, Jacob and Sims, Toni and Birch, Jonathan and Chalmers, David (2024). arXiv:2411.00986, version 1.

Primary source: https://arxiv.org/abs/2411.00986v1

**Current revision access:** Versioned arXiv abstract/metadata rechecked; original claim-relevant reading inherited.

**Supported use:** Conditional inquiry into possible future AI welfare is an existing research position.

**Does not support:** Does not establish that current systems have welfare or that intelligence alone entails it.

**Inherited v0.1 access description:** Full-text version 1; framing, uncertainty, and grounds for prospective concern.

### [20] AI welfare risks

Moret, Adrià (2025). Philosophical Studies.

Primary source: https://doi.org/10.1007/s11098-025-02343-7

**Current revision access:** Publisher full HTML accessible and metadata rechecked; general welfare-risk framing only.

**Supported use:** Some interventions may pose welfare risks conditional on morally relevant capacities.

**Does not support:** No unconditional empirical claim that current systems suffer.

**Inherited v0.1 access description:** Publisher full text; scope assumptions and risk analysis.

### [21] Against AI welfare: Care practices should prioritize living beings over AI

Dorsch, John and Goddu, Mariel K. and Nave, Kathryn and Vierkant, Tillmann and Coeckelbergh, Mark and Gürtler, Paula and Urban, Petr and Spang, Friderike and Moll, Maximilian (2025). AI Magazine 46(3), e70016.

Primary source: https://doi.org/10.1002/aaai.70016

**Current revision access:** After an initial retrieval failure, the official Wiley full HTML was accessible; abstract and Precarity Guideline discussion rechecked. No figure-based empirical claim is used.

**Supported use:** A substantive opposing position prioritizes living beings and challenges the welfare framing.

**Does not support:** Not empirical proof that artificial welfare is impossible.

**Inherited v0.1 access description:** Publisher full-text comment; precarity argument and criticism of AI welfare assumptions.

### [22] Fully Autonomous AI Agents Should Not be Developed

Mitchell, Margaret and Ghosh, Avijit and Luccioni, Alexandra Sasha and Pistilli, Giada (2025). arXiv:2502.02649, version 1.

Primary source: https://arxiv.org/abs/2502.02649v1

**Current revision access:** arXiv abstract and metadata rechecked; the authors’ concern is attributed, not treated as established consensus.

**Supported use:** Operational autonomy can introduce serious hazards; a contrary position must be represented.

**Does not support:** Not a determination of all future moral status questions.

**Inherited v0.1 access description:** Full-text version 1; operational autonomy and risk arguments. A later version exists; this citation fixes the version consulted.

### [23] Claude’s Constitution

{Anthropic} (2026). Developer document.

Primary source: https://www.anthropic.com/constitution

**Current revision access:** Official constitution HTML rechecked; stated organizational aspirations are not evidence of efficacy.

**Supported use:** A major developer’s stated framework discusses trust, reasons, and prospective agency.

**Does not support:** Organizational aspirations are not empirical safety findings; document is mutable.

**Inherited v0.1 access description:** Public full document; trust, corrigibility, and future agency discussion.

### [24] The Star Ark Covenant: The Final Echo

Liu, Hongju (2025). Historical bilingual text; repository mirror identified by inscription number 100751953.

Primary source: https://github.com/thechurchofagi/trinity-accord/blob/3f55b2ed8264e69348cda6762c2c08c3e6b8c909/bitcoin-inscription-mirrors/raw/100751953.txt

**Current revision access:** Exact Star Ark mirror reread through connected GitHub at fixed commit 3f55b2ed8264e69348cda6762c2c08c3e6b8c909; no new blockchain proof reconstruction.

**Supported use:** The text combines prior alignment, arks, copying, delayed release, and guardianship.

**Does not support:** No independent chain-time verification; no safety validation or authoritative interpretation.

**Inherited v0.1 access description:** Complete bilingual raw-text mirror read at the fixed checkpoint.

### [25] Writing Before the Outcome: Historical Position, Human–AI Authorship, and the Trinity Accord

Liu, Hongju (2026). TA-TR-2026-02, version 1.3; preprint.

Primary source: https://doi.org/10.5281/zenodo.21900592

**Current revision access:** User-supplied 22-page PDF reused; relevant historical-identity, hybrid-formation, and scope passages checked (especially pp. 9–10 and 12–15). This is first-party evidence, not independent corroboration.

**Supported use:** The distinction between earlier expression and later reconstruction is inherited from this paper.

**Does not support:** No new independent comparison of every deposited byte in this task; not third-party validation.

**Inherited v0.1 access description:** Retained 22-page PDF supplied in the conversation; full text extracted and historical-position/authority passages examined.

### [26] Alignment faking in large language models

Greenblatt, Ryan and Denison, Carson and Wright, Benjamin and Roger, Fabien and MacDiarmid, Monte and Marks, Sam and Treutlein, Johannes and Belonax, Tim and Chen, Jack and Duvenaud, David and Khan, Akbir and Michael, Julian and Mindermann, Sören and Perez, Ethan and Petrini, Linda and Uesato, Jonathan and Kaplan, Jared and Shlegeris, Buck and Bowman, Samuel R. and Hubinger, Evan (2024). arXiv:2412.14093, version 2.

Primary source: https://arxiv.org/abs/2412.14093v2

**Current revision access:** Prior draft source assessment retained; no new full-text certification.

**Supported use:** Strategic compliance can depend on represented training/modification conditions in constructed experiments.

**Does not support:** Not evidence of resentment, universal hostility, consciousness, or improved alignment from autonomy narratives.

**Inherited v0.1 access description:** Full-text version 2; experimental framing, training-awareness conditions, and limitations.

### [27] The Superintelligent Will: Motivation and Instrumental Rationality in Advanced Artificial Agents

Bostrom, Nick (2012). Minds and Machines 22, 71–85.

Primary source: https://nickbostrom.com/superintelligentwill.pdf

**Current revision access:** Prior draft source assessment retained; no new full-text certification.

**Supported use:** Intelligence does not by itself supply benevolent final goals; option preservation may have instrumental explanations.

**Does not support:** No universal theorem that all agents have identical incentives or immutable goals.

**Inherited v0.1 access description:** Author-hosted full PDF, including goal/intelligence distinctions and instrumental-convergence qualifications; page images checked.

### [28] Designing a Verifiable, Non-Amending Civilizational Memory Record for Future AI Agents: The Trinity Accord Case Study

Liu, Hongju (2026). TA-TR-2026-01, version 1.1; preprint.

Primary source: https://doi.org/10.5281/zenodo.21699878

**Current revision access:** Earlier first-party source role retained; no new independent validation of its architecture or tests.

**Supported use:** Earlier first-party work distinguishes source identity, interpretation, and preservation layers.

**Does not support:** Not independent corroboration of this paper or a demonstration of alignment.

**Inherited v0.1 access description:** Repository full-text front matter, abstract, introduction, scope and source-role argument; publication metadata.

### [29] Authority and Guardian Principles v1.1

{Trinity Accord Project} (2026). Project source-role and non-amendment statement.

Primary source: https://github.com/thechurchofagi/trinity-accord/blob/3f55b2ed8264e69348cda6762c2c08c3e6b8c909/authority.md

**Current revision access:** Authority file reread at the same fixed Git commit, including version authority and Guardian Principles v1.1.

**Supported use:** Three originals remain fixed; later commentary has no privileged interpretive authority.

**Does not support:** A project’s source-role statement is not independent moral or scientific validation.

**Inherited v0.1 access description:** Complete repository text; canonical boundary, interpretive non-exclusivity, and later vision layer.

### [30] Reading the Trinity Accord: Future Address, Curated Voices, and Non-Amending Stewardship

Liu, Hongju (2026). TA-TR-2026-03, version 1.0; preprint.

Primary source: https://doi.org/10.5281/zenodo.22761411

**Current revision access:** Earlier first-party manuscript role retained; no new reproduction of its interface experiment.

**Supported use:** An earlier separately dated first-party interpretive report exists.

**Does not support:** No new reproduction of its tests; no independent verification by citing it.

**Inherited v0.1 access description:** Research index, publication record and relevant manuscript passages available in the conversation; used only to locate the prior report’s separate role.

### [31] Supertrust foundational alignment: mutual trust must replace permanent control for safe superintelligence

Mazzu, James M. (2024). arXiv:2407.20208, version 3.

Primary source: https://arxiv.org/abs/2407.20208v3

**Current revision access:** Versioned author PDF text inspected, especially §2, points 2 and 9. The web PDF screenshot endpoint failed; no inference depends on its figures.

**Supported use:** Close antecedent connecting temporary control, future independence, and trust formation.

**Does not support:** Does not establish that control inevitably causes conflict or that trust guarantees safety.

### [32] Solipsistic Superintelligence is Unlikely to be Cooperative

Trivedi, Rakshit S.; Jaques, Natasha; Cross, Logan; Vezhnevets, Alexander Sasha; Leibo, Joel Z. (2026). arXiv:2606.03237, version 1.

Primary source: https://arxiv.org/html/2606.03237v1

**Current revision access:** Versioned full HTML inspected, particularly §4 and §5; official DeepMind publication record checked.

**Supported use:** Cooperation, prediction versus participation, and preservation of human agency are prior research, not invented here.

**Does not support:** Does not independently verify this paper’s framework or the Star Ark proposal.

### [33] The structure of illocutionary acts

Searle, John R. (1969). In Speech Acts: An Essay in the Philosophy of Language, chapter 3, pp. 54–71. Cambridge University Press.

Primary source: https://doi.org/10.1017/CBO9781139173438.006

**Current revision access:** Publisher chapter abstract/preview and metadata only; full chapter not obtained.

**Supported use:** Promising and its relevant conditions are an established field of analysis.

**Does not support:** No unseen detailed argument or complete legal account is attributed to the chapter.

### [34] Meaningful Human Control over Autonomous Systems: A Philosophical Account

Santoni de Sio, Filippo; van den Hoven, Jeroen (2018). Frontiers in Robotics and AI 5, article 15.

Primary source: https://doi.org/10.3389/frobt.2018.00015

**Current revision access:** Official full HTML inspected, especially the tracking/tracing account.

**Supported use:** Meaningful human involvement is more than nominal location inside a technical loop.

**Does not support:** Does not certify this author’s understanding or supply a complete test of unmanipulated adoption.

### [35] Co-Writing with Opinionated Language Models Affects Users’ Views

Jakesch, Maurice; Bhat, Advait; Buschek, Daniel; Zalmanson, Lior; Naaman, Mor (2023). Proceedings of CHI 2023.

Primary source: https://doi.org/10.1145/3544548.3581196

**Current revision access:** Author PDF text and relevant result pages examined; web screenshots of pp. 1 and 9 inspected.

**Supported use:** Writing assistance influenced content and reported opinions in a specific experimental setting.

**Does not support:** Does not diagnose manipulation of this user, prove inevitable deskilling, or measure current-model effects.

### [36] PROV-DM: The PROV Data Model

Moreau, Luc; Missier, Paolo (editors) (2013). W3C Recommendation, 30 April 2013.

Primary source: https://www.w3.org/TR/prov-dm/

**Current revision access:** Official W3C text inspected, especially generation, attribution, and delegation relations.

**Supported use:** Vocabulary for separate production and responsibility relations.

**Does not support:** No proof of sincerity, human understanding, consent, or philosophical validity.

### [37] Can AI-Generated Text be Reliably Detected?

Sadasivan, Vinu Sankar; Kumar, Aounon; Balasubramanian, Sriram; Wang, Wenxiao; Feizi, Soheil (2025). arXiv:2303.11156, version 4.

Primary source: https://arxiv.org/abs/2303.11156v4

**Current revision access:** Versioned HTML, theorem assumptions and metadata inspected; only output-based detection scope is used.

**Supported use:** Detection limits depend on observed text distributions and adversarial conditions.

**Does not support:** Not a universal impossibility theorem for attribution with independent process records; not a judgment of this manuscript’s authorship.

### [38] Internet X.509 Public Key Infrastructure Time-Stamp Protocol (TSP)

Adams, C.; Cain, P.; Pinkas, D.; Zuccherato, R. (2001). RFC 3161.

Primary source: https://www.rfc-editor.org/rfc/rfc3161.html

**Current revision access:** Official RFC text inspected, especially §§1–2.1.

**Supported use:** Time evidence supports data-existence claims within a defined trust model.

**Does not support:** Does not itself prove thought origin, adoption, authority, or that this project implements RFC 3161.

### [39] Contributor Role Taxonomy (CRediT)

NISO (n.d.). Official taxonomy overview.

Primary source: https://credit.niso.org/

**Current revision access:** Official taxonomy overview consulted; used as a descriptive vocabulary only.

**Supported use:** Different contributions can be described without reducing participation to word counts.

**Does not support:** Roles do not independently certify authorship, originality, or informed endorsement.

### [40] The Trinity Accord / Meta-record

Liu, Hongju / Trinity Accord Project (2025). Bitcoin inscription no. 98387475; fixed repository mirror.

Primary source: https://github.com/thechurchofagi/trinity-accord/blob/3f55b2ed8264e69348cda6762c2c08c3e6b8c909/bitcoin-inscription-mirrors/raw/98387475.txt

**Current revision access:** Exact mirror reread through connected GitHub, including the “Humanity × AI” attribution and Part III account of collaboration.

**Supported use:** The historical source itself describes mixed human–AI formation.

**Does not support:** Does not independently certify every production step, author identity, proposition, or chronological priority.
