#!/usr/bin/env python3
"""Extra finite checks for the publication's explicitly nonuniform decision law."""
from fractions import Fraction as F
from itertools import permutations, product
from pathlib import Path
import json
from check_transport import inv

def run():
    count=0
    for n in (2,3):
        priors=[tuple(F(1,n) for _ in range(n)),tuple(F(i+1,n*(n+1)//2) for i in range(n)),tuple(F(int(i==0)) for i in range(n))]
        for p,q in product(permutations(range(n)),repeat=2):
            rs=(p,q)
            for f in product((0,1),repeat=n):
                for mu in priors:
                    for w in ((F(1,2),F(1,2)),(F(1,4),F(3,4))):
                        formula=sum(max(sum(w[j]*mu[inv(r)[y]]*int(f[inv(r)[y]]==a) for j,r in enumerate(rs)) for a in (0,1)) for y in range(n))
                        direct=max(sum(w[j]*mu[x]*int(d[r[x]]==f[x]) for j,r in enumerate(rs) for x in range(n)) for d in product((0,1),repeat=n))
                        assert formula==direct
                        count+=1
    out={'status':'PASS','nonuniform_bayes_cases':count,'scope':'Finite verification of Eq. (10); source zeros allowed in this probability formula, not substituted into full-domain zero-error claims.'}
    print(json.dumps(out,indent=2))
    return out
if __name__=='__main__':
    out=run()
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args()
    if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2)+'\n')
