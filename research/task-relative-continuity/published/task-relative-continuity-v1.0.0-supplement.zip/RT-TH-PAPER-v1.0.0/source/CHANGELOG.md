# RT-TH-PAPER-v1.0.0

First public-paper version following RT-TH-PAPER-v0.1.0. Adds self-contained inherited TH proofs; makes general Bayes calculation explicit; clarifies route distribution, tag access, generated versus executable group, current-map provenance and the modest synthesis claim; improves citations and mathematical typesetting. No basal-experience axiom is changed. The prior research and global-map version numbers are not overwritten.
