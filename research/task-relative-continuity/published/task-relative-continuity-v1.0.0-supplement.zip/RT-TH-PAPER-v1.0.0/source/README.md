# Task-Relative Continuity: reproduction material

Author: Hongju Liu. First public-paper version 1.0.0; theoretical preprint, not peer reviewed.

Run the standard-library checks from this folder:

```sh
python code/check_transport.py --output RT_rerun.json
python code/check_handoff.py --output TH_rerun.json
python code/check_publication.py --output Publication_rerun.json
```

Compare with results/. Tests describe finite mathematical models, not human or AI subjective experiments. Claims and limits are in the paper and map/PAPER_CLAIM_REVIEW.json. Historical RT map files retain their source identity and are not automatically the current authoritative UCT graph.

CC BY 4.0 applies to original text/code material to the extent rights are held; third-party references retain their rights. Hashes attest bytes, not truth.
