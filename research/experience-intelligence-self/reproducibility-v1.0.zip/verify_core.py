from itertools import product, permutations, combinations
from collections import defaultdict
import math,json
# Exhaustive decoder existence rather than only re-evaluating a fiber formula.
def decoder_exists(rep,target):
    labels=tuple(sorted(set(rep))); values=tuple(sorted(set(target)))
    for output in product(values,repeat=len(labels)):
        table=dict(zip(labels,output))
        if all(table[r]==t for r,t in zip(rep,target)):return True
    return False
t2_cases=0
for k in product(range(2),repeat=3):
    for r in product(range(2),repeat=3):
        for flip in range(2):
            e=tuple(v^flip for v in k)
            reflect=all(r[i]!=r[j] or k[i]==k[j] for i in range(3) for j in range(3))
            assert decoder_exists(r,e)==reflect==decoder_exists(r,k)
            t2_cases+=1
assert decoder_exists((0,1,2),(0,0,1))  # external labels can refine a type
assert not decoder_exists((0,0),(0,1))
assert decoder_exists((0,0),(1,1))  # a selected target can still be exact

# Evaluate body-state dynamics, then compare complete labeled sensor laws.
rows=0; pairing_cases=0; classes={}
for n in (2,3):
    perms=list(permutations(range(n))); vectors=list(product(range(2),repeat=n))
    law_groups=defaultdict(list)
    for sigma in perms:
        for tau in perms:
            inv={j:i for i,j in enumerate(tau)}
            relative=tuple(inv[sigma[i]] for i in range(n))
            law=[]; exact=[True]*n
            for m in vectors:
                x=[0]*n
                for i in range(n):x[sigma[i]]=m[i]
                for u in vectors:
                    xp=tuple(x[j]^u[inv[j]] for j in range(n))
                    observed=tuple(xp[sigma[i]] for i in range(n))
                    expected=tuple(m[i]^u[relative[i]] for i in range(n))
                    assert observed==expected
                    for i in range(n):exact[i]&=observed[i]==(m[i]^u[i])
                    law.append(observed);rows+=1
            assert exact==[sigma[i]==tau[i] for i in range(n)]
            law_groups[tuple(law)].append(relative);pairing_cases+=1
    assert len(law_groups)==math.factorial(n)
    assert all(len(v)==math.factorial(n) and len(set(v))==1 for v in law_groups.values())
    assert len({v[0] for v in law_groups.values()})==math.factorial(n)
    classes[str(n)]={'laws':len(law_groups),'pairs_per_law':math.factorial(n)}

# A conjunction cannot be certified by checking only all pairs.
assignments=list(product(range(2),repeat=3))
constraints=(lambda t:t[0]==t[1],lambda t:t[1]==t[2],lambda t:t[0]!=t[2])
assert all(any(all(constraints[i](t) for i in pair) for t in assignments) for pair in combinations(range(3),2))
assert not any(all(c(t) for c in constraints) for t in assignments)

print(json.dumps({"status":"PASS","compatibility_assignments":t2_cases,"rewiring_state_command_rows":rows,"connection_pairings":pairing_cases}))
