# SCU reproducibility supplement, release 1.0.1

Companion to Hongju Liu, *Matched Behavior and Source Use*. This is a theoretical and computational methods preprint, not externally peer reviewed. No new human or neural data are included. The original working manuscript remains SCU-PAPER-v1.0.0 at research commit 8bac31cc0b9fb4c70d87f688dabbadeb6166addb; the release changes status, version metadata, the DOI and pinned pointers, not the scientific claims.

Run `python3 reproduce_all.py` with Python 3.11 or later. The six deterministic jobs use the standard library, write to temporary directories and compare their complete output bytes against the frozen JSON files. Their finite scopes and counts are separate; they are not a human sample or a semantic proof of an adopted map.

The result is SCU-RESULT-v0.2.0. R204 and R205 are credited inherited inputs. Corrections to R194/R201/R202 are explicit historical overlays and do not provide premises for the paper's source theorems. Candidate-map overlays remain disabled. The completed map remains UCT-MAP-v1.1.2; open historical proof-depth, actual-installation and phenomenal-endpoint obligations remain open.

The source-reading receipt records which sections and primary sources were actually read. Historical internal reports retain the status true when written; the new release review and publication manifest determine release status. This archive is not a complete repository backup. It includes no copied third-party article PDFs or personal human data.

Copyright: Hongju Liu, newly authored research material and code, CC BY 4.0 to the extent rights are held. Cited third-party work retains its own rights. Substantial ChatGPT assistance was used under the author's direction in formalization, coding, research, review and writing. Internal agent review is not independent external peer review or a representation of final author line-by-line inspection.

Pinned full research context: https://github.com/thechurchofagi/trinity-accord/tree/8bac31cc0b9fb4c70d87f688dabbadeb6166addb/research/uct-agent-consciousness-workspace/records/SCU20261010_Source_Consumer_Protocols
